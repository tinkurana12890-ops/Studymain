package com.abhi.study;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomsheet.BottomSheetDialog;

/**
 * Main Activity displaying the "Study Only" Mode Selection screen in Full Mode.
 * - Calm dark-blue to navy gradient wallpaper covering the full screen
 * - Large white sans-serif heading "Study Only" at top
 * - Smaller muted "Select mode" subtitle beneath
 * - Two large stacked rounded rectangular buttons centered:
 *   * Simple (mint-to-cyan gradient, lightbulb icon)
 *   * Deep (indigo-to-violet gradient, book-and-gear icon)
 * - Frosted-glass neumorphic styling with soft inner glow, beveled edges, and drop shadows
 * - Simple Mode displays "Free Time"
 * - Deep Mode displays "SET TIME" with interactive selector:
 *   30 min, 45 min, 60 min, 90 min, 120 min, and Custom (dialog minutes picker)
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private View mainRoot;
    private View headerContainer;
    private View btnSimpleMode;
    private View btnDeepMode;
    private View dialogBlurOverlay;
    private View btnOpenSettings;
    private View viewSettingsDot;

    @Override
    protected void onResume() {
        super.onResume();
        updateSettingsBadgeStatus();
    }

    private void updateSettingsBadgeStatus() {
        if (viewSettingsDot != null) {
            boolean allReady = StudyPermissionHelper.areRequiredPermissionsGranted(this, false);
            int granted = StudyPermissionHelper.getGrantedCount(this);
            int total = StudyPermissionHelper.getTotalPermissionsCount();
            if (allReady && granted >= 7) {
                viewSettingsDot.setVisibility(View.GONE);
            } else {
                viewSettingsDot.setVisibility(View.VISIBLE);
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            makeEdgeToEdge();
            setContentView(R.layout.activity_main);

            initViews();
            setupTouchInteractions();
            animateEntrance();
        } catch (Throwable t) {
            Log.e(TAG, "Error initializing MainActivity", t);
        }
    }

    private void makeEdgeToEdge() {
        try {
            Window window = getWindow();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                window.setStatusBarColor(Color.TRANSPARENT);
                window.setNavigationBarColor(Color.TRANSPARENT);
            }
            int uiOptions = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            window.getDecorView().setSystemUiVisibility(uiOptions);
        } catch (Exception ignored) {
        }
    }

    private void initViews() {
        mainRoot = findViewById(R.id.mainRoot);
        headerContainer = findViewById(R.id.headerContainer);
        btnSimpleMode = findViewById(R.id.btnSimpleMode);
        btnDeepMode = findViewById(R.id.btnDeepMode);
        dialogBlurOverlay = findViewById(R.id.dialogBlurOverlay);
        btnOpenSettings = findViewById(R.id.btnOpenSettings);
        viewSettingsDot = findViewById(R.id.viewSettingsDot);

        if (btnOpenSettings != null) {
            btnOpenSettings.setOnClickListener(v -> {
                try { v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); } catch (Exception ignored) {}
                openPermissionManager("Simple", 0, "Free Time");
            });
        }
    }

    private void applyBackgroundBlur(boolean enable) {
        try {
            if (enable) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && mainRoot != null) {
                    mainRoot.setRenderEffect(RenderEffect.createBlurEffect(28f, 28f, Shader.TileMode.CLAMP));
                }
                if (dialogBlurOverlay != null) {
                    dialogBlurOverlay.setVisibility(View.VISIBLE);
                    dialogBlurOverlay.animate().alpha(1f).setDuration(260).start();
                }
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && mainRoot != null) {
                    mainRoot.setRenderEffect(null);
                }
                if (dialogBlurOverlay != null) {
                    dialogBlurOverlay.animate().alpha(0f).setDuration(220).withEndAction(() -> {
                        dialogBlurOverlay.setVisibility(View.GONE);
                    }).start();
                }
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        applyBackgroundBlur(false);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupTouchInteractions() {
        if (btnSimpleMode != null) {
            btnSimpleMode.setOnTouchListener((v, event) -> {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        try { v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); } catch (Exception ignored) {}
                        v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(120).start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(220)
                                .setInterpolator(new OvershootInterpolator(1.8f)).start();
                        break;
                }
                return false;
            });
            btnSimpleMode.setOnClickListener(v -> showModeSheet("Simple"));
        }

        if (btnDeepMode != null) {
            btnDeepMode.setOnTouchListener((v, event) -> {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        try { v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); } catch (Exception ignored) {}
                        v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(120).start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(220)
                                .setInterpolator(new OvershootInterpolator(1.8f)).start();
                        break;
                }
                return false;
            });
            btnDeepMode.setOnClickListener(v -> showModeSheet("Deep"));
        }

        if (btnOpenSettings != null) {
            btnOpenSettings.setOnTouchListener((v, event) -> {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        try { v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); } catch (Exception ignored) {}
                        v.animate().scaleX(0.90f).scaleY(0.90f).setDuration(100).start();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(180)
                                .setInterpolator(new OvershootInterpolator(2.0f)).start();
                        break;
                }
                return false;
            });
        }
    }

    private void animateEntrance() {
        try {
            if (headerContainer != null) {
                headerContainer.setAlpha(0f);
                headerContainer.setTranslationY(-dpToPx(24));
                headerContainer.animate()
                        .alpha(1f)
                        .translationY(0f)
                        .setDuration(700)
                        .setStartDelay(100)
                        .setInterpolator(new DecelerateInterpolator())
                        .start();
            }

            if (btnSimpleMode != null) {
                btnSimpleMode.setAlpha(0f);
                btnSimpleMode.setTranslationY(dpToPx(36));
                btnSimpleMode.setScaleX(0.92f);
                btnSimpleMode.setScaleY(0.92f);
                btnSimpleMode.animate()
                        .alpha(1f)
                        .translationY(0f)
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .setDuration(800)
                        .setStartDelay(200)
                        .setInterpolator(new OvershootInterpolator(1.2f))
                        .start();
            }

            if (btnDeepMode != null) {
                btnDeepMode.setAlpha(0f);
                btnDeepMode.setTranslationY(dpToPx(36));
                btnDeepMode.setScaleX(0.92f);
                btnDeepMode.setScaleY(0.92f);
                btnDeepMode.animate()
                        .alpha(1f)
                        .translationY(0f)
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .setDuration(800)
                        .setStartDelay(360)
                        .setInterpolator(new OvershootInterpolator(1.2f))
                        .start();
            }
        } catch (Exception ignored) {
        }
    }

    private void showModeSheet(String mode) {
        try {
            BottomSheetDialog dialog = new BottomSheetDialog(this);
            View sheetView = getLayoutInflater().inflate(R.layout.bottom_sheet_mode_detail, null);

            ImageView sheetIcon = sheetView.findViewById(R.id.sheetIcon);
            TextView sheetTitle = sheetView.findViewById(R.id.sheetTitle);
            TextView sheetSubtitle = sheetView.findViewById(R.id.sheetSubtitle);
            TextView sheetDescription = sheetView.findViewById(R.id.sheetDescription);
            TextView sheetStat1Label = sheetView.findViewById(R.id.sheetStat1Label);
            TextView sheetStat1Value = sheetView.findViewById(R.id.sheetStat1Value);
            TextView sheetStat2Label = sheetView.findViewById(R.id.sheetStat2Label);
            TextView sheetStat2Value = sheetView.findViewById(R.id.sheetStat2Value);
            LinearLayout layoutTimeSelector = sheetView.findViewById(R.id.layoutTimeSelector);
            AppCompatButton btnStart = sheetView.findViewById(R.id.btnStartSession);

            final int[] selectedMinutes = new int[]{60};

            if ("Simple".equalsIgnoreCase(mode)) {
                if (sheetIcon != null) sheetIcon.setImageResource(R.drawable.ic_lightbulb);
                if (sheetTitle != null) sheetTitle.setText(R.string.button_simple_title);
                if (sheetSubtitle != null) sheetSubtitle.setText("Free focus & agile recall");
                if (sheetDescription != null) sheetDescription.setText("Simple Mode provides an open, unrestricted study session. Study freely at your own natural pace without countdown pressure.");
                
                // Simple Mode: 20 minutes changed to "Free Time"
                if (sheetStat1Label != null) sheetStat1Label.setText("SESSION TIME");
                if (sheetStat1Value != null) {
                    sheetStat1Value.setText("Free Time");
                    sheetStat1Value.setTextColor(ContextCompat.getColor(this, R.color.cyan_end));
                }

                if (sheetStat2Label != null) sheetStat2Label.setText("FOCUS INTENSITY");
                if (sheetStat2Value != null) {
                    sheetStat2Value.setText("Light / Agile");
                    sheetStat2Value.setTextColor(ContextCompat.getColor(this, R.color.mint_start));
                }

                // Hide time selector in Simple mode
                if (layoutTimeSelector != null) layoutTimeSelector.setVisibility(View.GONE);
                if (btnStart != null) btnStart.setBackgroundResource(R.drawable.bg_button_simple);

                if (btnStart != null) {
                    btnStart.setOnClickListener(v -> {
                        try { v.performHapticFeedback(HapticFeedbackConstants.CONFIRM); } catch (Exception ignored) {}
                        dialog.dismiss();
                        if (!StudyPermissionHelper.areRequiredPermissionsGranted(MainActivity.this, false)) {
                            openPermissionManager("Simple", 0, "Free Time");
                        } else {
                            launchStudySession("Simple", 0, "Free Time");
                        }
                    });
                }
            } else {
                // Deep Mode: Recommended time changed to "SET TIME" with interactive selector
                if (sheetIcon != null) sheetIcon.setImageResource(R.drawable.ic_book_gear);
                if (sheetTitle != null) sheetTitle.setText(R.string.button_deep_title);
                if (sheetSubtitle != null) sheetSubtitle.setText("High-cognitive immersion & mastery");
                if (sheetDescription != null) sheetDescription.setText("Deep Mode activates distraction-free neural flow. Select your dedicated study duration below to lock into deep work.");

                // Deep Mode: "SET TIME"
                if (sheetStat1Label != null) sheetStat1Label.setText("SET TIME");
                if (sheetStat1Value != null) {
                    sheetStat1Value.setText("1 Hour");
                    sheetStat1Value.setTextColor(ContextCompat.getColor(this, R.color.violet_light));
                }

                if (sheetStat2Label != null) sheetStat2Label.setText("FOCUS INTENSITY");
                if (sheetStat2Value != null) {
                    sheetStat2Value.setText("Deep Mastery");
                    sheetStat2Value.setTextColor(ContextCompat.getColor(this, R.color.violet_end));
                }

                // Show duration selector in Deep mode
                if (layoutTimeSelector != null) layoutTimeSelector.setVisibility(View.VISIBLE);
                if (btnStart != null) btnStart.setBackgroundResource(R.drawable.bg_button_deep);

                // Setup duration chips: 30m, 45m, 60m, 90m, 120m, Custom
                TextView chip30 = sheetView.findViewById(R.id.chip30);
                TextView chip45 = sheetView.findViewById(R.id.chip45);
                TextView chip60 = sheetView.findViewById(R.id.chip60);
                TextView chip90 = sheetView.findViewById(R.id.chip90);
                TextView chip120 = sheetView.findViewById(R.id.chip120);
                TextView chipCustom = sheetView.findViewById(R.id.chipCustom);

                TextView[] allChips = new TextView[]{chip30, chip45, chip60, chip90, chip120, chipCustom};
                int[] presetValues = new int[]{30, 45, 60, 90, 120};

                // Setup preset chips (30, 45, 60, 90, 120)
                for (int i = 0; i < presetValues.length; i++) {
                    final int mins = presetValues[i];
                    final TextView currentChip = allChips[i];
                    if (currentChip != null) {
                        currentChip.setOnClickListener(v -> {
                            try { v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); } catch (Exception ignored) {}
                            selectedMinutes[0] = mins;

                            // Update styles
                            for (TextView chip : allChips) {
                                if (chip != null) {
                                    if (chip == currentChip) {
                                        chip.setBackgroundResource(R.drawable.bg_chip_selected);
                                        chip.setTextColor(ContextCompat.getColor(this, R.color.text_white_pure));
                                    } else {
                                        chip.setBackgroundResource(R.drawable.bg_chip_unselected);
                                        chip.setTextColor(ContextCompat.getColor(this, R.color.text_muted_sub));
                                    }
                                }
                            }

                            // Reset custom label if another preset is picked
                            if (chipCustom != null) {
                                chipCustom.setText("Custom");
                            }

                            // Update SET TIME text
                            if (sheetStat1Value != null) {
                                sheetStat1Value.setText(formatMinutes(mins));
                            }
                        });
                    }
                }

                // Setup Custom chip
                if (chipCustom != null) {
                    chipCustom.setOnClickListener(v -> {
                        try { v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); } catch (Exception ignored) {}
                        showCustomTimeDialog(selectedMinutes, sheetStat1Value, chipCustom, allChips);
                    });
                }

                if (btnStart != null) {
                    btnStart.setOnClickListener(v -> {
                        try { v.performHapticFeedback(HapticFeedbackConstants.CONFIRM); } catch (Exception ignored) {}
                        int mins = selectedMinutes[0];
                        String timeStr = formatMinutes(mins);
                        dialog.setOnDismissListener(null);
                        dialog.dismiss();
                        showDeepModeWarningDialog(mins, timeStr);
                    });
                }
            }

            if ("Deep".equalsIgnoreCase(mode)) {
                applyBackgroundBlur(true);
                dialog.setOnDismissListener(d -> applyBackgroundBlur(false));
            }

            dialog.setContentView(sheetView);
            try {
                if (dialog.getWindow() != null) {
                    View bottomSheet = dialog.getWindow().findViewById(com.google.android.material.R.id.design_bottom_sheet);
                    if (bottomSheet != null) {
                        bottomSheet.setBackgroundColor(Color.TRANSPARENT);
                    }
                }
            } catch (Exception ignored) {}
            dialog.show();
        } catch (Exception e) {
            Log.e(TAG, "Error displaying mode sheet", e);
            Toast.makeText(this, mode + " Mode selected", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Displays a high-fidelity Deep Mode Commitment Warning Dialog.
     * Features:
     * - Warning Header with animated pulsing shield alert icon.
     * - Clear commitment display with selected duration (e.g. 60 Minutes).
     * - Active 5-second countdown with zoom/fade scale animations & tick haptics.
     * - Cancel button: immediately terminates countdown and aborts session.
     * - Start Now button: bypasses countdown and launches immediately.
     * - Auto-launches Deep Mode session when 5-second countdown reaches 0.
     */
    private void showDeepModeWarningDialog(final int minutes, final String timeLabel) {
        try {
            applyBackgroundBlur(true);

            Dialog warningDialog = new Dialog(this);
            warningDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            warningDialog.setContentView(R.layout.dialog_deep_mode_warning);
            warningDialog.setCancelable(true);
            warningDialog.setCanceledOnTouchOutside(false);

            if (warningDialog.getWindow() != null) {
                Window window = warningDialog.getWindow();
                window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                lp.copyFrom(window.getAttributes());
                lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.90);
                lp.dimAmount = 0.55f;
                window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
                    lp.setBlurBehindRadius(35);
                }
                window.setAttributes(lp);
            }

            View warningIconContainer = warningDialog.findViewById(R.id.warningIconContainer);
            TextView tvWarningCommittedTime = warningDialog.findViewById(R.id.tvWarningCommittedTime);
            View countdownCircleContainer = warningDialog.findViewById(R.id.countdownCircleContainer);
            TextView tvCountdownNumber = warningDialog.findViewById(R.id.tvCountdownNumber);
            TextView tvCountdownStatus = warningDialog.findViewById(R.id.tvCountdownStatus);
            AppCompatButton btnCancelWarning = warningDialog.findViewById(R.id.btnCancelWarning);
            AppCompatButton btnStartNowWarning = warningDialog.findViewById(R.id.btnStartNowWarning);

            if (tvWarningCommittedTime != null) {
                tvWarningCommittedTime.setText("Committed Time: " + timeLabel);
            }

            // Pulsing warning icon animation
            if (warningIconContainer != null) {
                warningIconContainer.animate()
                        .scaleX(1.1f)
                        .scaleY(1.1f)
                        .setDuration(600)
                        .setInterpolator(new AccelerateDecelerateInterpolator())
                        .withEndAction(() -> {
                            warningIconContainer.animate()
                                    .scaleX(1.0f)
                                    .scaleY(1.0f)
                                    .setDuration(600)
                                    .setInterpolator(new AccelerateDecelerateInterpolator())
                                    .start();
                        })
                        .start();
            }

            final int[] secondsRemaining = new int[]{5};
            final boolean[] isCancelled = new boolean[]{false};
            final boolean[] isLaunched = new boolean[]{false};
            final Handler countdownHandler = new Handler(Looper.getMainLooper());

            final Runnable countdownRunnable = new Runnable() {
                @Override
                public void run() {
                    if (isCancelled[0] || isFinishing() || (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && isDestroyed())) {
                        return;
                    }

                    if (secondsRemaining[0] <= 1) {
                        // 5-Second Countdown complete: Auto-launch Deep Mode session!
                        if (!isLaunched[0]) {
                            isLaunched[0] = true;
                            try {
                                if (countdownCircleContainer != null) {
                                    countdownCircleContainer.performHapticFeedback(HapticFeedbackConstants.CONFIRM);
                                }
                            } catch (Exception ignored) {}

                            if (warningDialog.isShowing()) {
                                warningDialog.dismiss();
                            }
                            if (!StudyPermissionHelper.areRequiredPermissionsGranted(MainActivity.this, true)) {
                                openPermissionManager("Deep", minutes, timeLabel);
                            } else {
                                launchStudySession("Deep", minutes, timeLabel);
                            }
                        }
                        return;
                    }

                    secondsRemaining[0]--;

                    // Tick animations & Haptic Pulse
                    if (tvCountdownNumber != null) {
                        tvCountdownNumber.setText(String.valueOf(secondsRemaining[0]));
                        if (secondsRemaining[0] <= 2) {
                            tvCountdownNumber.setTextColor(Color.parseColor("#EF4444")); // Red alert near start
                        } else if (secondsRemaining[0] == 3) {
                            tvCountdownNumber.setTextColor(Color.parseColor("#F59E0B")); // Amber
                        } else {
                            tvCountdownNumber.setTextColor(Color.parseColor("#38BDF8")); // Cyan
                        }

                        tvCountdownNumber.setScaleX(1.45f);
                        tvCountdownNumber.setScaleY(1.45f);
                        tvCountdownNumber.setAlpha(0.35f);
                        tvCountdownNumber.animate()
                                .scaleX(1.0f)
                                .scaleY(1.0f)
                                .alpha(1.0f)
                                .setDuration(320)
                                .setInterpolator(new OvershootInterpolator(1.6f))
                                .start();
                    }

                    if (countdownCircleContainer != null) {
                        try {
                            countdownCircleContainer.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                        } catch (Exception ignored) {}

                        countdownCircleContainer.animate()
                                .scaleX(1.08f)
                                .scaleY(1.08f)
                                .setDuration(140)
                                .withEndAction(() -> {
                                    countdownCircleContainer.animate()
                                            .scaleX(1.0f)
                                            .scaleY(1.0f)
                                            .setDuration(140)
                                            .start();
                                })
                                .start();
                    }

                    if (tvCountdownStatus != null) {
                        tvCountdownStatus.setText("Session automatically begins in " + secondsRemaining[0] + "s...");
                    }

                    countdownHandler.postDelayed(this, 1000);
                }
            };

            // Cancel Button: cancels countdown immediately and dismisses
            if (btnCancelWarning != null) {
                btnCancelWarning.setOnClickListener(v -> {
                    try { v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); } catch (Exception ignored) {}
                    isCancelled[0] = true;
                    countdownHandler.removeCallbacks(countdownRunnable);
                    warningDialog.dismiss();
                    Toast.makeText(MainActivity.this, "Deep Mode session cancelled", Toast.LENGTH_SHORT).show();
                });
            }

            // Start Now Button: bypasses remaining countdown and launches immediately
            if (btnStartNowWarning != null) {
                btnStartNowWarning.setOnClickListener(v -> {
                    try { v.performHapticFeedback(HapticFeedbackConstants.CONFIRM); } catch (Exception ignored) {}
                    if (!isLaunched[0]) {
                        isLaunched[0] = true;
                        isCancelled[0] = true;
                        countdownHandler.removeCallbacks(countdownRunnable);
                        warningDialog.dismiss();
                        if (!StudyPermissionHelper.areRequiredPermissionsGranted(MainActivity.this, true)) {
                            openPermissionManager("Deep", minutes, timeLabel);
                        } else {
                            launchStudySession("Deep", minutes, timeLabel);
                        }
                    }
                });
            }

            warningDialog.setOnDismissListener(d -> {
                isCancelled[0] = true;
                countdownHandler.removeCallbacks(countdownRunnable);
                applyBackgroundBlur(false);
            });

            warningDialog.show();

            // Entrance scale bounce animation
            View dialogView = warningDialog.getWindow() != null ? warningDialog.getWindow().getDecorView() : null;
            if (dialogView != null) {
                dialogView.setScaleX(0.85f);
                dialogView.setScaleY(0.85f);
                dialogView.setAlpha(0f);
                dialogView.animate()
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .alpha(1.0f)
                        .setDuration(260)
                        .setInterpolator(new OvershootInterpolator(1.2f))
                        .start();
            }

            // Start countdown sequence
            countdownHandler.postDelayed(countdownRunnable, 1000);

        } catch (Exception e) {
            Log.e(TAG, "Error displaying Deep Mode warning dialog", e);
            // Graceful fallback to launch session if dialog fails
            launchStudySession("Deep", minutes, timeLabel);
        }
    }

    private void openPermissionManager(String mode, int minutes, String label) {
        try {
            Intent intent = new Intent(this, PermissionManagerActivity.class);
            intent.putExtra(PermissionManagerActivity.EXTRA_TARGET_MODE, mode);
            intent.putExtra(PermissionManagerActivity.EXTRA_TARGET_MINUTES, minutes);
            intent.putExtra(PermissionManagerActivity.EXTRA_TARGET_LABEL, label);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        } catch (Exception e) {
            Log.e(TAG, "Failed to launch PermissionManagerActivity", e);
            launchStudySession(mode, minutes, label);
        }
    }

    private void launchStudySession(String mode, int minutes, String label) {
        try {
            Intent intent = new Intent(this, StudySessionActivity.class);
            intent.putExtra(StudySessionActivity.EXTRA_MODE, mode);
            intent.putExtra(StudySessionActivity.EXTRA_MINUTES, minutes);
            intent.putExtra(StudySessionActivity.EXTRA_LABEL, label);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        } catch (Exception e) {
            Log.e(TAG, "Failed to launch StudySessionActivity", e);
            Toast.makeText(this, mode + " Mode started!", Toast.LENGTH_SHORT).show();
        }
    }

    private void showCustomTimeDialog(final int[] selectedMinutes, final TextView sheetStat1Value,
                                      final TextView chipCustom, final TextView[] allChips) {
        try {
            Dialog customDialog = new Dialog(this);
            customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            customDialog.setContentView(R.layout.dialog_custom_time);

            if (customDialog.getWindow() != null) {
                customDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                lp.copyFrom(customDialog.getWindow().getAttributes());
                lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.90);
                customDialog.getWindow().setAttributes(lp);
            }

            EditText etCustomMinutes = customDialog.findViewById(R.id.etCustomMinutes);
            TextView tvDurationPreview = customDialog.findViewById(R.id.tvDurationPreview);
            AppCompatButton btnMinus5 = customDialog.findViewById(R.id.btnMinus5);
            AppCompatButton btnPlus5 = customDialog.findViewById(R.id.btnPlus5);
            AppCompatButton btnCancel = customDialog.findViewById(R.id.btnCancelCustom);
            AppCompatButton btnApply = customDialog.findViewById(R.id.btnApplyCustom);

            int initialMins = selectedMinutes[0] > 0 ? selectedMinutes[0] : 75;
            if (etCustomMinutes != null) {
                etCustomMinutes.setText(String.valueOf(initialMins));
            }
            if (tvDurationPreview != null) {
                tvDurationPreview.setText("= " + formatMinutes(initialMins));
            }

            // Real-time preview update as user types
            if (etCustomMinutes != null && tvDurationPreview != null) {
                etCustomMinutes.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        try {
                            String input = s.toString().trim();
                            if (!input.isEmpty()) {
                                int val = Integer.parseInt(input);
                                tvDurationPreview.setText("= " + formatMinutes(val));
                            } else {
                                tvDurationPreview.setText("= 0 Minutes");
                            }
                        } catch (Exception e) {
                            tvDurationPreview.setText("= --");
                        }
                    }

                    @Override
                    public void afterTextChanged(Editable s) {}
                });
            }

            // Stepper -5 button
            if (btnMinus5 != null && etCustomMinutes != null) {
                btnMinus5.setOnClickListener(v -> {
                    try {
                        int cur = Integer.parseInt(etCustomMinutes.getText().toString().trim());
                        int newVal = Math.max(5, cur - 5);
                        etCustomMinutes.setText(String.valueOf(newVal));
                        etCustomMinutes.setSelection(etCustomMinutes.getText().length());
                    } catch (Exception ignored) {}
                });
            }

            // Stepper +5 button
            if (btnPlus5 != null && etCustomMinutes != null) {
                btnPlus5.setOnClickListener(v -> {
                    try {
                        int cur = Integer.parseInt(etCustomMinutes.getText().toString().trim());
                        int newVal = Math.min(480, cur + 5);
                        etCustomMinutes.setText(String.valueOf(newVal));
                        etCustomMinutes.setSelection(etCustomMinutes.getText().length());
                    } catch (Exception ignored) {}
                });
            }

            // Cancel button
            if (btnCancel != null) {
                btnCancel.setOnClickListener(v -> customDialog.dismiss());
            }

            // Apply button
            if (btnApply != null) {
                btnApply.setOnClickListener(v -> {
                    try {
                        String input = etCustomMinutes.getText().toString().trim();
                        if (input.isEmpty()) {
                            Toast.makeText(this, "Please enter minutes", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        int mins = Integer.parseInt(input);
                        if (mins <= 0 || mins > 480) {
                            Toast.makeText(this, "Please enter between 1 and 480 minutes", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        try { v.performHapticFeedback(HapticFeedbackConstants.CONFIRM); } catch (Exception ignored) {}

                        selectedMinutes[0] = mins;

                        // Highlight Custom chip and unhighlight others
                        for (TextView chip : allChips) {
                            if (chip != null) {
                                if (chip == chipCustom) {
                                    chip.setBackgroundResource(R.drawable.bg_chip_selected);
                                    chip.setTextColor(ContextCompat.getColor(this, R.color.text_white_pure));
                                } else {
                                    chip.setBackgroundResource(R.drawable.bg_chip_unselected);
                                    chip.setTextColor(ContextCompat.getColor(this, R.color.text_muted_sub));
                                }
                            }
                        }

                        // Update chip text to show custom duration
                        if (chipCustom != null) {
                            chipCustom.setText(mins + " min");
                        }

                        // Update SET TIME text
                        if (sheetStat1Value != null) {
                            sheetStat1Value.setText(formatMinutes(mins));
                        }

                        customDialog.dismiss();
                    } catch (Exception e) {
                        Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            customDialog.show();
        } catch (Exception e) {
            Log.e(TAG, "Error displaying custom time dialog", e);
        }
    }

    private String formatMinutes(int minutes) {
        if (minutes < 60) {
            return minutes + " Minutes";
        } else if (minutes % 60 == 0) {
            int hours = minutes / 60;
            return hours == 1 ? "1 Hour" : hours + " Hours";
        } else {
            int hours = minutes / 60;
            int remMin = minutes % 60;
            return hours + "h " + remMin + "m";
        }
    }

    private float dpToPx(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }
}
