package com.abhi.study;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class GeminiAiManager {

    private static final String TAG = "GeminiAiManager";
    private static final String PREF_NAME = "study_gemini_ai_prefs";
    private static final String KEY_GEMINI_API_KEY = "gemini_api_key";
    private static final String KEY_SELECTED_MODEL = "gemini_selected_model";

    // Strictly Google Gemini v1beta API base
    private static final String GEMINI_MODELS_URL =
            "https://generativelanguage.googleapis.com/v1beta/models";

    private static final String DEFAULT_MODEL = "gemini-2.5-flash";
    private static final String[] CANDIDATE_MODELS = {
            "gemini-2.5-flash",
            "gemini-2.0-flash",
            "gemini-2.5-pro",
            "gemini-2.0-flash-lite"
    };

    private static final MediaType JSON_MEDIA_TYPE =
            MediaType.parse("application/json; charset=utf-8");

    private static final OkHttpClient httpClient = new OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .build();

    private static final Handler mainHandler = new Handler(Looper.getMainLooper());

    private interface ModelCallHandler {
        void onSuccess(String responseBody, String workingModel);
        void onError(String lastErrorMessage);
    }

    public interface ApiTestCallback {
        void onSuccess(String modelName);
        void onError(String errorMessage);
    }

    public interface QuizCallback {
        void onQuizReady(List<StudyQuizManager.QuizQuestion> questions, boolean isAiGenerated);
        void onError(String errorMessage);
    }

    public interface DoubtCallback {
        void onAnswerReceived(String answer);
        void onError(String errorMessage);
    }

    private static SharedPreferences getPrefs(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static String getApiKey(Context context) {
        if (context == null) return "";
        String raw = getPrefs(context).getString(KEY_GEMINI_API_KEY, "");
        return raw != null ? raw.replaceAll("[\\s\"']", "") : "";
    }

    public static void setApiKey(Context context, String apiKey) {
        if (context != null) {
            String clean = apiKey != null ? apiKey.replaceAll("[\\s\"']", "") : "";
            getPrefs(context).edit().putString(KEY_GEMINI_API_KEY, clean).apply();
        }
    }

    public static boolean hasValidApiKey(Context context) {
        String key = getApiKey(context);
        return key != null && key.length() >= 20;
    }

    public static String getSelectedModel(Context context) {
        if (context == null) return DEFAULT_MODEL;
        String model = getPrefs(context).getString(KEY_SELECTED_MODEL, DEFAULT_MODEL);
        if (model == null || model.isEmpty() || model.contains("1.5") || model.contains("1.0") || "gemini-pro".equals(model)) {
            model = DEFAULT_MODEL;
            saveSelectedModel(context, model);
        }
        return model;
    }

    public static void saveSelectedModel(Context context, String model) {
        if (context != null && model != null && !model.isEmpty()) {
            getPrefs(context).edit().putString(KEY_SELECTED_MODEL, model.trim()).apply();
        }
    }

    /**
     * Builds the exact Gemini v1beta generateContent URL for a model.
     */
    public static String buildGenerateContentUrl(String modelName, String apiKey) {
        String model = modelName != null && !modelName.isEmpty() ? modelName.trim() : DEFAULT_MODEL;
        if (model.startsWith("models/")) {
            model = model.substring(7);
        }
        String cleanKey = apiKey != null ? apiKey.replaceAll("[\\s\"']", "") : "";
        return "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent?key=" + cleanKey;
    }

    /**
     * Executes content generation with automatic candidate fallback if a model is deprecated/unsupported.
     */
    private static void executeGeminiWithModelFallback(final Context context,
                                                       final String apiKey,
                                                       final JSONObject requestPayload,
                                                       final ModelCallHandler handler) {
        final List<String> modelsToTry = new ArrayList<>();
        String currentSelected = getSelectedModel(context);
        if (currentSelected != null && !currentSelected.isEmpty()) {
            modelsToTry.add(currentSelected);
        }
        for (String m : CANDIDATE_MODELS) {
            if (!modelsToTry.contains(m)) {
                modelsToTry.add(m);
            }
        }

        tryNextModel(context, apiKey, requestPayload, modelsToTry, 0, null, handler);
    }

    private static void tryNextModel(final Context context,
                                     final String apiKey,
                                     final JSONObject requestPayload,
                                     final List<String> modelsToTry,
                                     final int index,
                                     final String lastError,
                                     final ModelCallHandler handler) {
        if (index >= modelsToTry.size()) {
            if (handler != null) {
                handler.onError(lastError != null ? lastError : "All available models failed.");
            }
            return;
        }

        final String model = modelsToTry.get(index);
        final String url = buildGenerateContentUrl(model, apiKey);
        RequestBody body = RequestBody.create(JSON_MEDIA_TYPE, requestPayload.toString());
        Request request = new Request.Builder()
                .url(url)
                .addHeader("x-goog-api-key", apiKey)
                .post(body)
                .build();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                mainHandler.post(() -> {
                    if (handler != null) {
                        handler.onError("Network error: " + (e != null ? e.getMessage() : "Unknown"));
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final int code = response.code();
                final String respBody = response.body() != null ? response.body().string() : "";

                if (response.isSuccessful()) {
                    saveSelectedModel(context, model);
                    mainHandler.post(() -> {
                        if (handler != null) handler.onSuccess(respBody, model);
                    });
                } else {
                    String errMessage = "HTTP " + code;
                    try {
                        JSONObject errRoot = new JSONObject(respBody);
                        if (errRoot.has("error")) {
                            JSONObject errObj = errRoot.getJSONObject("error");
                            errMessage = errObj.optString("message", errMessage);
                        }
                    } catch (Exception ignored) {}

                    boolean isModelNotFoundError = (code == 404)
                            || errMessage.toLowerCase().contains("not found")
                            || errMessage.toLowerCase().contains("not supported");

                    if (isModelNotFoundError && index + 1 < modelsToTry.size()) {
                        Log.w(TAG, "Model " + model + " failed (" + errMessage + "). Trying next candidate: " + modelsToTry.get(index + 1));
                        tryNextModel(context, apiKey, requestPayload, modelsToTry, index + 1, errMessage, handler);
                    } else {
                        final String finalErr = errMessage;
                        mainHandler.post(() -> {
                            if (handler != null) handler.onError(finalErr);
                        });
                    }
                }
            }
        });
    }

    /**
     * Validates the provided Gemini API key using Google's official v1beta /models endpoint.
     * - Returns 200 with model list if key is valid.
     * - Returns exact error message from Google if key is invalid.
     */
    public static void validateApiKey(final Context context, final String apiKey, final ApiTestCallback callback) {
        final String cleanKey = apiKey != null ? apiKey.replaceAll("[\\s\"']", "") : "";
        if (cleanKey.isEmpty()) {
            if (callback != null) callback.onError("API Key is empty.");
            return;
        }

        String url = GEMINI_MODELS_URL + "?key=" + cleanKey;

        Request request = new Request.Builder()
                .url(url)
                .addHeader("x-goog-api-key", cleanKey)
                .get()
                .build();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                mainHandler.post(() -> {
                    if (callback != null) callback.onError("Network error: " + (e != null ? e.getMessage() : "Unknown"));
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final int code = response.code();
                final String respBody = response.body() != null ? response.body().string() : "";

                mainHandler.post(() -> {
                    if (response.isSuccessful()) {
                        String identifiedModel = DEFAULT_MODEL;
                        try {
                            JSONObject root = new JSONObject(respBody);
                            JSONArray models = root.optJSONArray("models");
                            if (models != null) {
                                List<String> supportedModels = new ArrayList<>();
                                for (int i = 0; i < models.length(); i++) {
                                    JSONObject m = models.optJSONObject(i);
                                    if (m != null) {
                                        String name = m.optString("name", "");
                                        if (name.startsWith("models/")) {
                                            name = name.substring(7);
                                        }
                                        JSONArray methods = m.optJSONArray("supportedGenerationMethods");
                                        boolean supportsGenerate = false;
                                        if (methods != null) {
                                            for (int j = 0; j < methods.length(); j++) {
                                                if ("generateContent".equals(methods.optString(j))) {
                                                    supportsGenerate = true;
                                                    break;
                                                }
                                            }
                                        } else {
                                            supportsGenerate = true;
                                        }

                                        if (supportsGenerate && name.toLowerCase().contains("gemini")) {
                                            supportedModels.add(name);
                                        }
                                    }
                                }

                                for (String candidate : CANDIDATE_MODELS) {
                                    if (supportedModels.contains(candidate)) {
                                        identifiedModel = candidate;
                                        break;
                                    }
                                }
                                if (identifiedModel.equals(DEFAULT_MODEL) && !supportedModels.isEmpty() && !supportedModels.contains(DEFAULT_MODEL)) {
                                    identifiedModel = supportedModels.get(0);
                                }
                            }
                        } catch (Exception ignored) {}

                        saveSelectedModel(context, identifiedModel);
                        setApiKey(context, cleanKey);
                        if (callback != null) {
                            callback.onSuccess(identifiedModel.toUpperCase() + " (v1beta) Connected ✓");
                        }
                    } else {
                        String errMsg = "HTTP " + code;
                        try {
                            JSONObject errRoot = new JSONObject(respBody);
                            if (errRoot.has("error")) {
                                JSONObject errObj = errRoot.getJSONObject("error");
                                String msg = errObj.optString("message", "");
                                if (!msg.isEmpty()) {
                                    errMsg = msg;
                                } else {
                                    errMsg = errObj.optString("status", errMsg);
                                }
                            }
                        } catch (Exception ignored) {}
                        if (callback != null) callback.onError(errMsg);
                    }
                });
            }
        });
    }

    /**
     * Generates Multiple Choice Questions strictly from the video lecture transcript using Gemini AI (v1beta).
     * Rule: Zero questions from outside the video. If transcript or AI is unavailable, fails gracefully so checkpoint skips.
     */
    public static void generateCheckpointQuiz(final Context context,
                                               final String videoTitle,
                                               final String subject,
                                               final String transcriptSnippet,
                                               final QuizCallback callback) {
        String key = getApiKey(context);
        if (key.isEmpty()) {
            Log.w(TAG, "No Gemini API key configured. Cannot generate video-specific quiz.");
            if (callback != null) {
                callback.onError("Gemini API key not configured. Video quiz cannot be generated.");
            }
            return;
        }

        if (transcriptSnippet == null || transcriptSnippet.trim().length() < 60) {
            Log.w(TAG, "Insufficient or empty transcript for " + videoTitle + ". Skipping video quiz generation.");
            if (callback != null) {
                callback.onError("No transcript available for this video. Cannot generate video-specific quiz.");
            }
            return;
        }

        try {
            String trimmedTranscript = transcriptSnippet.trim();
            if (trimmedTranscript.length() > 30000) {
                trimmedTranscript = trimmedTranscript.substring(0, 30000);
            }

            StringBuilder promptBuilder = new StringBuilder();
            promptBuilder.append("You are an expert academic evaluator testing a student on this specific video lecture.\n");
            promptBuilder.append("Lecture Video Title: ").append(videoTitle != null ? videoTitle : "Educational Lecture").append("\n");
            promptBuilder.append("Subject: ").append(subject != null ? subject : "Science").append("\n\n");
            promptBuilder.append("--- LECTURE SPOKEN TRANSCRIPT (ACTUAL VIDEO CONTENT) ---\n");
            promptBuilder.append(trimmedTranscript).append("\n");
            promptBuilder.append("--- END TRANSCRIPT ---\n\n");

            promptBuilder.append("CRITICAL REQUIREMENTS - ZERO TOLERANCE FOR OUTSIDE QUESTIONS:\n");
            promptBuilder.append("1. MANDATORY: Every single question MUST be strictly, directly, and 100% based ONLY on the concepts, formulas, definitions, derivations, problems, or facts EXPLICITLY discussed or taught in the lecture transcript above.\n");
            promptBuilder.append("2. Under NO circumstances should you ask questions about topics, theories, or syllabus facts not mentioned in this video segment. Absolutely ZERO questions from outside this video.\n");
            promptBuilder.append("3. Each question must have exactly 4 plausible options.\n");
            promptBuilder.append("4. 'correctIndex' must be 0, 1, 2, or 3 corresponding to the correct option according to the lecture.\n");
            promptBuilder.append("5. 'explanation' must be 1-2 concise sentences quoting or referencing what the instructor explained in the video.\n");
            promptBuilder.append("6. Generate between 10 and 20 multiple choice questions (aim for 20 MCQs if content permits).\n");
            promptBuilder.append("7. If the lecture is in Hindi/Hinglish, formulate questions in clear English or Hinglish matching the terminology used by the instructor in the video.\n");
            promptBuilder.append("8. Output ONLY a valid JSON array of objects. Do not include markdown ```json or backticks. Only the raw JSON array.\n");
            promptBuilder.append("Format structure:\n");
            promptBuilder.append("[\n");
            promptBuilder.append("  {\"question\": \"...\", \"options\": [\"Option A\", \"Option B\", \"Option C\", \"Option D\"], \"correctIndex\": 0, \"explanation\": \"...\"}\n");
            promptBuilder.append("]\n");

            JSONObject content = new JSONObject();
            content.put("role", "user");

            JSONArray parts = new JSONArray();
            JSONObject textPart = new JSONObject();
            textPart.put("text", promptBuilder.toString());
            parts.put(textPart);
            content.put("parts", parts);

            JSONArray contents = new JSONArray();
            contents.put(content);

            JSONObject requestPayload = new JSONObject();
            requestPayload.put("contents", contents);

            JSONObject genConfig = new JSONObject();
            genConfig.put("temperature", 0.7);
            genConfig.put("maxOutputTokens", 4096);
            requestPayload.put("generationConfig", genConfig);

            executeGeminiWithModelFallback(context, key, requestPayload, new ModelCallHandler() {
                @Override
                public void onSuccess(String responseBody, String workingModel) {
                    try {
                        List<StudyQuizManager.QuizQuestion> questions = parseQuizFromGeminiResponse(responseBody);
                        if (questions != null && questions.size() >= 5) {
                            int count = Math.min(20, questions.size());
                            List<StudyQuizManager.QuizQuestion> validList = new ArrayList<>(questions.subList(0, count));
                            if (callback != null) callback.onQuizReady(validList, true);
                            return;
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Failed parsing quiz from Gemini response", e);
                    }
                    if (callback != null) {
                        callback.onError("Failed to parse sufficient video-based questions from AI response.");
                    }
                }

                @Override
                public void onError(String lastErrorMessage) {
                    Log.w(TAG, "Gemini video quiz generation failed: " + lastErrorMessage);
                    if (callback != null) {
                        callback.onError(lastErrorMessage);
                    }
                }
            });

        } catch (Exception e) {
            Log.e(TAG, "Error initiating video quiz generation", e);
            if (callback != null) {
                callback.onError("Error: " + e.getMessage());
            }
        }
    }

    private static List<StudyQuizManager.QuizQuestion> parseQuizFromGeminiResponse(String jsonResponse) {
        try {
            JSONObject root = new JSONObject(jsonResponse);
            JSONArray candidates = root.optJSONArray("candidates");
            if (candidates == null || candidates.length() == 0) return null;

            JSONObject candidate = candidates.getJSONObject(0);
            JSONObject content = candidate.optJSONObject("content");
            if (content == null) return null;

            JSONArray parts = content.optJSONArray("parts");
            if (parts == null || parts.length() == 0) return null;

            String rawText = parts.getJSONObject(0).optString("text", "");
            rawText = rawText.trim();

            if (rawText.startsWith("```json")) {
                rawText = rawText.substring(7);
            } else if (rawText.startsWith("```")) {
                rawText = rawText.substring(3);
            }
            if (rawText.endsWith("```")) {
                rawText = rawText.substring(0, rawText.length() - 3);
            }
            rawText = rawText.trim();

            int startBracket = rawText.indexOf('[');
            int endBracket = rawText.lastIndexOf(']');
            if (startBracket >= 0 && endBracket > startBracket) {
                rawText = rawText.substring(startBracket, endBracket + 1);
            }

            JSONArray questionsArr = new JSONArray(rawText);
            List<StudyQuizManager.QuizQuestion> list = new ArrayList<>();

            for (int i = 0; i < questionsArr.length(); i++) {
                JSONObject qObj = questionsArr.optJSONObject(i);
                if (qObj == null) continue;

                String question = qObj.optString("question", "");
                int correctIdx = qObj.optInt("correctIndex", 0);
                String explanation = qObj.optString("explanation", "");

                JSONArray opts = qObj.optJSONArray("options");
                List<String> optList = new ArrayList<>();
                if (opts != null) {
                    for (int j = 0; j < opts.length(); j++) {
                        optList.add(opts.optString(j, ""));
                    }
                }

                if (!question.isEmpty() && optList.size() >= 4) {
                    list.add(new StudyQuizManager.QuizQuestion(question, optList.subList(0, 4), correctIdx, explanation));
                }
            }
            return list;
        } catch (Exception e) {
            Log.e(TAG, "Failed to parse questions JSON from Gemini", e);
            return null;
        }
    }

    /**
     * Answers student's doubt about the lecture video using Gemini v1beta.
     */
    public static void askLectureDoubt(final Context context,
                                       final String videoTitle,
                                       final String subject,
                                       final long timestampMs,
                                       final String transcriptSnippet,
                                       final String userDoubt,
                                       final DoubtCallback callback) {
        final String safeSubject = subject != null && !subject.isEmpty() ? subject : "General Science";
        final String safeTitle = videoTitle != null && !videoTitle.isEmpty() ? videoTitle : "Educational Lecture";
        final long totalSec = timestampMs / 1000;
        final String timeFormatted = String.format("%02d:%02d", totalSec / 60, totalSec % 60);

        String key = getApiKey(context);
        if (key.isEmpty()) {
            if (callback != null) {
                callback.onAnswerReceived(buildLocalInsight(safeSubject, safeTitle, userDoubt, timeFormatted, null));
            }
            return;
        }

        try {
            StringBuilder promptBuilder = new StringBuilder();
            promptBuilder.append("You are an expert, encouraging AI academic tutor for high school and college students.\n");
            promptBuilder.append("The student is watching: '").append(safeTitle).append("' (Subject: ").append(safeSubject).append(") at video timestamp ").append(timeFormatted).append(".\n");

            if (transcriptSnippet != null && !transcriptSnippet.trim().isEmpty()) {
                String snippet = transcriptSnippet.trim();
                if (snippet.length() > 3000) snippet = snippet.substring(0, 3000);
                promptBuilder.append("Nearby lecture transcript context:\n").append(snippet).append("\n\n");
            }

            promptBuilder.append("Student's Doubt/Question:\n\"").append(userDoubt).append("\"\n\n");
            promptBuilder.append("Instructions:\n");
            promptBuilder.append("1. Provide a direct, step-by-step conceptual answer to this question.\n");
            promptBuilder.append("2. Include any fundamental formulas, definitions, or boundary rules needed.\n");
            promptBuilder.append("3. Keep it encouraging, well-structured, and easy to understand with clear bullet points.");

            JSONObject content = new JSONObject();
            content.put("role", "user");

            JSONArray parts = new JSONArray();
            JSONObject textPart = new JSONObject();
            textPart.put("text", promptBuilder.toString());
            parts.put(textPart);
            content.put("parts", parts);

            JSONArray contents = new JSONArray();
            contents.put(content);

            JSONObject requestPayload = new JSONObject();
            requestPayload.put("contents", contents);

            JSONObject genConfig = new JSONObject();
            genConfig.put("maxOutputTokens", 1500);
            requestPayload.put("generationConfig", genConfig);

            executeGeminiWithModelFallback(context, key, requestPayload, new ModelCallHandler() {
                @Override
                public void onSuccess(String responseBody, String workingModel) {
                    try {
                        JSONObject root = new JSONObject(responseBody);
                        JSONArray candidates = root.optJSONArray("candidates");
                        if (candidates != null && candidates.length() > 0) {
                            JSONObject cand = candidates.getJSONObject(0);
                            JSONObject cContent = cand.optJSONObject("content");
                            if (cContent != null) {
                                JSONArray cParts = cContent.optJSONArray("parts");
                                if (cParts != null && cParts.length() > 0) {
                                    String ans = cParts.getJSONObject(0).optString("text", "");
                                    if (!ans.isEmpty()) {
                                        if (callback != null) callback.onAnswerReceived(ans);
                                        return;
                                    }
                                }
                            }
                        }
                    } catch (Exception ignored) {}
                    if (callback != null) {
                        callback.onAnswerReceived(buildLocalInsight(safeSubject, safeTitle, userDoubt, timeFormatted, "Parsing response issue"));
                    }
                }

                @Override
                public void onError(String lastErrorMessage) {
                    if (callback != null) {
                        callback.onAnswerReceived(buildLocalInsight(safeSubject, safeTitle, userDoubt, timeFormatted, "Gemini note: " + lastErrorMessage));
                    }
                }
            });

        } catch (Exception e) {
            if (callback != null) {
                callback.onAnswerReceived(buildLocalInsight(safeSubject, safeTitle, userDoubt, timeFormatted, "Error: " + e.getMessage()));
            }
        }
    }

    private static String buildLocalInsight(String subject, String title, String doubt, String timestamp, String note) {
        StringBuilder sb = new StringBuilder();
        sb.append("💡 **Lecture Concept Insight (").append(subject != null ? subject : "General").append(")**\n\n");
        sb.append("• **Topic:** ").append(title != null ? title : "Lecture").append(" [").append(timestamp).append("]\n");
        sb.append("• **Doubt:** \"").append(doubt).append("\"\n\n");
        sb.append("### Key Conceptual Guidance:\n");
        sb.append("1. **Fundamentals:** Pay attention to the definitions, assumptions, and primary equations demonstrated around this timestamp.\n");
        sb.append("2. **Core Formulae:** Double-check units, vector directions, and algebraic sign conventions.\n");
        sb.append("3. **Exam Focus:** Be sure to memorize any standard exceptions or constant parameters highlighted in this section.\n\n");
        if (note != null && !note.isEmpty()) {
            sb.append("*(Note: ").append(note).append(". Set up or verify your Gemini API Key in Settings to get real-time neural explanations.)*");
        } else {
            sb.append("*(Tip: Configure your Gemini API Key in Permission Manager for instant live AI doubt clearing!)*");
        }
        return sb.toString();
    }

    /**
     * High-yield 20-question syllabus generator (Physics, Chemistry, Maths, Biology).
     * Guaranteed 20 questions with 4 options and explanations so user checkpoint is always functional.
     */
    public static List<StudyQuizManager.QuizQuestion> generateCuratedQuiz(String videoTitle, String subject) {
        List<StudyQuizManager.QuizQuestion> questions = new ArrayList<>();
        String s = subject != null ? subject.toLowerCase() : "general";

        if (s.contains("phys")) {
            addPhysicsQuestions(questions);
        } else if (s.contains("chem")) {
            addChemistryQuestions(questions);
        } else if (s.contains("math")) {
            addMathQuestions(questions);
        } else if (s.contains("bio")) {
            addBiologyQuestions(questions);
        } else {
            addGeneralScienceQuestions(questions);
        }

        while (questions.size() < 20) {
            int idx = questions.size() + 1;
            List<String> opts = new ArrayList<>();
            opts.add("Fundamental law holds true under all conditions");
            opts.add("Dependent on external temperature only");
            opts.add("Valid only in macroscopic non-inertial systems");
            opts.add("Constant of proportionality is negative");
            questions.add(new StudyQuizManager.QuizQuestion(
                    "Concept Verification Q" + idx + " regarding " + (videoTitle != null ? videoTitle : "this lecture") + ": Which statement is universally valid?",
                    opts,
                    0,
                    "The primary fundamental principle remains universally invariant under standard boundary frames."
            ));
        }

        Collections.shuffle(questions);
        return questions.subList(0, 20);
    }

    private static void addPhysicsQuestions(List<StudyQuizManager.QuizQuestion> q) {
        q.add(createQ("What is the SI unit of electric potential?", "Volt", "Joule", "Watt", "Ampere", 0, "Electric potential is defined as work done per unit charge (J/C = Volt)."));
        q.add(createQ("According to Newton's First Law, a body remains at rest or in uniform motion unless acted upon by:", "An unbalanced external force", "Gravity", "Friction", "Internal forces", 0, "Inertia maintains the state of uniform motion unless an external net force acts."));
        q.add(createQ("The rate of change of linear momentum is directly proportional to:", "Applied Force", "Inertia", "Velocity", "Acceleration", 0, "Newton's Second Law states F = dp/dt."));
        q.add(createQ("Work done by a conservative force along a closed path is:", "Zero", "Positive", "Negative", "Infinite", 0, "For conservative forces, the line integral around any closed loop is identically zero."));
        q.add(createQ("What type of collision conserves both momentum and kinetic energy?", "Elastic collision", "Inelastic collision", "Completely inelastic", "Explosive collision", 0, "In a perfectly elastic collision, total kinetic energy is conserved."));
        q.add(createQ("The dimensional formula of universal gravitational constant (G) is:", "[M⁻¹ L³ T⁻²]", "[M¹ L² T⁻¹]", "[M L T⁻²]", "[M⁻¹ L² T⁻²]", 0, "From F = G*m1*m2/r², G = F*r²/(m²), giving [M⁻¹ L³ T⁻²]."));
        q.add(createQ("Escape velocity from the surface of Earth depends on:", "Mass and radius of Earth", "Mass of the projectile", "Angle of projection", "Density of atmosphere", 0, "v_e = sqrt(2GM/R), completely independent of the projectile's mass."));
        q.add(createQ("Young's modulus is a measure of an object's resistance to:", "Linear deformation (tensile strain)", "Shear strain", "Volume compression", "Torsional twisting", 0, "Young's modulus is the ratio of tensile stress to tensile strain."));
        q.add(createQ("Bernoulli's principle is based on the conservation of:", "Energy", "Mass", "Linear momentum", "Angular momentum", 0, "Bernoulli's equation represents energy conservation for flowing non-viscous fluids."));
        q.add(createQ("In Simple Harmonic Motion (SHM), acceleration is maximum at:", "Extreme positions", "Mean position", "Half amplitude", "Quarter amplitude", 0, "a = -ω²x, which is maximized when displacement x is at extreme amplitude."));
        q.add(createQ("The Zeroth Law of Thermodynamics introduces the concept of:", "Temperature", "Internal energy", "Entropy", "Heat capacity", 0, "The Zeroth Law defines thermal equilibrium and temperature."));
        q.add(createQ("For an adiabatic process, the heat exchanged (dQ) is:", "0", "Positive", "Equal to work done", "Infinite", 0, "In an adiabatic system, no heat enters or leaves the boundary (dQ = 0)."));
        q.add(createQ("The velocity of sound is fastest in which medium?", "Solids", "Liquids", "Gases", "Vacuum", 0, "Solids have higher elasticity and density ratios, conducting sound fastest."));
        q.add(createQ("What is the frequency range of human audibility?", "20 Hz to 20,000 Hz", "5 Hz to 500 Hz", "20 kHz to 200 kHz", "100 Hz to 10 kHz", 0, "Standard human hearing spans 20 Hz to 20 kHz."));
        q.add(createQ("Torque is the rotational analogue of:", "Force", "Mass", "Momentum", "Work", 0, "Torque produces angular acceleration just as force produces linear acceleration."));
        q.add(createQ("The moment of inertia of a uniform thin ring of mass M and radius R about its central axis is:", "MR²", "1/2 MR²", "2/5 MR²", "2/3 MR²", 0, "All mass of the ring is at radius R, so I = MR²."));
        q.add(createQ("Surface tension of a liquid arises due to:", "Cohesive intermolecular forces", "Adhesive intermolecular forces", "Gravity", "Atmospheric pressure", 0, "Cohesive forces pull surface molecules inwards into the bulk liquid."));
        q.add(createQ("In an isobaric thermodynamic process, which quantity remains constant?", "Pressure", "Volume", "Temperature", "Entropy", 0, "Isobaric means constant pressure (dP = 0)."));
        q.add(createQ("Light year is a unit of:", "Distance", "Time", "Intensity", "Velocity", 0, "A light-year is the astronomical distance traversed by light in one Julian year."));
        q.add(createQ("Apparent weight of a person in a freely falling elevator is:", "Zero", "Double", "Half", "Equal to true weight", 0, "In free fall, normal reaction N = m(g - g) = 0."));
    }

    private static void addChemistryQuestions(List<StudyQuizManager.QuizQuestion> q) {
        q.add(createQ("The number of moles in 44 grams of CO₂ is:", "1 mole", "2 moles", "0.5 mole", "44 moles", 0, "Molar mass of CO₂ is 12 + 32 = 44 g/mol."));
        q.add(createQ("Which quantum number determines the spatial orientation of an orbital?", "Magnetic quantum number (m)", "Principal (n)", "Azimuthal (l)", "Spin (s)", 0, "m values describe orbital orientation along axes."));
        q.add(createQ("According to Aufbau principle, electrons occupy orbitals of:", "Lowest energy first", "Highest energy first", "Equal spin only", "Maximum multiplicity", 0, "Aufbau states electrons fill lowest available subshells first."));
        q.add(createQ("Which element has the highest electronegativity?", "Fluorine", "Oxygen", "Chlorine", "Nitrogen", 0, "Fluorine has the highest electronegativity (approx 4.0 on Pauling scale)."));
        q.add(createQ("The shape of a methane (CH₄) molecule is:", "Tetrahedral", "Trigonal planar", "Linear", "Square planar", 0, "sp³ hybridization with 4 bonding pairs forms a tetrahedral geometry."));
        q.add(createQ("For an ideal gas equation PV = nRT, R is:", "Universal gas constant", "Rydberg constant", "Rate constant", "Resistance", 0, "R is the universal gas constant (8.314 J/mol·K)."));
        q.add(createQ("An exothermic reaction has which sign of enthalpy change (ΔH)?", "Negative", "Positive", "Zero", "Variable", 0, "Exothermic processes release heat into surroundings, so ΔH < 0."));
        q.add(createQ("What is the oxidation state of Chromium in K₂Cr₂O₇?", "+6", "+3", "+7", "+2", 0, "2(+1) + 2(Cr) + 7(-2) = 0 => 2Cr = +12 => Cr = +6."));
        q.add(createQ("Which law states that mass is neither created nor destroyed in a chemical reaction?", "Law of Conservation of Mass", "Law of Definite Proportions", "Gay-Lussac's Law", "Avogadro's Law", 0, "Lavoisier formulated the Law of Conservation of Mass."));
        q.add(createQ("The conjugate base of HSO₄⁻ is:", "SO₄²⁻", "H₂SO₄", "HSO₃⁻", "SO₃²⁻", 0, "Removing one H⁺ from HSO₄⁻ leaves SO₄²⁻."));
        q.add(createQ("What type of hybridization is present in ethyne (C₂H₂)?", "sp", "sp²", "sp³", "dsp²", 0, "Carbon in ethyne forms a triple bond and one single bond, which is sp hybridized."));
        q.add(createQ("Avogadro's number is equal to approximately:", "6.022 × 10²³", "3.00 × 10⁸", "1.602 × 10⁻¹⁹", "9.1 × 10⁻³¹", 0, "One mole contains 6.022 × 10²³ particles."));
        q.add(createQ("Boyle's Law states that at constant temperature:", "P is inversely proportional to V", "P is directly proportional to V", "V is proportional to T", "P is proportional to T", 0, "Boyle's Law: P1V1 = P2V2 at constant T."));
        q.add(createQ("Which gas is liberated when zinc reacts with dilute sulfuric acid?", "Hydrogen (H₂)", "Oxygen (O₂)", "Sulfur dioxide", "Carbon dioxide", 0, "Zn + H₂SO₄ -> ZnSO₄ + H₂."));
        q.add(createQ("A solution with pH = 3 is:", "Acidic", "Basic", "Neutral", "Amphoteric", 0, "pH < 7 indicates an acidic solution."));
        q.add(createQ("What is the geometry of water (H₂O) molecule?", "Bent / V-shaped", "Linear", "Tetrahedral", "Pyramidal", 0, "Two bond pairs and two lone pairs yield a bent geometry."));
        q.add(createQ("Which of the following is an intensive thermodynamic property?", "Density", "Volume", "Mass", "Internal Energy", 0, "Density does not depend on the total quantity of matter."));
        q.add(createQ("Electrons were discovered by:", "J.J. Thomson", "Ernest Rutherford", "James Chadwick", "Niels Bohr", 0, "J.J. Thomson discovered the electron via cathode ray tube experiments."));
        q.add(createQ("The general formula for alkanes is:", "CnH2n+2", "CnH2n", "CnH2n-2", "CnHn", 0, "Alkanes are saturated hydrocarbons with formula CnH2n+2."));
        q.add(createQ("What is the unit of rate constant for a first order reaction?", "s⁻¹", "mol L⁻¹ s⁻¹", "L mol⁻¹ s⁻¹", "Dimensionless", 0, "For first order kinetics, rate = k[A], hence k has units of time⁻¹ (s⁻¹)."));
    }

    private static void addMathQuestions(List<StudyQuizManager.QuizQuestion> q) {
        q.add(createQ("What is the derivative of sin(x) with respect to x?", "cos(x)", "-cos(x)", "tan(x)", "sec²(x)", 0, "d/dx(sin x) = cos x."));
        q.add(createQ("The value of log₁₀(100) is:", "2", "1", "10", "100", 0, "10² = 100, so log₁₀(100) = 2."));
        q.add(createQ("What is the sum of angles in a planar triangle?", "180 degrees (π rad)", "360 degrees", "90 degrees", "270 degrees", 0, "The interior angle sum of any Euclidean triangle is 180°."));
        q.add(createQ("If a matrix A has det(A) = 0, the matrix is called:", "Singular", "Non-singular", "Orthogonal", "Identity", 0, "A singular matrix has determinant equal to zero and lacks an inverse."));
        q.add(createQ("The solution to the quadratic equation ax² + bx + c = 0 has equal real roots if:", "b² - 4ac = 0", "b² - 4ac > 0", "b² - 4ac < 0", "b = 0", 0, "The discriminant Δ = 0 implies repeated equal real roots."));
        q.add(createQ("What is the value of i² where i is the imaginary unit?", "-1", "1", "0", "-i", 0, "By definition, i = sqrt(-1), so i² = -1."));
        q.add(createQ("The integral of 1/x dx is:", "ln|x| + C", "-1/x² + C", "e^x + C", "x + C", 0, "∫(1/x) dx = ln|x| + C for x ≠ 0."));
        q.add(createQ("The nth term of an Arithmetic Progression (AP) is:", "a + (n-1)d", "a * r^(n-1)", "a + nd", "n/2 [2a + d]", 0, "The standard nth term formula for an AP is a + (n-1)d."));
        q.add(createQ("What is the limit of (sin x)/x as x approaches 0?", "1", "0", "Infinity", "Undefined", 0, "A standard fundamental trigonometric limit: lim (x->0) (sin x)/x = 1."));
        q.add(createQ("The slope of the line tangent to y = x² at x = 3 is:", "6", "9", "3", "12", 0, "dy/dx = 2x; at x=3, slope = 2(3) = 6."));
        q.add(createQ("How many diagonals does a regular hexagon have?", "9", "6", "12", "15", 0, "Formula: n(n-3)/2; for n=6: 6(3)/2 = 9."));
        q.add(createQ("The value of cos(0°) is:", "1", "0", "-1", "1/2", 0, "cos(0) = 1."));
        q.add(createQ("What is the probability of rolling a prime number on a standard 6-sided die?", "1/2", "1/3", "2/3", "1/6", 0, "Prime outcomes are {2, 3, 5} out of {1, 2, 3, 4, 5, 6}, which is 3/6 = 1/2."));
        q.add(createQ("Two vectors are perpendicular if their dot product is:", "0", "1", "-1", "Equal to magnitude", 0, "A · B = |A||B| cos(90°) = 0."));
        q.add(createQ("The domain of f(x) = sqrt(x - 4) in real numbers is:", "x >= 4", "x > 4", "x <= 4", "All real numbers", 0, "The term under the square root must be non-negative: x - 4 >= 0 => x >= 4."));
        q.add(createQ("What is the median of the numbers 3, 7, 1, 9, 5?", "5", "7", "3", "1", 0, "Sorted list: 1, 3, 5, 7, 9. The middle element is 5."));
        q.add(createQ("What is the value of 5! (5 factorial)?", "120", "60", "24", "720", 0, "5! = 5 × 4 × 3 × 2 × 1 = 120."));
        q.add(createQ("The centroid of a triangle divides each median in the ratio:", "2 : 1", "1 : 1", "3 : 1", "3 : 2", 0, "The centroid divides every median in the ratio 2:1 from the vertex."));
        q.add(createQ("If f(x) = e^(2x), what is f'(x)?", "2e^(2x)", "e^(2x)", "4e^(2x)", "2e^x", 0, "Chain rule: d/dx(e^(2x)) = 2 * e^(2x)."));
        q.add(createQ("The distance between points (0,0) and (3,4) is:", "5", "7", "12", "25", 0, "sqrt(3² + 4²) = sqrt(9 + 16) = sqrt(25) = 5."));
    }

    private static void addBiologyQuestions(List<StudyQuizManager.QuizQuestion> q) {
        q.add(createQ("Which organelle is known as the powerhouse of the cell?", "Mitochondria", "Ribosome", "Golgi apparatus", "Endoplasmic reticulum", 0, "Mitochondria generate cellular energy in the form of ATP."));
        q.add(createQ("The basic functional unit of human kidney is:", "Nephron", "Neuron", "Alveoli", "Hepatocyte", 0, "The nephron is the structural and functional filtration unit of the kidney."));
        q.add(createQ("Which blood group is known as the universal donor?", "O negative", "AB positive", "A positive", "B negative", 0, "O negative blood lacks A, B, and Rh surface antigens."));
        q.add(createQ("Photosynthesis in plants primarily occurs inside:", "Chloroplasts", "Mitochondria", "Vacuoles", "Centrosomes", 0, "Chloroplasts contain chlorophyll that absorbs radiant light."));
        q.add(createQ("DNA replication occurs during which phase of cell cycle?", "S phase (Synthesis)", "G1 phase", "G2 phase", "M phase", 0, "Chromosome duplication occurs strictly during the synthesis (S) phase."));
        q.add(createQ("Which hormone regulates blood glucose levels by promoting absorption?", "Insulin", "Glucagon", "Adrenaline", "Thyroxine", 0, "Insulin secreted by beta cells lowers blood glucose levels."));
        q.add(createQ("The exchange of gases in human lungs occurs at the:", "Alveoli", "Bronchi", "Trachea", "Larynx", 0, "Alveoli provide high surface area with capillaries for O₂/CO₂ diffusion."));
        q.add(createQ("Which molecule carries genetic information from DNA to ribosomes?", "mRNA", "tRNA", "rRNA", "Plasmid", 0, "Messenger RNA (mRNA) transcribes genetic code from the nucleus."));
        q.add(createQ("Enzymes are predominantly composed of:", "Proteins", "Lipids", "Carbohydrates", "Nucleic acids", 0, "Almost all biological catalyst enzymes are globular proteins."));
        q.add(createQ("What is the primary function of platelets in human blood?", "Blood clotting (Coagulation)", "Oxygen transport", "Immune response", "Nutrient absorption", 0, "Platelets aggregate at injury sites to form blood clots."));
        q.add(createQ("Which tissue transports water and minerals from roots to leaves?", "Xylem", "Phloem", "Cambium", "Pith", 0, "Xylem conducts unidirectional water and dissolved minerals upward."));
        q.add(createQ("Mendel conducted his famous genetics experiments on which organism?", "Pisum sativum (Garden Pea)", "Drosophila", "E. coli", "Neurospora", 0, "Gregor Mendel studied inheritance patterns using garden peas."));
        q.add(createQ("The structural framework of cell membranes is a bilayer of:", "Phospholipids", "Triglycerides", "Polysaccharides", "Glycoproteins", 0, "Phospholipids form the amphipathic fluid mosaic bilayer."));
        q.add(createQ("Which chamber of the human heart pumps oxygenated blood into the aorta?", "Left ventricle", "Right ventricle", "Left atrium", "Right atrium", 0, "Left ventricle contracts with high pressure to circulate blood through the aorta."));
        q.add(createQ("A nucleotide consists of a nitrogenous base, a phosphate group, and:", "A 5-carbon pentose sugar", "An amino acid", "A fatty acid chain", "A glycerol molecule", 0, "Nucleotides comprise pentose sugar + nitrogenous base + phosphate."));
        q.add(createQ("In meiosis, crossing over occurs during:", "Pachytene of Prophase I", "Leptotene", "Metaphase II", "Anaphase I", 0, "Homologous non-sister chromatids recombine during pachytene."));
        q.add(createQ("Which mineral ion is essential for human muscle contraction?", "Calcium (Ca²⁺)", "Sodium (Na⁺)", "Potassium (K⁺)", "Iron (Fe²⁺)", 0, "Calcium binding to troponin exposes actin binding sites."));
        q.add(createQ("Normal human resting blood pressure is considered:", "120/80 mmHg", "140/90 mmHg", "100/60 mmHg", "160/100 mmHg", 0, "Standard nominal systolic/diastolic pressure is 120/80 mmHg."));
        q.add(createQ("Which vitamin is synthesized in human skin upon exposure to sunlight?", "Vitamin D", "Vitamin A", "Vitamin C", "Vitamin K", 0, "Sunlight converts 7-dehydrocholesterol in the epidermis into cholecalciferol (Vitamin D3)."));
        q.add(createQ("The powerhouse of aerobic cellular respiration generates ATP primarily via:", "Oxidative phosphorylation", "Glycolysis alone", "Lactic fermentation", "Substrate phosphorylation only", 0, "The electron transport chain drives chemiosmotic oxidative phosphorylation."));
    }

    private static void addGeneralScienceQuestions(List<StudyQuizManager.QuizQuestion> q) {
        addPhysicsQuestions(q);
    }

    private static StudyQuizManager.QuizQuestion createQ(String question, String a, String b, String c, String d, int correct, String exp) {
        List<String> rawOpts = new ArrayList<>();
        rawOpts.add(a);
        rawOpts.add(b);
        rawOpts.add(c);
        rawOpts.add(d);
        String correctOptionText = rawOpts.get(correct);

        Collections.shuffle(rawOpts);
        int newCorrectIdx = rawOpts.indexOf(correctOptionText);

        return new StudyQuizManager.QuizQuestion(question, rawOpts, newCorrectIdx, exp);
    }
}
