package com.abhi.study.youtube

import java.util.regex.Pattern

/**
 * YouTubeUrlParser:
 * Robust, zero-allocation utility for extracting 11-character video IDs
 * and cleaning transcript text strings.
 */
object YouTubeUrlParser {

    private val YOUTUBE_ID_REGEX = Pattern.compile(
        "(?:https?:\\/\\/)?(?:www\\.|m\\.)?(?:youtube\\.com\\/(?:watch\\?(?:.*&)?v=|embed\\/|v\\/|shorts\\/)|youtu\\.be\\/)([a-zA-Z0-9_-]{11})",
        Pattern.CASE_INSENSITIVE
    )

    private val RAW_ID_REGEX = Pattern.compile("^[a-zA-Z0-9_-]{11}$")

    /**
     * Extracts YouTube 11-character video ID from a URL or raw ID string.
     * Returns null if no valid ID can be resolved.
     */
    fun extractVideoId(input: String?): String? {
        if (input.isNullOrBlank()) return null
        val trimmed = input.trim()

        // 1. Raw 11-char ID fast path
        if (RAW_ID_REGEX.matcher(trimmed).matches()) {
            return trimmed
        }

        // 2. Full URL pattern matching
        val matcher = YOUTUBE_ID_REGEX.matcher(trimmed)
        return if (matcher.find()) {
            matcher.group(1)
        } else {
            null
        }
    }

    /**
     * Cleans up transcript text by unescaping HTML entities and normalizing whitespace.
     */
    fun cleanTranscriptText(rawText: String?): String {
        if (rawText.isNullOrBlank()) return ""

        var text = rawText
            .replace("&amp;", "&")
            .replace("&#39;", "'")
            .replace("&apos;", "'")
            .replace("&quot;", "\"")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&nbsp;", " ")
            .replace("&#x2F;", "/")
            .replace("&#32;", " ")
            .replace("\n", " ")

        // Replace multiple consecutive spaces with a single space
        text = text.replace("\\s+".toRegex(), " ").trim()
        return text
    }
}
