package com.abhi.study;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.Dialog;
import android.app.KeyguardManager;
import android.app.admin.DevicePolicyManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;

import java.lang.ref.WeakReference;
import android.provider.Telephony;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.HapticFeedbackConstants;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import android.Manifest;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.lang.reflect.Method;

/**
 * Active Study Session Activity (Dashboard).
 * Redesigned according to latest user specifications:
 * - 70% Real-Time Clock with split-flap upward page-turning half-flip animation.
 * - 30% Right Control Panel column split into 4 interactive tiles:
 *     1. Battery (XX% normal, XX.XX% charging with real-time current/voltage computation)
 *     2. Mobile Data (Cellular status, single tap toggle / panel, long press settings)
 *     3. Wi-Fi (Live SSID & state, single tap toggle, long press Wi-Fi settings)
 *     4. Bluetooth (Live state, single tap toggle, long press Bluetooth settings)
 * - iOS Lock Screen Torch (left) and Camera (right) circular glass buttons operating on 450ms long press.
 */
public class StudySessionActivity extends AppCompatActivity {

    private static final String TAG = "StudySessionActivity";
    private static final int RC_BT_CONNECT_PERMISSION = 101;

    public static final String EXTRA_MODE = "extra_mode";
    public static final String EXTRA_MINUTES = "extra_minutes";
    public static final String EXTRA_LABEL = "extra_label";

    private View sessionRoot;
    private View heroDashboardRow;


    // 70% Real Time Flip Clock Components (Upward Half-Flip Page Turning)
    private FlipDigitCardView flipHours;
    private FlipDigitCardView flipMinutes;
    private FlipDigitCardView flipSeconds;
    private TextView tvFlipStatusPill;

    // 4 Control Panel Tiles (Battery, Data, WiFi, Bluetooth)
    private View tileBattery;
    private View tileData;
    private View tileWifi;
    private View tileBluetooth;

    // Tile 1: Battery
    private AppCompatImageView ivHeroBatteryIcon;
    private TextView tvDecimalBattery;
    private TextView tvBatteryStatePill;

    // Tile 2: Mobile Data
    private AppCompatImageView ivDataIcon;
    private TextView tvDataTitle;
    private TextView tvDataStatePill;

    // Tile 3: Wi-Fi
    private AppCompatImageView ivWifiIcon;
    private TextView tvWifiTitle;
    private TextView tvWifiStatePill;

    // Tile 4: Bluetooth
    private AppCompatImageView ivBluetoothIcon;
    private TextView tvBluetoothTitle;
    private TextView tvBluetoothStatePill;

    // Connectivity & Hardware managers
    private ConnectivityManager connectivityManager;
    private WifiManager wifiManager;
    private BluetoothAdapter bluetoothAdapter;
    private BroadcastReceiver networkAndBtReceiver;

    // Session Timer Aura & Counter
    private View timerHeroContainer;
    private FocusSessionAuraView focusAuraView;
    private TextView tvTimerDisplay;
    private TextView tvTimerSubtitle;
    private TextView tvStatusPill;

    // Interactive iOS Slide to End Session (Bidirectional)
    private FrameLayout sliderContainer;
    private FrameLayout sliderThumb;
    private LinearLayout layoutSliderHintLeft;
    private LinearLayout layoutSliderHintRight;
    private TextView tvSliderHintLeft;
    private TextView tvSliderHintRight;
    private DancingPikachuView pikachuDancingView;
    private boolean isSliderCompleted = false;

    // Mini Genie Quick Apps Popup (Left Slide Trigger)
    private FrameLayout layoutGenieAppsOverlay;
    private View cardGenieApps;
    private View genieScrimDismiss;
    private View btnGenieClose;
    private View btnAppWhatsApp;
    private View btnAppDialer;
    private View btnAppContacts;
    private View btnAppMessages;

    // iOS Bottom Controls
    private View bottomControlsBar;
    private FrameLayout btnIosTorch;
    private AppCompatImageView ivTorchIcon;
    private FrameLayout btnIosCamera;
    private AppCompatImageView ivCameraIcon;
    private View btnDeepExit;

    // Session State
    private boolean isDeepMode = false;
    private int targetMinutes = 0;
    private long totalSeconds = 0;
    private long remainingSeconds = 0;
    private long elapsedSeconds = 0;
    private boolean isSessionSuccessDialogShown = false;

    // Smart Focus Timer: Screen Inactive / Lock Instant Freeze
    private BroadcastReceiver screenStateReceiver;
    private boolean isScreenActiveState = true;
    private boolean isTimerFrozen = false;
    private long totalFrozenSeconds = 0;
    private long freezeStartTimestamp = 0;

    // Kiosk Mode & Device Owner (Exclusive to Deep Mode)
    private DevicePolicyManager devicePolicyManager;
    private ComponentName adminComponentName;
    private boolean isKioskActive = false;
    private boolean isLaunchingAllowedApp = false;

    // Real-time battery & charging tracker (Normal: XX%, Charging: XX.XX%)
    private float realBatteryPct = -1f;
    private boolean isBatteryCharging = false;
    private int batteryVoltageMv = 0;
    private int batteryCurrentUa = 0;
    private float chargingDecimalOffset = 0.0f;
    private int lastBaseLevel = -1;
    private long lastChargingTimestamp = 0;

    // Torch / Flashlight state
    private CameraManager cameraManager;
    private String backCameraId = null;
    private boolean isTorchActive = false;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private Runnable clockAndSessionRunnable;

    private BroadcastReceiver batteryReceiver;
    private StudyDynamicIslandController dynamicIslandController;

    private static WeakReference<StudySessionActivity> activeInstance = null;
    private static volatile boolean isForeground = false;

    public static boolean isForeground() {
        return isForeground;
    }

    public static void notifyLaunchingAllowedApp() {
        StudySessionActivity act = activeInstance != null ? activeInstance.get() : null;
        if (act != null) {
            act.isLaunchingAllowedApp = true;
            if (act.isDeepMode) {
                // If not device owner, release lock task temporarily so the external allowed app can open smoothly
                if (!act.isDeviceOwner()) {
                    try {
                        act.stopLockTask();
                        act.isKioskActive = false;
                    } catch (Exception ignored) {}
                }
            }
        }
    }

    public static void applySessionTimerPenalty(int penaltySeconds) {
        StudySessionActivity act = activeInstance != null ? activeInstance.get() : null;
        if (act != null && !act.isFinishing()) {
            act.runOnUiThread(() -> act.chargeTimerPenalty(penaltySeconds));
        }
    }

    public void chargeTimerPenalty(int penaltySeconds) {
        try {
            if (isDeepMode) {
                remainingSeconds += penaltySeconds;
                totalSeconds += penaltySeconds;
                if (tvTimerDisplay != null) {
                    tvTimerDisplay.setText(formatSessionSeconds(remainingSeconds));
                }
            } else {
                elapsedSeconds = Math.max(0, elapsedSeconds - penaltySeconds);
                if (tvTimerDisplay != null) {
                    tvTimerDisplay.setText(formatSessionSeconds(elapsedSeconds));
                }
            }
            Toast.makeText(this, "⚠️ " + (penaltySeconds / 60) + " Min Checkpoint Penalty Charged to Timer!", Toast.LENGTH_LONG).show();
        } catch (Exception ignored) {}
    }

    public boolean isDeviceOwner() {
        try {
            if (devicePolicyManager == null) {
                devicePolicyManager = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
            }
            return devicePolicyManager != null && devicePolicyManager.isDeviceOwnerApp(getPackageName());
        } catch (Exception ignored) {
            return false;
        }
    }

    public boolean isActuallyInLockTask() {
        try {
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            if (am != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    return am.getLockTaskModeState() != ActivityManager.LOCK_TASK_MODE_NONE;
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    return am.isInLockTaskMode();
                }
            }
        } catch (Exception ignored) {}
        return isKioskActive;
    }

    public static StudySessionActivity getActiveInstance() {
        return activeInstance != null ? activeInstance.get() : null;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activeInstance = new WeakReference<>(this);

        try {
            makeEdgeToEdge();
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

            setContentView(R.layout.activity_study_session);

            getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
                @Override
                public void handleOnBackPressed() {
                    handleBackAction();
                }
            });

            parseIntent();
            initViews();
            initTorchManager();
            configureModeUI();
            if (isDeepMode) {
                startKioskMode();
            }
            setupBatteryMonitor();
            setupControlPanel();
            setupClockAndSessionLoop();
            setupSmartFocusTimer();
            setupIosControls();
            animateEntrance();
            dynamicIslandController = new StudyDynamicIslandController(this, findViewById(R.id.sessionRoot));
            StudyFocusNotificationManager.startTelephonyMonitoring(this);
            checkAndRequestStudyFocusPermissions();
        } catch (Throwable t) {
            Log.e(TAG, "Error in onCreate", t);
        }
    }

    private void checkAndRequestStudyFocusPermissions() {
        try {
            List<String> perms = new ArrayList<>();
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                perms.add(Manifest.permission.READ_PHONE_STATE);
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                perms.add(Manifest.permission.CALL_PHONE);
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
                perms.add(Manifest.permission.READ_CALL_LOG);
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                perms.add(Manifest.permission.READ_CONTACTS);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
                    perms.add(Manifest.permission.ANSWER_PHONE_CALLS);
                }
            }
            if (!perms.isEmpty()) {
                ActivityCompat.requestPermissions(this, perms.toArray(new String[0]), 8821);
            }

            if (!StudyFocusNotificationManager.isNotificationListenerEnabled(this)) {
                mainHandler.postDelayed(() -> {
                    if (!isFinishing() && !StudyFocusNotificationManager.isNotificationListenerEnabled(this)) {
                        showNotificationAccessPromptDialog();
                    }
                }, 1500);
            }
        } catch (Exception ignored) {}
    }

    private void showNotificationAccessPromptDialog() {
        try {
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert);
            builder.setTitle("🔔 WhatsApp & Call Alerts");
            builder.setMessage("Dynamic Island par WhatsApp calls aur messages dekhne ke liye Study app ki Notification Access enable karein.");
            builder.setPositiveButton("Turn On", (dialog, which) -> {
                StudyFocusNotificationManager.openNotificationAccessSettings(this);
            });
            builder.setNegativeButton("Later", (dialog, which) -> dialog.dismiss());
            builder.show();
        } catch (Exception ignored) {}
    }

    private void makeEdgeToEdge() {
        try {
            Window window = getWindow();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                window.setStatusBarColor(Color.TRANSPARENT);
                window.setNavigationBarColor(Color.TRANSPARENT);
            }
            int uiOptions = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            window.getDecorView().setSystemUiVisibility(uiOptions);
        } catch (Exception ignored) {
        }
    }

    private void parseIntent() {
        Intent intent = getIntent();
        if (intent != null) {
            String modeStr = intent.getStringExtra(EXTRA_MODE);
            isDeepMode = "Deep".equalsIgnoreCase(modeStr);
            targetMinutes = intent.getIntExtra(EXTRA_MINUTES, 60);
        }
    }

    private void initViews() {
        sessionRoot = findViewById(R.id.sessionRoot);

        // Hero Dashboard moved directly to top
        heroDashboardRow = findViewById(R.id.heroDashboardRow);

        // 70% Real Clock Flip Timer
        flipHours = findViewById(R.id.flipHours);
        flipMinutes = findViewById(R.id.flipMinutes);
        flipSeconds = findViewById(R.id.flipSeconds);
        tvFlipStatusPill = findViewById(R.id.tvFlipStatusPill);

        // Control Panel 4 Tiles
        tileBattery = findViewById(R.id.tileBattery);
        tileData = findViewById(R.id.tileData);
        tileWifi = findViewById(R.id.tileWifi);
        tileBluetooth = findViewById(R.id.tileBluetooth);

        // Tile 1: Battery
        ivHeroBatteryIcon = findViewById(R.id.ivHeroBatteryIcon);
        tvDecimalBattery = findViewById(R.id.tvDecimalBattery);
        tvBatteryStatePill = findViewById(R.id.tvBatteryStatePill);

        // Tile 2: Mobile Data
        ivDataIcon = findViewById(R.id.ivDataIcon);
        tvDataTitle = findViewById(R.id.tvDataTitle);
        tvDataStatePill = findViewById(R.id.tvDataStatePill);

        // Tile 3: Wi-Fi
        ivWifiIcon = findViewById(R.id.ivWifiIcon);
        tvWifiTitle = findViewById(R.id.tvWifiTitle);
        tvWifiStatePill = findViewById(R.id.tvWifiStatePill);

        // Tile 4: Bluetooth
        ivBluetoothIcon = findViewById(R.id.ivBluetoothIcon);
        tvBluetoothTitle = findViewById(R.id.tvBluetoothTitle);
        tvBluetoothStatePill = findViewById(R.id.tvBluetoothStatePill);

        // Session Timer Hero Container
        timerHeroContainer = findViewById(R.id.timerHeroContainer);
        focusAuraView = findViewById(R.id.focusAuraView);
        tvTimerDisplay = findViewById(R.id.tvTimerDisplay);
        tvTimerSubtitle = findViewById(R.id.tvTimerSubtitle);
        tvStatusPill = findViewById(R.id.tvStatusPill);

        // Interactive iOS Slide to End Session (Bidirectional)
        sliderContainer = findViewById(R.id.sliderContainer);
        sliderThumb = findViewById(R.id.sliderThumb);
        layoutSliderHintLeft = findViewById(R.id.layoutSliderHintLeft);
        layoutSliderHintRight = findViewById(R.id.layoutSliderHintRight);
        tvSliderHintLeft = findViewById(R.id.tvSliderHintLeft);
        tvSliderHintRight = findViewById(R.id.tvSliderHintRight);
        pikachuDancingView = findViewById(R.id.pikachuDancingView);
        setupSlideToEndInteraction();
        startSliderShimmerAnimation();

        // iOS Bottom Controls
        bottomControlsBar = findViewById(R.id.bottomControlsBar);
        btnIosTorch = findViewById(R.id.btnIosTorch);
        ivTorchIcon = findViewById(R.id.ivTorchIcon);
        btnIosCamera = findViewById(R.id.btnIosCamera);
        ivCameraIcon = findViewById(R.id.ivCameraIcon);
        btnDeepExit = findViewById(R.id.btnDeepExit);
        if (btnDeepExit != null) {
            btnDeepExit.setVisibility(isDeepMode ? View.VISIBLE : View.GONE);
        }

        // Mini Genie Quick Apps Popup (Left Slide Trigger)
        layoutGenieAppsOverlay = findViewById(R.id.layoutGenieAppsOverlay);
        cardGenieApps = findViewById(R.id.cardGenieApps);
        genieScrimDismiss = findViewById(R.id.genieScrimDismiss);
        btnGenieClose = findViewById(R.id.btnGenieClose);
        btnAppWhatsApp = findViewById(R.id.btnAppWhatsApp);
        btnAppDialer = findViewById(R.id.btnAppDialer);
        btnAppContacts = findViewById(R.id.btnAppContacts);
        btnAppMessages = findViewById(R.id.btnAppMessages);

        if (genieScrimDismiss != null) {
            genieScrimDismiss.setOnClickListener(v -> closeGenieAppsPopup());
        }
        if (btnGenieClose != null) {
            btnGenieClose.setOnClickListener(v -> closeGenieAppsPopup());
        }
        if (btnAppWhatsApp != null) {
            btnAppWhatsApp.setOnClickListener(v -> launchWhatsApp());
        }
        if (btnAppDialer != null) {
            btnAppDialer.setOnClickListener(v -> launchDialer());
        }
        if (btnAppContacts != null) {
            btnAppContacts.setOnClickListener(v -> launchContacts());
        }
        if (btnAppMessages != null) {
            btnAppMessages.setOnClickListener(v -> launchMessages());
        }
    }

    private void configureModeUI() {
        int glowColor = isDeepMode ? Color.parseColor("#808B5CF6") : Color.parseColor("#8006B6D4");
        if (flipHours != null) flipHours.setGlowColor(glowColor);
        if (flipMinutes != null) flipMinutes.setGlowColor(glowColor);
        if (flipSeconds != null) flipSeconds.setGlowColor(glowColor);

        if (focusAuraView != null) {
            focusAuraView.setMode(isDeepMode);
        }

        if (isDeepMode) {
            totalSeconds = (long) targetMinutes * 60;
            remainingSeconds = totalSeconds;
            if (tvTimerSubtitle != null) tvTimerSubtitle.setText("COUNTDOWN REMAINING");
            if (tvTimerDisplay != null) tvTimerDisplay.setText(formatSessionSeconds(remainingSeconds));
            if (tvSliderHintLeft != null) tvSliderHintLeft.setText("APPS");
            if (tvSliderHintRight != null) tvSliderHintRight.setText("STUDYTUBE");
        } else {
            elapsedSeconds = 0;
            if (tvTimerSubtitle != null) tvTimerSubtitle.setText("SESSION ELAPSED");
            if (tvTimerDisplay != null) tvTimerDisplay.setText("00:00");
            if (tvSliderHintLeft != null) tvSliderHintLeft.setText("APPS");
            if (tvSliderHintRight != null) tvSliderHintRight.setText("STUDYTUBE");
        }

        if (btnDeepExit != null) {
            btnDeepExit.setVisibility(isDeepMode ? View.VISIBLE : View.GONE);
        }
    }

    /**
     * Drives both:
     * 1) Main real-world time in 75% Flip Clock (Hour : Minute : Second in upward page-turning half flip)
     * 2) Study Session Timer inside FocusSessionAuraView (countdown or stopwatch)
     *    SMART FOCUS TIMER: Freezes instantly when screen is off or locked. Runs only on active screen.
     * 3) Real battery percentage (Normal: XX%, Charging: XX.XX% with current & voltage)
     */
    private void setupClockAndSessionLoop() {
        clockAndSessionRunnable = new Runnable() {
            @Override
            public void run() {
                try {
                    // 1. Update Real Clock Time into 75% Flip Cards (12-hour format)
                    Calendar cal = Calendar.getInstance();
                    int rawHour = cal.get(Calendar.HOUR);
                    int hour = rawHour == 0 ? 12 : rawHour;
                    int minute = cal.get(Calendar.MINUTE);
                    int second = cal.get(Calendar.SECOND);

                    String hStr = String.format(Locale.US, "%02d", hour);
                    String mStr = String.format(Locale.US, "%02d", minute);
                    String sStr = String.format(Locale.US, "%02d", second);

                    if (flipHours != null) flipHours.setValue(hStr);
                    if (flipMinutes != null) flipMinutes.setValue(mStr);
                    if (flipSeconds != null) flipSeconds.setValue(sStr);

                    // 2. Update Session Study Timer (SMART FOCUS TIMER: Screen On check)
                    boolean active = isScreenActive();
                    if (!active) {
                        if (!isTimerFrozen) {
                            freezeSmartFocusTimer("Screen Off");
                        }
                    } else {
                        if (isTimerFrozen) {
                            resumeSmartFocusTimer("Screen On");
                        }

                        if (isDeepMode) {
                            if (remainingSeconds > 0) {
                                remainingSeconds--;
                                String timeStr = formatSessionSeconds(remainingSeconds);
                                if (tvTimerDisplay != null) {
                                    tvTimerDisplay.setText(timeStr);
                                }
                                if (focusAuraView != null && totalSeconds > 0) {
                                    float progressPercent = (remainingSeconds / (float) totalSeconds) * 100f;
                                    focusAuraView.setProgressPercent(progressPercent);
                                }
                            }

                            if (remainingSeconds <= 0 && !isSessionSuccessDialogShown) {
                                isSessionSuccessDialogShown = true;
                                if (tvTimerDisplay != null) {
                                    tvTimerDisplay.setText("00:00");
                                }
                                if (focusAuraView != null) {
                                    focusAuraView.setProgressPercent(0f);
                                }
                                onDeepModeCompleted();
                            }

                            // Strict Kiosk Enforcement: Ensure LockTask remains actively engaged
                            if (remainingSeconds > 0 && !isLaunchingAllowedApp && hasWindowFocus()) {
                                if (!isActuallyInLockTask()) {
                                    startKioskMode();
                                }
                            }
                        } else {
                            // Simple Mode Stopwatch
                            elapsedSeconds++;
                            String elapsedStr = formatSessionSeconds(elapsedSeconds);
                            if (tvTimerDisplay != null) {
                                tvTimerDisplay.setText(elapsedStr);
                            }
                        }
                    }

                    // 3. Keep accurate battery synchronized (XX% when unplugged, XX.XX% when charging)
                    updateRealBatteryStatus();
                } catch (Exception e) {
                    Log.e(TAG, "Error in clockAndSessionRunnable", e);
                }

                mainHandler.postDelayed(this, 1000);
            }
        };
        mainHandler.post(clockAndSessionRunnable);
    }

    /**
     * Smart Focus Timer: Registers hardware broadcast receiver for instant screen off and screen on events.
     * Timer runs whenever screen/display is turned ON (interactive), even if the phone is locked.
     * Timer freezes ONLY when the screen is actually turned OFF.
     */
    private void setupSmartFocusTimer() {
        screenStateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || intent.getAction() == null) return;
                String action = intent.getAction();

                if (Intent.ACTION_SCREEN_OFF.equals(action)) {
                    isScreenActiveState = false;
                    freezeSmartFocusTimer("Screen Off");
                } else if (Intent.ACTION_SCREEN_ON.equals(action) || Intent.ACTION_USER_PRESENT.equals(action)) {
                    isScreenActiveState = true;
                    resumeSmartFocusTimer("Screen On");
                }
            }
        };

        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_USER_PRESENT);

        try {
            registerReceiver(screenStateReceiver, filter);
        } catch (Exception e) {
            Log.e(TAG, "Error registering screen state receiver", e);
        }
    }

    /**
     * Smart Focus Screen State Verification:
     * Returns true whenever the display screen is ON (interactive).
     * Timer runs as long as screen is ON, even if device is locked.
     * Freezes ONLY when screen turns OFF.
     */
    public boolean isScreenActive() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                boolean isInteractive;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
                    isInteractive = pm.isInteractive();
                } else {
                    isInteractive = pm.isScreenOn();
                }
                return isInteractive;
            }
            return isScreenActiveState;
        } catch (Exception e) {
            return isScreenActiveState;
        }
    }

    /**
     * Instantly freezes the Smart Focus Timer when screen is off.
     * Pauses the timer countdown / elapsed tally and pauses glowing aura animations.
     */
    private void freezeSmartFocusTimer(String reason) {
        if (isTimerFrozen) return;
        isTimerFrozen = true;
        freezeStartTimestamp = System.currentTimeMillis();
        Log.i(TAG, "❄️ Smart Focus Timer INSTANT FREEZE: " + reason);

        mainHandler.post(() -> {
            if (focusAuraView != null) {
                focusAuraView.setPaused(true);
            }
            if (tvStatusPill != null) {
                tvStatusPill.setText("❄️ SMART FOCUS • FROZEN");
                tvStatusPill.setTextColor(Color.parseColor("#38BDF8"));
                tvStatusPill.setBackgroundResource(R.drawable.bg_badge_pill);
            }
            if (tvTimerSubtitle != null) {
                tvTimerSubtitle.setText("SCREEN OFF • TIMER FROZEN");
                tvTimerSubtitle.setTextColor(Color.parseColor("#38BDF8"));
            }
            if (tvTimerDisplay != null) {
                tvTimerDisplay.animate().alpha(0.70f).setDuration(220).start();
            }
        });
    }

    /**
     * Resumes the Smart Focus Timer whenever the screen is turned on.
     */
    private void resumeSmartFocusTimer(String reason) {
        if (!isTimerFrozen) return;
        isTimerFrozen = false;
        if (freezeStartTimestamp > 0) {
            totalFrozenSeconds += (System.currentTimeMillis() - freezeStartTimestamp) / 1000;
            freezeStartTimestamp = 0;
        }
        Log.i(TAG, "▶️ Smart Focus Timer RESUMED: " + reason);

        mainHandler.post(() -> {
            if (focusAuraView != null) {
                focusAuraView.setPaused(false);
            }
            if (tvStatusPill != null) {
                if (isDeepMode) {
                    tvStatusPill.setText("● DEEP FOCUS • ACTIVE");
                    tvStatusPill.setTextColor(Color.parseColor("#8B5CF6"));
                } else {
                    tvStatusPill.setText("● SIMPLE FOCUS • ACTIVE");
                    tvStatusPill.setTextColor(Color.parseColor("#10B981"));
                }
                tvStatusPill.setBackgroundResource(R.drawable.bg_glass_pill);
            }
            if (tvTimerSubtitle != null) {
                tvTimerSubtitle.setText(isDeepMode ? "COUNTDOWN REMAINING" : "SESSION ELAPSED");
                tvTimerSubtitle.setTextColor(ContextCompat.getColor(this, R.color.text_muted_sub));
            }
            if (tvTimerDisplay != null) {
                tvTimerDisplay.animate().alpha(1.0f).setDuration(220).start();
            }
        });
    }

    private void setupBatteryMonitor() {
        batteryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                updateBatteryFromIntent(intent);
            }
        };
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(batteryReceiver, filter, Context.RECEIVER_EXPORTED);
            } else {
                registerReceiver(batteryReceiver, filter);
            }
        } catch (Exception e) {
            try {
                registerReceiver(batteryReceiver, filter);
            } catch (Exception ignored) {}
        }

        updateRealBatteryStatus();
    }

    private void updateBatteryFromIntent(Intent intent) {
        if (intent == null) {
            updateRealBatteryStatus();
            return;
        }

        int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        batteryVoltageMv = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0);

        isBatteryCharging = (status == BatteryManager.BATTERY_STATUS_CHARGING
                || status == BatteryManager.BATTERY_STATUS_FULL);

        if (level >= 0 && scale > 0) {
            realBatteryPct = (level * 100.0f) / (float) scale;
        }
        updateRealBatteryStatus();
    }

    private void updateRealBatteryStatus() {
        try {
            // 1. Query sticky battery intent from system
            IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent batteryStatus = registerReceiver(null, ifilter);

            if (batteryStatus != null) {
                int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                batteryVoltageMv = batteryStatus.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0);

                isBatteryCharging = (status == BatteryManager.BATTERY_STATUS_CHARGING
                        || status == BatteryManager.BATTERY_STATUS_FULL);

                if (level >= 0 && scale > 0) {
                    realBatteryPct = (level * 100.0f) / (float) scale;
                }
            }

            // 2. Query hardware fuel gauge properties (current and capacity)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                BatteryManager bm = (BatteryManager) getSystemService(Context.BATTERY_SERVICE);
                if (bm != null) {
                    int currentNow = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
                    if (currentNow != Integer.MIN_VALUE && currentNow != 0) {
                        batteryCurrentUa = Math.abs(currentNow);
                    }
                    if (realBatteryPct < 0) {
                        int cap = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
                        if (cap >= 0 && cap <= 100) {
                            realBatteryPct = (float) cap;
                        }
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (!isBatteryCharging) {
                            isBatteryCharging = bm.isCharging();
                        }
                    }
                }
            }

            if (realBatteryPct < 0) {
                realBatteryPct = 100f;
            }

            // 3. Compute accurate micro-decimal accumulation when charging
            int currentBaseLevel = (int) realBatteryPct;
            long now = System.currentTimeMillis();

            if (!isBatteryCharging) {
                chargingDecimalOffset = 0.0f;
                lastBaseLevel = currentBaseLevel;
                lastChargingTimestamp = now;
            } else {
                if (currentBaseLevel != lastBaseLevel) {
                    chargingDecimalOffset = 0.0f;
                    lastBaseLevel = currentBaseLevel;
                    lastChargingTimestamp = now;
                } else if (lastChargingTimestamp > 0) {
                    long dtMs = now - lastChargingTimestamp;
                    if (dtMs > 0 && dtMs < 10000) {
                        float currentMa = batteryCurrentUa > 0 ? (batteryCurrentUa / 1000f) : 1600f;
                        // Battery capacity ~4500mAh
                        // Micro percentage delta: (currentMa * dtMs) / (4500mAh * 3600000ms) * 100%
                        float deltaPct = (currentMa * dtMs) / (4500f * 36000f);
                        chargingDecimalOffset += deltaPct;
                        if (chargingDecimalOffset > 0.99f) {
                            chargingDecimalOffset = 0.99f;
                        }
                    }
                    lastChargingTimestamp = now;
                } else {
                    lastChargingTimestamp = now;
                }
            }

            renderBatteryUI();
        } catch (Exception e) {
            Log.e(TAG, "Error updating real battery status", e);
        }
    }

    private void renderBatteryUI() {
        if (tvDecimalBattery != null) {
            if (isBatteryCharging) {
                // Charging: high-precision two-decimal percentage: XX.XX%
                float chargingPct = Math.min(100.00f, ((int) realBatteryPct) + chargingDecimalOffset);
                String formattedCharging = String.format(Locale.US, "%.2f%%", chargingPct);
                tvDecimalBattery.setText(formattedCharging);
            } else {
                // Normal (unplugged): clean integer percentage: XX%
                String formattedNormal = String.format(Locale.US, "%d%%", (int) realBatteryPct);
                tvDecimalBattery.setText(formattedNormal);
            }
        }

        // Battery Icon color
        if (ivHeroBatteryIcon != null) {
            if (realBatteryPct <= 20.0f) {
                ivHeroBatteryIcon.setColorFilter(Color.parseColor("#EF4444")); // Red alert
            } else if (realBatteryPct <= 45.0f) {
                ivHeroBatteryIcon.setColorFilter(Color.parseColor("#F59E0B")); // Amber warning
            } else {
                ivHeroBatteryIcon.setColorFilter(ContextCompat.getColor(this, R.color.mint_start)); // Optimal green
            }
        }

        // Battery State Pill
        if (tvBatteryStatePill != null) {
            if (isBatteryCharging) {
                if (batteryVoltageMv > 0 && batteryCurrentUa > 0) {
                    float watts = (batteryVoltageMv / 1000f) * (batteryCurrentUa / 1000000f);
                    if (watts >= 0.5f) {
                        tvBatteryStatePill.setText(String.format(Locale.US, "⚡ %.1fW CHARGING", watts));
                    } else {
                        tvBatteryStatePill.setText("⚡ CHARGING");
                    }
                } else if (batteryVoltageMv > 0) {
                    float volts = batteryVoltageMv / 1000f;
                    tvBatteryStatePill.setText(String.format(Locale.US, "⚡ %.1fV CHARGING", volts));
                } else {
                    tvBatteryStatePill.setText("⚡ CHARGING");
                }
                tvBatteryStatePill.setTextColor(Color.parseColor("#10B981"));
            } else if (realBatteryPct <= 20.0f) {
                tvBatteryStatePill.setText("LOW");
                tvBatteryStatePill.setTextColor(Color.parseColor("#EF4444"));
            } else {
                tvBatteryStatePill.setText("OPTIMAL");
                tvBatteryStatePill.setTextColor(Color.parseColor("#38BDF8"));
            }
        }

        // Active liquid glass tile glow
        if (tileBattery != null) {
            tileBattery.setBackgroundResource(isBatteryCharging ? R.drawable.bg_ios_glass_tile_active : R.drawable.bg_ios_glass_tile);
        }
    }

    // ==========================================
    // Control Panel (Battery, Data, WiFi, BT)
    // ==========================================

    private void setupControlPanel() {
        try {
            connectivityManager = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                BluetoothManager btManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
                if (btManager != null) {
                    bluetoothAdapter = btManager.getAdapter();
                }
            } else {
                bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error initializing hardware connectivity managers", e);
        }

        // 1. Battery Tile Actions (Single tap: quick stats toast, Long press: battery settings)
        setupTileActions(tileBattery, this::showBatteryQuickToast, this::openBatterySettings);

        // 2. Mobile Data Tile Actions (Single tap: toggle/panel, Long press: data usage settings)
        setupTileActions(tileData, this::toggleOrOpenDataPanel, this::openDataSettings);

        // 3. Wi-Fi Tile Actions (Single tap: toggle/panel, Long press: wifi settings)
        setupTileActions(tileWifi, this::toggleWifi, this::openWifiSettings);

        // 4. Bluetooth Tile Actions (Single tap: toggle, Long press: bluetooth settings)
        setupTileActions(tileBluetooth, this::toggleBluetooth, this::openBluetoothSettings);

        // Register broadcast receiver for real-time Wi-Fi, BT, Network updates
        setupNetworkAndBtReceiver();

        // Initial UI sync
        updateNetworkStates();
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupTileActions(final View targetTile, final Runnable onSingleTap, final Runnable onLongPress) {
        if (targetTile == null) return;

        final long LONG_PRESS_THRESHOLD = 380; // ms
        final boolean[] isLongPressTriggered = new boolean[]{false};
        final float[] downX = new float[1];
        final float[] downY = new float[1];

        final Runnable longPressRunnable = new Runnable() {
            @Override
            public void run() {
                isLongPressTriggered[0] = true;
                try {
                    targetTile.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                } catch (Exception ignored) {}

                targetTile.animate()
                        .scaleX(1.06f)
                        .scaleY(1.06f)
                        .setDuration(120)
                        .setInterpolator(new OvershootInterpolator(1.4f))
                        .withEndAction(() -> {
                            targetTile.animate()
                                    .scaleX(1.0f)
                                    .scaleY(1.0f)
                                    .setDuration(100)
                                    .setInterpolator(new DecelerateInterpolator())
                                    .start();
                        })
                        .start();

                if (onLongPress != null) {
                    onLongPress.run();
                }
            }
        };

        targetTile.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    if (v.getParent() != null) {
                        v.getParent().requestDisallowInterceptTouchEvent(true);
                    }
                    isLongPressTriggered[0] = false;
                    downX[0] = event.getX();
                    downY[0] = event.getY();
                    try {
                        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                    } catch (Exception ignored) {}

                    v.animate()
                            .scaleX(0.95f)
                            .scaleY(0.95f)
                            .setDuration(100)
                            .setInterpolator(new DecelerateInterpolator())
                            .start();

                    mainHandler.postDelayed(longPressRunnable, LONG_PRESS_THRESHOLD);
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float deltaX = Math.abs(event.getX() - downX[0]);
                    float deltaY = Math.abs(event.getY() - downY[0]);
                    if (deltaX > dpToPx(32) || deltaY > dpToPx(32)) {
                        mainHandler.removeCallbacks(longPressRunnable);
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                    if (v.getParent() != null) {
                        v.getParent().requestDisallowInterceptTouchEvent(false);
                    }
                    mainHandler.removeCallbacks(longPressRunnable);
                    v.animate()
                            .scaleX(1.0f)
                            .scaleY(1.0f)
                            .setDuration(120)
                            .setInterpolator(new DecelerateInterpolator())
                            .start();

                    if (!isLongPressTriggered[0]) {
                        try {
                            v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                        } catch (Exception ignored) {}
                        if (onSingleTap != null) {
                            onSingleTap.run();
                        }
                    }
                    return true;

                case MotionEvent.ACTION_CANCEL:
                    if (v.getParent() != null) {
                        v.getParent().requestDisallowInterceptTouchEvent(false);
                    }
                    mainHandler.removeCallbacks(longPressRunnable);
                    v.animate()
                            .scaleX(1.0f)
                            .scaleY(1.0f)
                            .setDuration(100)
                            .start();
                    return true;
            }
            return false;
        });
    }

    private void showBatteryQuickToast() {
        String state = isBatteryCharging ? "⚡ Charging" : "🔋 Discharging";
        String pctStr = tvDecimalBattery != null ? tvDecimalBattery.getText().toString() : String.format(Locale.US, "%.1f%%", realBatteryPct);
        String details = "Battery: " + pctStr + " (" + state + ")";
        if (batteryVoltageMv > 0) {
            details += " • " + String.format(Locale.US, "%.2fV", batteryVoltageMv / 1000f);
        }
        Toast.makeText(this, details, Toast.LENGTH_SHORT).show();
    }

    /**
     * Ensures any targeted settings activity package is whitelisted in LockTask mode on the fly,
     * so that Android never blocks Wi-Fi, Bluetooth or Mobile Data settings in Deep Mode.
     */
    private void ensurePackageWhitelistedForLockTask(String targetPackage) {
        if (targetPackage == null || !isDeepMode) return;
        try {
            if (devicePolicyManager == null) {
                devicePolicyManager = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
            }
            if (adminComponentName == null) {
                adminComponentName = new ComponentName(this, StudyDeviceAdminReceiver.class);
            }
            if (devicePolicyManager != null && adminComponentName != null && devicePolicyManager.isDeviceOwnerApp(getPackageName())) {
                String[] current = devicePolicyManager.getLockTaskPackages(adminComponentName);
                boolean exists = false;
                if (current != null) {
                    for (String p : current) {
                        if (targetPackage.equals(p)) {
                            exists = true;
                            break;
                        }
                    }
                }
                if (!exists) {
                    List<String> list = new ArrayList<>();
                    if (current != null) Collections.addAll(list, current);
                    list.add(targetPackage);
                    devicePolicyManager.setLockTaskPackages(adminComponentName, list.toArray(new String[0]));
                    Log.i(TAG, "Dynamically whitelisted for LockTask: " + targetPackage);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error ensuring package whitelisted for LockTask: " + targetPackage, e);
        }
    }

    private void openBatterySettings() {
        isLaunchingAllowedApp = true;
        Intent[] batteryIntents = new Intent[] {
            new Intent(Intent.ACTION_POWER_USAGE_SUMMARY),
            new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS),
            new Intent(Settings.ACTION_SETTINGS)
        };
        for (Intent intent : batteryIntents) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                ComponentName cn = intent.resolveActivity(getPackageManager());
                if (cn != null) {
                    ensurePackageWhitelistedForLockTask(cn.getPackageName());
                    startActivity(intent);
                    return;
                }
            } catch (Exception ignored) {}
        }
        Toast.makeText(this, "Battery settings not available", Toast.LENGTH_SHORT).show();
    }

    /**
     * Mobile Data - Single Click: Direct Toggle ONLY (Never opens full settings on single click).
     */
    private void toggleOrOpenDataPanel() {
        boolean isConnected = false;
        if (connectivityManager != null) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    Network net = connectivityManager.getActiveNetwork();
                    if (net != null) {
                        NetworkCapabilities caps = connectivityManager.getNetworkCapabilities(net);
                        if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                            isConnected = true;
                        }
                    }
                }
            } catch (Exception ignored) {}
        }

        // 1. Try reflection on TelephonyManager
        try {
            TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
            if (tm != null) {
                Method setMobileDataEnabled = tm.getClass().getDeclaredMethod("setDataEnabled", boolean.class);
                setMobileDataEnabled.setAccessible(true);
                setMobileDataEnabled.invoke(tm, !isConnected);
                Toast.makeText(this, !isConnected ? "Mobile Data turning ON" : "Mobile Data turning OFF", Toast.LENGTH_SHORT).show();
                mainHandler.postDelayed(this::updateDataUI, 600);
                return;
            }
        } catch (Exception ignored) {}

        // 2. Try shell command if rooted/adb
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"svc", "data", (!isConnected ? "enable" : "disable")});
            p.waitFor();
            Toast.makeText(this, !isConnected ? "Mobile Data turning ON" : "Mobile Data turning OFF", Toast.LENGTH_SHORT).show();
            mainHandler.postDelayed(this::updateDataUI, 600);
            return;
        } catch (Exception ignored) {}

        // 3. Floating native quick panel toggle (does NOT open full settings)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                isLaunchingAllowedApp = true;
                Intent panelIntent = new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY);
                panelIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(panelIntent);
                return;
            } catch (Exception ignored) {}
        }

        Toast.makeText(this, "Mobile Data toggle restricted by Android. Long press for settings.", Toast.LENGTH_SHORT).show();
    }

    /**
     * Mobile Data - Long Press: Open More Settings (SIM & Mobile Networks / Data Usage).
     */
    private void openDataSettings() {
        isLaunchingAllowedApp = true;
        Intent[] dataIntents = new Intent[] {
            new Intent(Settings.ACTION_DATA_USAGE_SETTINGS),
            new Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS),
            new Intent(Settings.ACTION_WIRELESS_SETTINGS),
            new Intent(Settings.ACTION_SETTINGS)
        };
        for (Intent intent : dataIntents) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                ComponentName cn = intent.resolveActivity(getPackageManager());
                if (cn != null) {
                    ensurePackageWhitelistedForLockTask(cn.getPackageName());
                    startActivity(intent);
                    return;
                }
            } catch (Exception ignored) {}
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                Intent panelIntent = new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY);
                panelIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ComponentName cn = panelIntent.resolveActivity(getPackageManager());
                if (cn != null) ensurePackageWhitelistedForLockTask(cn.getPackageName());
                startActivity(panelIntent);
                return;
            } catch (Exception ignored) {}
        }
        Toast.makeText(this, "Mobile network settings not accessible", Toast.LENGTH_SHORT).show();
    }

    /**
     * Wi-Fi - Single Click: Direct Toggle ONLY (Never opens full settings on single click).
     */
    private void toggleWifi() {
        if (wifiManager == null) {
            Toast.makeText(this, "Wi-Fi not available", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean currentEnabled = false;
        try {
            currentEnabled = wifiManager.isWifiEnabled();
        } catch (Exception ignored) {}

        // 1. Try direct toggle via WifiManager
        try {
            boolean success = wifiManager.setWifiEnabled(!currentEnabled);
            if (success) {
                Toast.makeText(this, !currentEnabled ? "Wi-Fi turning ON" : "Wi-Fi turning OFF", Toast.LENGTH_SHORT).show();
                mainHandler.postDelayed(this::updateWifiUI, 600);
                return;
            }
        } catch (Exception ignored) {}

        // 2. Try shell command if rooted/adb
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"svc", "wifi", (!currentEnabled ? "enable" : "disable")});
            p.waitFor();
            Toast.makeText(this, !currentEnabled ? "Wi-Fi turning ON" : "Wi-Fi turning OFF", Toast.LENGTH_SHORT).show();
            mainHandler.postDelayed(this::updateWifiUI, 600);
            return;
        } catch (Exception ignored) {}

        // 3. On Android 10+ (API 29+), open floating quick-switch panel (NOT full settings)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                isLaunchingAllowedApp = true;
                Intent panelIntent = new Intent(Settings.Panel.ACTION_WIFI);
                panelIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(panelIntent);
                return;
            } catch (Exception ignored) {}
        }

        Toast.makeText(this, "Wi-Fi toggle restricted by OS. Long press for settings.", Toast.LENGTH_SHORT).show();
    }

    /**
     * Wi-Fi - Long Press: Open More Settings (Full Wi-Fi preferences & network list).
     */
    private void openWifiSettings() {
        isLaunchingAllowedApp = true;
        Intent[] wifiIntents = new Intent[] {
            new Intent(Settings.ACTION_WIFI_SETTINGS),
            new Intent(Settings.ACTION_WIRELESS_SETTINGS),
            new Intent(Settings.ACTION_SETTINGS)
        };
        for (Intent intent : wifiIntents) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                ComponentName cn = intent.resolveActivity(getPackageManager());
                if (cn != null) {
                    ensurePackageWhitelistedForLockTask(cn.getPackageName());
                    startActivity(intent);
                    return;
                }
            } catch (Exception ignored) {}
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                Intent panelIntent = new Intent(Settings.Panel.ACTION_WIFI);
                panelIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ComponentName cn = panelIntent.resolveActivity(getPackageManager());
                if (cn != null) ensurePackageWhitelistedForLockTask(cn.getPackageName());
                startActivity(panelIntent);
                return;
            } catch (Exception ignored) {}
        }
        Toast.makeText(this, "Wi-Fi settings not accessible", Toast.LENGTH_SHORT).show();
    }

    /**
     * Bluetooth - Single Click: Direct Toggle ONLY (Never opens full settings on single click).
     */
    private void toggleBluetooth() {
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth not supported on this device", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check runtime permission for Android 12+ (API 31+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, "android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.BLUETOOTH_CONNECT"}, RC_BT_CONNECT_PERMISSION);
                Toast.makeText(this, "Please grant Bluetooth permission to toggle", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        try {
            if (bluetoothAdapter.isEnabled()) {
                // Turn OFF directly
                boolean disabled = bluetoothAdapter.disable();
                if (disabled) {
                    Toast.makeText(this, "Bluetooth turning OFF", Toast.LENGTH_SHORT).show();
                    mainHandler.postDelayed(this::updateBtUI, 500);
                } else {
                    try {
                        Runtime.getRuntime().exec("svc bluetooth disable");
                    } catch (Exception ignored) {}
                    mainHandler.postDelayed(this::updateBtUI, 500);
                    Toast.makeText(this, "Bluetooth turning OFF", Toast.LENGTH_SHORT).show();
                }
            } else {
                // Turn ON directly
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    isLaunchingAllowedApp = true;
                    Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    enableBtIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(enableBtIntent);
                } else {
                    boolean enabled = bluetoothAdapter.enable();
                    if (enabled) {
                        Toast.makeText(this, "Bluetooth turning ON", Toast.LENGTH_SHORT).show();
                        mainHandler.postDelayed(this::updateBtUI, 500);
                    } else {
                        isLaunchingAllowedApp = true;
                        startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
                    }
                }
            }
        } catch (SecurityException se) {
            Log.e(TAG, "Bluetooth security exception", se);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                requestPermissions(new String[]{"android.permission.BLUETOOTH_CONNECT"}, RC_BT_CONNECT_PERMISSION);
            } else {
                Toast.makeText(this, "Bluetooth permission required to toggle", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e(TAG, "Bluetooth toggle error", e);
            Toast.makeText(this, "Failed to toggle Bluetooth", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Bluetooth - Long Press: Open More Settings (Full Bluetooth preferences & paired devices).
     */
    private void openBluetoothSettings() {
        isLaunchingAllowedApp = true;
        Intent[] btIntents = new Intent[] {
            new Intent(Settings.ACTION_BLUETOOTH_SETTINGS),
            new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),
            new Intent(Settings.ACTION_WIRELESS_SETTINGS),
            new Intent(Settings.ACTION_SETTINGS)
        };
        for (Intent intent : btIntents) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                ComponentName cn = intent.resolveActivity(getPackageManager());
                if (cn != null) {
                    ensurePackageWhitelistedForLockTask(cn.getPackageName());
                    startActivity(intent);
                    return;
                }
            } catch (Exception ignored) {}
        }
        Toast.makeText(this, "Bluetooth settings not accessible", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 8821) {
            StudyFocusNotificationManager.startTelephonyMonitoring(this);
            if (dynamicIslandController != null) {
                dynamicIslandController.refreshData();
            }
        } else if (requestCode == RC_BT_CONNECT_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                toggleBluetooth();
            } else {
                Toast.makeText(this, "Bluetooth permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void setupNetworkAndBtReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        filter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        filter.addAction(BluetoothAdapter.ACTION_CONNECTION_STATE_CHANGED);
        filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
        filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);

        networkAndBtReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                updateNetworkStates();
            }
        };

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(networkAndBtReceiver, filter, Context.RECEIVER_EXPORTED);
            } else {
                registerReceiver(networkAndBtReceiver, filter);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to register network/bt receiver", e);
        }
    }

    private void updateNetworkStates() {
        updateDataUI();
        updateWifiUI();
        updateBtUI();
    }

    private void updateDataUI() {
        boolean isCellularConnected = false;
        if (connectivityManager != null) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    Network net = connectivityManager.getActiveNetwork();
                    if (net != null) {
                        NetworkCapabilities caps = connectivityManager.getNetworkCapabilities(net);
                        if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                            isCellularConnected = true;
                        }
                    }
                } else {
                    NetworkInfo info = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
                    if (info != null && info.isConnected()) {
                        isCellularConnected = true;
                    }
                }
            } catch (Exception ignored) {}
        }

        if (tileData != null) {
            tileData.setBackgroundResource(isCellularConnected ? R.drawable.bg_ios_glass_tile_active : R.drawable.bg_ios_glass_tile);
        }

        if (ivDataIcon != null && tvDataStatePill != null) {
            if (isCellularConnected) {
                ivDataIcon.setColorFilter(Color.parseColor("#10B981"));
                tvDataStatePill.setText("ON RUNNING");
                tvDataStatePill.setTextColor(Color.parseColor("#10B981"));
            } else {
                ivDataIcon.setColorFilter(Color.parseColor("#64748B"));
                tvDataStatePill.setText("OFF");
                tvDataStatePill.setTextColor(Color.parseColor("#64748B"));
            }
        }
    }

    private void updateWifiUI() {
        boolean isWifiEnabled = false;
        boolean isWifiConnected = false;

        if (wifiManager != null) {
            try {
                isWifiEnabled = wifiManager.isWifiEnabled();
                if (isWifiEnabled) {
                    WifiInfo wifiInfo = wifiManager.getConnectionInfo();
                    if (wifiInfo != null && wifiInfo.getNetworkId() != -1) {
                        isWifiConnected = true;
                    }
                }
            } catch (Exception ignored) {}
        }

        if (connectivityManager != null && !isWifiConnected && isWifiEnabled) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    Network net = connectivityManager.getActiveNetwork();
                    if (net != null) {
                        NetworkCapabilities caps = connectivityManager.getNetworkCapabilities(net);
                        if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                            isWifiConnected = true;
                        }
                    }
                } else {
                    NetworkInfo netInfo = connectivityManager.getActiveNetworkInfo();
                    if (netInfo != null && netInfo.isConnected() && netInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                        isWifiConnected = true;
                    }
                }
            } catch (Exception ignored) {}
        }

        if (tileWifi != null) {
            tileWifi.setBackgroundResource(isWifiConnected ? R.drawable.bg_ios_glass_tile_active : R.drawable.bg_ios_glass_tile);
        }

        if (ivWifiIcon != null && tvWifiStatePill != null) {
            if (isWifiConnected) {
                // Connected to Wi-Fi network: "ON RUNNING"
                ivWifiIcon.setColorFilter(Color.parseColor("#10B981"));
                tvWifiStatePill.setText("ON RUNNING");
                tvWifiStatePill.setTextColor(Color.parseColor("#10B981"));
            } else if (isWifiEnabled) {
                // Wi-Fi ON, but not connected: "ON"
                ivWifiIcon.setColorFilter(Color.parseColor("#38BDF8"));
                tvWifiStatePill.setText("ON");
                tvWifiStatePill.setTextColor(Color.parseColor("#38BDF8"));
            } else {
                // Wi-Fi OFF: "OFF"
                ivWifiIcon.setColorFilter(Color.parseColor("#64748B"));
                tvWifiStatePill.setText("OFF");
                tvWifiStatePill.setTextColor(Color.parseColor("#64748B"));
            }
        }
    }

    private boolean isAnyBluetoothDeviceConnected() {
        if (bluetoothAdapter == null) return false;
        try {
            if (!bluetoothAdapter.isEnabled()) return false;
        } catch (Exception ignored) {
            return false;
        }

        try {
            Method getConnectionStateMethod = bluetoothAdapter.getClass().getMethod("getConnectionState");
            int state = (int) getConnectionStateMethod.invoke(bluetoothAdapter);
            if (state == BluetoothAdapter.STATE_CONNECTED) {
                return true;
            }
        } catch (Exception ignored) {}

        try {
            if (bluetoothAdapter.getProfileConnectionState(BluetoothProfile.A2DP) == BluetoothProfile.STATE_CONNECTED) {
                return true;
            }
            if (bluetoothAdapter.getProfileConnectionState(BluetoothProfile.HEADSET) == BluetoothProfile.STATE_CONNECTED) {
                return true;
            }
            if (bluetoothAdapter.getProfileConnectionState(BluetoothProfile.GATT) == BluetoothProfile.STATE_CONNECTED) {
                return true;
            }
        } catch (Exception ignored) {}

        try {
            Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
            if (pairedDevices != null) {
                for (BluetoothDevice device : pairedDevices) {
                    Method isConnectedMethod = device.getClass().getMethod("isConnected");
                    boolean isConnected = (boolean) isConnectedMethod.invoke(device);
                    if (isConnected) return true;
                }
            }
        } catch (Exception ignored) {}

        return false;
    }

    private void updateBtUI() {
        boolean isBtOn = false;
        if (bluetoothAdapter != null) {
            try {
                isBtOn = bluetoothAdapter.isEnabled();
            } catch (Exception ignored) {}
        }

        boolean isBtConnected = isBtOn && isAnyBluetoothDeviceConnected();

        if (tileBluetooth != null) {
            tileBluetooth.setBackgroundResource((isBtConnected || isBtOn) ? R.drawable.bg_ios_glass_tile_active : R.drawable.bg_ios_glass_tile);
        }

        if (ivBluetoothIcon != null && tvBluetoothStatePill != null) {
            if (isBtConnected) {
                // Any Bluetooth device connected: "ON RUNNING"
                ivBluetoothIcon.setColorFilter(Color.parseColor("#10B981"));
                tvBluetoothStatePill.setText("ON RUNNING");
                tvBluetoothStatePill.setTextColor(Color.parseColor("#10B981"));
            } else if (isBtOn) {
                // Bluetooth ON, but idle: "ON"
                ivBluetoothIcon.setColorFilter(Color.parseColor("#818CF8"));
                tvBluetoothStatePill.setText("ON");
                tvBluetoothStatePill.setTextColor(Color.parseColor("#818CF8"));
            } else {
                // Bluetooth OFF: "OFF"
                ivBluetoothIcon.setColorFilter(Color.parseColor("#64748B"));
                tvBluetoothStatePill.setText("OFF");
                tvBluetoothStatePill.setTextColor(Color.parseColor("#64748B"));
            }
        }
    }

    // ==========================================
    // iOS Lock Screen Torch & Camera Controls
    // ==========================================

    private void initTorchManager() {
        StudyTorchManager.getInstance(this).addListener(isTorchOn -> {
            isTorchActive = isTorchOn;
            updateTorchUI();
        });
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupIosControls() {
        // 1. iOS Torch (Long Press Only)
        attachIosLongPress(btnIosTorch, this::toggleTorch);

        // 2. iOS Camera (Long Press Only)
        attachIosLongPress(btnIosCamera, this::launchCamera);

        // 3. Deep Mode Kiosk Exit Button (Safe Exit Fail-safe)
        if (btnDeepExit != null) {
            btnDeepExit.setOnClickListener(v -> handleEmergencyExit());
        }
    }

    /**
     * Emergency / Testing Safe-Exit for Deep Mode Kiosk:
     * Immediately releases Kiosk LockTask mode, stops overlay service,
     * turns off torch, and safely exits session back to home.
     */
    private void handleEmergencyExit() {
        StudyTorchManager.getInstance(this).setTorch(false);
        try {
            if (btnDeepExit != null) {
                btnDeepExit.performHapticFeedback(HapticFeedbackConstants.CONFIRM);
                btnDeepExit.animate()
                        .scaleX(0.90f)
                        .scaleY(0.90f)
                        .setDuration(90)
                        .withEndAction(() -> {
                            if (btnDeepExit != null) {
                                btnDeepExit.animate().scaleX(1.0f).scaleY(1.0f).setDuration(90).start();
                            }
                        })
                        .start();
            }
        } catch (Exception ignored) {}

        Toast.makeText(this, "Exited Deep Mode Kiosk ✓", Toast.LENGTH_SHORT).show();
        exitSession();
    }

    /**
     * Authentic iOS Lock Screen Long Press (Press-and-Hold Only):
     * - Press Down: Subtle button shrink (0.90x) + light tactile virtual key haptic.
     * - Tap / Short Release (< 400ms): Cancels trigger and smoothly springs back to 1.0x (NO action fired).
     * - Press and Hold (>= 400ms): Confirmed pop haptic feedback + spring pop bounce (1.12x -> 1.0x) + executes action!
     */
    @SuppressLint("ClickableViewAccessibility")
    private void attachIosLongPress(final View targetView, final Runnable action) {
        if (targetView == null) return;

        final long LONG_PRESS_DURATION = 400; // ms (Authentic iOS hold threshold)
        final boolean[] isTriggered = new boolean[]{false};
        final Runnable triggerRunnable = new Runnable() {
            @Override
            public void run() {
                isTriggered[0] = true;
                try {
                    targetView.performHapticFeedback(HapticFeedbackConstants.CONFIRM);
                } catch (Exception ignored) {}

                targetView.animate()
                        .scaleX(1.12f)
                        .scaleY(1.12f)
                        .setDuration(130)
                        .setInterpolator(new OvershootInterpolator(1.4f))
                        .withEndAction(() -> {
                            targetView.animate()
                                    .scaleX(1.0f)
                                    .scaleY(1.0f)
                                    .setDuration(120)
                                    .setInterpolator(new DecelerateInterpolator())
                                    .start();
                        })
                        .start();

                if (action != null) {
                    action.run();
                }
            }
        };

        targetView.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    isTriggered[0] = false;
                    try {
                        v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                    } catch (Exception ignored) {}

                    v.animate()
                            .scaleX(0.90f)
                            .scaleY(0.90f)
                            .setDuration(110)
                            .setInterpolator(new DecelerateInterpolator())
                            .start();

                    mainHandler.postDelayed(triggerRunnable, LONG_PRESS_DURATION);
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    mainHandler.removeCallbacks(triggerRunnable);
                    v.animate()
                            .scaleX(1.0f)
                            .scaleY(1.0f)
                            .setDuration(130)
                            .setInterpolator(new DecelerateInterpolator())
                            .start();
                    return true;
            }
            return false;
        });
    }

    private void toggleTorch() {
        StudyTorchManager.getInstance(this).toggleTorch();
        boolean active = StudyTorchManager.getInstance(this).isTorchOn();
        Toast.makeText(this, active ? "Flashlight On" : "Flashlight Off", Toast.LENGTH_SHORT).show();
    }

    private void updateTorchUI() {
        if (btnIosTorch != null && ivTorchIcon != null) {
            if (isTorchActive) {
                btnIosTorch.setBackgroundResource(R.drawable.bg_ios_lock_button_active);
                ivTorchIcon.setColorFilter(Color.parseColor("#0F172A"));
            } else {
                btnIosTorch.setBackgroundResource(R.drawable.bg_ios_lock_button);
                ivTorchIcon.setColorFilter(Color.WHITE);
            }
        }
    }

    private void launchCamera() {
        notifyLaunchingAllowedApp();
        try {
            Intent intent = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
                return;
            }
        } catch (Exception ignored) {}

        try {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
                return;
            }
        } catch (Exception ignored) {}

        // Fallback: search known camera package names across all phone brands
        String[] knownCameraPackages = new String[] {
            "com.google.android.GoogleCamera",
            "com.android.camera",
            "com.android.camera2",
            "com.sec.android.app.camera",
            "com.samsung.android.camera",
            "com.oppo.camera",
            "com.oneplus.camera",
            "com.motorola.camera",
            "com.motorola.camera2",
            "com.motorola.camera3",
            "com.huawei.camera",
            "com.transsion.camera",
            "com.miui.camera",
            "org.lineageos.aperture"
        };
        PackageManager pm = getPackageManager();
        for (String pkg : knownCameraPackages) {
            try {
                Intent launchIntent = pm.getLaunchIntentForPackage(pkg);
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launchIntent);
                    return;
                }
            } catch (Exception ignored) {}
        }
        Toast.makeText(this, "Camera app not found", Toast.LENGTH_SHORT).show();
    }

    private void confirmEndSession() {
        if (isDeepMode && remainingSeconds > 0) {
            Toast.makeText(this, "🔒 Deep Mode Kiosk: Locked until timer completes!", Toast.LENGTH_SHORT).show();
            try {
                if (sessionRoot != null) {
                    sessionRoot.performHapticFeedback(HapticFeedbackConstants.REJECT);
                }
            } catch (Exception ignored) {}
            resetSlider();
            return;
        }
        try {
            Dialog endDialog = new Dialog(this);
            endDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            endDialog.setContentView(R.layout.dialog_end_session);

            if (endDialog.getWindow() != null) {
                endDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                lp.copyFrom(endDialog.getWindow().getAttributes());
                lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.90);
                endDialog.getWindow().setAttributes(lp);
            }

            TextView tvTitle = endDialog.findViewById(R.id.tvEndSessionTitle);
            TextView tvSpent = endDialog.findViewById(R.id.tvEndSessionTimeSpent);
            TextView tvMsg = endDialog.findViewById(R.id.tvEndSessionMessage);
            AppCompatButton btnKeep = endDialog.findViewById(R.id.btnKeepStudying);
            AppCompatButton btnEnd = endDialog.findViewById(R.id.btnEndSessionConfirm);

            long spentSecs = isDeepMode ? (totalSeconds - remainingSeconds) : elapsedSeconds;
            if (spentSecs < 0) spentSecs = 0;
            String timeSpent = formatSpentSeconds(spentSecs);
            if (tvSpent != null) {
                tvSpent.setText(timeSpent);
            }
            if (tvMsg != null) {
                if (spentSecs < 60) {
                    tvMsg.setText("Every second counts. Ready to take a break or jump back in?");
                } else {
                    tvMsg.setText("Great effort! Every focused minute compounds into mastery.");
                }
            }

            if (btnKeep != null) {
                btnKeep.setOnClickListener(v -> endDialog.dismiss());
            }

            if (btnEnd != null) {
                btnEnd.setOnClickListener(v -> {
                    endDialog.dismiss();
                    exitSession();
                });
            }

            endDialog.setOnDismissListener(d -> resetSlider());
            endDialog.show();
        } catch (Exception e) {
            exitSession();
        }
    }

    /**
     * Celebratory Success Modal when Deep Mode countdown hits 0.
     * Features:
     * - Success colors & fanfare (Trophy badge, emerald green victory typography).
     * - "Continue in Simple Mode" option (converts to continuous stopwatch focus without interruption).
     * - "Exit Session" option (graceful exit back to home).
     */
    private void onDeepModeCompleted() {
        try {
            StudyDynamicIslandOverlayService.stopOverlay(this);
            stopKioskMode();
            if (tvStatusPill != null) {
                tvStatusPill.setText("🎉 GOAL ACHIEVED!");
                tvStatusPill.setTextColor(Color.parseColor("#34D399"));
            }

            try {
                if (sessionRoot != null) {
                    sessionRoot.performHapticFeedback(HapticFeedbackConstants.CONFIRM);
                }
            } catch (Exception ignored) {}

            Dialog successDialog = new Dialog(this);
            successDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            successDialog.setContentView(R.layout.dialog_deep_session_success);

            if (successDialog.getWindow() != null) {
                successDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                lp.copyFrom(successDialog.getWindow().getAttributes());
                lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.90);
                successDialog.getWindow().setAttributes(lp);
            }

            TextView tvDuration = successDialog.findViewById(R.id.tvSuccessDuration);
            TextView tvTargetPill = successDialog.findViewById(R.id.tvSuccessTargetPill);
            AppCompatButton btnContinueSimple = successDialog.findViewById(R.id.btnContinueSimpleMode);
            AppCompatButton btnExit = successDialog.findViewById(R.id.btnExitCompletedSession);

            if (tvDuration != null) {
                tvDuration.setText(formatMinutes(targetMinutes));
            }
            if (tvTargetPill != null) {
                tvTargetPill.setText("🎯 " + targetMinutes + " MIN GOAL ACHIEVED");
            }

            if (btnContinueSimple != null) {
                btnContinueSimple.setOnClickListener(v -> {
                    successDialog.dismiss();
                    continueInSimpleMode();
                });
            }

            if (btnExit != null) {
                btnExit.setOnClickListener(v -> {
                    successDialog.dismiss();
                    exitSession();
                });
            }

            successDialog.setCanceledOnTouchOutside(false);
            successDialog.show();
        } catch (Exception e) {
            Log.e(TAG, "Failed to display session success dialog", e);
            exitSession();
        }
    }

    private void continueInSimpleMode() {
        try {
            stopKioskMode();
            isDeepMode = false;
            elapsedSeconds = totalSeconds; // Start seamless continuous counting from the completed duration
            isSessionSuccessDialogShown = false;

            if (tvTimerSubtitle != null) {
                tvTimerSubtitle.setText("CONTINUOUS SIMPLE FOCUS");
            }
            if (tvStatusPill != null) {
                tvStatusPill.setText("SIMPLE • RUNNING");
                tvStatusPill.setTextColor(Color.parseColor("#38BDF8"));
            }
            if (focusAuraView != null) {
                focusAuraView.setMode(false);
                focusAuraView.setProgressPercent(100f);
            }
            configureModeUI();
            Toast.makeText(this, "Switched to Simple Mode! Keep going!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e(TAG, "Error switching to Simple Mode", e);
        }
    }

    private void exitSession() {
        StudyDynamicIslandOverlayService.stopOverlay(this);
        stopKioskMode();
        if (isTorchActive && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && cameraManager != null && backCameraId != null) {
            try {
                cameraManager.setTorchMode(backCameraId, false);
                isTorchActive = false;
            } catch (Exception ignored) {}
        }

        sessionRoot.animate()
                .alpha(0f)
                .scaleX(0.96f)
                .scaleY(0.96f)
                .setDuration(350)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(this::finish)
                .start();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    /**
     * Activates hardware-level Kiosk LockTask mode for Deep Mode only.
     * When provisioned as Device Owner:
     * - Disables Home button, Recents button, status bar swipe, notifications, power menu actions.
     * - Dynamically whitelists all installed Camera, Phone, Messaging, Contacts, WhatsApp, and YouTube apps.
     * When not Device Owner:
     * - Falls back to system screen pinning LockTask mode.
     */
    private void startKioskMode() {
        if (!isDeepMode || remainingSeconds <= 0) {
            return; // Simple mode or finished session is NEVER kiosk locked
        }
        try {
            if (devicePolicyManager == null) {
                devicePolicyManager = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
            }
            if (adminComponentName == null) {
                adminComponentName = new ComponentName(this, StudyDeviceAdminReceiver.class);
            }

            if (isDeviceOwner()) {
                String[] kioskPackages = getWhitelistedKioskPackages();
                devicePolicyManager.setLockTaskPackages(adminComponentName, kioskPackages);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    devicePolicyManager.setLockTaskFeatures(adminComponentName, DevicePolicyManager.LOCK_TASK_FEATURE_NONE);
                }
                Log.i(TAG, "Device Owner LockTask whitelisting configured with " + kioskPackages.length + " packages");
            }

            startLockTask();
            isKioskActive = true;
            Log.i(TAG, "Kiosk Mode locked for Deep Focus");
        } catch (Exception e) {
            Log.e(TAG, "Failed to start Kiosk mode", e);
        }
    }

    /**
     * Dynamically gathers all installed Camera, Phone, Messaging, Contacts,
     * WhatsApp, YouTube, and System packages to ensure 100% full functionality inside Kiosk mode.
     */
    private String[] getWhitelistedKioskPackages() {
        Set<String> packages = new HashSet<>();
        packages.add(getPackageName());

        PackageManager pm = getPackageManager();

        // 1. All Camera apps (System camera, Google Camera, Samsung, Xiaomi, Oppo, Vivo, Motorola, etc.)
        try {
            Intent cameraIntent = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            List<ResolveInfo> cameraList = pm.queryIntentActivities(cameraIntent, 0);
            if (cameraList != null) {
                for (ResolveInfo ri : cameraList) {
                    if (ri.activityInfo != null && ri.activityInfo.packageName != null) {
                        packages.add(ri.activityInfo.packageName);
                    }
                }
            }
            Intent captureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            List<ResolveInfo> captureList = pm.queryIntentActivities(captureIntent, 0);
            if (captureList != null) {
                for (ResolveInfo ri : captureList) {
                    if (ri.activityInfo != null && ri.activityInfo.packageName != null) {
                        packages.add(ri.activityInfo.packageName);
                    }
                }
            }
        } catch (Exception ignored) {}

        // 2. All Phone / Dialer apps
        try {
            Intent dialerIntent = new Intent(Intent.ACTION_DIAL);
            List<ResolveInfo> dialerList = pm.queryIntentActivities(dialerIntent, 0);
            if (dialerList != null) {
                for (ResolveInfo ri : dialerList) {
                    if (ri.activityInfo != null && ri.activityInfo.packageName != null) {
                        packages.add(ri.activityInfo.packageName);
                    }
                }
            }
        } catch (Exception ignored) {}

        // 3. All Contacts apps
        try {
            Intent contactsIntent = new Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI);
            List<ResolveInfo> contactsList = pm.queryIntentActivities(contactsIntent, 0);
            if (contactsList != null) {
                for (ResolveInfo ri : contactsList) {
                    if (ri.activityInfo != null && ri.activityInfo.packageName != null) {
                        packages.add(ri.activityInfo.packageName);
                    }
                }
            }
        } catch (Exception ignored) {}

        // 4. All SMS / Messaging apps
        try {
            Intent smsIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"));
            List<ResolveInfo> smsList = pm.queryIntentActivities(smsIntent, 0);
            if (smsList != null) {
                for (ResolveInfo ri : smsList) {
                    if (ri.activityInfo != null && ri.activityInfo.packageName != null) {
                        packages.add(ri.activityInfo.packageName);
                    }
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                String defaultSms = Telephony.Sms.getDefaultSmsPackage(this);
                if (defaultSms != null) {
                    packages.add(defaultSms);
                }
            }
        } catch (Exception ignored) {}

        // 5. All WhatsApp variants (Official, Business, GB, Dual, Clone)
        try {
            Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
            mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> launcherList = pm.queryIntentActivities(mainIntent, 0);
            if (launcherList != null) {
                for (ResolveInfo ri : launcherList) {
                    if (ri.activityInfo != null && ri.activityInfo.packageName != null) {
                        String pkg = ri.activityInfo.packageName.toLowerCase(Locale.ROOT);
                        if (pkg.contains("whatsapp")) {
                            packages.add(ri.activityInfo.packageName);
                        }
                    }
                }
            }
        } catch (Exception ignored) {}

        // 6. YouTube apps & Browsers
        try {
            Intent ytIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"));
            List<ResolveInfo> ytList = pm.queryIntentActivities(ytIntent, 0);
            if (ytList != null) {
                for (ResolveInfo ri : ytList) {
                    if (ri.activityInfo != null && ri.activityInfo.packageName != null) {
                        packages.add(ri.activityInfo.packageName);
                    }
                }
            }
        } catch (Exception ignored) {}

        // 7. System Settings & Quick Panels (Wi-Fi, Bluetooth, Mobile Network, Battery Settings across all ROMs)
        Intent[] settingsQueries = new Intent[] {
            new Intent(Settings.ACTION_SETTINGS),
            new Intent(Settings.ACTION_WIFI_SETTINGS),
            new Intent(Settings.ACTION_BLUETOOTH_SETTINGS),
            new Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS),
            new Intent(Settings.ACTION_DATA_USAGE_SETTINGS),
            new Intent(Settings.ACTION_WIRELESS_SETTINGS),
            new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
        };
        for (Intent si : settingsQueries) {
            try {
                List<ResolveInfo> resList = pm.queryIntentActivities(si, 0);
                if (resList != null) {
                    for (ResolveInfo ri : resList) {
                        if (ri.activityInfo != null && ri.activityInfo.packageName != null) {
                            packages.add(ri.activityInfo.packageName);
                        }
                    }
                }
            } catch (Exception ignored) {}
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                Intent panelWifi = new Intent(Settings.Panel.ACTION_WIFI);
                List<ResolveInfo> pList = pm.queryIntentActivities(panelWifi, 0);
                if (pList != null) {
                    for (ResolveInfo ri : pList) {
                        if (ri.activityInfo != null && ri.activityInfo.packageName != null) {
                            packages.add(ri.activityInfo.packageName);
                        }
                    }
                }
            } catch (Exception ignored) {}
            try {
                Intent panelInternet = new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY);
                List<ResolveInfo> pList = pm.queryIntentActivities(panelInternet, 0);
                if (pList != null) {
                    for (ResolveInfo ri : pList) {
                        if (ri.activityInfo != null && ri.activityInfo.packageName != null) {
                            packages.add(ri.activityInfo.packageName);
                        }
                    }
                }
            } catch (Exception ignored) {}
        }

        // 8. Comprehensive OEM fallback package names across ALL Android manufacturers
        String[] fallbackPackages = new String[] {
            "com.whatsapp", "com.whatsapp.w4b", "com.gbwhatsapp", "com.yowhatsapp", "com.fmwhatsapp",
            "com.google.android.dialer", "com.android.dialer", "com.samsung.android.dialer",
            "com.android.incallui", "com.samsung.android.incallui", "com.android.phone",
            "com.android.server.telecom", "com.heytap.telecom", "com.coloros.telecom",
            "com.oplus.subsys.telephony", "com.vivo.telecom", "com.transsion.phone",
            "com.transsion.smartcaller", "com.asus.telephony", "com.lge.telephony",
            "com.google.android.contacts", "com.android.contacts", "com.samsung.android.app.contacts",
            "com.google.android.apps.messaging", "com.android.mms", "com.samsung.android.messaging",
            "com.google.android.youtube", "com.google.android.apps.youtube.mango",
            "com.google.android.GoogleCamera", "com.android.camera", "com.android.camera2",
            "com.sec.android.app.camera", "com.samsung.android.camera", "com.miui.camera",
            "com.oppo.camera", "com.oneplus.camera", "com.motorola.camera", "com.motorola.camera2",
            "com.motorola.camera3", "com.huawei.camera", "com.transsion.camera", "org.lineageos.aperture",
            "com.android.settings", "com.samsung.android.settings", "com.coloros.wirelesssettings",
            "com.oplus.wirelesssettings", "com.coloros.settings", "com.oplus.settings",
            "com.vivo.settings", "com.bbk.networkmanager", "com.miui.securitycenter",
            "com.google.android.settings.intelligence", "com.android.systemui", "com.android.chrome"
        };
        Collections.addAll(packages, fallbackPackages);

        return packages.toArray(new String[0]);
    }

    /**
     * Unlocks hardware Kiosk LockTask mode when timer finishes or session ends.
     */
    private void stopKioskMode() {
        try {
            stopLockTask();
        } catch (Exception e) {
            Log.e(TAG, "Failed to stop lock task", e);
        }
        isKioskActive = false;
        Log.i(TAG, "Kiosk Mode unlocked");
    }

    private void animateEntrance() {
        heroDashboardRow.setAlpha(0f);
        heroDashboardRow.setScaleX(0.90f);
        heroDashboardRow.setScaleY(0.90f);

        timerHeroContainer.setAlpha(0f);
        timerHeroContainer.setScaleX(0.85f);
        timerHeroContainer.setScaleY(0.85f);

        if (sliderContainer != null) {
            sliderContainer.setAlpha(0f);
            sliderContainer.setTranslationY(dpToPx(24));
        }

        bottomControlsBar.setAlpha(0f);
        bottomControlsBar.setTranslationY(dpToPx(24));

        heroDashboardRow.animate()
                .alpha(1f)
                .scaleX(1.0f)
                .scaleY(1.0f)
                .setDuration(700)
                .setStartDelay(80)
                .setInterpolator(new OvershootInterpolator(1.1f))
                .start();

        timerHeroContainer.animate()
                .alpha(1f)
                .scaleX(1.0f)
                .scaleY(1.0f)
                .setDuration(700)
                .setStartDelay(140)
                .setInterpolator(new OvershootInterpolator(1.1f))
                .start();

        if (sliderContainer != null) {
            sliderContainer.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setDuration(600)
                    .setStartDelay(240)
                    .setInterpolator(new DecelerateInterpolator())
                    .start();
        }

        bottomControlsBar.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(600)
                .setStartDelay(320)
                .setInterpolator(new DecelerateInterpolator())
                .start();
    }

    private String formatSessionSeconds(long seconds) {
        long hrs = seconds / 3600;
        long mins = (seconds % 3600) / 60;
        long secs = seconds % 60;

        if (hrs > 0) {
            return String.format(Locale.US, "%02d:%02d:%02d", hrs, mins, secs);
        } else {
            return String.format(Locale.US, "%02d:%02d", mins, secs);
        }
    }

    private String formatMinutes(int minutes) {
        if (minutes < 60) {
            return minutes + " Minutes";
        } else if (minutes % 60 == 0) {
            int hours = minutes / 60;
            return hours == 1 ? "1 Hour" : hours + " Hours";
        } else {
            int hours = minutes / 60;
            int remMin = minutes % 60;
            return hours + "h " + remMin + "m";
        }
    }

    private String formatDurationHuman(int minutes) {
        return formatMinutes(minutes);
    }

    private String formatSpentSeconds(long seconds) {
        long mins = seconds / 60;
        if (mins < 1) {
            return seconds + " seconds";
        } else if (mins < 60) {
            return mins + " minutes";
        } else {
            return (mins / 60) + "h " + (mins % 60) + "m";
        }
    }

    private void handleBackAction() {
        if (dynamicIslandController != null && dynamicIslandController.isExpanded()) {
            dynamicIslandController.collapseIsland();
            return;
        }
        if (layoutGenieAppsOverlay != null && layoutGenieAppsOverlay.getVisibility() == View.VISIBLE) {
            closeGenieAppsPopup();
            return;
        }
        if (isDeepMode && remainingSeconds > 0) {
            Toast.makeText(this, "🔒 Deep Mode Kiosk: Locked until timer completes!", Toast.LENGTH_SHORT).show();
            try {
                if (sessionRoot != null) {
                    sessionRoot.performHapticFeedback(HapticFeedbackConstants.REJECT);
                }
            } catch (Exception ignored) {}
            return;
        }
        confirmEndSession();
    }

    @Override
    public void onBackPressed() {
        handleBackAction();
    }

    @Override
    protected void onDestroy() {
        isForeground = false;
        if (activeInstance != null && activeInstance.get() == this) {
            activeInstance = null;
        }
        super.onDestroy();
        try {
            StudyDynamicIslandOverlayService.stopOverlay(this);
            if (dynamicIslandController != null) {
                dynamicIslandController.onDestroy();
                dynamicIslandController = null;
            }
            stopKioskMode();
            if (clockAndSessionRunnable != null) {
                mainHandler.removeCallbacks(clockAndSessionRunnable);
            }
            if (batteryReceiver != null) {
                unregisterReceiver(batteryReceiver);
                batteryReceiver = null;
            }
            if (screenStateReceiver != null) {
                unregisterReceiver(screenStateReceiver);
                screenStateReceiver = null;
            }
            if (networkAndBtReceiver != null) {
                unregisterReceiver(networkAndBtReceiver);
                networkAndBtReceiver = null;
            }
            StudyTorchManager.getInstance(this).setTorch(false);
        } catch (Exception ignored) {}
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupSlideToEndInteraction() {
        if (sliderThumb == null || sliderContainer == null) return;

        final float[] downRawX = new float[1];
        final float[] thumbDownX = new float[1];

        sliderContainer.post(() -> {
            int containerW = sliderContainer.getWidth();
            if (containerW > 0) {
                // Wide flexible pill thumb (~30% width, min 92dp)
                int targetThumbW = Math.max((int) dpToPx(92), Math.round(containerW * 0.30f));
                ViewGroup.LayoutParams lp = sliderThumb.getLayoutParams();
                if (lp != null && lp.width != targetThumbW) {
                    lp.width = targetThumbW;
                    sliderThumb.setLayoutParams(lp);
                }
            }
            resetSlider();
        });

        sliderThumb.setOnTouchListener((v, event) -> {
            float containerW = sliderContainer.getWidth();
            float thumbW = sliderThumb.getWidth();
            if (containerW <= 0) containerW = dpToPx(300);
            if (thumbW <= 0) thumbW = dpToPx(96);

            float initialCenterX = (containerW - thumbW) / 2f;
            float minX = dpToPx(5);
            float maxX = containerW - thumbW - dpToPx(5);
            float maxSlideRight = Math.max(dpToPx(40), maxX - initialCenterX);
            float maxSlideLeft = Math.max(dpToPx(40), initialCenterX - minX);

            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    if (v.getParent() != null) {
                        v.getParent().requestDisallowInterceptTouchEvent(true);
                    }
                    v.animate().cancel();
                    downRawX[0] = event.getRawX();
                    thumbDownX[0] = v.getX();
                    isSliderCompleted = false;
                    v.animate().scaleX(1.06f).scaleY(0.95f).setDuration(100).start();
                    if (pikachuDancingView != null) {
                        pikachuDancingView.setExcited(true);
                    }
                    try { v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); } catch (Exception ignored) {}
                    return true;

                case MotionEvent.ACTION_MOVE:
                    if (isSliderCompleted) {
                        return true;
                    }
                    if (v.getParent() != null) {
                        v.getParent().requestDisallowInterceptTouchEvent(true);
                    }
                    float deltaX = event.getRawX() - downRawX[0];
                    float newX = thumbDownX[0] + deltaX;
                    float clampedX = Math.max(minX, Math.min(newX, maxX));
                    v.setX(clampedX);

                    if (clampedX >= initialCenterX) {
                        // Sliding to the RIGHT -> YOUTUBE PAGE (One-shot Zoom In)
                        float progress = Math.min(1.0f, (clampedX - initialCenterX) / maxSlideRight);
                        float stretchX = 1.0f + 0.12f * progress;
                        float stretchY = 1.0f - 0.05f * progress;
                        v.setScaleX(stretchX);
                        v.setScaleY(stretchY);
                        v.setRotation(progress * 4.5f);

                        if (pikachuDancingView != null) {
                            pikachuDancingView.setDragLean(progress);
                        }
                        if (layoutSliderHintRight != null) {
                            layoutSliderHintRight.setAlpha(Math.max(0f, 1f - progress * 1.6f));
                        }
                        if (layoutSliderHintLeft != null) {
                            layoutSliderHintLeft.setAlpha(Math.max(0f, 1f - progress * 1.2f));
                        }

                        if (progress >= 0.78f && !isSliderCompleted) {
                            isSliderCompleted = true; // One-shot trigger: locks further triggers
                            v.setEnabled(false);      // Immediately disable touches to avoid repeated triggers
                            if (v.getParent() != null) {
                                v.getParent().requestDisallowInterceptTouchEvent(false);
                            }
                            try { v.performHapticFeedback(HapticFeedbackConstants.CONFIRM); } catch (Exception ignored) {}

                            // Beautiful zoom-in scale animation expanding out of the slider
                            v.animate()
                                    .x(maxX)
                                    .scaleX(1.4f)
                                    .scaleY(1.4f)
                                    .alpha(0.2f)
                                    .rotation(0f)
                                    .setDuration(160)
                                    .setInterpolator(new AccelerateInterpolator())
                                    .withEndAction(this::openYouTubePage)
                                    .start();
                        }
                    } else {
                        // Sliding to the LEFT -> MINI GENIE APPS POPUP (One-shot trigger)
                        float progress = Math.min(1.0f, (initialCenterX - clampedX) / maxSlideLeft);
                        float stretchX = 1.0f + 0.12f * progress;
                        float stretchY = 1.0f - 0.05f * progress;
                        v.setScaleX(stretchX);
                        v.setScaleY(stretchY);
                        v.setRotation(-progress * 4.5f);

                        if (pikachuDancingView != null) {
                            pikachuDancingView.setDragLean(-progress);
                        }
                        if (layoutSliderHintLeft != null) {
                            layoutSliderHintLeft.setAlpha(Math.max(0f, 1f - progress * 1.6f));
                        }
                        if (layoutSliderHintRight != null) {
                            layoutSliderHintRight.setAlpha(Math.max(0f, 1f - progress * 1.2f));
                        }

                        if (progress >= 0.78f && !isSliderCompleted) {
                            isSliderCompleted = true; // One-shot trigger
                            v.setEnabled(false);
                            if (v.getParent() != null) {
                                v.getParent().requestDisallowInterceptTouchEvent(false);
                            }
                            try { v.performHapticFeedback(HapticFeedbackConstants.CONFIRM); } catch (Exception ignored) {}
                            v.animate().x(minX).scaleX(1.0f).scaleY(1.0f).rotation(0f).setDuration(120).withEndAction(this::openGenieAppsPopup).start();
                        }
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (v.getParent() != null) {
                        v.getParent().requestDisallowInterceptTouchEvent(false);
                    }
                    if (!isSliderCompleted) {
                        resetSlider();
                    }
                    return true;
            }
            return false;
        });
    }

    private void resetSlider() {
        isSliderCompleted = false;
        if (sliderThumb != null) {
            sliderThumb.setEnabled(true);
            sliderThumb.setAlpha(1.0f);
        }
        if (pikachuDancingView != null) {
            pikachuDancingView.setExcited(false);
            pikachuDancingView.setDragLean(0f);
        }
        if (sliderThumb != null && sliderContainer != null) {
            sliderThumb.animate().cancel();
            float containerW = sliderContainer.getWidth();
            float thumbW = sliderThumb.getWidth();
            if (containerW <= 0) containerW = sliderContainer.getMeasuredWidth();
            if (thumbW <= 0) thumbW = sliderThumb.getMeasuredWidth();
            float targetCenterX = (containerW > 0 && thumbW > 0) ? ((containerW - thumbW) / 2f) : dpToPx(100);

            sliderThumb.animate()
                    .x(targetCenterX)
                    .scaleX(1.0f)
                    .scaleY(1.0f)
                    .alpha(1.0f)
                    .rotation(0f)
                    .setDuration(360)
                    .setInterpolator(new OvershootInterpolator(1.4f))
                    .start();
        }
        if (layoutSliderHintLeft != null) {
            layoutSliderHintLeft.animate().alpha(1.0f).setDuration(280).start();
        }
        if (layoutSliderHintRight != null) {
            layoutSliderHintRight.animate().alpha(1.0f).setDuration(280).start();
        }
    }

    private void openYouTubePage() {
        isLaunchingAllowedApp = true;
        try {
            Intent intent = new Intent(this, YouTubeActivity.class);
            intent.putExtra("is_deep_mode", isDeepMode);
            startActivity(intent);
            overridePendingTransition(R.anim.zoom_in_enter, R.anim.zoom_fade_out);
        } catch (Exception e) {
            Log.e(TAG, "Failed to launch YouTubeActivity", e);
            resetSlider();
        }
    }

    /**
     * Mini Genie Blossom Animation: Blossoms out fluidly from the slider thumb anchor point.
     */
    private void openGenieAppsPopup() {
        if (layoutGenieAppsOverlay == null || cardGenieApps == null) return;

        layoutGenieAppsOverlay.setVisibility(View.VISIBLE);
        if (genieScrimDismiss != null) {
            genieScrimDismiss.setAlpha(0f);
            genieScrimDismiss.animate().alpha(1f).setDuration(260).start();
        }

        cardGenieApps.post(() -> {
            float pivotX = 0f;
            float pivotY = cardGenieApps.getHeight();

            if (sliderThumb != null) {
                int[] thumbLoc = new int[2];
                sliderThumb.getLocationOnScreen(thumbLoc);
                int[] cardLoc = new int[2];
                cardGenieApps.getLocationOnScreen(cardLoc);

                pivotX = (thumbLoc[0] - cardLoc[0]) + (sliderThumb.getWidth() / 2f);
                pivotY = (thumbLoc[1] - cardLoc[1]) + (sliderThumb.getHeight() / 2f);
            }

            cardGenieApps.setPivotX(pivotX);
            cardGenieApps.setPivotY(pivotY);
            cardGenieApps.setScaleX(0.06f);
            cardGenieApps.setScaleY(0.06f);
            cardGenieApps.setRotation(-8f);
            cardGenieApps.setAlpha(0f);

            cardGenieApps.animate()
                    .scaleX(1.0f)
                    .scaleY(1.0f)
                    .rotation(0f)
                    .alpha(1.0f)
                    .setDuration(320)
                    .setInterpolator(new OvershootInterpolator(1.25f))
                    .start();
        });
    }

    /**
     * Reverse Mini Genie Suck-In Animation: Sucks back into the slider thumb and smoothly resets the slider.
     */
    private void closeGenieAppsPopup() {
        if (layoutGenieAppsOverlay == null || layoutGenieAppsOverlay.getVisibility() != View.VISIBLE) return;

        if (genieScrimDismiss != null) {
            genieScrimDismiss.animate().alpha(0f).setDuration(200).start();
        }

        if (cardGenieApps != null) {
            cardGenieApps.animate()
                    .scaleX(0.06f)
                    .scaleY(0.06f)
                    .rotation(-8f)
                    .alpha(0f)
                    .setDuration(220)
                    .setInterpolator(new AccelerateInterpolator(1.4f))
                    .withEndAction(() -> {
                        if (layoutGenieAppsOverlay != null) {
                            layoutGenieAppsOverlay.setVisibility(View.GONE);
                        }
                        resetSlider();
                    })
                    .start();
        } else {
            layoutGenieAppsOverlay.setVisibility(View.GONE);
            resetSlider();
        }
    }

    public void launchWhatsApp() {
        notifyLaunchingAllowedApp();
        try {
            PackageManager pm = getPackageManager();
            List<ResolveInfo> whatsappApps = new ArrayList<>();
            Set<String> addedPackages = new HashSet<>();

            // 1. Direct package lookup for official and common WhatsApp packages
            String[] knownPackages = new String[]{
                    "com.whatsapp",
                    "com.whatsapp.w4b",
                    "com.gbwhatsapp",
                    "com.yowhatsapp",
                    "com.fmwhatsapp",
                    "com.aerowhatsapp"
            };
            for (String pkgName : knownPackages) {
                if (!addedPackages.contains(pkgName)) {
                    try {
                        Intent launchIntent = pm.getLaunchIntentForPackage(pkgName);
                        if (launchIntent != null) {
                            List<ResolveInfo> res = pm.queryIntentActivities(launchIntent, 0);
                            if (res != null && !res.isEmpty()) {
                                whatsappApps.add(res.get(0));
                                addedPackages.add(pkgName);
                            }
                        }
                    } catch (Exception ignored) {}
                }
            }

            // 2. Query all launcher activities to catch WhatsApp clones / dual messenger
            try {
                Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
                mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> allLaunchers = pm.queryIntentActivities(mainIntent, 0);

                if (allLaunchers != null) {
                    for (ResolveInfo ri : allLaunchers) {
                        if (ri.activityInfo == null || ri.activityInfo.packageName == null) continue;
                        String pkg = ri.activityInfo.packageName.toLowerCase(Locale.ROOT);
                        CharSequence labelCs = ri.loadLabel(pm);
                        String label = (labelCs != null) ? labelCs.toString().toLowerCase(Locale.ROOT) : "";

                        if (pkg.contains("whatsapp") || label.contains("whatsapp")) {
                            if (!addedPackages.contains(ri.activityInfo.packageName)) {
                                addedPackages.add(ri.activityInfo.packageName);
                                whatsappApps.add(ri);
                            }
                        }
                    }
                }
            } catch (Exception ignored) {}

            if (whatsappApps.isEmpty()) {
                // Fallback to whatsapp:// uri scheme
                try {
                    Intent waUriIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("whatsapp://app"));
                    waUriIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(waUriIntent);
                    return;
                } catch (Exception ignored) {}
                Toast.makeText(this, "WhatsApp is not installed on this device", Toast.LENGTH_SHORT).show();
            } else if (whatsappApps.size() == 1) {
                launchWhatsAppResolveInfo(whatsappApps.get(0));
            } else {
                showWhatsAppChooserDialog(whatsappApps);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error launching WhatsApp", e);
            Toast.makeText(this, "Could not open WhatsApp", Toast.LENGTH_SHORT).show();
        }
    }

    private void launchWhatsAppResolveInfo(ResolveInfo ri) {
        notifyLaunchingAllowedApp();
        if (ri != null && ri.activityInfo != null) {
            ensurePackageWhitelistedForLockTask(ri.activityInfo.packageName);
        }
        try {
            PackageManager pm = getPackageManager();
            Intent launchIntent = pm.getLaunchIntentForPackage(ri.activityInfo.packageName);
            if (launchIntent == null) {
                launchIntent = new Intent(Intent.ACTION_MAIN);
                launchIntent.addCategory(Intent.CATEGORY_LAUNCHER);
                launchIntent.setClassName(ri.activityInfo.packageName, ri.activityInfo.name);
            }
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(launchIntent);
        } catch (Exception e) {
            Log.e(TAG, "Failed to launch package: " + ri.activityInfo.packageName, e);
            Toast.makeText(this, "Failed to open " + ri.loadLabel(getPackageManager()), Toast.LENGTH_SHORT).show();
        }
    }

    private void showWhatsAppChooserDialog(List<ResolveInfo> apps) {
        try {
            Dialog dialog = new Dialog(this);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.dialog_choose_whatsapp);

            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                lp.copyFrom(dialog.getWindow().getAttributes());
                lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.90);
                dialog.getWindow().setAttributes(lp);
            }

            View btnClose = dialog.findViewById(R.id.btnWhatsAppDialogClose);
            if (btnClose != null) {
                btnClose.setOnClickListener(v -> dialog.dismiss());
            }

            LinearLayout container = dialog.findViewById(R.id.containerWhatsAppItems);
            if (container != null) {
                container.removeAllViews();
                PackageManager pm = getPackageManager();
                LayoutInflater inflater = LayoutInflater.from(this);

                for (ResolveInfo ri : apps) {
                    View itemView = inflater.inflate(R.layout.item_whatsapp_choice, container, false);
                    AppCompatImageView ivIcon = itemView.findViewById(R.id.ivWhatsAppChoiceIcon);
                    TextView tvName = itemView.findViewById(R.id.tvWhatsAppChoiceName);
                    TextView tvPackage = itemView.findViewById(R.id.tvWhatsAppChoicePackage);

                    if (ivIcon != null) {
                        try {
                            ivIcon.setImageDrawable(ri.loadIcon(pm));
                        } catch (Exception e) {
                            ivIcon.setImageResource(R.drawable.ic_whatsapp);
                        }
                    }

                    CharSequence label = ri.loadLabel(pm);
                    if (tvName != null) {
                        tvName.setText(label != null ? label : "WhatsApp");
                    }

                    if (tvPackage != null) {
                        if ("com.whatsapp".equalsIgnoreCase(ri.activityInfo.packageName)) {
                            tvPackage.setText("WhatsApp Messenger");
                        } else if ("com.whatsapp.w4b".equalsIgnoreCase(ri.activityInfo.packageName)) {
                            tvPackage.setText("WhatsApp Business");
                        } else {
                            tvPackage.setText(ri.activityInfo.packageName);
                        }
                    }

                    itemView.setOnClickListener(v -> {
                        dialog.dismiss();
                        launchWhatsAppResolveInfo(ri);
                    });

                    container.addView(itemView);
                }
            }

            dialog.show();
        } catch (Exception e) {
            Log.e(TAG, "Error displaying WhatsApp chooser dialog", e);
            if (!apps.isEmpty()) {
                launchWhatsAppResolveInfo(apps.get(0));
            }
        }
    }

    public void launchDialer() {
        notifyLaunchingAllowedApp();
        try {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            ComponentName cn = intent.resolveActivity(getPackageManager());
            if (cn != null) {
                ensurePackageWhitelistedForLockTask(cn.getPackageName());
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        } catch (Exception e) {
            try {
                Intent fallback = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:"));
                ComponentName cn = fallback.resolveActivity(getPackageManager());
                if (cn != null) {
                    ensurePackageWhitelistedForLockTask(cn.getPackageName());
                }
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(fallback);
            } catch (Exception ex) {
                Toast.makeText(this, "Dialer app not found", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void launchContacts() {
        notifyLaunchingAllowedApp();
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI);
            ComponentName cn = intent.resolveActivity(getPackageManager());
            if (cn != null) {
                ensurePackageWhitelistedForLockTask(cn.getPackageName());
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        } catch (Exception e) {
            try {
                Intent fallback = new Intent(Intent.ACTION_DEFAULT, ContactsContract.Contacts.CONTENT_URI);
                ComponentName cn = fallback.resolveActivity(getPackageManager());
                if (cn != null) {
                    ensurePackageWhitelistedForLockTask(cn.getPackageName());
                }
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(fallback);
            } catch (Exception ex) {
                Toast.makeText(this, "Contacts app not found", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void launchMessages() {
        notifyLaunchingAllowedApp();
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                String defaultSmsPackage = android.provider.Telephony.Sms.getDefaultSmsPackage(this);
                if (defaultSmsPackage != null) {
                    ensurePackageWhitelistedForLockTask(defaultSmsPackage);
                    Intent intent = getPackageManager().getLaunchIntentForPackage(defaultSmsPackage);
                    if (intent != null) {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        return;
                    }
                }
            }
            Intent smsIntent = new Intent(Intent.ACTION_MAIN);
            smsIntent.addCategory(Intent.CATEGORY_APP_MESSAGING);
            ComponentName cn = smsIntent.resolveActivity(getPackageManager());
            if (cn != null) {
                ensurePackageWhitelistedForLockTask(cn.getPackageName());
            }
            smsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(smsIntent);
        } catch (Exception e) {
            try {
                Intent fallbackSms = new Intent(Intent.ACTION_VIEW, Uri.parse("sms:"));
                fallbackSms.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(fallbackSms);
            } catch (Exception ex) {
                Toast.makeText(this, "Messages app not found", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        isForeground = true;
        StudyDynamicIslandOverlayService.stopOverlay(this);
        if (dynamicIslandController != null) {
            dynamicIslandController.refreshData();
        }
        isLaunchingAllowedApp = false;
        makeEdgeToEdge();

        // Smart Focus: Check screen active state onResume (Runs whenever screen is ON)
        if (isScreenActive()) {
            resumeSmartFocusTimer("Screen On onResume");
        } else {
            freezeSmartFocusTimer("Screen Off onResume");
        }

        if (isDeepMode && remainingSeconds > 0) {
            mainHandler.postDelayed(() -> {
                if (isDeepMode && remainingSeconds > 0 && !isActuallyInLockTask() && !isFinishing() && !isDestroyed()) {
                    startKioskMode();
                }
            }, 200);
        }
        mainHandler.postDelayed(this::resetSlider, 150);
    }

    @Override
    protected void onPause() {
        super.onPause();
        isForeground = false;
        if (!isScreenActive()) {
            freezeSmartFocusTimer("Screen Off onPause");
        }
        if (isDeepMode && remainingSeconds > 0 && isLaunchingAllowedApp) {
            StudyDynamicIslandOverlayService.startOverlay(this);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            isForeground = true;
            StudyDynamicIslandOverlayService.stopOverlay(this);
            makeEdgeToEdge();
            if (isScreenActive()) {
                resumeSmartFocusTimer("Window Focus Regained");
            }
            if (isDeepMode && remainingSeconds > 0 && !isActuallyInLockTask()) {
                mainHandler.postDelayed(this::startKioskMode, 200);
            }
        } else {
            if (!isScreenActive()) {
                freezeSmartFocusTimer("Screen Off onFocusLost");
            }
            if (isDeepMode && remainingSeconds > 0 && !isLaunchingAllowedApp) {
                try {
                    sendBroadcast(new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS));
                } catch (Exception ignored) {}
            }
        }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (isLaunchingAllowedApp) {
            if (isDeepMode && remainingSeconds > 0) {
                StudyDynamicIslandOverlayService.startOverlay(this);
            }
            return;
        }
        if (!isScreenActive()) {
            freezeSmartFocusTimer("Screen Off onUserLeaveHint");
            return;
        }
        KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        boolean isLocked = km != null && km.isKeyguardLocked();
        if (isDeepMode && remainingSeconds > 0 && !isLocked) {
            try {
                Intent intent = new Intent(this, StudySessionActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            } catch (Exception ignored) {}
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        isForeground = false;
        if (!isScreenActive()) {
            freezeSmartFocusTimer("Screen Off onStop");
        }
        if (isDeepMode && remainingSeconds > 0 && isLaunchingAllowedApp) {
            StudyDynamicIslandOverlayService.startOverlay(this);
        }
        // ONLY relaunch activity if the screen is ACTIVE and user is attempting to leave Deep Mode Kiosk (not when device is locked)
        if (isDeepMode && remainingSeconds > 0 && !isLaunchingAllowedApp && isScreenActive()) {
            KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
            boolean isLocked = km != null && km.isKeyguardLocked();
            if (!isLocked) {
                mainHandler.postDelayed(() -> {
                    if (isDeepMode && remainingSeconds > 0 && !isLaunchingAllowedApp && isScreenActive() && !isFinishing() && !isDestroyed()) {
                        try {
                            Intent intent = new Intent(StudySessionActivity.this, StudySessionActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                        } catch (Exception ignored) {}
                    }
                }, 100);
            }
        }
    }

    private void startSliderShimmerAnimation() {
        if (layoutSliderHintLeft != null && layoutSliderHintRight != null) {
            layoutSliderHintLeft.setAlpha(0.65f);
            layoutSliderHintRight.setAlpha(0.65f);
            layoutSliderHintLeft.animate()
                    .alpha(1.0f)
                    .setDuration(1200)
                    .setInterpolator(new AccelerateDecelerateInterpolator())
                    .withEndAction(() -> {
                        if (layoutSliderHintLeft != null) {
                            layoutSliderHintLeft.animate()
                                    .alpha(0.65f)
                                    .setDuration(1200)
                                    .setInterpolator(new AccelerateDecelerateInterpolator())
                                    .withEndAction(this::startSliderShimmerAnimation)
                                    .start();
                        }
                    })
                    .start();

            layoutSliderHintRight.animate()
                    .alpha(1.0f)
                    .setDuration(1200)
                    .setInterpolator(new AccelerateDecelerateInterpolator())
                    .withEndAction(() -> {
                        if (layoutSliderHintRight != null) {
                            layoutSliderHintRight.animate()
                                    .alpha(0.65f)
                                    .setDuration(1200)
                                    .setInterpolator(new AccelerateDecelerateInterpolator())
                                    .start();
                        }
                    })
                    .start();
        }
    }

    private float dpToPx(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }
}
