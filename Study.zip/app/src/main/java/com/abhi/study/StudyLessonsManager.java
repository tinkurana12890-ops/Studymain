package com.abhi.study;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Persistent manager for StudyTube Focus Hub:
 * - Dynamic Incomplete Lessons, Upcoming Lessons, and Completed Lessons.
 * - Daily Study Streak (Fire Points & Goal Progress).
 * - Previous Incomplete Lesson (20+ minute resume tracking).
 * - First-time Gestures Tutorial preference.
 */
public class StudyLessonsManager {

    private static final String PREF_NAME = "studytube_lessons_pref";
    private static final String KEY_INCOMPLETE = "key_incomplete_lessons";
    private static final String KEY_UPCOMING = "key_upcoming_lessons";
    private static final String KEY_COMPLETED = "key_completed_lessons";
    private static final String KEY_DOWNLOADED = "key_downloaded_lessons";

    // Streak & Points Keys
    private static final String KEY_STREAK_DAYS = "key_streak_days";
    private static final String KEY_STREAK_POINTS = "key_streak_points";
    private static final String KEY_LAST_ACTIVE_DATE = "key_last_active_date";
    private static final String KEY_DAILY_WATCH_MINS = "key_daily_watch_mins";
    private static final String KEY_TOTAL_WATCH_SECONDS = "key_total_watch_seconds";

    // Resume Lesson Keys
    private static final String KEY_RESUME_ID = "key_resume_id";
    private static final String KEY_RESUME_TITLE = "key_resume_title";
    private static final String KEY_RESUME_SUBJECT = "key_resume_subject";
    private static final String KEY_RESUME_CHANNEL = "key_resume_channel";
    private static final String KEY_RESUME_POS = "key_resume_pos";
    private static final String KEY_RESUME_DUR = "key_resume_dur";

    // Gesture Tutorial
    private static final String KEY_GESTURE_TUTORIAL_SHOWN = "key_gesture_tutorial_shown";

    private static SharedPreferences getPrefs(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    // ==========================================
    // INCOMPLETE LESSONS
    // ==========================================
    public static List<Class11Video> getIncompleteLessons(Context context) {
        return loadVideos(context, KEY_INCOMPLETE);
    }

    public static boolean addIncompleteLesson(Context context, Class11Video video) {
        if (video == null) return false;
        List<Class11Video> list = getIncompleteLessons(context);
        for (Class11Video v : list) {
            if (v.getId().equals(video.getId())) return false; // already present
        }
        list.add(0, video);
        saveVideos(context, KEY_INCOMPLETE, list);
        return true;
    }

    public static void removeIncompleteLesson(Context context, String videoId) {
        removeVideo(context, KEY_INCOMPLETE, videoId);
    }

    // ==========================================
    // UPCOMING LESSONS
    // ==========================================
    public static List<Class11Video> getUpcomingLessons(Context context) {
        return loadVideos(context, KEY_UPCOMING);
    }

    public static boolean addUpcomingLesson(Context context, Class11Video video) {
        if (video == null) return false;
        List<Class11Video> list = getUpcomingLessons(context);
        for (Class11Video v : list) {
            if (v.getId().equals(video.getId())) return false;
        }
        list.add(video);
        saveVideos(context, KEY_UPCOMING, list);
        return true;
    }

    public static void removeUpcomingLesson(Context context, String videoId) {
        removeVideo(context, KEY_UPCOMING, videoId);
    }

    // ==========================================
    // COMPLETED LESSONS
    // ==========================================
    public static List<Class11Video> getCompletedLessons(Context context) {
        return loadVideos(context, KEY_COMPLETED);
    }

    public static void markLessonCompleted(Context context, Class11Video video) {
        if (video == null) return;
        // Remove from Incomplete & Upcoming
        removeIncompleteLesson(context, video.getId());
        removeUpcomingLesson(context, video.getId());

        List<Class11Video> completed = getCompletedLessons(context);
        for (Class11Video v : completed) {
            if (v.getId().equals(video.getId())) return; // already marked
        }
        completed.add(0, video);
        saveVideos(context, KEY_COMPLETED, completed);

        // Award streak fire points on completion (+50 points)
        addStreakPoints(context, 50);
    }

    public static void removeCompletedLesson(Context context, String videoId) {
        removeVideo(context, KEY_COMPLETED, videoId);
    }

    public static List<Class11Video> getDownloadedLessons(Context context) {
        return loadVideos(context, KEY_DOWNLOADED);
    }

    public static boolean addDownloadedLesson(Context context, Class11Video video) {
        if (context == null || video == null) return false;
        List<Class11Video> list = getDownloadedLessons(context);
        for (Class11Video v : list) {
            if (v.getId().equals(video.getId())) return false;
        }
        list.add(0, video);
        saveVideos(context, KEY_DOWNLOADED, list);
        return true;
    }

    public static void removeDownloadedLesson(Context context, String videoId) {
        removeVideo(context, KEY_DOWNLOADED, videoId);
    }

    // ==========================================
    // STREAK & FIRE POINTS ENGINE
    // ==========================================
    public static void recordDailyVisit(Context context) {
        SharedPreferences sp = getPrefs(context);
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        String lastDate = sp.getString(KEY_LAST_ACTIVE_DATE, "");

        if (today.equals(lastDate)) {
            // Already counted today
            return;
        }

        int streak = sp.getInt(KEY_STREAK_DAYS, 0);
        int points = sp.getInt(KEY_STREAK_POINTS, 0);

        // Check if yesterday or first time
        if (lastDate.isEmpty()) {
            streak = 1;
            points += 20;
        } else {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                long diff = sdf.parse(today).getTime() - sdf.parse(lastDate).getTime();
                long daysDiff = diff / (1000 * 60 * 60 * 24);
                if (daysDiff == 1) {
                    streak++;
                    points += 25; // consecutive day streak bonus!
                } else if (daysDiff > 1) {
                    streak = 1; // broken streak restarted
                    points += 15;
                }
            } catch (Exception e) {
                streak = 1;
                points += 15;
            }
        }

        sp.edit()
                .putString(KEY_LAST_ACTIVE_DATE, today)
                .putInt(KEY_STREAK_DAYS, Math.max(1, streak))
                .putInt(KEY_STREAK_POINTS, points)
                .putInt(KEY_DAILY_WATCH_MINS, 0) // reset daily goal minutes
                .apply();
    }

    public static int getStreakDays(Context context) {
        int d = getPrefs(context).getInt(KEY_STREAK_DAYS, 1);
        return Math.max(1, d);
    }

    public static int getStreakPoints(Context context) {
        int pts = getPrefs(context).getInt(KEY_STREAK_POINTS, 50);
        return Math.max(20, pts);
    }

    public static void addStreakPoints(Context context, int pts) {
        int cur = getPrefs(context).getInt(KEY_STREAK_POINTS, 50);
        getPrefs(context).edit().putInt(KEY_STREAK_POINTS, cur + pts).apply();
    }

    public static int getDailyGoalProgressPercent(Context context) {
        int mins = getPrefs(context).getInt(KEY_DAILY_WATCH_MINS, 0);
        int targetMins = 60; // 1 hour daily focus goal
        int pct = (mins * 100) / targetMins;
        return Math.min(100, Math.max(15, pct));
    }

    // ==========================================
    // 10-TIER STUDYTUBE RANK SYSTEM
    // (Every 9 Hours of watch time = +1 Rank Level up to Level 10)
    // ==========================================
    public static final long SECONDS_PER_RANK_LEVEL = 9 * 3600L; // 9 Hours = 32400s per Rank
    public static final int MAX_RANK_LEVEL = 10;

    public static long getTotalWatchSeconds(Context context) {
        return getPrefs(context).getLong(KEY_TOTAL_WATCH_SECONDS, 0L);
    }

    public static boolean addWatchSeconds(Context context, long seconds) {
        if (seconds <= 0) return false;
        long curTotal = getTotalWatchSeconds(context);
        int oldLevel = getRankLevelFromSeconds(curTotal);

        long newTotal = curTotal + seconds;
        getPrefs(context).edit().putLong(KEY_TOTAL_WATCH_SECONDS, newTotal).apply();

        // Also track daily watch minutes
        int curMins = getPrefs(context).getInt(KEY_DAILY_WATCH_MINS, 0);
        int addMins = (int) ((newTotal / 60) - (curTotal / 60));
        if (addMins > 0) {
            getPrefs(context).edit().putInt(KEY_DAILY_WATCH_MINS, curMins + addMins).apply();
        }

        int newLevel = getRankLevelFromSeconds(newTotal);
        if (newLevel > oldLevel) {
            // Award rank-up bonus points!
            addStreakPoints(context, 100);
            return true; // Ranked up!
        }
        return false;
    }

    public static int getRankLevelFromSeconds(long totalSeconds) {
        int level = (int) (totalSeconds / SECONDS_PER_RANK_LEVEL) + 1;
        return Math.min(MAX_RANK_LEVEL, Math.max(1, level));
    }

    public static int getFireRankLevel(Context context) {
        return getRankLevelFromSeconds(getTotalWatchSeconds(context));
    }

    public static String getRankTitle(int level) {
        switch (level) {
            case 1: return "BRONZE I";
            case 2: return "SILVER II";
            case 3: return "GOLD III";
            case 4: return "PLATINUM IV";
            case 5: return "DIAMOND V";
            case 6: return "HEROIC VI";
            case 7: return "MASTER VII";
            case 8: return "GRANDMASTER VIII";
            case 9: return "CHALLENGER IX";
            case 10: return "APEX GODLIKE X";
            default: return "BRONZE I";
        }
    }

    public static String getRankSubtitle(int level) {
        switch (level) {
            case 1: return "Rookie Ember (0 - 9h)";
            case 2: return "Metallic Silver (9 - 18h)";
            case 3: return "Imperial Gold (18 - 27h)";
            case 4: return "Luminescent Platinum (27 - 36h)";
            case 5: return "Crystalline Diamond (36 - 45h)";
            case 6: return "Heroic Crimson Blaze (45 - 54h)";
            case 7: return "Royal Amethyst Master (54 - 63h)";
            case 8: return "Mythic Jade Grandmaster (63 - 72h)";
            case 9: return "Hyper Challenger Plasma (72 - 81h)";
            case 10: return "Godlike Apex Legend (81h+)";
            default: return "Bronze Spark";
        }
    }

    public static int getRankProgressPercent(Context context) {
        long total = getTotalWatchSeconds(context);
        int level = getRankLevelFromSeconds(total);
        if (level >= MAX_RANK_LEVEL) return 100;
        long currentLevelProgress = total % SECONDS_PER_RANK_LEVEL;
        return (int) ((currentLevelProgress * 100) / SECONDS_PER_RANK_LEVEL);
    }

    public static String getWatchTimeToNextRankFormatted(Context context) {
        long total = getTotalWatchSeconds(context);
        int level = getRankLevelFromSeconds(total);
        if (level >= MAX_RANK_LEVEL) return "MAX RANK UNLOCKED";
        long currentLevelProgress = total % SECONDS_PER_RANK_LEVEL;
        long remaining = SECONDS_PER_RANK_LEVEL - currentLevelProgress;
        long hours = remaining / 3600;
        long mins = (remaining % 3600) / 60;
        return String.format(Locale.getDefault(), "%dh %02dm to rank up", hours, mins);
    }

    public static String getFormattedTotalWatchTime(Context context) {
        long total = getTotalWatchSeconds(context);
        long hours = total / 3600;
        long mins = (total % 3600) / 60;
        return String.format(Locale.getDefault(), "%dh %02dm", hours, mins);
    }

    public static void addWatchTimeSeconds(Context context, int seconds) {
        addWatchSeconds(context, seconds);
    }

    // ==========================================
    // PREVIOUS INCOMPLETE LESSON (20+ MIN RESUME)
    // ==========================================
    public static class ResumeSession {
        public final String id;
        public final String title;
        public final String subject;
        public final String channel;
        public final long positionMs;
        public final long durationMs;

        public ResumeSession(String id, String title, String subject, String channel, long positionMs, long durationMs) {
            this.id = id;
            this.title = title;
            this.subject = subject;
            this.channel = channel;
            this.positionMs = positionMs;
            this.durationMs = durationMs;
        }

        public String getFormattedPosition() {
            int totalSec = (int) (positionMs / 1000L);
            int m = totalSec / 60;
            int s = totalSec % 60;
            return String.format(Locale.getDefault(), "%02d:%02d", m, s);
        }
    }

    public static void saveLastWatchedSession(Context context, Class11Video video, long posMs, long durMs) {
        if (video == null || posMs < 10000L) return; // ignore < 10s
        // Auto-add to Incomplete Lessons if user has watched significant time!
        addIncompleteLesson(context, video);

        getPrefs(context).edit()
                .putString(KEY_RESUME_ID, video.getId())
                .putString(KEY_RESUME_TITLE, video.getTitle())
                .putString(KEY_RESUME_SUBJECT, video.getSubject())
                .putString(KEY_RESUME_CHANNEL, video.getChannel())
                .putLong(KEY_RESUME_POS, posMs)
                .putLong(KEY_RESUME_DUR, durMs)
                .apply();
    }

    public static ResumeSession getLastWatchedSession(Context context) {
        SharedPreferences sp = getPrefs(context);
        String id = sp.getString(KEY_RESUME_ID, "");
        if (id.isEmpty()) return null;

        long pos = sp.getLong(KEY_RESUME_POS, 0);
        long dur = sp.getLong(KEY_RESUME_DUR, 0);
        String title = sp.getString(KEY_RESUME_TITLE, "");
        String subject = sp.getString(KEY_RESUME_SUBJECT, "Class 11");
        String channel = sp.getString(KEY_RESUME_CHANNEL, "");

        // Show prompt if watched significantly (e.g. >= 20 mins or > 15% progress)
        if (pos >= (20 * 60 * 1000L) || (dur > 0 && pos > 60000L)) {
            return new ResumeSession(id, title, subject, channel, pos, dur);
        }
        return null;
    }

    public static void clearLastWatchedSession(Context context) {
        getPrefs(context).edit()
                .remove(KEY_RESUME_ID)
                .remove(KEY_RESUME_TITLE)
                .remove(KEY_RESUME_POS)
                .remove(KEY_RESUME_DUR)
                .apply();
    }

    // ==========================================
    // GESTURE TUTORIAL
    // ==========================================
    public static boolean isGestureTutorialShown(Context context) {
        return getPrefs(context).getBoolean(KEY_GESTURE_TUTORIAL_SHOWN, false);
    }

    public static void setGestureTutorialShown(Context context, boolean shown) {
        getPrefs(context).edit().putBoolean(KEY_GESTURE_TUTORIAL_SHOWN, shown).apply();
    }

    // ==========================================
    // JSON PERSISTENCE HELPERS
    // ==========================================
    private static List<Class11Video> loadVideos(Context context, String key) {
        List<Class11Video> list = new ArrayList<>();
        String jsonStr = getPrefs(context).getString(key, "[]");
        try {
            JSONArray arr = new JSONArray(jsonStr);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                list.add(new Class11Video(
                        obj.optString("id"),
                        obj.optString("title"),
                        obj.optString("subject"),
                        obj.optString("channel"),
                        obj.optString("views", "Focus Lecture"),
                        obj.optString("duration", "Lesson"),
                        obj.optString("badge", "STUDY TRACK"),
                        obj.optString("description", "")
                ));
            }
        } catch (Exception ignored) {}
        return list;
    }

    private static void saveVideos(Context context, String key, List<Class11Video> list) {
        try {
            JSONArray arr = new JSONArray();
            for (Class11Video v : list) {
                JSONObject obj = new JSONObject();
                obj.put("id", v.getId());
                obj.put("title", v.getTitle());
                obj.put("subject", v.getSubject());
                obj.put("channel", v.getChannel());
                obj.put("views", v.getViews());
                obj.put("duration", v.getDuration());
                obj.put("badge", v.getBadge());
                obj.put("description", v.getDescription());
                arr.put(obj);
            }
            getPrefs(context).edit().putString(key, arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    private static void removeVideo(Context context, String key, String videoId) {
        if (videoId == null) return;
        List<Class11Video> list = loadVideos(context, key);
        boolean changed = false;
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i).getId().equals(videoId)) {
                list.remove(i);
                changed = true;
            }
        }
        if (changed) {
            saveVideos(context, key, list);
        }
    }
}
