package com.abhi.study;

import android.annotation.SuppressLint;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;

public class PermissionManagerActivity extends AppCompatActivity {

    public static final String EXTRA_TARGET_MODE = "target_mode";
    public static final String EXTRA_TARGET_MINUTES = "target_minutes";
    public static final String EXTRA_TARGET_LABEL = "target_label";

    private static final int REQ_PHONE_PERMISSIONS = 201;
    private static final int REQ_POST_NOTIF = 202;
    private static final int REQ_CAMERA = 203;
    private static final int REQ_DEVICE_ADMIN = 204;

    private String targetMode = "Simple";
    private int targetMinutes = 0;
    private String targetLabel = "Free Time";
    private boolean isDeepMode = false;

    // Overall Status Views
    private TextView tvOverallStatusBadge;
    private TextView tvOverallProgressText;
    private TextView tvOverallSubtitle;
    private TextView tvOverallPercent;
    private ProgressBar pbOverallPermissions;

    // AI Card Views
    private View cardAiSetup;
    private TextView tvAiKeyStatus;
    private TextView badgeAiStatus;
    private SwitchCompat switchAiSetup;
    private EditText etGeminiApiKey;
    private AppCompatButton btnValidateAiKey;
    private AppCompatButton btnSaveAiKey;
    private View btnGetFreeKeyLink;

    // System Permission Cards, Badges & Switches
    private View cardPermOverlay;
    private TextView badgePermOverlay;
    private SwitchCompat switchPermOverlay;
    private TextView btnTutorialOverlay;
    private View layoutTutorialOverlay;

    private View cardPermNotifListener;
    private TextView badgePermNotifListener;
    private SwitchCompat switchPermNotifListener;
    private TextView btnTutorialNotifListener;
    private View layoutTutorialNotifListener;

    private View cardPermPhone;
    private TextView badgePermPhone;
    private SwitchCompat switchPermPhone;
    private TextView btnTutorialPhone;
    private View layoutTutorialPhone;

    private View cardPermPostNotif;
    private TextView badgePermPostNotif;
    private SwitchCompat switchPermPostNotif;

    private View cardPermBattery;
    private TextView badgePermBattery;
    private SwitchCompat switchPermBattery;

    private View cardPermCamera;
    private TextView badgePermCamera;
    private SwitchCompat switchPermCamera;

    private View cardPermDeviceAdmin;
    private TextView badgePermDeviceAdmin;
    private SwitchCompat switchPermDeviceAdmin;
    private TextView btnTutorialDeviceAdmin;
    private View layoutTutorialDeviceAdmin;

    // Bottom Action Button
    private AppCompatButton btnProceedSession;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        makeEdgeToEdge();
        setContentView(R.layout.activity_permission_manager);

        parseIntentExtras();
        initViews();
        setupTutorialToggles();
        setupAiSection();
        setupClickListeners();
        animateEntrance();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshAllPermissionStates();
    }

    private void makeEdgeToEdge() {
        try {
            Window window = getWindow();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                window.setStatusBarColor(Color.TRANSPARENT);
                window.setNavigationBarColor(Color.TRANSPARENT);
            }
            int uiOptions = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            window.getDecorView().setSystemUiVisibility(uiOptions);
        } catch (Exception ignored) {}
    }

    private void parseIntentExtras() {
        Intent intent = getIntent();
        if (intent != null) {
            targetMode = intent.getStringExtra(EXTRA_TARGET_MODE);
            if (targetMode == null || targetMode.isEmpty()) targetMode = "Simple";
            targetMinutes = intent.getIntExtra(EXTRA_TARGET_MINUTES, 0);
            targetLabel = intent.getStringExtra(EXTRA_TARGET_LABEL);
            if (targetLabel == null) targetLabel = "Free Time";
        }
        isDeepMode = "Deep".equalsIgnoreCase(targetMode);
    }

    private void initViews() {
        View btnBack = findViewById(R.id.btnPermBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        tvOverallStatusBadge = findViewById(R.id.tvOverallStatusBadge);
        tvOverallProgressText = findViewById(R.id.tvOverallProgressText);
        tvOverallSubtitle = findViewById(R.id.tvOverallSubtitle);
        tvOverallPercent = findViewById(R.id.tvOverallPercent);
        pbOverallPermissions = findViewById(R.id.pbOverallPermissions);

        // AI
        cardAiSetup = findViewById(R.id.cardAiSetup);
        tvAiKeyStatus = findViewById(R.id.tvAiKeyStatus);
        badgeAiStatus = findViewById(R.id.badgeAiStatus);
        switchAiSetup = findViewById(R.id.switchAiSetup);
        etGeminiApiKey = findViewById(R.id.etGeminiApiKey);
        btnValidateAiKey = findViewById(R.id.btnValidateAiKey);
        btnSaveAiKey = findViewById(R.id.btnSaveAiKey);
        btnGetFreeKeyLink = findViewById(R.id.btnGetFreeKeyLink);

        // Overlay
        cardPermOverlay = findViewById(R.id.cardPermOverlay);
        badgePermOverlay = findViewById(R.id.badgePermOverlay);
        switchPermOverlay = findViewById(R.id.switchPermOverlay);
        btnTutorialOverlay = findViewById(R.id.btnTutorialOverlay);
        layoutTutorialOverlay = findViewById(R.id.layoutTutorialOverlay);

        // Notif Listener
        cardPermNotifListener = findViewById(R.id.cardPermNotifListener);
        badgePermNotifListener = findViewById(R.id.badgePermNotifListener);
        switchPermNotifListener = findViewById(R.id.switchPermNotifListener);
        btnTutorialNotifListener = findViewById(R.id.btnTutorialNotifListener);
        layoutTutorialNotifListener = findViewById(R.id.layoutTutorialNotifListener);

        // Phone
        cardPermPhone = findViewById(R.id.cardPermPhone);
        badgePermPhone = findViewById(R.id.badgePermPhone);
        switchPermPhone = findViewById(R.id.switchPermPhone);
        btnTutorialPhone = findViewById(R.id.btnTutorialPhone);
        layoutTutorialPhone = findViewById(R.id.layoutTutorialPhone);

        // Post Notif
        cardPermPostNotif = findViewById(R.id.cardPermPostNotif);
        badgePermPostNotif = findViewById(R.id.badgePermPostNotif);
        switchPermPostNotif = findViewById(R.id.switchPermPostNotif);

        // Battery
        cardPermBattery = findViewById(R.id.cardPermBattery);
        badgePermBattery = findViewById(R.id.badgePermBattery);
        switchPermBattery = findViewById(R.id.switchPermBattery);

        // Camera
        cardPermCamera = findViewById(R.id.cardPermCamera);
        badgePermCamera = findViewById(R.id.badgePermCamera);
        switchPermCamera = findViewById(R.id.switchPermCamera);

        // Device Admin
        cardPermDeviceAdmin = findViewById(R.id.cardPermDeviceAdmin);
        badgePermDeviceAdmin = findViewById(R.id.badgePermDeviceAdmin);
        switchPermDeviceAdmin = findViewById(R.id.switchPermDeviceAdmin);
        btnTutorialDeviceAdmin = findViewById(R.id.btnTutorialDeviceAdmin);
        layoutTutorialDeviceAdmin = findViewById(R.id.layoutTutorialDeviceAdmin);

        // Bottom Button
        btnProceedSession = findViewById(R.id.btnProceedSession);
        if (btnProceedSession != null) {
            btnProceedSession.setText("PROCEED TO " + targetMode.toUpperCase() + " SESSION");
            btnProceedSession.setOnClickListener(v -> attemptProceedToSession());
        }
    }

    private void setupTutorialToggles() {
        setupToggle(btnTutorialOverlay, layoutTutorialOverlay);
        setupToggle(btnTutorialNotifListener, layoutTutorialNotifListener);
        setupToggle(btnTutorialPhone, layoutTutorialPhone);
        setupToggle(btnTutorialDeviceAdmin, layoutTutorialDeviceAdmin);
    }

    private void setupToggle(TextView btn, View layout) {
        if (btn == null || layout == null) return;
        btn.setOnClickListener(v -> {
            boolean isVisible = layout.getVisibility() == View.VISIBLE;
            if (isVisible) {
                layout.setVisibility(View.GONE);
                btn.setText("📖 How to enable tutorial ▼");
            } else {
                layout.setVisibility(View.VISIBLE);
                btn.setText("📖 Hide tutorial ▲");
                layout.setAlpha(0f);
                layout.animate().alpha(1f).setDuration(220).start();
            }
        });
    }

    private void setupAiSection() {
        String existingKey = GeminiAiManager.getApiKey(this);
        if (etGeminiApiKey != null && !existingKey.isEmpty()) {
            etGeminiApiKey.setText(existingKey);
            if (btnValidateAiKey != null && GeminiAiManager.hasValidApiKey(this)) {
                btnValidateAiKey.setText("VERIFIED ✓");
            }
        }

        if (etGeminiApiKey != null) {
            etGeminiApiKey.addTextChangedListener(new android.text.TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (btnValidateAiKey != null && !"TESTING...".equals(btnValidateAiKey.getText())) {
                        btnValidateAiKey.setText("TEST KEY");
                    }
                }
                @Override public void afterTextChanged(android.text.Editable s) {}
            });
        }

        if (btnGetFreeKeyLink != null) {
            btnGetFreeKeyLink.setOnClickListener(v -> {
                try {
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW,
                            Uri.parse("https://aistudio.google.com/app/apikey"));
                    startActivity(browserIntent);
                } catch (Exception e) {
                    Toast.makeText(this, "Visit: https://aistudio.google.com/app/apikey", Toast.LENGTH_LONG).show();
                }
            });
        }

        if (btnValidateAiKey != null) {
            btnValidateAiKey.setOnClickListener(v -> {
                String rawKey = etGeminiApiKey != null ? etGeminiApiKey.getText().toString() : "";
                final String key = rawKey.replaceAll("[\\s\"']", "");
                if (key.isEmpty()) {
                    Toast.makeText(this, "Please enter an API Key first.", Toast.LENGTH_SHORT).show();
                    return;
                }
                btnValidateAiKey.setText("TESTING...");
                btnValidateAiKey.setEnabled(false);

                GeminiAiManager.validateApiKey(this, key, new GeminiAiManager.ApiTestCallback() {
                    @Override
                    public void onSuccess(String modelName) {
                        btnValidateAiKey.setEnabled(true);
                        btnValidateAiKey.setText("VERIFIED ✓");
                        GeminiAiManager.setApiKey(PermissionManagerActivity.this, key);
                        if (etGeminiApiKey != null && !key.equals(rawKey)) {
                            etGeminiApiKey.setText(key);
                        }
                        refreshAllPermissionStates();
                        Toast.makeText(PermissionManagerActivity.this, "🎉 " + modelName, Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onError(String errorMessage) {
                        btnValidateAiKey.setEnabled(true);
                        btnValidateAiKey.setText("TEST KEY");
                        Toast.makeText(PermissionManagerActivity.this, "Verification failed: " + errorMessage, Toast.LENGTH_LONG).show();
                    }
                });
            });
        }

        if (btnSaveAiKey != null) {
            btnSaveAiKey.setOnClickListener(v -> {
                String rawKey = etGeminiApiKey != null ? etGeminiApiKey.getText().toString() : "";
                String key = rawKey.replaceAll("[\\s\"']", "");
                GeminiAiManager.setApiKey(this, key);
                if (etGeminiApiKey != null && !key.equals(rawKey)) {
                    etGeminiApiKey.setText(key);
                }
                refreshAllPermissionStates();
                Toast.makeText(this, key.isEmpty() ? "API Key cleared" : "API Key saved!", Toast.LENGTH_SHORT).show();
            });
        }
    }

    private void performCardClickFeedback(View card) {
        if (card != null) {
            try { card.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); } catch (Exception ignored) {}
            card.animate().scaleX(0.98f).scaleY(0.98f).setDuration(80)
                    .withEndAction(() -> card.animate().scaleX(1.0f).scaleY(1.0f).setDuration(120).start()).start();
        }
    }

    private void setupClickListeners() {
        // AI Card
        if (cardAiSetup != null) {
            cardAiSetup.setOnClickListener(v -> {
                performCardClickFeedback(cardAiSetup);
                View inputSec = findViewById(R.id.layoutAiKeyInputSection);
                if (inputSec != null) {
                    boolean visible = inputSec.getVisibility() == View.VISIBLE;
                    inputSec.setVisibility(visible ? View.GONE : View.VISIBLE);
                    if (!visible && etGeminiApiKey != null) {
                        etGeminiApiKey.requestFocus();
                    }
                }
            });
        }

        // Overlay
        if (cardPermOverlay != null) {
            cardPermOverlay.setOnClickListener(v -> {
                performCardClickFeedback(cardPermOverlay);
                StudyPermissionHelper.openOverlaySettings(this);
            });
        }

        // Notification Listener
        if (cardPermNotifListener != null) {
            cardPermNotifListener.setOnClickListener(v -> {
                performCardClickFeedback(cardPermNotifListener);
                StudyPermissionHelper.openNotificationListenerSettings(this);
            });
        }

        // Phone
        if (cardPermPhone != null) {
            cardPermPhone.setOnClickListener(v -> {
                performCardClickFeedback(cardPermPhone);
                if (!StudyPermissionHelper.isPhonePermissionsGranted(this)) {
                    ActivityCompat.requestPermissions(this, StudyPermissionHelper.PHONE_PERMISSIONS, REQ_PHONE_PERMISSIONS);
                } else {
                    StudyPermissionHelper.openAppSettings(this);
                }
            });
        }

        // Post Notifications
        if (cardPermPostNotif != null) {
            cardPermPostNotif.setOnClickListener(v -> {
                performCardClickFeedback(cardPermPostNotif);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    if (!StudyPermissionHelper.isNotificationPostGranted(this)) {
                        ActivityCompat.requestPermissions(this,
                                new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQ_POST_NOTIF);
                    } else {
                        StudyPermissionHelper.openAppSettings(this);
                    }
                } else {
                    StudyPermissionHelper.openAppSettings(this);
                }
            });
        }

        // Battery
        if (cardPermBattery != null) {
            cardPermBattery.setOnClickListener(v -> {
                performCardClickFeedback(cardPermBattery);
                StudyPermissionHelper.openBatteryOptimizationSettings(this);
            });
        }

        // Camera
        if (cardPermCamera != null) {
            cardPermCamera.setOnClickListener(v -> {
                performCardClickFeedback(cardPermCamera);
                if (!StudyPermissionHelper.isCameraGranted(this)) {
                    ActivityCompat.requestPermissions(this,
                            new String[]{android.Manifest.permission.CAMERA}, REQ_CAMERA);
                } else {
                    StudyPermissionHelper.openAppSettings(this);
                }
            });
        }

        // Device Admin
        if (cardPermDeviceAdmin != null) {
            cardPermDeviceAdmin.setOnClickListener(v -> {
                performCardClickFeedback(cardPermDeviceAdmin);
                StudyPermissionHelper.openDeviceAdminSettings(this, REQ_DEVICE_ADMIN);
            });
        }
    }

    private void refreshAllPermissionStates() {
        int grantedCount = 0;
        int totalCount = StudyPermissionHelper.getTotalPermissionsCount();

        // 1. AI Setup
        boolean hasAi = StudyPermissionHelper.isGeminiAiConfigured(this);
        if (switchAiSetup != null) switchAiSetup.setChecked(hasAi);
        if (hasAi) {
            grantedCount++;
            setGrantedStyle(cardAiSetup, badgeAiStatus, "CONFIGURED ✓");
            if (tvAiKeyStatus != null) {
                String k = GeminiAiManager.getApiKey(this);
                String masked = k.length() > 8 ? k.substring(0, 6) + "..." + k.substring(k.length() - 4) : "Active";
                tvAiKeyStatus.setText("AI Key Active (" + masked + ")");
            }
        } else {
            setActionStyle(cardAiSetup, badgeAiStatus, "SETUP KEY");
            if (tvAiKeyStatus != null) {
                tvAiKeyStatus.setText("Required for video checkpoint quizzes & doubts");
            }
        }

        // 2. Overlay
        boolean hasOverlay = StudyPermissionHelper.isOverlayGranted(this);
        if (switchPermOverlay != null) switchPermOverlay.setChecked(hasOverlay);
        if (hasOverlay) {
            grantedCount++;
            setGrantedStyle(cardPermOverlay, badgePermOverlay, "ACTIVE ✓");
        } else {
            setActionStyle(cardPermOverlay, badgePermOverlay, "REQUIRED");
        }

        // 3. Notification Listener
        boolean hasListener = StudyPermissionHelper.isNotificationListenerGranted(this);
        if (switchPermNotifListener != null) switchPermNotifListener.setChecked(hasListener);
        if (hasListener) {
            grantedCount++;
            setGrantedStyle(cardPermNotifListener, badgePermNotifListener, "ACTIVE ✓");
        } else {
            setActionStyle(cardPermNotifListener, badgePermNotifListener, "REQUIRED");
        }

        // 4. Phone
        boolean hasPhone = StudyPermissionHelper.isPhonePermissionsGranted(this);
        if (switchPermPhone != null) switchPermPhone.setChecked(hasPhone);
        if (hasPhone) {
            grantedCount++;
            setGrantedStyle(cardPermPhone, badgePermPhone, "ACTIVE ✓");
        } else {
            setActionStyle(cardPermPhone, badgePermPhone, "REQUIRED");
        }

        // 5. Post Notifications
        boolean hasPostNotif = StudyPermissionHelper.isNotificationPostGranted(this);
        if (switchPermPostNotif != null) switchPermPostNotif.setChecked(hasPostNotif);
        if (hasPostNotif) {
            grantedCount++;
            setGrantedStyle(cardPermPostNotif, badgePermPostNotif, "ACTIVE ✓");
        } else {
            setActionStyle(cardPermPostNotif, badgePermPostNotif, "REQUIRED");
        }

        // 6. Battery
        boolean hasBattery = StudyPermissionHelper.isBatteryOptimizationIgnored(this);
        if (switchPermBattery != null) switchPermBattery.setChecked(hasBattery);
        if (hasBattery) {
            grantedCount++;
            setGrantedStyle(cardPermBattery, badgePermBattery, "ACTIVE ✓");
        } else {
            setActionStyle(cardPermBattery, badgePermBattery, "REQUIRED");
        }

        // 7. Camera
        boolean hasCamera = StudyPermissionHelper.isCameraGranted(this);
        if (switchPermCamera != null) switchPermCamera.setChecked(hasCamera);
        if (hasCamera) {
            grantedCount++;
            setGrantedStyle(cardPermCamera, badgePermCamera, "ACTIVE ✓");
        } else {
            setActionStyle(cardPermCamera, badgePermCamera, "REQUIRED");
        }

        // 8. Device Admin
        boolean hasDeviceAdmin = StudyPermissionHelper.isDeviceAdminGranted(this);
        if (switchPermDeviceAdmin != null) switchPermDeviceAdmin.setChecked(hasDeviceAdmin);
        if (hasDeviceAdmin) {
            grantedCount++;
            setGrantedStyle(cardPermDeviceAdmin, badgePermDeviceAdmin, "ACTIVE ✓");
        } else {
            setActionStyle(cardPermDeviceAdmin, badgePermDeviceAdmin, isDeepMode ? "REQUIRED FOR DEEP" : "OPTIONAL");
        }

        // Update Overall Progress Header
        int percent = (int) Math.round(((double) grantedCount / totalCount) * 100);
        if (tvOverallProgressText != null) {
            tvOverallProgressText.setText(grantedCount + " of " + totalCount + " Enabled");
        }
        if (tvOverallPercent != null) {
            tvOverallPercent.setText(percent + "%");
        }
        if (pbOverallPermissions != null) {
            pbOverallPermissions.setProgress(grantedCount);
        }

        boolean essentialGranted = StudyPermissionHelper.areRequiredPermissionsGranted(this, isDeepMode);
        if (tvOverallStatusBadge != null) {
            if (essentialGranted && grantedCount >= 7) {
                tvOverallStatusBadge.setText("ALL SYSTEMS OPERATIONAL");
                tvOverallStatusBadge.setBackgroundResource(R.drawable.bg_permission_pill_granted);
                tvOverallStatusBadge.setTextColor(Color.parseColor("#34D399"));
            } else if (essentialGranted) {
                tvOverallStatusBadge.setText("ESSENTIALS READY (" + targetMode.toUpperCase() + ")");
                tvOverallStatusBadge.setBackgroundResource(R.drawable.bg_permission_pill_granted);
                tvOverallStatusBadge.setTextColor(Color.parseColor("#34D399"));
            } else {
                tvOverallStatusBadge.setText("ACTION REQUIRED FOR " + targetMode.toUpperCase());
                tvOverallStatusBadge.setBackgroundResource(R.drawable.bg_permission_pill_action);
                tvOverallStatusBadge.setTextColor(Color.parseColor("#FFFFFF"));
            }
        }

        if (btnProceedSession != null) {
            if (essentialGranted) {
                btnProceedSession.setBackgroundResource(isDeepMode ? R.drawable.bg_button_deep : R.drawable.bg_button_simple);
                btnProceedSession.setAlpha(1.0f);
            } else {
                btnProceedSession.setBackgroundResource(R.drawable.bg_permission_card);
                btnProceedSession.setAlpha(0.7f);
            }
        }
    }

    private void setGrantedStyle(View card, TextView badge, String text) {
        if (card != null) card.setBackgroundResource(R.drawable.bg_permission_card_granted);
        if (badge != null) {
            badge.setText(text);
            badge.setBackgroundResource(R.drawable.bg_permission_pill_granted);
            badge.setTextColor(Color.parseColor("#34D399"));
        }
    }

    private void setActionStyle(View card, TextView badge, String text) {
        if (card != null) card.setBackgroundResource(R.drawable.bg_permission_card);
        if (badge != null) {
            badge.setText(text);
            badge.setBackgroundResource(R.drawable.bg_permission_pill_action);
            badge.setTextColor(Color.parseColor("#FFFFFF"));
        }
    }

    private void attemptProceedToSession() {
        boolean essentialGranted = StudyPermissionHelper.areRequiredPermissionsGranted(this, isDeepMode);
        if (!essentialGranted) {
            try {
                if (btnProceedSession != null) {
                    btnProceedSession.performHapticFeedback(HapticFeedbackConstants.REJECT);
                    btnProceedSession.animate().translationXBy(15).setDuration(60)
                            .withEndAction(() -> btnProceedSession.animate().translationXBy(-30).setDuration(60)
                                    .withEndAction(() -> btnProceedSession.animate().translationX(0).setDuration(60).start()).start()).start();
                }
            } catch (Exception ignored) {}

            String missing = "";
            if (!StudyPermissionHelper.isOverlayGranted(this)) missing += "• Dynamic Island Overlay\n";
            if (!StudyPermissionHelper.isNotificationListenerGranted(this)) missing += "• Notification Listener\n";
            if (!StudyPermissionHelper.isPhonePermissionsGranted(this)) missing += "• Phone & Caller Identity\n";
            if (isDeepMode && !StudyPermissionHelper.isDeviceAdminGranted(this)) missing += "• Deep Mode Device Admin Shield\n";

            Toast.makeText(this, "Please enable the following required access:\n" + missing, Toast.LENGTH_LONG).show();
            return;
        }

        try {
            if (btnProceedSession != null) {
                btnProceedSession.performHapticFeedback(HapticFeedbackConstants.CONFIRM);
            }
        } catch (Exception ignored) {}

        Intent intent = new Intent(this, StudySessionActivity.class);
        intent.putExtra(StudySessionActivity.EXTRA_MODE, targetMode);
        intent.putExtra(StudySessionActivity.EXTRA_MINUTES, targetMinutes);
        intent.putExtra(StudySessionActivity.EXTRA_LABEL, targetLabel);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }

    private void animateEntrance() {
        View[] cards = new View[]{
                cardAiSetup,
                cardPermOverlay,
                cardPermNotifListener,
                cardPermPhone,
                cardPermPostNotif,
                cardPermBattery,
                cardPermCamera,
                cardPermDeviceAdmin
        };

        for (int i = 0; i < cards.length; i++) {
            View c = cards[i];
            if (c != null) {
                c.setAlpha(0f);
                c.setTranslationY(60f);
                c.animate()
                        .alpha(1f)
                        .translationY(0f)
                        .setDuration(450)
                        .setStartDelay(100 + (i * 50))
                        .setInterpolator(new OvershootInterpolator(1.1f))
                        .start();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refreshAllPermissionStates();
    }
}
