package com.abhi.study;

import android.content.Context;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * StudyTorchManager:
 * Centralized manager and hardware observer for the flashlight / torch.
 * Synchronizes flashlight state with CameraManager.TorchCallback across
 * StudySessionActivity, Dynamic Island (iOS 18 Torch Fan widget), and system tiles.
 */
public class StudyTorchManager {

    private static final String TAG = "StudyTorchManager";

    public interface TorchListener {
        void onTorchStateChanged(boolean isTorchOn);
    }

    private static volatile StudyTorchManager instance;
    private final Context appContext;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final List<TorchListener> listeners = new CopyOnWriteArrayList<>();

    private CameraManager cameraManager;
    private String backCameraId = null;
    private boolean isTorchOn = false;
    private boolean isCallbackRegistered = false;

    private final CameraManager.TorchCallback torchCallback = new CameraManager.TorchCallback() {
        @Override
        public void onTorchModeChanged(@NonNull String cameraId, boolean enabled) {
            super.onTorchModeChanged(cameraId, enabled);
            if (backCameraId != null && backCameraId.equals(cameraId)) {
                if (isTorchOn != enabled) {
                    isTorchOn = enabled;
                    notifyListeners();
                }
            } else if (backCameraId == null) {
                if (isTorchOn != enabled) {
                    isTorchOn = enabled;
                    notifyListeners();
                }
            }
        }

        @Override
        public void onTorchModeUnavailable(@NonNull String cameraId) {
            super.onTorchModeUnavailable(cameraId);
            if (backCameraId != null && backCameraId.equals(cameraId)) {
                if (isTorchOn) {
                    isTorchOn = false;
                    notifyListeners();
                }
            }
        }
    };

    private StudyTorchManager(Context context) {
        this.appContext = context.getApplicationContext();
        initCameraManager();
    }

    public static StudyTorchManager getInstance(Context context) {
        if (instance == null) {
            synchronized (StudyTorchManager.class) {
                if (instance == null) {
                    instance = new StudyTorchManager(context);
                }
            }
        }
        return instance;
    }

    private void initCameraManager() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                cameraManager = (CameraManager) appContext.getSystemService(Context.CAMERA_SERVICE);
                if (cameraManager != null) {
                    for (String id : cameraManager.getCameraIdList()) {
                        CameraCharacteristics characteristics = cameraManager.getCameraCharacteristics(id);
                        Boolean hasFlash = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                        Integer facing = characteristics.get(CameraCharacteristics.LENS_FACING);
                        if (Boolean.TRUE.equals(hasFlash) && facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                            backCameraId = id;
                            break;
                        }
                    }
                    if (backCameraId == null && cameraManager.getCameraIdList().length > 0) {
                        backCameraId = cameraManager.getCameraIdList()[0];
                    }

                    registerCallback();
                }
            } catch (Exception e) {
                Log.e(TAG, "Failed to initialize CameraManager for torch", e);
            }
        }
    }

    private void registerCallback() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && cameraManager != null && !isCallbackRegistered) {
            try {
                cameraManager.registerTorchCallback(torchCallback, mainHandler);
                isCallbackRegistered = true;
            } catch (Exception e) {
                Log.e(TAG, "Failed to register TorchCallback", e);
            }
        }
    }

    public boolean isTorchOn() {
        return isTorchOn;
    }

    public void toggleTorch() {
        setTorch(!isTorchOn);
    }

    public void setTorch(boolean enabled) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && cameraManager != null && backCameraId != null) {
            try {
                cameraManager.setTorchMode(backCameraId, enabled);
                isTorchOn = enabled;
                notifyListeners();
            } catch (Exception e) {
                Log.e(TAG, "Error setting torch mode to: " + enabled, e);
            }
        }
    }

    public void addListener(TorchListener listener) {
        if (listener != null && !listeners.contains(listener)) {
            listeners.add(listener);
            listener.onTorchStateChanged(isTorchOn);
        }
    }

    public void removeListener(TorchListener listener) {
        if (listener != null) {
            listeners.remove(listener);
        }
    }

    private void notifyListeners() {
        mainHandler.post(() -> {
            for (TorchListener l : listeners) {
                try {
                    l.onTorchStateChanged(isTorchOn);
                } catch (Exception ignored) {}
            }
        });
    }
}
