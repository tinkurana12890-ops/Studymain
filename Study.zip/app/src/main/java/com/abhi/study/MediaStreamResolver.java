package com.abhi.study;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * MediaStreamResolver:
 * 100% Native, NewPipe-style direct multi-quality media stream extractor.
 * Resolves 1080p FHD, 720p HD, 480p, 360p, 240p, 144p video streams
 * and high-fidelity audio streams for native playback in AndroidX Media3 ExoPlayer.
 *
 * NO WebViews. NO browser embeds. NO YouTube web players. NO Google Play Services.
 */
public class MediaStreamResolver {

    public static class VideoStreamInfo {
        public final String qualityLabel; // "1080p FHD", "720p HD", "480p", "360p", "240p", "144p"
        public final int height;
        public final int width;
        public final int itag;
        public final String videoUrl;
        public final String audioUrl;
        public final boolean isProgressive;
        public final long contentLength;

        public VideoStreamInfo(String qualityLabel, int height, int width, int itag,
                               String videoUrl, String audioUrl, boolean isProgressive, long contentLength) {
            this.qualityLabel = qualityLabel;
            this.height = height;
            this.width = width;
            this.itag = itag;
            this.videoUrl = videoUrl;
            this.audioUrl = audioUrl;
            this.isProgressive = isProgressive;
            this.contentLength = contentLength;
        }
    }

    public static class MediaStreamResult {
        public final String videoId;
        public final Map<String, VideoStreamInfo> qualityStreams = new LinkedHashMap<>();
        public VideoStreamInfo bestStream;
        public VideoStreamInfo progressiveStream;
        public String audioUrl;
        public String hlsManifestUrl;

        public MediaStreamResult(String videoId) {
            this.videoId = videoId;
        }

        public List<String> getAvailableQualityLabels() {
            return new ArrayList<>(qualityStreams.keySet());
        }

        public boolean hasQuality(String qualityLabel) {
            if (qualityLabel == null) return false;
            for (String q : qualityStreams.keySet()) {
                if (qualityLabel.contains(q)) return true;
            }
            return false;
        }

        public VideoStreamInfo getStreamForQuality(String label) {
            if (label == null || label.startsWith("Auto")) {
                return bestStream != null ? bestStream : progressiveStream;
            }
            for (Map.Entry<String, VideoStreamInfo> entry : qualityStreams.entrySet()) {
                if (label.contains(entry.getKey())) {
                    return entry.getValue();
                }
            }
            return bestStream != null ? bestStream : progressiveStream;
        }
    }

    public interface StreamResultCallback {
        void onStreamsResolved(MediaStreamResult result);
        void onError(String message);
    }

    public interface StreamCallback {
        void onStreamResolved(String streamUrl);
        void onError(String message);
    }

    // Modern Android Client Versions supported by YouTube Innertube
    private static final String[] ANDROID_CLIENT_VERSIONS = {
            "21.26.364",
            "20.15.36",
            "20.10.35",
            "20.08.34"
    };

    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(4);
    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());

    public static void resolveMediaStream(final Context context, final String videoId, final StreamResultCallback callback) {
        if (videoId == null || videoId.trim().isEmpty() || callback == null) {
            if (callback != null) callback.onError("Invalid video identifier");
            return;
        }

        final String cleanVideoId = videoId.trim();
        final AtomicBoolean isResolved = new AtomicBoolean(false);

        EXECUTOR.execute(() -> {
            MediaStreamResult streamResult = null;

            // Strategy 1: Rotate through verified Android Innertube Client versions
            for (String version : ANDROID_CLIENT_VERSIONS) {
                if (isResolved.get()) return;
                streamResult = extractResultFromInnertube(cleanVideoId, version);
                if (streamResult != null && (!streamResult.qualityStreams.isEmpty() || streamResult.bestStream != null)) {
                    break;
                }
            }

            if (streamResult != null && (!streamResult.qualityStreams.isEmpty() || streamResult.bestStream != null) && isResolved.compareAndSet(false, true)) {
                final MediaStreamResult finalResult = streamResult;
                MAIN_HANDLER.post(() -> callback.onStreamsResolved(finalResult));
                return;
            }

            // Strategy 2: iOS Client fallback
            if (!isResolved.get()) {
                streamResult = extractResultFromInnertubeIos(cleanVideoId);
                if (streamResult != null && (!streamResult.qualityStreams.isEmpty() || streamResult.bestStream != null) && isResolved.compareAndSet(false, true)) {
                    final MediaStreamResult finalResult = streamResult;
                    MAIN_HANDLER.post(() -> callback.onStreamsResolved(finalResult));
                    return;
                }
            }

            // Strategy 3: Fast Invidious Fallback
            if (!isResolved.get()) {
                streamResult = queryInvidiousFallbackToResult(cleanVideoId);
                if (streamResult != null && (!streamResult.qualityStreams.isEmpty() || streamResult.bestStream != null) && isResolved.compareAndSet(false, true)) {
                    final MediaStreamResult finalResult = streamResult;
                    MAIN_HANDLER.post(() -> callback.onStreamsResolved(finalResult));
                    return;
                }
            }

            // If completely unresolvable, deliver clear error message
            if (isResolved.compareAndSet(false, true)) {
                MAIN_HANDLER.post(() -> callback.onError("Stream currently unavailable. Please select another lecture."));
            }
        });
    }

    public static void resolveStreamUrl(final String videoId, final StreamCallback callback) {
        resolveStreamUrl(null, videoId, callback);
    }

    public static void resolveStreamUrl(final Context context, final String videoId, final StreamCallback callback) {
        if (videoId == null || videoId.trim().isEmpty() || callback == null) {
            if (callback != null) callback.onError("Invalid video identifier");
            return;
        }

        resolveMediaStream(context, videoId, new StreamResultCallback() {
            @Override
            public void onStreamsResolved(MediaStreamResult result) {
                if (result.progressiveStream != null && result.progressiveStream.videoUrl != null) {
                    callback.onStreamResolved(result.progressiveStream.videoUrl);
                } else if (result.bestStream != null && result.bestStream.videoUrl != null) {
                    callback.onStreamResolved(result.bestStream.videoUrl);
                } else if (result.hlsManifestUrl != null && !result.hlsManifestUrl.isEmpty()) {
                    callback.onStreamResolved(result.hlsManifestUrl);
                } else {
                    callback.onError("Stream not available");
                }
            }

            @Override
            public void onError(String message) {
                callback.onError(message);
            }
        });
    }

    private static MediaStreamResult extractResultFromInnertube(String videoId, String clientVersion) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL("https://www.youtube.com/youtubei/v1/player?prettyPrint=false");
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            conn.setDoOutput(true);

            String userAgent = "com.google.android.youtube/" + clientVersion + " (Linux; U; Android 11) gzip";
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("User-Agent", userAgent);
            conn.setRequestProperty("X-YouTube-Client-Name", "3");
            conn.setRequestProperty("X-YouTube-Client-Version", clientVersion);

            JSONObject client = new JSONObject();
            client.put("clientName", "ANDROID");
            client.put("clientVersion", clientVersion);
            client.put("androidSdkVersion", 30);
            client.put("userAgent", userAgent);
            client.put("osName", "Android");
            client.put("osVersion", "11");
            client.put("hl", "en");
            client.put("gl", "IN");

            JSONObject context = new JSONObject();
            context.put("client", client);

            JSONObject body = new JSONObject();
            body.put("context", context);
            body.put("videoId", videoId);
            body.put("contentCheckOk", true);
            body.put("racyCheckOk", true);

            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(bytes);
                os.flush();
            }

            if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
                reader.close();

                return parseStreamingDataToResult(videoId, sb.toString());
            }
        } catch (Exception ignored) {
        } finally {
            if (conn != null) conn.disconnect();
        }
        return null;
    }

    private static MediaStreamResult extractResultFromInnertubeIos(String videoId) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL("https://www.youtube.com/youtubei/v1/player?prettyPrint=false");
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            conn.setDoOutput(true);

            String iosVersion = "21.26.4";
            String userAgent = "com.google.ios.youtube/" + iosVersion + " (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)";
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("User-Agent", userAgent);
            conn.setRequestProperty("X-YouTube-Client-Name", "5");
            conn.setRequestProperty("X-YouTube-Client-Version", iosVersion);

            JSONObject client = new JSONObject();
            client.put("clientName", "IOS");
            client.put("clientVersion", iosVersion);
            client.put("deviceMake", "Apple");
            client.put("deviceModel", "iPhone16,2");
            client.put("userAgent", userAgent);
            client.put("osName", "iPhone");
            client.put("osVersion", "18.3.2.22D82");
            client.put("hl", "en");
            client.put("gl", "IN");

            JSONObject context = new JSONObject();
            context.put("client", client);

            JSONObject body = new JSONObject();
            body.put("context", context);
            body.put("videoId", videoId);
            body.put("contentCheckOk", true);
            body.put("racyCheckOk", true);

            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(bytes);
                os.flush();
            }

            if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
                reader.close();

                return parseStreamingDataToResult(videoId, sb.toString());
            }
        } catch (Exception ignored) {
        } finally {
            if (conn != null) conn.disconnect();
        }
        return null;
    }

    public static MediaStreamResult parseStreamingDataToResult(String videoId, String jsonString) {
        if (jsonString == null || jsonString.isEmpty()) return null;
        try {
            JSONObject root = new JSONObject(jsonString);

            // Verify Playability Status
            JSONObject playability = root.optJSONObject("playabilityStatus");
            if (playability != null) {
                String status = playability.optString("status", "");
                if (!"OK".equalsIgnoreCase(status)) {
                    return null;
                }
            }

            if (!root.has("streamingData")) {
                return null;
            }

            JSONObject sd = root.getJSONObject("streamingData");
            MediaStreamResult result = new MediaStreamResult(videoId);

            // Step 1: HLS Manifest
            if (sd.has("hlsManifestUrl")) {
                String hls = sd.optString("hlsManifestUrl");
                if (hls != null && !hls.isEmpty()) {
                    result.hlsManifestUrl = hls.replace("&amp;", "&");
                }
            }

            // Step 2: Extract Best Audio Stream from adaptiveFormats
            String bestAudioUrl = null;
            long bestAudioBitrate = 0;
            boolean hasMp4Audio = false;

            if (sd.has("adaptiveFormats")) {
                JSONArray adaptive = sd.getJSONArray("adaptiveFormats");
                for (int i = 0; i < adaptive.length(); i++) {
                    JSONObject f = adaptive.getJSONObject(i);
                    String mime = f.optString("mimeType", "");
                    String fUrl = f.optString("url", "");
                    if (fUrl.isEmpty()) continue;
                    fUrl = fUrl.replace("&amp;", "&");

                    if (mime.startsWith("audio/")) {
                        long bitrate = f.optLong("bitrate", 0);
                        boolean isMp4 = mime.contains("audio/mp4") || f.optInt("itag", 0) == 140;

                        if (!hasMp4Audio && isMp4) {
                            bestAudioUrl = fUrl;
                            bestAudioBitrate = bitrate;
                            hasMp4Audio = true;
                        } else if (isMp4 && bitrate > bestAudioBitrate) {
                            bestAudioUrl = fUrl;
                            bestAudioBitrate = bitrate;
                        } else if (!hasMp4Audio && bitrate > bestAudioBitrate) {
                            bestAudioUrl = fUrl;
                            bestAudioBitrate = bitrate;
                        }
                    }
                }
            }
            result.audioUrl = bestAudioUrl;

            // Step 3: Progressive Formats (Combined audio + video)
            if (sd.has("formats")) {
                JSONArray formats = sd.getJSONArray("formats");
                for (int i = 0; i < formats.length(); i++) {
                    JSONObject f = formats.getJSONObject(i);
                    String fUrl = f.optString("url", "");
                    if (fUrl.isEmpty()) continue;
                    fUrl = fUrl.replace("&amp;", "&");

                    int itag = f.optInt("itag", 0);
                    int height = f.optInt("height", 0);
                    int width = f.optInt("width", 0);
                    String qLabel = f.optString("qualityLabel", "");
                    long len = f.optLong("contentLength", 0);

                    if (itag == 22 || height == 720 || qLabel.contains("720")) {
                        VideoStreamInfo info = new VideoStreamInfo("720p HD", 720, width > 0 ? width : 1280, itag, fUrl, null, true, len);
                        result.qualityStreams.put("720p", info);
                        if (result.progressiveStream == null) result.progressiveStream = info;
                    } else if (itag == 18 || height == 360 || qLabel.contains("360")) {
                        VideoStreamInfo info = new VideoStreamInfo("360p", 360, width > 0 ? width : 640, itag, fUrl, null, true, len);
                        result.qualityStreams.put("360p", info);
                        if (result.progressiveStream == null) result.progressiveStream = info;
                    } else if (result.progressiveStream == null) {
                        VideoStreamInfo info = new VideoStreamInfo(height > 0 ? (height + "p") : "Standard", height, width, itag, fUrl, null, true, len);
                        result.progressiveStream = info;
                    }
                }
            }

            // Step 4: Adaptive Video Formats (1080p, 720p, 480p, 360p, 240p, 144p)
            if (sd.has("adaptiveFormats")) {
                JSONArray adaptive = sd.getJSONArray("adaptiveFormats");
                for (int i = 0; i < adaptive.length(); i++) {
                    JSONObject f = adaptive.getJSONObject(i);
                    String mime = f.optString("mimeType", "");
                    String fUrl = f.optString("url", "");
                    if (fUrl.isEmpty() || !mime.startsWith("video/")) continue;
                    fUrl = fUrl.replace("&amp;", "&");

                    int itag = f.optInt("itag", 0);
                    int height = f.optInt("height", 0);
                    int width = f.optInt("width", 0);
                    String qLabel = f.optString("qualityLabel", "");
                    long len = f.optLong("contentLength", 0);
                    boolean isMp4 = mime.contains("video/mp4");

                    String key = null;
                    String displayName = null;
                    int targetH = height;
                    int targetW = width;

                    if (height >= 1080 || qLabel.contains("1080")) {
                        key = "1080p";
                        displayName = "1080p FHD";
                        targetH = 1080;
                        if (targetW <= 0) targetW = 1920;
                    } else if (height >= 720 || qLabel.contains("720")) {
                        key = "720p";
                        displayName = "720p HD";
                        targetH = 720;
                        if (targetW <= 0) targetW = 1280;
                    } else if (height >= 480 || qLabel.contains("480")) {
                        key = "480p";
                        displayName = "480p";
                        targetH = 480;
                        if (targetW <= 0) targetW = 854;
                    } else if (height >= 360 || qLabel.contains("360")) {
                        key = "360p";
                        displayName = "360p";
                        targetH = 360;
                        if (targetW <= 0) targetW = 640;
                    } else if (height >= 240 || qLabel.contains("240")) {
                        key = "240p";
                        displayName = "240p";
                        targetH = 240;
                        if (targetW <= 0) targetW = 426;
                    } else if (height >= 144 || qLabel.contains("144")) {
                        key = "144p";
                        displayName = "144p";
                        targetH = 144;
                        if (targetW <= 0) targetW = 256;
                    }

                    if (key != null) {
                        VideoStreamInfo existing = result.qualityStreams.get(key);
                        // If progressive already registered for this quality, keep it, otherwise prefer mp4 over webm
                        if (existing == null || (!existing.isProgressive && isMp4)) {
                            VideoStreamInfo info = new VideoStreamInfo(displayName, targetH, targetW, itag, fUrl, bestAudioUrl, false, len);
                            result.qualityStreams.put(key, info);
                        }
                    }
                }
            }

            // Step 5: Choose bestStream
            String[] qualityPriority = {"1080p", "720p", "480p", "360p", "240p", "144p"};
            for (String q : qualityPriority) {
                if (result.qualityStreams.containsKey(q)) {
                    result.bestStream = result.qualityStreams.get(q);
                    break;
                }
            }
            if (result.bestStream == null) {
                result.bestStream = result.progressiveStream;
            }

            if (!result.qualityStreams.isEmpty() || result.bestStream != null || result.hlsManifestUrl != null) {
                return result;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private static MediaStreamResult queryInvidiousFallbackToResult(String videoId) {
        String[] instances = {
                "https://inv.nadeko.net",
                "https://invidious.nerdvpn.de",
                "https://invidious.tiekoetter.com"
        };

        for (String instance : instances) {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(instance + "/api/v1/videos/" + videoId);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(2500);
                conn.setReadTimeout(2500);
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");

                if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                    }
                    reader.close();

                    JSONObject json = new JSONObject(sb.toString());
                    MediaStreamResult result = new MediaStreamResult(videoId);

                    if (json.has("hlsUrl") && !json.isNull("hlsUrl")) {
                        result.hlsManifestUrl = json.getString("hlsUrl");
                    }

                    // Best Audio
                    String bestAudio = null;
                    if (json.has("adaptiveFormats")) {
                        JSONArray adaptive = json.getJSONArray("adaptiveFormats");
                        for (int i = 0; i < adaptive.length(); i++) {
                            JSONObject f = adaptive.getJSONObject(i);
                            String type = f.optString("type", "");
                            if (type.startsWith("audio/")) {
                                bestAudio = f.optString("url");
                                if (type.contains("mp4")) break;
                            }
                        }
                    }
                    result.audioUrl = bestAudio;

                    // Formats
                    if (json.has("formatStreams")) {
                        JSONArray streams = json.getJSONArray("formatStreams");
                        for (int i = 0; i < streams.length(); i++) {
                            JSONObject f = streams.getJSONObject(i);
                            String fUrl = f.optString("url");
                            String res = f.optString("resolution", f.optString("qualityLabel", ""));
                            int itag = f.optInt("itag", 0);
                            if (fUrl != null && !fUrl.isEmpty()) {
                                if (res.contains("720")) {
                                    VideoStreamInfo info = new VideoStreamInfo("720p HD", 720, 1280, itag, fUrl, null, true, 0);
                                    result.qualityStreams.put("720p", info);
                                    if (result.progressiveStream == null) result.progressiveStream = info;
                                } else if (res.contains("360")) {
                                    VideoStreamInfo info = new VideoStreamInfo("360p", 360, 640, itag, fUrl, null, true, 0);
                                    result.qualityStreams.put("360p", info);
                                    if (result.progressiveStream == null) result.progressiveStream = info;
                                }
                            }
                        }
                    }

                    if (json.has("adaptiveFormats")) {
                        JSONArray adaptive = json.getJSONArray("adaptiveFormats");
                        for (int i = 0; i < adaptive.length(); i++) {
                            JSONObject f = adaptive.getJSONObject(i);
                            String fUrl = f.optString("url");
                            String res = f.optString("resolution", f.optString("qualityLabel", ""));
                            String type = f.optString("type", "");
                            int itag = f.optInt("itag", 0);
                            if (fUrl != null && !fUrl.isEmpty() && type.startsWith("video/")) {
                                String key = null;
                                String label = null;
                                int h = 0;
                                int w = 0;
                                if (res.contains("1080")) { key = "1080p"; label = "1080p FHD"; h = 1080; w = 1920; }
                                else if (res.contains("720")) { key = "720p"; label = "720p HD"; h = 720; w = 1280; }
                                else if (res.contains("480")) { key = "480p"; label = "480p"; h = 480; w = 854; }
                                else if (res.contains("360")) { key = "360p"; label = "360p"; h = 360; w = 640; }
                                else if (res.contains("240")) { key = "240p"; label = "240p"; h = 240; w = 426; }
                                else if (res.contains("144")) { key = "144p"; label = "144p"; h = 144; w = 256; }

                                if (key != null && !result.qualityStreams.containsKey(key)) {
                                    result.qualityStreams.put(key, new VideoStreamInfo(label, h, w, itag, fUrl, bestAudio, false, 0));
                                }
                            }
                        }
                    }

                    String[] qualityPriority = {"1080p", "720p", "480p", "360p", "240p", "144p"};
                    for (String q : qualityPriority) {
                        if (result.qualityStreams.containsKey(q)) {
                            result.bestStream = result.qualityStreams.get(q);
                            break;
                        }
                    }
                    if (result.bestStream == null) {
                        result.bestStream = result.progressiveStream;
                    }

                    if (!result.qualityStreams.isEmpty() || result.bestStream != null || result.hlsManifestUrl != null) {
                        return result;
                    }
                }
            } catch (Exception ignored) {
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        return null;
    }
}
