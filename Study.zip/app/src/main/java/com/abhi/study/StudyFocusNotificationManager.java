package com.abhi.study;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.service.notification.StatusBarNotification;
import android.telecom.TelecomManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.view.KeyEvent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * StudyFocusNotificationManager:
 * Central engine to track, manage, and filter active phone calls, WhatsApp incoming/ongoing calls,
 * and messages exclusively for strictly allowed apps (Phone, WhatsApp, SMS).
 */
public class StudyFocusNotificationManager {

    public interface FocusUpdateListener {
        void onFocusDataChanged();
    }

    private static final List<FocusUpdateListener> listeners = new CopyOnWriteArrayList<>();

    // Whitelisted package identifiers
    public static final String PKG_WHATSAPP = "com.whatsapp";
    public static final String PKG_WHATSAPP_BUSINESS = "com.whatsapp.w4b";

    // Data structures
    public static class PhoneCallInfo {
        public String callerName = "Phone Call";
        public String callerNumber = "";
        public boolean isRinging = false;
        public boolean isOngoing = false;
        public boolean isOutgoing = false;
        public PendingIntent answerIntent = null;
        public PendingIntent declineIntent = null;
        public PendingIntent contentIntent = null;
        public PendingIntent fullScreenIntent = null;

        public String getInitials() {
            return getContactInitials(callerName);
        }
    }

    public static class WhatsAppCallInfo {
        public String callerName = "WhatsApp Caller";
        public String callType = "Voice Call";
        public boolean isRinging = true;
        public boolean isOngoing = false;
        public boolean isOutgoing = false;
        public PendingIntent answerIntent = null;
        public PendingIntent declineIntent = null;
        public PendingIntent contentIntent = null;
        public PendingIntent fullScreenIntent = null;

        public String getInitials() {
            return getContactInitials(callerName);
        }
    }

    public static class FocusMessageItem {
        public String key;
        public String packageName;
        public String appTitle; // "WhatsApp" or "Messages"
        public String sender;
        public String message;
        public long postTime;
        public PendingIntent contentIntent;
        public long eventId = System.currentTimeMillis();

        public boolean isWhatsApp() {
            return packageName != null && packageName.toLowerCase().contains("whatsapp");
        }

        public String getInitials() {
            return getContactInitials(sender);
        }

        public String getUniqueMessageSignature() {
            return (key != null ? key : "") + "#" + postTime + "#" + (message != null ? message.hashCode() : 0);
        }
    }

    private static PhoneCallInfo activePhoneCall = null;
    private static WhatsAppCallInfo activeWhatsAppCall = null;
    private static final Map<String, FocusMessageItem> recentMessages = Collections.synchronizedMap(new LinkedHashMap<>());

    public static void registerListener(FocusUpdateListener l) {
        if (l != null && !listeners.contains(l)) {
            listeners.add(l);
        }
    }

    public static void unregisterListener(FocusUpdateListener l) {
        if (l != null) {
            listeners.remove(l);
        }
    }

    private static void notifyListeners() {
        for (FocusUpdateListener l : listeners) {
            try {
                l.onFocusDataChanged();
            } catch (Exception ignored) {}
        }
    }

    public static String getContactInitials(String name) {
        if (TextUtils.isEmpty(name)) return "iOS";
        String clean = name.trim();
        String[] parts = clean.split("\\s+");
        if (parts.length >= 2 && parts[0].length() > 0 && parts[1].length() > 0) {
            return ("" + parts[0].charAt(0) + parts[1].charAt(0)).toUpperCase();
        } else if (clean.length() >= 2) {
            return clean.substring(0, 2).toUpperCase();
        } else {
            return clean.toUpperCase();
        }
    }

    public static String resolveContactName(Context context, String phoneNumber) {
        if (context == null || TextUtils.isEmpty(phoneNumber)) return phoneNumber;
        try {
            Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber));
            String[] projection = new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME};
            try (Cursor cursor = context.getContentResolver().query(uri, projection, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int nameIdx = cursor.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME);
                    if (nameIdx >= 0) {
                        String name = cursor.getString(nameIdx);
                        if (!TextUtils.isEmpty(name)) {
                            return name;
                        }
                    }
                }
            }
        } catch (Exception ignored) {}
        return phoneNumber;
    }

    public static boolean isWhitelistedPackage(String pkg) {
        if (pkg == null) return false;
        String p = pkg.toLowerCase();
        return p.contains("whatsapp")
                || p.contains("dialer")
                || p.contains("telecom")
                || p.contains("telephony")
                || p.contains("phone")
                || p.contains("incall")
                || p.contains("call")
                || p.contains("contact")
                || p.contains("messaging")
                || p.contains("mms")
                || p.contains("sms");
    }

    public static boolean isNotificationListenerEnabled(Context context) {
        if (context == null) return false;
        String pkgName = context.getPackageName();
        final String flat = Settings.Secure.getString(context.getContentResolver(), "enabled_notification_listeners");
        if (!TextUtils.isEmpty(flat)) {
            final String[] names = flat.split(":");
            for (String name : names) {
                final ComponentName cn = ComponentName.unflattenFromString(name);
                if (cn != null && TextUtils.equals(pkgName, cn.getPackageName())) {
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean isTelephonyMonitoringStarted = false;

    public static boolean hasPhonePermissions(Context context) {
        if (context == null) return false;
        return androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_PHONE_STATE) == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    public static void startTelephonyMonitoring(Context context) {
        if (context == null || isTelephonyMonitoringStarted) return;
        try {
            TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) return;
            isTelephonyMonitoringStarted = true;

            android.telephony.PhoneStateListener listener = new android.telephony.PhoneStateListener() {
                @Override
                public void onCallStateChanged(int state, String incomingNumber) {
                    if (state == TelephonyManager.CALL_STATE_RINGING) {
                        onPhoneRinging(context, incomingNumber);
                    } else if (state == TelephonyManager.CALL_STATE_OFFHOOK) {
                        onPhoneOffhook(context);
                    } else if (state == TelephonyManager.CALL_STATE_IDLE) {
                        onPhoneIdle(context);
                    }
                }
            };
            tm.listen(listener, android.telephony.PhoneStateListener.LISTEN_CALL_STATE);
        } catch (Exception ignored) {}
    }

    public static boolean canDrawOverlays(Context context) {
        if (context == null) return false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return Settings.canDrawOverlays(context);
        }
        return true;
    }

    public static void requestOverlayPermission(Context context) {
        if (context == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + context.getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            } catch (Exception e) {
                try {
                    Intent fallback = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                    fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(fallback);
                } catch (Exception ignored) {}
            }
        }
    }

    public static void openNotificationAccessSettings(Context context) {
        if (context == null) return;
        try {
            Intent intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            try {
                Intent fallback = new Intent(Settings.ACTION_SETTINGS);
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(fallback);
            } catch (Exception ignored) {}
        }
    }

    // Direct Phone State Receiver Callbacks (Guaranteed on all Android devices)
    public static void onPhoneRinging(Context context, String number) {
        if (activePhoneCall == null) {
            activePhoneCall = new PhoneCallInfo();
        }
        activePhoneCall.isOutgoing = false;
        activePhoneCall.isRinging = true;
        activePhoneCall.isOngoing = false;
        if (!TextUtils.isEmpty(number)) {
            activePhoneCall.callerNumber = number;
            String resolved = resolveContactName(context, number);
            activePhoneCall.callerName = !TextUtils.isEmpty(resolved) ? resolved : number;
        } else if (TextUtils.isEmpty(activePhoneCall.callerName) || activePhoneCall.callerName.equals("Phone Call")) {
            activePhoneCall.callerName = "Incoming Phone Call";
        }
        notifyListeners();
    }

    public static void onPhoneOffhook(Context context) {
        if (activePhoneCall == null) {
            activePhoneCall = new PhoneCallInfo();
            activePhoneCall.isOutgoing = true; // Offhook without ringing is outgoing call
        }
        activePhoneCall.isRinging = false;
        activePhoneCall.isOngoing = true;
        if (TextUtils.isEmpty(activePhoneCall.callerName) || activePhoneCall.callerName.equals("Phone Call")) {
            activePhoneCall.callerName = activePhoneCall.isOutgoing ? "Outgoing Call" : "Active Call";
        }
        notifyListeners();
    }

    public static void onPhoneIdle(Context context) {
        activePhoneCall = null;
        isManualMute = false;
        isManualSpeaker = false;
        notifyListeners();
    }

    // Called from StudyNotificationListenerService
    public static void processPostedNotification(StatusBarNotification sbn) {
        if (sbn == null) return;
        String pkg = sbn.getPackageName();

        Notification n = sbn.getNotification();
        if (n == null) return;

        boolean isCallCategory = Notification.CATEGORY_CALL.equals(n.category);
        if (!isWhitelistedPackage(pkg) && !isCallCategory && n.fullScreenIntent == null) return;

        Bundle extras = n.extras;
        CharSequence titleSeq = extras != null ? extras.getCharSequence(Notification.EXTRA_TITLE) : null;
        CharSequence textSeq = extras != null ? extras.getCharSequence(Notification.EXTRA_TEXT) : null;

        String title = titleSeq != null ? titleSeq.toString().trim() : "";
        String text = textSeq != null ? textSeq.toString().trim() : "";

        // Discard silent/background WhatsApp noise
        if (text.contains("Checking for new messages")
                || text.contains("WhatsApp Web is currently active")
                || text.contains("Backup in progress")
                || text.contains("Searching for new messages")) {
            return;
        }

        String lowerText = text.toLowerCase();
        String lowerTitle = title.toLowerCase();

        // Check if missed call (missed calls must not be treated as ringing calls)
        boolean isMissed = lowerText.contains("missed") || lowerTitle.contains("missed") || lowerText.contains("छूटी");

        // A. Is this definitely a MESSAGE notification?
        boolean isDefinitelyMessage = Notification.CATEGORY_MESSAGE.equals(n.category)
                || (extras != null && (extras.containsKey(Notification.EXTRA_MESSAGES)
                        || extras.containsKey("android.messagingStyleUser")));

        boolean hasReplyAction = false;
        boolean hasMarkReadAction = false;
        boolean hasCallActions = false;
        PendingIntent answerIntent = null;
        PendingIntent declineIntent = null;

        // Check CallStyle in extras (Android 12+)
        if (extras != null) {
            if (extras.containsKey("android.callAnswerIntent")) {
                Object o = extras.get("android.callAnswerIntent");
                if (o instanceof PendingIntent) {
                    answerIntent = (PendingIntent) o;
                    hasCallActions = true;
                }
            } else if (extras.containsKey("android.answerIntent")) {
                Object o = extras.get("android.answerIntent");
                if (o instanceof PendingIntent) {
                    answerIntent = (PendingIntent) o;
                    hasCallActions = true;
                }
            }
            if (extras.containsKey("android.callDeclineIntent")) {
                Object o = extras.get("android.callDeclineIntent");
                if (o instanceof PendingIntent) {
                    declineIntent = (PendingIntent) o;
                    hasCallActions = true;
                }
            } else if (extras.containsKey("android.declineIntent")) {
                Object o = extras.get("android.declineIntent");
                if (o instanceof PendingIntent) {
                    declineIntent = (PendingIntent) o;
                    hasCallActions = true;
                }
            }
        }

        if (n.actions != null) {
            for (Notification.Action act : n.actions) {
                if (act.getRemoteInputs() != null && act.getRemoteInputs().length > 0) {
                    // Only message notifications feature RemoteInput for inline typing!
                    hasReplyAction = true;
                }
                if (act.title != null) {
                    String at = act.title.toString().toLowerCase();
                    if (at.contains("reply") || at.contains("जवाब") || at.contains("रिप्लाई")) {
                        hasReplyAction = true;
                    } else if (at.contains("mark as read") || at.contains("mark read") || at.contains("read") || at.contains("पढ़ा गया")) {
                        hasMarkReadAction = true;
                    } else if (at.contains("answer") || at.contains("receive") || at.contains("pickup") || at.contains("pick up") || at.contains("accept") || at.contains("उत्तर") || at.contains("उठाएं") || at.contains("स्वीकार")) {
                        hasCallActions = true;
                        if (answerIntent == null) answerIntent = act.actionIntent;
                    } else if (at.contains("decline") || at.contains("reject") || at.contains("hang up") || at.contains("end call") || at.contains("dismiss") || at.contains("काटें") || at.contains("अस्वीकार")) {
                        hasCallActions = true;
                        if (declineIntent == null) declineIntent = act.actionIntent;
                    }
                }
            }
        }

        if (hasReplyAction || hasMarkReadAction) {
            isDefinitelyMessage = true;
        }

        // B. Is this a real CALL?
        boolean isCallText = lowerText.contains("voice call")
                || lowerText.contains("video call")
                || lowerText.contains("incoming voice")
                || lowerText.contains("incoming video")
                || lowerText.contains("ongoing voice")
                || lowerText.contains("ongoing video")
                || lowerText.equals("incoming call")
                || lowerText.equals("ringing")
                || lowerText.equals("calling")
                || lowerText.contains("वॉइस कॉल")
                || lowerText.contains("वीडियो कॉल");

        boolean isDialer = pkg.toLowerCase().contains("dialer")
                || pkg.toLowerCase().contains("telecom")
                || pkg.toLowerCase().contains("phone")
                || pkg.toLowerCase().contains("incall")
                || pkg.toLowerCase().contains("smart.caller");

        boolean isCall = !isDefinitelyMessage && !isMissed && (isCallCategory || isDialer || n.fullScreenIntent != null || hasCallActions || isCallText);

        if (isCall && !hasCallActions && n.actions != null && n.actions.length >= 2) {
            if (declineIntent == null) declineIntent = n.actions[0].actionIntent;
            if (answerIntent == null) answerIntent = n.actions[1].actionIntent;
            hasCallActions = true;
        }

        // 1. WhatsApp Call
        if (pkg.toLowerCase().contains("whatsapp") && isCall) {
            WhatsAppCallInfo wCall = activeWhatsAppCall != null ? activeWhatsAppCall : new WhatsAppCallInfo();
            if (!TextUtils.isEmpty(title) && !title.equalsIgnoreCase("WhatsApp")) {
                wCall.callerName = title;
            } else if (TextUtils.isEmpty(wCall.callerName)) {
                wCall.callerName = "WhatsApp Call";
            }
            if (lowerText.contains("video")) {
                wCall.callType = "WhatsApp Video Call";
            } else if (TextUtils.isEmpty(wCall.callType)) {
                wCall.callType = "WhatsApp Voice Call";
            }

            boolean previouslyOutgoing = (activeWhatsAppCall != null && activeWhatsAppCall.isOutgoing);
            boolean isOutgoing = (answerIntent == null) && (previouslyOutgoing || lowerText.contains("calling") || lowerText.contains("ringing") || lowerText.contains("outgoing") || lowerText.contains("dialing") || lowerText.contains("कॉल की जा रही") || lowerText.contains("घंटी"));
            boolean isOngoing = lowerText.contains("ongoing")
                    || lowerText.contains("connected")
                    || lowerText.contains("चालू")
                    || lowerText.contains("कॉल जारी")
                    || lowerText.matches(".*\\d{1,2}:\\d{2}.*")
                    || (activeWhatsAppCall != null && activeWhatsAppCall.isOngoing)
                    || (!lowerText.contains("calling") && !lowerText.contains("ringing") && !lowerText.contains("dialing") && !lowerText.contains("कॉल की जा रही") && !lowerText.contains("घंटी") && !lowerText.contains("incoming"));
            boolean isRinging = !isOngoing;

            wCall.isOutgoing = isOutgoing && !isOngoing;
            wCall.isRinging = isRinging;
            wCall.isOngoing = isOngoing;
            if (answerIntent != null) wCall.answerIntent = answerIntent;
            if (declineIntent != null) wCall.declineIntent = declineIntent;
            if (n.contentIntent != null) wCall.contentIntent = n.contentIntent;
            if (n.fullScreenIntent != null) wCall.fullScreenIntent = n.fullScreenIntent;

            activeWhatsAppCall = wCall;
            notifyListeners();
            return;
        }

        // 2. Phone Call Notification (Dialer, IncallUI, Telecom)
        if (isDialer && !isMissed) {
            if (activePhoneCall == null) {
                activePhoneCall = new PhoneCallInfo();
            }
            if (!TextUtils.isEmpty(title) && !title.equalsIgnoreCase("Phone")) {
                activePhoneCall.callerName = title;
            }
            if (!TextUtils.isEmpty(text) && !text.equalsIgnoreCase("Incoming call")) {
                activePhoneCall.callerNumber = text;
            }

            boolean previouslyOutgoing = (activePhoneCall != null && activePhoneCall.isOutgoing);
            boolean isOutgoing = (answerIntent == null) && (previouslyOutgoing || lowerText.contains("dialing") || lowerText.contains("calling") || lowerText.contains("ringing") || lowerText.contains("outgoing") || lowerText.contains("डायल") || lowerText.contains("कॉल किया जा रहा") || lowerText.contains("घंटी"));
            boolean isOngoing = lowerText.contains("ongoing")
                    || lowerText.contains("connected")
                    || lowerText.contains("चालू")
                    || lowerText.contains("कॉल जारी")
                    || lowerText.matches(".*\\d{1,2}:\\d{2}.*")
                    || (activePhoneCall != null && activePhoneCall.isOngoing)
                    || (!lowerText.contains("calling") && !lowerText.contains("ringing") && !lowerText.contains("dialing") && !lowerText.contains("incoming") && !lowerText.contains("डायल") && !lowerText.contains("घंटी"));
            boolean isRinging = !isOngoing && (hasCallActions || answerIntent != null || lowerText.contains("incoming") || lowerText.contains("ringing") || isOutgoing);

            activePhoneCall.isOutgoing = isOutgoing && !isOngoing;
            activePhoneCall.isRinging = isRinging;
            activePhoneCall.isOngoing = isOngoing;
            if (answerIntent != null) activePhoneCall.answerIntent = answerIntent;
            if (declineIntent != null) activePhoneCall.declineIntent = declineIntent;
            if (n.fullScreenIntent != null) activePhoneCall.fullScreenIntent = n.fullScreenIntent;
            if (n.contentIntent != null) activePhoneCall.contentIntent = n.contentIntent;

            notifyListeners();
            return;
        }

        // 3. WhatsApp & SMS Messages (Extracting via MessagingStyle and TextLines)
        if (extras != null) {
            Parcelable[] msgBundles = extras.getParcelableArray(Notification.EXTRA_MESSAGES);
            if (msgBundles != null && msgBundles.length > 0) {
                Bundle latestMsg = (Bundle) msgBundles[msgBundles.length - 1];
                if (latestMsg != null) {
                    CharSequence msgBody = latestMsg.getCharSequence("text");
                    if (!TextUtils.isEmpty(msgBody)) {
                        text = msgBody.toString();
                    }
                    CharSequence msgSender = latestMsg.getCharSequence("sender");
                    if (!TextUtils.isEmpty(msgSender)) {
                        title = msgSender.toString();
                    }
                }
            }

            CharSequence bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
            if (TextUtils.isEmpty(text) && !TextUtils.isEmpty(bigText)) {
                text = bigText.toString();
            }

            CharSequence[] textLines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
            if (textLines != null && textLines.length > 0) {
                CharSequence lastLine = textLines[textLines.length - 1];
                if (!TextUtils.isEmpty(lastLine)) {
                    String lineStr = lastLine.toString();
                    if (lineStr.contains(": ")) {
                        String[] parts = lineStr.split(": ", 2);
                        if (TextUtils.isEmpty(title) || title.equalsIgnoreCase("WhatsApp")) {
                            title = parts[0];
                        }
                        text = parts[1];
                    } else if (TextUtils.isEmpty(text) || text.contains("messages")) {
                        text = lineStr;
                    }
                }
            }

            CharSequence convoTitle = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE);
            if ((TextUtils.isEmpty(title) || title.equalsIgnoreCase("WhatsApp")) && !TextUtils.isEmpty(convoTitle)) {
                title = convoTitle.toString();
            }
        }

        if (title.contains(": ")) {
            String[] parts = title.split(": ", 2);
            title = parts[0];
            if (TextUtils.isEmpty(text) || text.equals("Sent a message")) {
                text = parts[1];
            }
        } else if (text.contains(": ") && (TextUtils.isEmpty(title) || title.equalsIgnoreCase("WhatsApp"))) {
            String[] parts = text.split(": ", 2);
            title = parts[0];
            text = parts[1];
        }

        if (TextUtils.isEmpty(title) || title.equalsIgnoreCase("WhatsApp")) {
            title = pkg.toLowerCase().contains("whatsapp") ? "WhatsApp Contact" : "Contact SMS";
        }
        if (TextUtils.isEmpty(text)) {
            text = "Sent a message";
        }

        FocusMessageItem item = new FocusMessageItem();
        item.key = sbn.getKey();
        item.packageName = pkg;
        item.appTitle = pkg.toLowerCase().contains("whatsapp") ? "WhatsApp" : "Messages";
        item.sender = title;
        item.message = text;
        item.postTime = sbn.getPostTime();
        item.contentIntent = n.contentIntent;
        item.eventId = System.currentTimeMillis();

        recentMessages.remove(item.key); // Ensure updated message moves to front of list
        recentMessages.put(item.key, item);
        notifyListeners();
    }

    public static void processRemovedNotification(StatusBarNotification sbn) {
        if (sbn == null) return;
        String key = sbn.getKey();
        recentMessages.remove(key);

        String pkg = sbn.getPackageName();
        if (pkg != null) {
            if (pkg.toLowerCase().contains("whatsapp") && activeWhatsAppCall != null) {
                activeWhatsAppCall = null;
            }
            if ((pkg.toLowerCase().contains("dialer") || pkg.toLowerCase().contains("phone") || pkg.toLowerCase().contains("incall")) && activePhoneCall != null) {
                activePhoneCall = null;
            }
        }
        notifyListeners();
    }

    public static PhoneCallInfo getActivePhoneCall(Context context) {
        if (context != null) {
            try {
                TelecomManager tm = (TelecomManager) context.getSystemService(Context.TELECOM_SERVICE);
                if (tm != null && tm.isInCall()) {
                    if (activePhoneCall == null) {
                        activePhoneCall = new PhoneCallInfo();
                        activePhoneCall.isOngoing = true;
                        activePhoneCall.callerName = "Active Call";
                    }
                } else if (activePhoneCall != null && !activePhoneCall.isRinging) {
                    activePhoneCall = null;
                }
            } catch (Exception ignored) {}
        }
        return activePhoneCall;
    }

    public static WhatsAppCallInfo getActiveWhatsAppCall() {
        return activeWhatsAppCall;
    }

    public static List<FocusMessageItem> getRecentMessages() {
        List<FocusMessageItem> list = new ArrayList<>(recentMessages.values());
        Collections.reverse(list); // Most recent first
        return list;
    }

    public static FocusMessageItem getLatestMessage() {
        List<FocusMessageItem> list = getRecentMessages();
        return list.isEmpty() ? null : list.get(0);
    }

    public static void removeMessageItem(String key) {
        if (key == null) return;
        recentMessages.remove(key);
        notifyListeners();
    }

    public static void clearAllMessages() {
        recentMessages.clear();
        notifyListeners();
    }

    // Call Action Handlers
    public static void answerPhoneCall(Context context) {
        StudySessionActivity.notifyLaunchingAllowedApp();

        boolean answered = false;

        // 1. Try sending the dialer notification's answer PendingIntent with NEW_TASK
        if (activePhoneCall != null && activePhoneCall.answerIntent != null) {
            try {
                Intent fillIn = new Intent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    try {
                        android.app.ActivityOptions options = android.app.ActivityOptions.makeBasic();
                        options.setPendingIntentBackgroundActivityStartMode(android.app.ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED);
                        activePhoneCall.answerIntent.send(context, 0, fillIn, null, null, null, options.toBundle());
                        answered = true;
                    } catch (Throwable t) {
                        activePhoneCall.answerIntent.send(context, 0, fillIn);
                        answered = true;
                    }
                } else {
                    activePhoneCall.answerIntent.send(context, 0, fillIn);
                    answered = true;
                }
            } catch (Exception e) {
                try {
                    activePhoneCall.answerIntent.send();
                    answered = true;
                } catch (Exception ignored) {}
            }
        }

        // 2. TelecomManager acceptRingingCall (Android 8.0+)
        if (context != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                TelecomManager tm = (TelecomManager) context.getSystemService(Context.TELECOM_SERVICE);
                if (tm != null) {
                    tm.acceptRingingCall();
                    answered = true;
                }
            } catch (Throwable ignored) {}
        }

        // 3. ITelephony reflection fallback
        if (context != null) {
            try {
                TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
                if (tm != null) {
                    java.lang.reflect.Method getITelephony = tm.getClass().getDeclaredMethod("getITelephony");
                    getITelephony.setAccessible(true);
                    Object iTelephony = getITelephony.invoke(tm);
                    if (iTelephony != null) {
                        java.lang.reflect.Method answerCallMethod = iTelephony.getClass().getDeclaredMethod("answerRingingCall");
                        answerCallMethod.invoke(iTelephony);
                        answered = true;
                    }
                }
            } catch (Throwable ignored) {}
        }

        // 4. Media key event fallback via AudioManager
        if (context != null) {
            try {
                AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
                if (am != null) {
                    long now = android.os.SystemClock.uptimeMillis();
                    KeyEvent down = new KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_HEADSETHOOK, 0);
                    KeyEvent up = new KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_HEADSETHOOK, 0);
                    am.dispatchMediaKeyEvent(down);
                    am.dispatchMediaKeyEvent(up);
                    answered = true;
                }
            } catch (Throwable ignored) {}
        }

        // 5. Media button broadcast fallback
        if (context != null) {
            try {
                long now = android.os.SystemClock.uptimeMillis();
                Intent downIntent = new Intent(Intent.ACTION_MEDIA_BUTTON);
                downIntent.putExtra(Intent.EXTRA_KEY_EVENT, new KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_HEADSETHOOK, 0));
                context.sendOrderedBroadcast(downIntent, null);

                Intent upIntent = new Intent(Intent.ACTION_MEDIA_BUTTON);
                upIntent.putExtra(Intent.EXTRA_KEY_EVENT, new KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_HEADSETHOOK, 0));
                context.sendOrderedBroadcast(upIntent, null);
            } catch (Throwable ignored) {}
        }

        // 6. Shell command fallback
        try {
            Runtime.getRuntime().exec("input keyevent 79");
        } catch (Throwable ignored) {}
        try {
            Runtime.getRuntime().exec("cmd telecom accept-call");
        } catch (Throwable ignored) {}

        // 7. Fallback: if silent answer could not be verified, launch native incoming screen so user can answer with one tap
        if (!answered) {
            boolean broughtToFront = false;
            if (activePhoneCall != null && activePhoneCall.fullScreenIntent != null) {
                try {
                    Intent fillIn = new Intent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    activePhoneCall.fullScreenIntent.send(context, 0, fillIn);
                    broughtToFront = true;
                } catch (Exception ignored) {}
            }
            if (!broughtToFront && activePhoneCall != null && activePhoneCall.contentIntent != null) {
                try {
                    Intent fillIn = new Intent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    activePhoneCall.contentIntent.send(context, 0, fillIn);
                    broughtToFront = true;
                } catch (Exception ignored) {}
            }
            if (!broughtToFront) {
                launchDialer(context);
            }
        }

        if (activePhoneCall != null) {
            activePhoneCall.isRinging = false;
            activePhoneCall.isOngoing = true;
            notifyListeners();
        }
    }

    public static void declinePhoneCall(Context context) {
        if (activePhoneCall != null && activePhoneCall.declineIntent != null) {
            try {
                Intent fillIn = new Intent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                activePhoneCall.declineIntent.send(context, 0, fillIn);
                activePhoneCall = null;
                notifyListeners();
                return;
            } catch (Exception ignored) {
                try {
                    activePhoneCall.declineIntent.send();
                    activePhoneCall = null;
                    notifyListeners();
                    return;
                } catch (Exception ignored2) {}
            }
        }
        if (context != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                TelecomManager tm = (TelecomManager) context.getSystemService(Context.TELECOM_SERVICE);
                if (tm != null) {
                    tm.endCall();
                    activePhoneCall = null;
                    notifyListeners();
                    return;
                }
            } catch (Throwable ignored) {}
        }
        // MediaKeyEvent headset hook hangup fallback
        if (context != null) {
            try {
                AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
                if (am != null) {
                    long now = android.os.SystemClock.uptimeMillis();
                    KeyEvent down = new KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_HEADSETHOOK, 0);
                    KeyEvent up = new KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_HEADSETHOOK, 0);
                    am.dispatchMediaKeyEvent(down);
                    am.dispatchMediaKeyEvent(up);
                }
            } catch (Throwable ignored) {}
        }
        activePhoneCall = null;
        notifyListeners();
    }

    public static void answerWhatsAppCall(Context context) {
        StudySessionActivity.notifyLaunchingAllowedApp();

        boolean answered = false;

        // 1. Send the WhatsApp Answer PendingIntent with NEW_TASK flags & background activity start options
        if (activeWhatsAppCall != null && activeWhatsAppCall.answerIntent != null) {
            try {
                Intent fillIn = new Intent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    try {
                        android.app.ActivityOptions options = android.app.ActivityOptions.makeBasic();
                        options.setPendingIntentBackgroundActivityStartMode(android.app.ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED);
                        activeWhatsAppCall.answerIntent.send(context, 0, fillIn, null, null, null, options.toBundle());
                        answered = true;
                    } catch (Throwable t) {
                        activeWhatsAppCall.answerIntent.send(context, 0, fillIn);
                        answered = true;
                    }
                } else {
                    activeWhatsAppCall.answerIntent.send(context, 0, fillIn);
                    answered = true;
                }
            } catch (Exception ignored) {
                try {
                    activeWhatsAppCall.answerIntent.send();
                    answered = true;
                } catch (Exception ignored2) {}
            }
        }

        // Fallback: If no answerIntent was available, bring WhatsApp call screen to front so user can answer
        if (!answered) {
            boolean broughtToFront = false;
            if (activeWhatsAppCall != null && activeWhatsAppCall.fullScreenIntent != null) {
                try {
                    Intent fillIn = new Intent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    activeWhatsAppCall.fullScreenIntent.send(context, 0, fillIn);
                    broughtToFront = true;
                } catch (Exception ignored) {}
            }
            if (!broughtToFront && activeWhatsAppCall != null && activeWhatsAppCall.contentIntent != null) {
                try {
                    Intent fillIn = new Intent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    activeWhatsAppCall.contentIntent.send(context, 0, fillIn);
                    broughtToFront = true;
                } catch (Exception ignored) {}
            }
            if (!broughtToFront) {
                launchWhatsApp(context);
            }
        }

        if (activeWhatsAppCall != null) {
            activeWhatsAppCall.isRinging = false;
            activeWhatsAppCall.isOngoing = true;
            notifyListeners();
        }
    }

    private static boolean isManualSpeaker = false;
    private static boolean isManualMute = false;

    public static boolean toggleSpeakerphone(Context context) {
        isManualSpeaker = !isManualSpeaker;
        if (context != null) {
            try {
                AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
                if (am != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        try {
                            if (isManualSpeaker) {
                                List<AudioDeviceInfo> devices = am.getAvailableCommunicationDevices();
                                for (AudioDeviceInfo device : devices) {
                                    if (device.getType() == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER) {
                                        am.setCommunicationDevice(device);
                                        break;
                                    }
                                }
                            } else {
                                am.clearCommunicationDevice();
                            }
                        } catch (Throwable ignored) {}
                    }
                    am.setSpeakerphoneOn(isManualSpeaker);
                }
            } catch (Throwable ignored) {}
        }
        notifyListeners();
        return isManualSpeaker;
    }

    public static boolean isSpeakerphoneOn(Context context) {
        if (context != null) {
            try {
                AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
                if (am != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        AudioDeviceInfo dev = am.getCommunicationDevice();
                        if (dev != null && dev.getType() == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER) {
                            return true;
                        }
                    }
                    return am.isSpeakerphoneOn() || isManualSpeaker;
                }
            } catch (Throwable ignored) {}
        }
        return isManualSpeaker;
    }

    public static boolean toggleMicrophoneMute(Context context) {
        isManualMute = !isManualMute;
        if (context != null) {
            try {
                AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
                if (am != null) {
                    am.setMicrophoneMute(isManualMute);
                }
            } catch (Throwable ignored) {}
        }
        notifyListeners();
        return isManualMute;
    }

    public static boolean isMicrophoneMute(Context context) {
        if (context != null) {
            try {
                AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
                if (am != null) {
                    return am.isMicrophoneMute() || isManualMute;
                }
            } catch (Throwable ignored) {}
        }
        return isManualMute;
    }

    public static void returnToPhoneCall(Context context) {
        if (context == null) return;
        StudySessionActivity.notifyLaunchingAllowedApp();

        boolean launched = false;
        // 1. Android TelecomManager show in-call UI (standard Android API 29+)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                TelecomManager tm = (TelecomManager) context.getSystemService(Context.TELECOM_SERVICE);
                if (tm != null && tm.isInCall()) {
                    tm.showInCallScreen(false);
                    launched = true;
                }
            }
        } catch (Throwable ignored) {}

        // 2. Try pending intents
        if (!launched && activePhoneCall != null) {
            if (activePhoneCall.fullScreenIntent != null) {
                try {
                    Intent fillIn = new Intent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    activePhoneCall.fullScreenIntent.send(context, 0, fillIn);
                    launched = true;
                } catch (Exception ignored) {}
            }
            if (!launched && activePhoneCall.contentIntent != null) {
                try {
                    Intent fillIn = new Intent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    activePhoneCall.contentIntent.send(context, 0, fillIn);
                    launched = true;
                } catch (Exception ignored) {}
            }
        }

        // 3. Fallback to TelecomManager even if isInCall() returned false
        if (!launched) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    TelecomManager tm = (TelecomManager) context.getSystemService(Context.TELECOM_SERVICE);
                    if (tm != null) {
                        tm.showInCallScreen(false);
                        launched = true;
                    }
                }
            } catch (Throwable ignored) {}
        }

        // 4. Fallback to launch dialer
        if (!launched) {
            launchDialer(context);
        }
    }

    public static void returnToWhatsAppCall(Context context) {
        if (context == null) return;
        StudySessionActivity.notifyLaunchingAllowedApp();

        boolean launched = false;
        // 1. Try WhatsApp pending intents
        if (activeWhatsAppCall != null) {
            if (activeWhatsAppCall.fullScreenIntent != null) {
                try {
                    Intent fillIn = new Intent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    activeWhatsAppCall.fullScreenIntent.send(context, 0, fillIn);
                    launched = true;
                } catch (Exception ignored) {}
            }
            if (!launched && activeWhatsAppCall.contentIntent != null) {
                try {
                    Intent fillIn = new Intent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    activeWhatsAppCall.contentIntent.send(context, 0, fillIn);
                    launched = true;
                } catch (Exception ignored) {}
            }
        }

        // 2. Try launching WhatsApp VoipActivity directly
        if (!launched) {
            try {
                Intent voipIntent = new Intent();
                voipIntent.setClassName("com.whatsapp", "com.whatsapp.voipcalling.VoipActivityV2");
                voipIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                context.startActivity(voipIntent);
                launched = true;
            } catch (Exception ignored) {}
        }

        // 3. Fallback: Launch WhatsApp app
        if (!launched) {
            launchWhatsApp(context);
        }
    }

    public static void returnToCall(Context context) {
        if (activeWhatsAppCall != null && (activeWhatsAppCall.isOngoing || activeWhatsAppCall.isRinging)) {
            returnToWhatsAppCall(context);
        } else if (activePhoneCall != null && (activePhoneCall.isOngoing || activePhoneCall.isRinging)) {
            returnToPhoneCall(context);
        } else if (activeWhatsAppCall != null) {
            returnToWhatsAppCall(context);
        } else {
            returnToPhoneCall(context);
        }
    }

    public static void declineWhatsAppCall(Context context) {
        if (activeWhatsAppCall != null && activeWhatsAppCall.declineIntent != null) {
            try {
                Intent fillIn = new Intent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                activeWhatsAppCall.declineIntent.send(context, 0, fillIn);
            } catch (Exception ignored) {
                try {
                    activeWhatsAppCall.declineIntent.send();
                } catch (Exception ignored2) {}
            }
        }
        activeWhatsAppCall = null;
        notifyListeners();
    }

    public static void openMessageItem(Context context, FocusMessageItem item) {
        StudySessionActivity.notifyLaunchingAllowedApp();
        if (item == null || context == null) return;
        if (item.contentIntent != null) {
            try {
                Intent fillIn = new Intent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                item.contentIntent.send(context, 0, fillIn);
                return;
            } catch (Exception ignored) {
                try {
                    item.contentIntent.send();
                    return;
                } catch (Exception ignored2) {}
            }
        }
        if (item.isWhatsApp()) {
            launchWhatsApp(context);
        } else {
            launchMessages(context);
        }
    }

    // App Launchers for Whitelisted Apps
    public static void launchWhatsApp(Context context) {
        StudySessionActivity.notifyLaunchingAllowedApp();
        if (context instanceof StudySessionActivity) {
            ((StudySessionActivity) context).launchWhatsApp();
            return;
        }
        if (context == null) return;
        try {
            Intent intent = context.getPackageManager().getLaunchIntentForPackage("com.whatsapp");
            if (intent == null) {
                intent = context.getPackageManager().getLaunchIntentForPackage("com.whatsapp.w4b");
            }
            if (intent == null) {
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse("whatsapp://app"));
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception ignored) {}
    }

    public static void launchDialer(Context context) {
        StudySessionActivity.notifyLaunchingAllowedApp();
        if (context instanceof StudySessionActivity) {
            ((StudySessionActivity) context).launchDialer();
            return;
        }
        if (context == null) return;
        try {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception ignored) {}
    }

    public static void launchMessages(Context context) {
        StudySessionActivity.notifyLaunchingAllowedApp();
        if (context instanceof StudySessionActivity) {
            ((StudySessionActivity) context).launchMessages();
            return;
        }
        if (context == null) return;
        try {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_APP_MESSAGING);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            try {
                Intent fallback = new Intent(Intent.ACTION_VIEW, Uri.parse("smsto:"));
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(fallback);
            } catch (Exception ignored) {}
        }
    }
}
