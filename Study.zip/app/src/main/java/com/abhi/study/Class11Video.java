package com.abhi.study;

import java.io.Serializable;

/**
 * Data model for Class 11 educational lectures.
 * Includes curated metadata for the most-watched Class 11 video lectures.
 */
public class Class11Video implements Serializable {
    private final String id;
    private final String title;
    private final String subject;
    private final String channel;
    private final String views;
    private final String duration;
    private final String badge;
    private final String description;

    public Class11Video(String id, String title, String subject, String channel,
                        String views, String duration, String badge, String description) {
        this.id = id;
        this.title = title;
        this.subject = subject;
        this.channel = channel;
        this.views = views;
        this.duration = duration;
        this.badge = badge;
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getSubject() {
        return subject;
    }

    public String getChannel() {
        return channel;
    }

    public String getViews() {
        return views;
    }

    public String getDuration() {
        return duration;
    }

    public String getBadge() {
        return badge;
    }

    public String getDescription() {
        return description;
    }

    public String getThumbnailUrl() {
        return "https://img.youtube.com/vi/" + id + "/hqdefault.jpg";
    }

    public boolean matchesQuery(String query) {
        if (query == null || query.trim().isEmpty()) return true;
        String q = query.toLowerCase().trim();
        return (title != null && title.toLowerCase().contains(q))
                || (subject != null && subject.toLowerCase().contains(q))
                || (channel != null && channel.toLowerCase().contains(q))
                || (description != null && description.toLowerCase().contains(q));
    }
}
