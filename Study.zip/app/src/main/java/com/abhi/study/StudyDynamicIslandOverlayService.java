package com.abhi.study;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.FrameLayout;

import androidx.annotation.Nullable;

/**
 * StudyDynamicIslandOverlayService:
 * Displays the iOS-style Dynamic Island floating seamlessly over whitelisted apps
 * (WhatsApp, Phone/Dialer, Messages, Contacts) during Deep Study Sessions.
 *
 * Automatically expands for incoming/outgoing calls and messages, manages in-call
 * audio routing (Mute/Speaker), Return to Call, and fluid Apple spring morphing.
 */
public class StudyDynamicIslandOverlayService extends Service {

    private static boolean isServiceRunning = false;

    private WindowManager windowManager;
    private FrameLayout overlayContainer;
    private WindowManager.LayoutParams windowParams;
    private StudyDynamicIslandController dynamicIslandController;

    public static boolean isRunning() {
        return isServiceRunning;
    }

    public static void startOverlay(Context context) {
        if (context == null) return;
        if (StudySessionActivity.isForeground()) {
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            return;
        }
        try {
            Intent intent = new Intent(context, StudyDynamicIslandOverlayService.class);
            context.startService(intent);
        } catch (Exception ignored) {}
    }

    public static void stopOverlay(Context context) {
        if (context == null) return;
        try {
            Intent intent = new Intent(context, StudyDynamicIslandOverlayService.class);
            context.stopService(intent);
        } catch (Exception ignored) {}
    }

    @Override
    public void onCreate() {
        super.onCreate();

        if (StudySessionActivity.isForeground()) {
            stopSelf();
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        try {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (windowManager == null) {
                stopSelf();
                return;
            }

            int layoutFlag;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
            } else {
                layoutFlag = WindowManager.LayoutParams.TYPE_PHONE;
            }

            windowParams = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    layoutFlag,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
            );
            windowParams.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;

            overlayContainer = new FrameLayout(this);
            windowManager.addView(overlayContainer, windowParams);

            dynamicIslandController = new StudyDynamicIslandController(this, overlayContainer);
            dynamicIslandController.setOnIslandStateChangeListener(new StudyDynamicIslandController.OnIslandStateChangeListener() {
                @Override
                public void onExpanded() {
                    updateOverlaySize(true);
                }

                @Override
                public void onCollapsed() {
                    updateOverlaySize(false);
                }
            });

            isServiceRunning = true;
        } catch (Exception e) {
            stopSelf();
        }
    }

    private void updateOverlaySize(boolean expanded) {
        if (windowManager != null && overlayContainer != null && windowParams != null) {
            try {
                windowParams.height = expanded ? WindowManager.LayoutParams.MATCH_PARENT : WindowManager.LayoutParams.WRAP_CONTENT;
                windowManager.updateViewLayout(overlayContainer, windowParams);
            } catch (Exception ignored) {}
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (StudySessionActivity.isForeground()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (dynamicIslandController != null) {
            dynamicIslandController.refreshData();
        }
        return START_NOT_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        isServiceRunning = false;
        if (dynamicIslandController != null) {
            dynamicIslandController.onDestroy();
            dynamicIslandController = null;
        }
        if (windowManager != null && overlayContainer != null) {
            try {
                if (overlayContainer.isAttachedToWindow()) {
                    windowManager.removeView(overlayContainer);
                }
            } catch (Exception ignored) {}
            overlayContainer = null;
        }
        super.onDestroy();
    }
}
