package com.abhi.study;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Repository containing curated, real, verified Class 11 educational lectures.
 * Provides filtered queries for subjects: All, Physics, Chemistry, Maths, Biology, One-Shots.
 */
public class Class11VideoRepository {

    private static final List<Class11Video> VIDEOS = new ArrayList<>();

    static {
        // --- PHYSICS (CLASS 11) ---
        VIDEOS.add(new Class11Video(
                "5rm-iI9Nqyo",
                "Units and Measurements Class 11 One Shot | Detailed Revision",
                "Physics",
                "PW Class 11 Science",
                "830K Views",
                "2h 15m",
                "🔥 MOST WATCHED #1",
                "Physical quantities, SI Units, Dimensional Analysis, Error Analysis and Significant figures."
        ));

        VIDEOS.add(new Class11Video(
                "tx76BJIqOd4",
                "Units and Measurements | Class 11 Physics Full NCERT",
                "Physics",
                "Prashant Kirad 11th & 12th",
                "14M Views",
                "1h 54m",
                "⚡ TOP RATED",
                "Complete NCERT coverage, Dimensions, Error Analysis, and Numericals."
        ));

        VIDEOS.add(new Class11Video(
                "wuI3MWvr0dY",
                "Units & Measurements in One Shot | All Concepts & PYQs",
                "Physics",
                "JEE Wallah",
                "1.2M Views",
                "6h 07m",
                "📐 ESSENTIAL",
                "Deep dive into Units, Dimensions, Vernier Caliper, Screw Gauge, and JEE/NEET PYQs."
        ));

        VIDEOS.add(new Class11Video(
                "bin4OCO-LSc",
                "Motion in a Straight Line | Class 11 Physics Chapter 1",
                "Physics",
                "PW Class 11 Science",
                "4.5M Views",
                "3h 17m",
                "⚡ HIGH YIELD",
                "Distance, Displacement, Speed, Velocity, Acceleration, Equations of Motion, and Graphs."
        ));

        // --- CHEMISTRY (CLASS 11) ---
        VIDEOS.add(new Class11Video(
                "cbnBy3e5vDI",
                "Some Basic Concepts Of Chemistry Class 11 One Shot",
                "Chemistry",
                "PW Class 11 Science",
                "990K Views",
                "2h 59m",
                "👑 ALL-TIME HIT",
                "Mole Concept, Molarity, Molality, Normality, Limiting Reagents, and Stoichiometry."
        ));

        VIDEOS.add(new Class11Video(
                "1t9Dq4wyhBw",
                "Some Basic Concepts of Chemistry Class 11 | Full Chapter",
                "Chemistry",
                "Next Toppers - 11th Science",
                "14M Views",
                "3h 03m",
                "🧪 FOUNDATION",
                "Full NCERT chapter revision, Mole Concept calculations, and Important Questions."
        ));

        VIDEOS.add(new Class11Video(
                "MfadB5RYDWY",
                "Mole Concept (Some Basic Concepts) in One Shot",
                "Chemistry",
                "PW Class 11 Science",
                "5.3M Views",
                "5h 50m",
                "⚡ TOP RATED",
                "Complete Mole Concept Mastery, Concentration terms, and Percentage Composition."
        ));

        VIDEOS.add(new Class11Video(
                "H-CypadbaM4",
                "Structure of Atom | Full Chapter Explanation Class 11",
                "Chemistry",
                "Magnet Brains",
                "1.1M Views",
                "3h 40m",
                "🔬 ATOMIC MODEL",
                "Bohr Model, Quantum Numbers, Electronic Configuration, Heisenberg Principle."
        ));

        // --- MATHS (CLASS 11) ---
        VIDEOS.add(new Class11Video(
                "F_7WUK7htRg",
                "Sets | Full Chapter in ONE SHOT | Class 11 Maths",
                "Maths",
                "PW Class 11 Science",
                "9.9M Views",
                "3h 51m",
                "🔥 MATHS MASTER",
                "Set representation, Types of Sets, Subsets, Power Set, Venn Diagrams, and Operations."
        ));

        VIDEOS.add(new Class11Video(
                "U9vZuAqjL3I",
                "Sets Class 11 One Shot | NCERT Class 11th Maths Chapter 1",
                "Maths",
                "Next Toppers - 11th Science",
                "2.6M Views",
                "2h 35m",
                "⚡ TOP RATED",
                "NCERT Chapter 1 complete exercises, Union, Intersection, and Problem Solving."
        ));

        VIDEOS.add(new Class11Video(
                "vcqyIgZfCog",
                "Relations and Functions Class 11 Maths | Chapter 2",
                "Maths",
                "Next Toppers - 11th Science",
                "2.7M Views",
                "1h 52m",
                "📐 ESSENTIAL",
                "Cartesian Product, Relations, Functions, Domain, Range, and Function Graphs."
        ));

        VIDEOS.add(new Class11Video(
                "r-3oBvZzzzo",
                "Trigonometric Functions Class 11 Maths | Full Chapter",
                "Maths",
                "Disha Science Classes",
                "270K Views",
                "1h 15m",
                "⚡ FORMULA RICH",
                "Angles, Radian Measure, Trigonometric Identities, Transformation Formulae, and Proofs."
        ));

        // --- BIOLOGY (CLASS 11) ---
        VIDEOS.add(new Class11Video(
                "AAih1XvW33g",
                "The Living World | Full Chapter in ONE SHOT | Class 11",
                "Biology",
                "PW Class 11 Science",
                "7.1M Views",
                "2h 28m",
                "🌿 NEET FAVORITE",
                "What is Living, Diversity in Living World, Taxonomic Categories, and Taxonomical Aids."
        ));

        VIDEOS.add(new Class11Video(
                "FNLxE6vrWzs",
                "The Living World - Full Chapter One Shot | Vipin Sir",
                "Biology",
                "Competition Wallah",
                "1.4M Views",
                "2h 20m",
                "⚡ NEET SCORE BOOSTER",
                "NCERT Line-by-Line line revision, Taxonomic Hierarchy, and PYQs."
        ));

        VIDEOS.add(new Class11Video(
                "pPBx4RPGNCQ",
                "The Living World Biology Class 11 ONE SHOT",
                "Biology",
                "PW Class 11 Science",
                "530K Views",
                "1h 26m",
                "🧬 REVISION",
                "Quick NCERT revision, Characteristics of Life, and Key Definitions."
        ));

        VIDEOS.add(new Class11Video(
                "r3_N_9Dtljk",
                "Biological Classification in 1 Shot | Full Chapter",
                "Biology",
                "Yakeen",
                "3.9M Views",
                "4h 37m",
                "🦠 ESSENTIAL",
                "Kingdom Monera, Protista, Fungi, Plantae, Animalia, Viruses, Viroids and Lichens."
        ));

        // --- ONE-SHOT / REVISION (CLASS 11) ---
        VIDEOS.add(new Class11Video(
                "MCFrSja9aBI",
                "Complete Class 11th PHYSICS in One Shot | ALL Chapters",
                "One-Shot",
                "PW Class 11 Science",
                "1.9M Views",
                "6h 31m",
                "⚡ MARATHON",
                "Kinematics, NLM, Work Power, Rotational, Gravitation, and Thermodynamics in one video."
        ));

        VIDEOS.add(new Class11Video(
                "fSBqwtd4yY4",
                "Rotational Motion Physics Class 11 One Shot | Detailed",
                "One-Shot",
                "PW Class 11 Science",
                "58K Views",
                "2h 40m",
                "⚡ CRITICAL CHAPTER",
                "Center of Mass, Torque, Moment of Inertia, Theorems of MOI, and Rolling Motion."
        ));

        VIDEOS.add(new Class11Video(
                "yiFY1sK2oXE",
                "Hornbill Class 11 One Shot | Full Book Explanation",
                "One-Shot",
                "Educational Bhaiya",
                "1.3M Views",
                "1h 57m",
                "📖 ALL CHAPTERS",
                "Complete English Hornbill Stories & Poems with Line by Line Explanation."
        ));

        VIDEOS.add(new Class11Video(
                "GjXMdGY7Ke4",
                "Class 11 Hornbill Full Book Revision | Dear Sir",
                "One-Shot",
                "Dear Sir",
                "2.3M Views",
                "1h 14m",
                "🔥 ALL-IN-ONE",
                "Long/Short Answers, Character Sketches, and Summary in one comprehensive session."
        ));

        VIDEOS.add(new Class11Video(
                "8GCv5SAOWp0",
                "Work, Energy & Power in One Shot | Class 11 Physics",
                "Physics",
                "JEE Wallah",
                "720K Views",
                "15h 09m",
                "⚡ HIGH YIELD",
                "Work done by forces, Kinetic Energy theorem, Potential Energy, Conservative forces, Collisions."
        ));

        VIDEOS.add(new Class11Video(
                "1_ZFWFFoPu8",
                "Gravitation Class 11 Physics Full Chapter NCERT",
                "Physics",
                "Prashant Kirad 11th & 12th",
                "3.0M Views",
                "2h 18m",
                "⚡ TOP RATED",
                "Kepler's laws, Universal Gravitation, Acceleration due to gravity g variation, Gravitational potential, Escape velocity."
        ));

        VIDEOS.add(new Class11Video(
                "kS8s_WX0IlY",
                "Chemical Bonding in One Shot | All Concepts & PYQs",
                "Chemistry",
                "JEE Wallah",
                "3.8M Views",
                "9h 29m",
                "🔥 MUST WATCH",
                "Kossel-Lewis approach, Ionic bond, VSEPR theory, Hybridization, Valence Bond Theory, Molecular Orbital Theory."
        ));

        VIDEOS.add(new Class11Video(
                "MU2jURO0-EU",
                "Chemical Equilibrium Class 11 One Shot | NCERT",
                "Chemistry",
                "PW Class 11 Science",
                "360K Views",
                "1h 12m",
                "📐 ESSENTIAL",
                "Equilibrium in physical & chemical processes, Law of chemical equilibrium, Le Chatelier's principle, Ionic equilibrium basics."
        ));

        VIDEOS.add(new Class11Video(
                "nfPvo7p-8t0",
                "Trigonometry Class 11 One Shot Full Prep",
                "Mathematics",
                "Neha Agrawal Mathematically Inclined",
                "520K Views",
                "1h 25m",
                "⚡ TOP RATED",
                "Angles, Trigonometric functions, Signs of trig functions, Trigonometric equations, Sum and difference formulas."
        ));

        VIDEOS.add(new Class11Video(
                "CHWhaAlo_ms",
                "Limits and Derivatives Full Chapter in One Shot",
                "Mathematics",
                "PW Class 11 Science",
                "3.8M Views",
                "3h 45m",
                "🔥 MOST WATCHED",
                "Intuitive idea of derivatives, Limits of trigonometric functions, Derivatives of polynomials and trig functions."
        ));

        VIDEOS.add(new Class11Video(
                "B6PqBuW46aI",
                "Cell Cycle & Cell Division Class 11th NEET One Shot",
                "Biology",
                "PW NEET",
                "160K Views",
                "5h 18m",
                "🧬 ESSENTIAL",
                "Cell cycle phases, G1, S, G2, M phase, Mitosis, Meiosis I and II, Significance of cell division."
        ));

        VIDEOS.add(new Class11Video(
                "BQjXZQ_grOc",
                "Biomolecules in One Shot | Class 11 NEET All Concepts",
                "Biology",
                "PW NEET",
                "2.0M Views",
                "3h 52m",
                "⚡ HIGH YIELD",
                "Carbohydrates, Proteins, Nucleic Acids, Enzymes mechanism and factors, Primary and Secondary metabolites."
        ));
    }

    public static List<Class11Video> getAllVideos() {
        return Collections.unmodifiableList(VIDEOS);
    }

    public static Class11Video getHeroVideo() {
        return VIDEOS.isEmpty() ? null : VIDEOS.get(0);
    }

    public static List<Class11Video> filterBySubject(String subject) {
        if (subject == null || subject.equalsIgnoreCase("All") || subject.trim().isEmpty()) {
            return getAllVideos();
        }
        String target = subject.trim().toLowerCase();
        List<Class11Video> filtered = new ArrayList<>();
        for (Class11Video v : VIDEOS) {
            String s = v.getSubject().toLowerCase();
            if (s.equals(target)
                    || (target.startsWith("math") && s.startsWith("math"))
                    || (target.contains("shot") && s.contains("shot"))) {
                filtered.add(v);
            }
        }
        return filtered.isEmpty() ? getAllVideos() : filtered;
    }

    public static List<Class11Video> getVideosBySubject(String subject) {
        return filterBySubject(subject);
    }

    public static List<Class11Video> search(String query) {
        if (query == null || query.trim().isEmpty()) {
            return getAllVideos();
        }
        String q = query.toLowerCase().trim();
        List<Class11Video> matches = new ArrayList<>();
        for (Class11Video v : VIDEOS) {
            if (v.getTitle().toLowerCase().contains(q)
                    || v.getSubject().toLowerCase().contains(q)
                    || v.getChannel().toLowerCase().contains(q)
                    || v.getDescription().toLowerCase().contains(q)) {
                matches.add(v);
            }
        }
        return matches;
    }
}
