package com.abhi.study;

import android.annotation.SuppressLint;
import android.app.PictureInPictureParams;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Rational;
import android.view.HapticFeedbackConstants;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.view.GestureDetector;
import android.view.OrientationEventListener;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import android.app.Dialog;
import com.abhi.study.youtube.ExtractionResult;
import com.abhi.study.youtube.Transcript;
import com.abhi.study.youtube.TranscriptSegment;
import com.abhi.study.youtube.YouTubeExtractor;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.MergingMediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.ui.PlayerView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import android.net.Uri;

/**
 * YouTubeActivity (StudyTube Focus Hub):
 * Powered by AndroidX Media3 (ExoPlayer).
 * Features:
 * - Native In-App Video Playback via AndroidX Media3 (ExoPlayer) with MediaStreamResolver.
 * - Custom Media Player with GlowOrbitLoadingView buffering animations, 10s seek, speed controller, and recommendations.
 * - Home Tab curated with the most-watched Class 11 educational lectures (Physics, Chemistry, Maths, Biology).
 * - Lessons & Completed Tabs integrated seamlessly into in-app playback.
 * - Strict Kiosk / Deep Mode integration with zoom-out transitions.
 */
public class YouTubeActivity extends AppCompatActivity {

    // Top Navigation & Branding
    private View btnYouTubeBack;
    private View btnClearSearch;
    private EditText etYouTubeSearch;
    private AppCompatImageView ivSearchIcon;

    // Content Tabs (5 Tabs: Quiz, Lessons, Home, Completed, Downloads)
    private View layoutQuizTab;
    private View layoutLessonsTab;
    private ScrollView layoutHomeTab;
    private View layoutCompletedTab;
    private View layoutDownloadsTab;
    private View layoutDownloadsEmpty;
    private LinearLayout layoutDownloadsList;

    // Bottom Navigation (5 Buttons: Quiz, Lessons, Home, Completed, Downloads)
    private View btnNavQuiz;
    private AppCompatImageView ivNavQuizIcon;
    private TextView tvNavQuizText;

    private View btnNavLessons;
    private AppCompatImageView ivNavLessonsIcon;
    private TextView tvNavLessonsText;

    private View btnNavHome;
    private AppCompatImageView ivNavHomeIcon;
    private TextView tvNavHomeText;

    private View btnNavCompleted;
    private AppCompatImageView ivNavCompletedIcon;
    private TextView tvNavCompletedText;

    private View btnNavDownloads;
    private AppCompatImageView ivNavDownloadsIcon;
    private TextView tvNavDownloadsText;

    // Category Filter Chips (100% Pure Educational Syllabus)
    private TextView chipAll;
    private TextView chipPhysics;
    private TextView chipChemistry;
    private TextView chipMathematics;
    private TextView chipBiology;
    private TextView chipOneShot;
    private TextView chipNcert;
    private TextView chipJeeNeet;

    // Infinite Non-stop Scroll Engine
    private View layoutInfiniteScrollLoading;
    private boolean isLoadingMoreVideos = false;
    private int infiniteScrollTopicIndex = 0;
    private final Set<String> displayedVideoIds = new HashSet<>();
    private String currentSelectedCategory = "All";

    // Class 11 Home Feed Views
    private View layoutHeroSectionContainer;
    private TextView tvAllLecturesHeader;
    private View cardHeroVideo11;
    private ImageView ivHeroThumbnail;
    private TextView tvHeroTitle;
    private View btnOpenYouTubeApp;
    private LinearLayout layoutClass11VideosList;
    private TextView tvEmptySearchStatus;

    // Lessons Filter Buttons & Containers
    private View btnLessonIncomplete;
    private AppCompatImageView ivLessonIncompleteIcon;
    private TextView tvLessonIncompleteText;
    private TextView tvIncompleteCountBadge;

    private View btnLessonUpcoming;
    private AppCompatImageView ivLessonUpcomingIcon;
    private TextView tvLessonUpcomingText;
    private TextView tvUpcomingCountBadge;

    private View layoutIncompleteLessonsContainer;
    private View layoutUpcomingLessonsContainer;

    // Dynamic Lessons Lists & Empty States (Zero Mock Data)
    private LinearLayout layoutIncompleteLessonsList;
    private View layoutIncompleteEmptyState;
    private LinearLayout layoutUpcomingLessonsList;
    private View layoutUpcomingEmptyState;
    private boolean isShowingIncompleteLessons = true;

    // Completed Dynamic Container & Empty State
    private LinearLayout layoutCompletedLessonsList;
    private View layoutCompletedEmptyState;
    private TextView tvCompletedTotalCount;

    // Top Bar Streak Badge & Fire Flame Counter
    private View layoutStudyStreakBadge;
    private StudyRankFireView ivStreakFire;
    private TextView tvStreakScore;
    private StudyDynamicIslandController dynamicIslandController;

    // Floating Resume Incomplete Lesson Banner (3-4s delay after launch)
    private View layoutResumeLessonPrompt;
    private TextView tvResumePromptTitle;
    private TextView tvResumePromptSubtitle;
    private AppCompatButton btnResumeLessonAction;
    private View btnDismissResumePrompt;
    private final Handler resumePromptHandler = new Handler(Looper.getMainLooper());

    // ==========================================
    // CUSTOM MEDIA PLAYER (MEDIA3 EXOPLAYER)
    // ==========================================
    private View layoutCustomMediaPlayerOverlay;
    private View btnMinimizePlayer;
    private View btnPlayerHeaderClose;
    private TextView tvPlayerToolbarTitle;

    private FrameLayout layoutVideoContainer;
    private PlayerView playerViewMedia3;
    private ExoPlayer exoPlayer;

    private FrameLayout layoutPlayerBuffering;
    private PlanetaryGyroscopeView glowOrbitLoader;
    private TextView tvPlayerBufferStatus;

    private FrameLayout layoutPlayerControls;
    private TextView tvPlayerQualityBadge;
    private FrameLayout btnPlayerPip;
    private FrameLayout btnPlayerRotate;
    private TextView btnPlayerSpeed;
    private FrameLayout btnPlayerSettings;
    private FrameLayout btnPlayerRewind10;
    private FrameLayout btnPlayerPlayPause;
    private AppCompatImageView ivPlayerPlayPauseIcon;
    private FrameLayout btnPlayerForward10;
    private FrameLayout btnPlayerFullscreen;
    private AppCompatImageView ivPlayerFullscreenIcon;

    // Animated Neon SeekBar & Trackers
    private SeekBar playerSeekBar;
    private TextView tvPlayerCurrentTime;
    private TextView tvPlayerTotalDuration;
    private boolean isUserSeeking = false;

    // Settings Bottom Sheet Modal
    private View layoutPlayerSettingsSheet;
    private FrameLayout btnSettingsClose;
    private View btnSheetPip;
    private View btnSheetLandscape;
    private View btnSheetFullscreen;

    private View scrollPlayerDetails;
    private TextView tvPlayerSubjectBadge;
    private TextView tvPlayerRankTag;
    private TextView tvPlayerVideoTitle;
    private TextView tvPlayerChannelName;
    private TextView tvPlayerDuration;
    private TextView tvPlayerDescription;

    // Action Buttons under player (Add to lessons, Download, More, AI Doubt)
    private View btnAddCurrentToLessons;
    private View btnPlayerDownload;
    private View btnPlayerAiDoubt;
    private View btnPlayerMore;
    private LinearLayout layoutPlayerRecommendations;

    // AI Checkpoint Quizzes & Saved Quizzes Views
    private View layoutQuizEmpty;
    private LinearLayout layoutQuizList;
    private View layoutQuizStatsCard;
    private TextView tvQuizTotalCount;
    private TextView tvQuizPassRate;
    private TextView tvQuizAvgScore;
    private long lastQuizCheckpointMs = 0;
    private boolean isQuizDialogOpen = false;
    private Dialog activeQuizDialog = null;
    private boolean isDeepMode = false;

    // 19th-Minute Silent Prefetch Engine
    private List<StudyQuizManager.QuizQuestion> prefetchedQuiz = null;
    private boolean isPrefetchedAiGenerated = false;
    private boolean isPrefetchingQuiz = false;
    private boolean hasPrefetchedForCurrentCheckpoint = false;
    private boolean isWaitingForPrefetchToTriggerQuiz = false;
    private String prefetchedVideoId = null;
    private long prefetchedForCheckpointMs = 0;

    // Gesture HUD Overlays & Controllers
    private View layoutDoubleTapRewindOverlay;
    private View layoutDoubleTapForwardOverlay;
    private View layoutGestureBrightnessHud;
    private TextView tvBrightnessPercent;
    private ProgressBar pbBrightnessLevel;
    private View layoutGestureVolumeHud;
    private TextView tvVolumePercent;
    private ProgressBar pbVolumeLevel;
    private View layoutGestureSeekHud;
    private TextView tvGestureSeekPreview;
    private View layoutGestureSpeedBadge;
    private View layoutGestureTutorialOverlay;
    private AppCompatButton btnDismissGestureTutorial;

    private GestureDetector gestureDetector;
    private OrientationEventListener orientationEventListener;
    private boolean isSpeedBoostActive = false;
    private boolean isScrubbingActive = false;
    private long scrubStartPositionMs = 0;
    private long scrubTargetPositionMs = 0;
    private final Handler gestureHudHandler = new Handler(Looper.getMainLooper());
    private final Runnable hideGestureHudsRunnable = this::hideAllGestureHuds;

    private Class11Video currentPlayingVideo;
    private boolean isPlaying = false;
    private int playerRetryCount = 0;
    private float currentPlaybackSpeed = 1.0f;
    private String currentSelectedQuality = "720p HD";
    private MediaStreamResolver.MediaStreamResult currentMediaResult;
    private MediaStreamResolver.VideoStreamInfo currentVideoStreamInfo;
    private boolean isLandscapeMode = false;
    private boolean isFullscreenMode = false;

    private static final float[] EXTENDED_SPEEDS = {
            0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 2.5f, 3.0f, 3.5f, 4.0f
    };
    private final TextView[] speedChipViews = new TextView[12];
    private final TextView[] qualityChipViews = new TextView[7];

    private final Handler controlsHideHandler = new Handler(Looper.getMainLooper());
    private final Runnable hideControlsRunnable = this::hidePlayerControlsOverlay;

    private int watchTickCounter = 0;
    private final Handler timeTrackerHandler = new Handler(Looper.getMainLooper());
    private final Runnable timeTrackerRunnable = new Runnable() {
        @Override
        public void run() {
            if (exoPlayer != null && !isUserSeeking) {
                long pos = exoPlayer.getCurrentPosition();
                long dur = exoPlayer.getDuration();
                updateTimeAndSeekBar(pos, dur);

                if (exoPlayer.isPlaying() && currentPlayingVideo != null) {
                    // 20-Minute AI Knowledge Checkpoint Trigger (Pre-generated in advance)
                    if (!isQuizDialogOpen && pos > 0) {
                        long checkpointInterval = 20 * 60 * 1000L;
                        long nextCheckpointMs = lastQuizCheckpointMs + checkpointInterval;

                        // 1. Preload quiz in advance as early as possible for this specific video
                        if (!hasPrefetchedForCurrentCheckpoint && !isPrefetchingQuiz && prefetchedQuiz == null) {
                            checkAndTriggerAdvancePrefetch();
                        }

                        // 2. Exact Checkpoint at 20th minute
                        if (pos >= nextCheckpointMs) {
                            trigger20MinCheckpointQuiz(nextCheckpointMs);
                        }
                    }

                    watchTickCounter++;
                    if (watchTickCounter % 4 == 0) {
                        // Every 1 second of lecture watch time
                        boolean rankedUp = StudyLessonsManager.addWatchSeconds(YouTubeActivity.this, 1);
                        StudyLessonsManager.saveLastWatchedSession(YouTubeActivity.this, currentPlayingVideo, pos, dur);
                        if (rankedUp) {
                            updateStreakUI();
                            if (ivStreakFire != null) ivStreakFire.triggerSurge();
                            int newLevel = StudyLessonsManager.getFireRankLevel(YouTubeActivity.this);
                            String rankTitle = StudyLessonsManager.getRankTitle(newLevel);
                            Toast.makeText(YouTubeActivity.this, "🔥 RANK UP! " + rankTitle + " REACHED! (+100 PTS)", Toast.LENGTH_LONG).show();
                        } else if (watchTickCounter % 20 == 0) {
                            updateStreakUI();
                        }
                    }

                    // Auto-mark completed when 95%+ of lecture is watched
                    if (dur > 30000L && pos >= (dur * 0.95)) {
                        List<Class11Video> completed = StudyLessonsManager.getCompletedLessons(YouTubeActivity.this);
                        boolean alreadyMarked = false;
                        for (Class11Video cv : completed) {
                            if (cv.getId().equals(currentPlayingVideo.getId())) {
                                alreadyMarked = true;
                                break;
                            }
                        }
                        if (!alreadyMarked) {
                            StudyLessonsManager.markLessonCompleted(YouTubeActivity.this, currentPlayingVideo);
                            updateStreakUI();
                            loadDynamicLessonsTabs();
                            Toast.makeText(YouTubeActivity.this, "🎉 Lecture Completed! +50 Focus Points!", Toast.LENGTH_LONG).show();
                        }
                    }
                }
            }
            timeTrackerHandler.postDelayed(this, 250);
        }
    };

    private int currentTab = 2; // 0 = Quiz, 1 = Lessons, 2 = Home, 3 = Completed, 4 = Downloads

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        makeEdgeToEdge();
        setContentView(R.layout.activity_youtube);

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                handleBackAction();
            }
        });

        initViews();
        setupStreakBadge();
        setupBottomNav();
        setupLessonsToggle();
        setupSearchBar();
        setupCategoryChips();
        initClass11HomeFeed();
        setupInfiniteScroll();
        loadDynamicLessonsTabs();
        initCustomMediaPlayer();
        setupPlayerActionButtons();
        setupPlayerGestures();
        setupOrientationListener();
        animateEntrance();
        isDeepMode = getIntent() != null && getIntent().getBooleanExtra("is_deep_mode", false);
        if (isDeepMode) {
            dynamicIslandController = new StudyDynamicIslandController(this, findViewById(R.id.youtubeRoot));
            dynamicIslandController.setHideWhenIdle(true);
        }

        StudyVideoDownloadManager.getInstance(this).addListener(downloadListener);
        handleIncomingIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingIntent(intent);
    }

    private void handleIncomingIntent(Intent intent) {
        if (intent == null) return;
        if (intent.hasExtra("is_deep_mode")) {
            isDeepMode = intent.getBooleanExtra("is_deep_mode", false);
        }
        int targetTab = intent.getIntExtra("open_tab", -1);
        if (targetTab >= 0 && targetTab <= 4) {
            switchTab(targetTab);
        }
        String playVideoId = intent.getStringExtra("play_video_id");
        if (playVideoId != null && !playVideoId.isEmpty()) {
            File localFile = StudyVideoDownloadManager.getInstance(this).getDownloadedFile(playVideoId);
            if (localFile != null && localFile.exists()) {
                List<Class11Video> downloaded = StudyVideoDownloadManager.getInstance(this).getAllDownloadedVideos();
                for (Class11Video v : downloaded) {
                    if (v.getId().equals(playVideoId)) {
                        playClass11Video(v);
                        break;
                    }
                }
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (dynamicIslandController != null) {
            dynamicIslandController.refreshData();
        }
        updateStreakUI();
        loadDynamicLessonsTabs();
        loadDownloadedLessonsTab();
        scheduleResumePromptCheck();
    }

    private void makeEdgeToEdge() {
        try {
            Window window = getWindow();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                window.setStatusBarColor(Color.TRANSPARENT);
                window.setNavigationBarColor(Color.TRANSPARENT);
            }
            int uiOptions = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            window.getDecorView().setSystemUiVisibility(uiOptions);
        } catch (Exception ignored) {
        }
    }

    private void initViews() {
        // Top Back Button
        btnYouTubeBack = findViewById(R.id.btnYouTubeBack);
        if (btnYouTubeBack != null) {
            btnYouTubeBack.setOnClickListener(v -> handleBackAction());
            attachTouchShrink(btnYouTubeBack);
        }

        // Search Bar Views
        btnClearSearch = findViewById(R.id.btnClearSearch);
        etYouTubeSearch = findViewById(R.id.etYouTubeSearch);
        ivSearchIcon = findViewById(R.id.ivSearchIcon);

        // 5 Content Tabs
        layoutQuizTab = findViewById(R.id.layoutQuizTab);
        layoutLessonsTab = findViewById(R.id.layoutLessonsTab);
        layoutHomeTab = findViewById(R.id.layoutHomeTab);
        layoutCompletedTab = findViewById(R.id.layoutCompletedTab);
        layoutDownloadsTab = findViewById(R.id.layoutDownloadsTab);
        layoutDownloadsEmpty = findViewById(R.id.layoutDownloadsEmpty);
        layoutDownloadsList = findViewById(R.id.layoutDownloadsList);

        // Quiz Section Dynamic Views
        layoutQuizEmpty = findViewById(R.id.layoutQuizEmpty);
        layoutQuizList = findViewById(R.id.layoutQuizList);
        layoutQuizStatsCard = findViewById(R.id.layoutQuizStatsCard);
        tvQuizTotalCount = findViewById(R.id.tvQuizTotalCount);
        tvQuizPassRate = findViewById(R.id.tvQuizPassRate);
        tvQuizAvgScore = findViewById(R.id.tvQuizAvgScore);

        if (layoutQuizTab != null) layoutQuizTab.setHapticFeedbackEnabled(false);
        if (layoutLessonsTab != null) layoutLessonsTab.setHapticFeedbackEnabled(false);
        if (layoutHomeTab != null) layoutHomeTab.setHapticFeedbackEnabled(false);
        if (layoutCompletedTab != null) layoutCompletedTab.setHapticFeedbackEnabled(false);
        if (layoutDownloadsTab != null) layoutDownloadsTab.setHapticFeedbackEnabled(false);

        // Bottom Navigation (5 Buttons)
        btnNavQuiz = findViewById(R.id.btnNavQuiz);
        ivNavQuizIcon = findViewById(R.id.ivNavQuizIcon);
        tvNavQuizText = findViewById(R.id.tvNavQuizText);

        btnNavLessons = findViewById(R.id.btnNavLessons);
        ivNavLessonsIcon = findViewById(R.id.ivNavLessonsIcon);
        tvNavLessonsText = findViewById(R.id.tvNavLessonsText);

        btnNavHome = findViewById(R.id.btnNavHome);
        ivNavHomeIcon = findViewById(R.id.ivNavHomeIcon);
        tvNavHomeText = findViewById(R.id.tvNavHomeText);

        btnNavCompleted = findViewById(R.id.btnNavCompleted);
        ivNavCompletedIcon = findViewById(R.id.ivNavCompletedIcon);
        tvNavCompletedText = findViewById(R.id.tvNavCompletedText);

        btnNavDownloads = findViewById(R.id.btnNavDownloads);
        ivNavDownloadsIcon = findViewById(R.id.ivNavDownloadsIcon);
        tvNavDownloadsText = findViewById(R.id.tvNavDownloadsText);

        // Category Chips (100% Educational Syllabus)
        chipAll = findViewById(R.id.chipAll);
        chipPhysics = findViewById(R.id.chipPhysics);
        chipChemistry = findViewById(R.id.chipChemistry);
        chipMathematics = findViewById(R.id.chipMathematics);
        chipBiology = findViewById(R.id.chipBiology);
        chipOneShot = findViewById(R.id.chipOneShot);
        chipNcert = findViewById(R.id.chipNcert);
        chipJeeNeet = findViewById(R.id.chipJeeNeet);

        // Infinite Scroll Indicator
        layoutInfiniteScrollLoading = findViewById(R.id.layoutInfiniteScrollLoading);

        // Class 11 Hero Card & Feeds
        layoutHeroSectionContainer = findViewById(R.id.layoutHeroSectionContainer);
        tvAllLecturesHeader = findViewById(R.id.tvAllLecturesHeader);
        cardHeroVideo11 = findViewById(R.id.cardHeroVideo11);
        ivHeroThumbnail = findViewById(R.id.ivHeroThumbnail);
        tvHeroTitle = findViewById(R.id.tvHeroTitle);
        btnOpenYouTubeApp = findViewById(R.id.btnOpenYouTubeApp);
        layoutClass11VideosList = findViewById(R.id.layoutClass11VideosList);
        tvEmptySearchStatus = findViewById(R.id.tvEmptySearchStatus);

        // Lessons Top Toggle Buttons & Containers
        btnLessonIncomplete = findViewById(R.id.btnLessonIncomplete);
        ivLessonIncompleteIcon = findViewById(R.id.ivLessonIncompleteIcon);
        tvLessonIncompleteText = findViewById(R.id.tvLessonIncompleteText);
        tvIncompleteCountBadge = findViewById(R.id.tvIncompleteCountBadge);

        btnLessonUpcoming = findViewById(R.id.btnLessonUpcoming);
        ivLessonUpcomingIcon = findViewById(R.id.ivLessonUpcomingIcon);
        tvLessonUpcomingText = findViewById(R.id.tvLessonUpcomingText);
        tvUpcomingCountBadge = findViewById(R.id.tvUpcomingCountBadge);

        layoutIncompleteLessonsContainer = findViewById(R.id.layoutIncompleteLessonsContainer);
        layoutUpcomingLessonsContainer = findViewById(R.id.layoutUpcomingLessonsContainer);

        // Top Bar Streak Badge & Fire Flame Counter
        layoutStudyStreakBadge = findViewById(R.id.layoutStudyStreakBadge);
        ivStreakFire = findViewById(R.id.ivStreakFire);
        tvStreakScore = findViewById(R.id.tvStreakScore);

        // Dynamic Lessons Lists & Empty States (Zero Mock Data)
        layoutIncompleteLessonsList = findViewById(R.id.layoutIncompleteLessonsList);
        layoutIncompleteEmptyState = findViewById(R.id.layoutIncompleteEmptyState);
        layoutUpcomingLessonsList = findViewById(R.id.layoutUpcomingLessonsList);
        layoutUpcomingEmptyState = findViewById(R.id.layoutUpcomingEmptyState);
        layoutCompletedLessonsList = findViewById(R.id.layoutCompletedLessonsList);
        layoutCompletedEmptyState = findViewById(R.id.layoutCompletedEmptyState);
        tvCompletedTotalCount = findViewById(R.id.tvCompletedTotalCount);

        // Floating Resume Incomplete Lesson Banner
        layoutResumeLessonPrompt = findViewById(R.id.layoutResumeLessonPrompt);
        tvResumePromptTitle = findViewById(R.id.tvResumePromptTitle);
        tvResumePromptSubtitle = findViewById(R.id.tvResumePromptSubtitle);
        btnResumeLessonAction = findViewById(R.id.btnResumeLessonAction);
        btnDismissResumePrompt = findViewById(R.id.btnDismissResumePrompt);

        // ==========================================
        // CUSTOM MEDIA PLAYER (MEDIA3 EXOPLAYER)
        // ==========================================
        layoutCustomMediaPlayerOverlay = findViewById(R.id.layoutCustomMediaPlayerOverlay);
        btnMinimizePlayer = findViewById(R.id.btnMinimizePlayer);
        btnPlayerHeaderClose = findViewById(R.id.btnPlayerHeaderClose);
        tvPlayerToolbarTitle = findViewById(R.id.tvPlayerToolbarTitle);

        layoutVideoContainer = findViewById(R.id.layoutVideoContainer);
        playerViewMedia3 = findViewById(R.id.playerViewMedia3);

        layoutPlayerBuffering = findViewById(R.id.layoutPlayerBuffering);
        glowOrbitLoader = findViewById(R.id.glowOrbitLoader);
        tvPlayerBufferStatus = findViewById(R.id.tvPlayerBufferStatus);

        layoutPlayerControls = findViewById(R.id.layoutPlayerControls);
        btnPlayerSpeed = findViewById(R.id.btnPlayerSpeed);
        btnPlayerRewind10 = findViewById(R.id.btnPlayerRewind10);
        btnPlayerPlayPause = findViewById(R.id.btnPlayerPlayPause);
        ivPlayerPlayPauseIcon = findViewById(R.id.ivPlayerPlayPauseIcon);
        btnPlayerForward10 = findViewById(R.id.btnPlayerForward10);
        playerSeekBar = findViewById(R.id.playerSeekBar);
        tvPlayerCurrentTime = findViewById(R.id.tvPlayerCurrentTime);
        tvPlayerTotalDuration = findViewById(R.id.tvPlayerTotalDuration);
        btnPlayerFullscreen = findViewById(R.id.btnPlayerFullscreen);

        scrollPlayerDetails = findViewById(R.id.scrollPlayerDetails);
        tvPlayerSubjectBadge = findViewById(R.id.tvPlayerSubjectBadge);
        tvPlayerRankTag = findViewById(R.id.tvPlayerRankTag);
        tvPlayerVideoTitle = findViewById(R.id.tvPlayerVideoTitle);
        tvPlayerChannelName = findViewById(R.id.tvPlayerChannelName);
        tvPlayerDuration = findViewById(R.id.tvPlayerDuration);
        tvPlayerDescription = findViewById(R.id.tvPlayerDescription);

        // Quick Action Buttons
        btnAddCurrentToLessons = findViewById(R.id.btnAddCurrentToLessons);
        btnPlayerDownload = findViewById(R.id.btnPlayerDownload);
        btnPlayerAiDoubt = findViewById(R.id.btnPlayerAiDoubt);
        btnPlayerMore = findViewById(R.id.btnPlayerMore);
        layoutPlayerRecommendations = findViewById(R.id.layoutPlayerRecommendations);

        if (btnPlayerAiDoubt != null) {
            btnPlayerAiDoubt.setOnClickListener(v -> showAiDoubtSolverDialog());
            attachTouchShrink(btnPlayerAiDoubt);
        }

        // Gesture HUD Overlays & Controllers
        layoutDoubleTapRewindOverlay = findViewById(R.id.layoutDoubleTapRewindOverlay);
        layoutDoubleTapForwardOverlay = findViewById(R.id.layoutDoubleTapForwardOverlay);
        layoutGestureBrightnessHud = findViewById(R.id.layoutGestureBrightnessHud);
        tvBrightnessPercent = findViewById(R.id.tvBrightnessPercent);
        pbBrightnessLevel = findViewById(R.id.pbBrightnessLevel);
        layoutGestureVolumeHud = findViewById(R.id.layoutGestureVolumeHud);
        tvVolumePercent = findViewById(R.id.tvVolumePercent);
        pbVolumeLevel = findViewById(R.id.pbVolumeLevel);
        layoutGestureSeekHud = findViewById(R.id.layoutGestureSeekHud);
        tvGestureSeekPreview = findViewById(R.id.tvGestureSeekPreview);
        layoutGestureSpeedBadge = findViewById(R.id.layoutGestureSpeedBadge);
        layoutGestureTutorialOverlay = findViewById(R.id.layoutGestureTutorialOverlay);
        btnDismissGestureTutorial = findViewById(R.id.btnDismissGestureTutorial);
    }

    private void setupBottomNav() {
        if (btnNavQuiz != null) {
            btnNavQuiz.setOnClickListener(v -> switchTab(0));
            attachTouchShrink(btnNavQuiz);
        }

        if (btnNavLessons != null) {
            btnNavLessons.setOnClickListener(v -> switchTab(1));
            attachTouchShrink(btnNavLessons);
        }

        if (btnNavHome != null) {
            btnNavHome.setOnClickListener(v -> switchTab(2));
            attachTouchShrink(btnNavHome);
        }

        if (btnNavCompleted != null) {
            btnNavCompleted.setOnClickListener(v -> switchTab(3));
            attachTouchShrink(btnNavCompleted);
        }

        if (btnNavDownloads != null) {
            btnNavDownloads.setOnClickListener(v -> switchTab(4));
            attachTouchShrink(btnNavDownloads);
        }

        updateNavUI(2);
    }

    private void switchTab(int tabIndex) {
        if (currentTab == tabIndex) return;

        try {
            if (btnNavHome != null) {
                btnNavHome.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            }
        } catch (Exception ignored) {}

        View currentView = getTabView(currentTab);
        View nextView = getTabView(tabIndex);

        currentTab = tabIndex;
        updateNavUI(tabIndex);
        if (tabIndex == 0) {
            loadQuizSectionTab();
        } else if (tabIndex == 1 || tabIndex == 3) {
            loadDynamicLessonsTabs();
        } else if (tabIndex == 4) {
            loadDownloadedLessonsTab();
        }

        if (currentView != null) {
            currentView.animate()
                    .alpha(0f)
                    .translationY(-dpToPx(12))
                    .setDuration(160)
                    .setInterpolator(new AccelerateDecelerateInterpolator())
                    .withEndAction(() -> {
                        currentView.setVisibility(View.GONE);
                        currentView.setTranslationY(0f);
                        if (nextView != null) {
                            nextView.setAlpha(0f);
                            nextView.setTranslationY(dpToPx(16));
                            nextView.setVisibility(View.VISIBLE);
                            nextView.animate()
                                    .alpha(1f)
                                    .translationY(0f)
                                    .setDuration(220)
                                    .setInterpolator(new DecelerateInterpolator())
                                    .start();
                        }
                    })
                    .start();
        } else if (nextView != null) {
            nextView.setVisibility(View.VISIBLE);
            nextView.setAlpha(1f);
        }
    }

    private View getTabView(int index) {
        switch (index) {
            case 0: return layoutQuizTab;
            case 1: return layoutLessonsTab;
            case 2: return layoutHomeTab;
            case 3: return layoutCompletedTab;
            case 4: return layoutDownloadsTab;
            default: return layoutHomeTab;
        }
    }

    private void updateNavUI(int tabIndex) {
        int inactiveColor = Color.parseColor("#94A3B8");
        int activeCyan = Color.parseColor("#38BDF8");
        int activePurple = Color.parseColor("#C084FC");
        int activeGreen = Color.parseColor("#34D399");

        if (ivNavQuizIcon != null) ivNavQuizIcon.setColorFilter(inactiveColor);
        if (tvNavQuizText != null) {
            tvNavQuizText.setTextColor(inactiveColor);
            tvNavQuizText.setTypeface(null, android.graphics.Typeface.NORMAL);
        }

        if (ivNavLessonsIcon != null) ivNavLessonsIcon.setColorFilter(inactiveColor);
        if (tvNavLessonsText != null) {
            tvNavLessonsText.setTextColor(inactiveColor);
            tvNavLessonsText.setTypeface(null, android.graphics.Typeface.NORMAL);
        }

        if (ivNavCompletedIcon != null) ivNavCompletedIcon.setColorFilter(inactiveColor);
        if (tvNavCompletedText != null) {
            tvNavCompletedText.setTextColor(inactiveColor);
            tvNavCompletedText.setTypeface(null, android.graphics.Typeface.NORMAL);
        }

        if (ivNavDownloadsIcon != null) ivNavDownloadsIcon.setColorFilter(inactiveColor);
        if (tvNavDownloadsText != null) {
            tvNavDownloadsText.setTextColor(inactiveColor);
            tvNavDownloadsText.setTypeface(null, android.graphics.Typeface.NORMAL);
        }

        switch (tabIndex) {
            case 0:
                if (ivNavQuizIcon != null) ivNavQuizIcon.setColorFilter(activePurple);
                if (tvNavQuizText != null) {
                    tvNavQuizText.setTextColor(activePurple);
                    tvNavQuizText.setTypeface(null, android.graphics.Typeface.BOLD);
                }
                bounceView(btnNavQuiz);
                break;

            case 1:
                if (ivNavLessonsIcon != null) ivNavLessonsIcon.setColorFilter(activeCyan);
                if (tvNavLessonsText != null) {
                    tvNavLessonsText.setTextColor(activeCyan);
                    tvNavLessonsText.setTypeface(null, android.graphics.Typeface.BOLD);
                }
                bounceView(btnNavLessons);
                break;

            case 2:
                bounceView(btnNavHome);
                break;

            case 3:
                if (ivNavCompletedIcon != null) ivNavCompletedIcon.setColorFilter(activeGreen);
                if (tvNavCompletedText != null) {
                    tvNavCompletedText.setTextColor(activeGreen);
                    tvNavCompletedText.setTypeface(null, android.graphics.Typeface.BOLD);
                }
                bounceView(btnNavCompleted);
                break;

            case 4:
                if (ivNavDownloadsIcon != null) ivNavDownloadsIcon.setColorFilter(activeCyan);
                if (tvNavDownloadsText != null) {
                    tvNavDownloadsText.setTextColor(activeCyan);
                    tvNavDownloadsText.setTypeface(null, android.graphics.Typeface.BOLD);
                }
                bounceView(btnNavDownloads);
                break;
        }
    }

    private void bounceView(View v) {
        if (v == null) return;
        v.animate()
                .scaleX(1.14f)
                .scaleY(1.14f)
                .setDuration(130)
                .setInterpolator(new OvershootInterpolator(1.8f))
                .withEndAction(() -> v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(100).start())
                .start();
    }

    private void setupLessonsToggle() {
        if (btnLessonIncomplete != null) {
            btnLessonIncomplete.setOnClickListener(v -> switchLessonsFilter(true));
            attachTouchShrink(btnLessonIncomplete);
        }
        if (btnLessonUpcoming != null) {
            btnLessonUpcoming.setOnClickListener(v -> switchLessonsFilter(false));
            attachTouchShrink(btnLessonUpcoming);
        }
        updateLessonsFilterUI(true);
    }

    private void switchLessonsFilter(boolean showIncomplete) {
        if (isShowingIncompleteLessons == showIncomplete) return;
        isShowingIncompleteLessons = showIncomplete;

        try {
            if (btnLessonIncomplete != null) {
                btnLessonIncomplete.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            }
        } catch (Exception ignored) {}

        updateLessonsFilterUI(showIncomplete);

        View currentView = showIncomplete ? layoutUpcomingLessonsContainer : layoutIncompleteLessonsContainer;
        View nextView = showIncomplete ? layoutIncompleteLessonsContainer : layoutUpcomingLessonsContainer;

        if (currentView != null) {
            currentView.animate()
                    .alpha(0f)
                    .translationY(-dpToPx(8))
                    .setDuration(150)
                    .withEndAction(() -> {
                        currentView.setVisibility(View.GONE);
                        currentView.setTranslationY(0f);
                        if (nextView != null) {
                            nextView.setAlpha(0f);
                            nextView.setTranslationY(dpToPx(10));
                            nextView.setVisibility(View.VISIBLE);
                            nextView.animate()
                                    .alpha(1f)
                                    .translationY(0f)
                                    .setDuration(200)
                                    .setInterpolator(new DecelerateInterpolator())
                                    .start();
                        }
                    })
                    .start();
        } else if (nextView != null) {
            nextView.setVisibility(View.VISIBLE);
            nextView.setAlpha(1f);
        }
    }

    private void updateLessonsFilterUI(boolean showIncomplete) {
        if (showIncomplete) {
            if (btnLessonIncomplete != null) {
                btnLessonIncomplete.setBackgroundResource(R.drawable.bg_lessons_toggle_active);
                bounceView(btnLessonIncomplete);
            }
            if (ivLessonIncompleteIcon != null) ivLessonIncompleteIcon.setColorFilter(Color.WHITE);
            if (tvLessonIncompleteText != null) {
                tvLessonIncompleteText.setTextColor(Color.WHITE);
                tvLessonIncompleteText.setTypeface(null, android.graphics.Typeface.BOLD);
            }
            if (tvIncompleteCountBadge != null) {
                tvIncompleteCountBadge.setBackgroundResource(R.drawable.bg_badge_count_active);
                tvIncompleteCountBadge.setTextColor(Color.parseColor("#0284C7"));
            }

            if (btnLessonUpcoming != null) {
                btnLessonUpcoming.setBackgroundResource(R.drawable.bg_lessons_toggle_inactive);
            }
            if (ivLessonUpcomingIcon != null) ivLessonUpcomingIcon.setColorFilter(Color.parseColor("#94A3B8"));
            if (tvLessonUpcomingText != null) {
                tvLessonUpcomingText.setTextColor(Color.parseColor("#94A3B8"));
                tvLessonUpcomingText.setTypeface(null, android.graphics.Typeface.NORMAL);
            }
            if (tvUpcomingCountBadge != null) {
                tvUpcomingCountBadge.setBackgroundResource(R.drawable.bg_badge_count_inactive);
                tvUpcomingCountBadge.setTextColor(Color.parseColor("#94A3B8"));
            }
        } else {
            if (btnLessonUpcoming != null) {
                btnLessonUpcoming.setBackgroundResource(R.drawable.bg_lessons_toggle_active);
                bounceView(btnLessonUpcoming);
            }
            if (ivLessonUpcomingIcon != null) ivLessonUpcomingIcon.setColorFilter(Color.WHITE);
            if (tvLessonUpcomingText != null) {
                tvLessonUpcomingText.setTextColor(Color.WHITE);
                tvLessonUpcomingText.setTypeface(null, android.graphics.Typeface.BOLD);
            }
            if (tvUpcomingCountBadge != null) {
                tvUpcomingCountBadge.setBackgroundResource(R.drawable.bg_badge_count_active);
                tvUpcomingCountBadge.setTextColor(Color.parseColor("#0284C7"));
            }

            if (btnLessonIncomplete != null) {
                btnLessonIncomplete.setBackgroundResource(R.drawable.bg_lessons_toggle_inactive);
            }
            if (ivLessonIncompleteIcon != null) ivLessonIncompleteIcon.setColorFilter(Color.parseColor("#94A3B8"));
            if (tvLessonIncompleteText != null) {
                tvLessonIncompleteText.setTextColor(Color.parseColor("#94A3B8"));
                tvLessonIncompleteText.setTypeface(null, android.graphics.Typeface.NORMAL);
            }
            if (tvIncompleteCountBadge != null) {
                tvIncompleteCountBadge.setBackgroundResource(R.drawable.bg_badge_count_inactive);
                tvIncompleteCountBadge.setTextColor(Color.parseColor("#94A3B8"));
            }
        }
    }

    private void setupSearchBar() {
        if (etYouTubeSearch == null) return;

        // 1. Search action on soft keyboard -> hide keyboard & remove most wanted class 11
        etYouTubeSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                performSearch();
                return true;
            }
            return false;
        });

        // 2. Search Icon button -> hide keyboard & remove most wanted class 11
        if (ivSearchIcon != null) {
            ivSearchIcon.setOnClickListener(v -> performSearch());
            attachTouchShrink(ivSearchIcon);
        }

        etYouTubeSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int count, int after) {
                if (btnClearSearch != null) {
                    btnClearSearch.setVisibility(s.length() > 0 ? View.VISIBLE : View.GONE);
                }
                String q = s != null ? s.toString().trim() : "";
                String directId = extractYouTubeVideoId(q);
                if (directId != null && q.length() >= 11) {
                    handleDirectYouTubeLink(directId);
                } else {
                    filterClass11VideosBySearch(q);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        if (btnClearSearch != null) {
            btnClearSearch.setOnClickListener(v -> {
                lastDirectPlayedId = "";
                etYouTubeSearch.setText("");
                btnClearSearch.setVisibility(View.GONE);
                hideSoftKeyboard();
                if (layoutHeroSectionContainer != null) {
                    layoutHeroSectionContainer.setVisibility(View.VISIBLE);
                }
                if (tvAllLecturesHeader != null) {
                    tvAllLecturesHeader.setText("ALL CLASS 11 LECTURES (MOST POPULAR)");
                }
                renderClass11Videos(Class11VideoRepository.getAllVideos());
            });
        }
    }

    private void performSearch() {
        if (etYouTubeSearch == null) return;
        String query = etYouTubeSearch.getText().toString().trim();
        String directId = extractYouTubeVideoId(query);
        if (directId != null) {
            handleDirectYouTubeLink(directId);
        } else {
            filterClass11VideosBySearch(query);
        }
        hideSoftKeyboard();
        if (layoutHomeTab != null) {
            layoutHomeTab.smoothScrollTo(0, 0);
        }
    }

    private void hideSoftKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null && etYouTubeSearch != null) {
                imm.hideSoftInputFromWindow(etYouTubeSearch.getWindowToken(), 0);
            }
            if (etYouTubeSearch != null) {
                etYouTubeSearch.clearFocus();
            }
        } catch (Exception ignored) {
        }
    }

    private void setupCategoryChips() {
        if (chipAll != null) {
            chipAll.setText("All Lectures");
            chipAll.setOnClickListener(v -> {
                highlightChip(chipAll);
                currentSelectedCategory = "All";
                if (layoutHeroSectionContainer != null) {
                    layoutHeroSectionContainer.setVisibility(View.VISIBLE);
                }
                if (tvAllLecturesHeader != null) {
                    tvAllLecturesHeader.setText("ALL CLASS 11 LECTURES (MOST POPULAR)");
                }
                if (etYouTubeSearch != null) etYouTubeSearch.setText("");
                hideSoftKeyboard();
                renderClass11Videos(Class11VideoRepository.getAllVideos());
            });
        }
        if (chipPhysics != null) {
            chipPhysics.setText("Physics 11");
            chipPhysics.setOnClickListener(v -> {
                highlightChip(chipPhysics);
                currentSelectedCategory = "Physics";
                if (layoutHeroSectionContainer != null) {
                    layoutHeroSectionContainer.setVisibility(View.GONE);
                }
                if (tvAllLecturesHeader != null) {
                    tvAllLecturesHeader.setText("PHYSICS 11 LECTURES");
                }
                if (etYouTubeSearch != null) etYouTubeSearch.setText("");
                hideSoftKeyboard();
                renderClass11Videos(Class11VideoRepository.filterBySubject("Physics"));
            });
        }
        if (chipChemistry != null) {
            chipChemistry.setText("Chemistry 11");
            chipChemistry.setOnClickListener(v -> {
                highlightChip(chipChemistry);
                currentSelectedCategory = "Chemistry";
                if (layoutHeroSectionContainer != null) {
                    layoutHeroSectionContainer.setVisibility(View.GONE);
                }
                if (tvAllLecturesHeader != null) {
                    tvAllLecturesHeader.setText("CHEMISTRY 11 LECTURES");
                }
                if (etYouTubeSearch != null) etYouTubeSearch.setText("");
                hideSoftKeyboard();
                renderClass11Videos(Class11VideoRepository.filterBySubject("Chemistry"));
            });
        }
        if (chipMathematics != null) {
            chipMathematics.setText("Maths 11");
            chipMathematics.setOnClickListener(v -> {
                highlightChip(chipMathematics);
                currentSelectedCategory = "Mathematics";
                if (layoutHeroSectionContainer != null) {
                    layoutHeroSectionContainer.setVisibility(View.GONE);
                }
                if (tvAllLecturesHeader != null) {
                    tvAllLecturesHeader.setText("MATHEMATICS 11 LECTURES");
                }
                if (etYouTubeSearch != null) etYouTubeSearch.setText("");
                hideSoftKeyboard();
                renderClass11Videos(Class11VideoRepository.filterBySubject("Mathematics"));
            });
        }
        if (chipBiology != null) {
            chipBiology.setText("Biology 11");
            chipBiology.setOnClickListener(v -> {
                highlightChip(chipBiology);
                currentSelectedCategory = "Biology";
                if (layoutHeroSectionContainer != null) {
                    layoutHeroSectionContainer.setVisibility(View.GONE);
                }
                if (tvAllLecturesHeader != null) {
                    tvAllLecturesHeader.setText("BIOLOGY 11 LECTURES");
                }
                if (etYouTubeSearch != null) etYouTubeSearch.setText("");
                hideSoftKeyboard();
                renderClass11Videos(Class11VideoRepository.filterBySubject("Biology"));
            });
        }
        if (chipOneShot != null) {
            chipOneShot.setText("One-Shots");
            chipOneShot.setOnClickListener(v -> {
                highlightChip(chipOneShot);
                currentSelectedCategory = "One-Shot";
                if (layoutHeroSectionContainer != null) {
                    layoutHeroSectionContainer.setVisibility(View.GONE);
                }
                if (tvAllLecturesHeader != null) {
                    tvAllLecturesHeader.setText("ONE-SHOT REVISION LECTURES");
                }
                if (etYouTubeSearch != null) etYouTubeSearch.setText("");
                hideSoftKeyboard();
                renderClass11Videos(Class11VideoRepository.filterBySubject("One-Shot"));
            });
        }
        if (chipNcert != null) {
            chipNcert.setText("NCERT Revision");
            chipNcert.setOnClickListener(v -> {
                highlightChip(chipNcert);
                currentSelectedCategory = "NCERT";
                hideSoftKeyboard();
                filterClass11VideosBySearch("Class 11 NCERT revision full chapter");
            });
        }
        if (chipJeeNeet != null) {
            chipJeeNeet.setText("JEE / NEET");
            chipJeeNeet.setOnClickListener(v -> {
                highlightChip(chipJeeNeet);
                currentSelectedCategory = "JEE/NEET";
                hideSoftKeyboard();
                filterClass11VideosBySearch("Class 11 JEE NEET PYQ revision");
            });
        }
    }

    private void highlightChip(TextView activeChip) {
        TextView[] all = new TextView[]{chipAll, chipPhysics, chipChemistry, chipMathematics, chipBiology, chipOneShot, chipNcert, chipJeeNeet};
        for (TextView c : all) {
            if (c == null) continue;
            if (c == activeChip) {
                c.setBackgroundResource(R.drawable.bg_chip_neon_active);
                c.setTextColor(Color.WHITE);
            } else {
                c.setBackgroundResource(R.drawable.bg_chip_neon);
                c.setTextColor(Color.parseColor("#CBD5E1"));
            }
        }
    }

    // ========================================================
    // NON-STOP INFINITE SCROLL SYSTEM
    // ========================================================
    private void setupInfiniteScroll() {
        if (layoutHomeTab == null) return;

        layoutHomeTab.getViewTreeObserver().addOnScrollChangedListener(() -> {
            if (layoutHomeTab == null || layoutHomeTab.getVisibility() != View.VISIBLE) return;

            // Do not infinite scroll if search text is actively typed
            if (etYouTubeSearch != null && etYouTubeSearch.getText().toString().trim().length() > 0) return;

            if (layoutHomeTab.getChildCount() > 0) {
                View child = layoutHomeTab.getChildAt(0);
                if (child != null) {
                    int diff = child.getBottom() - (layoutHomeTab.getHeight() + layoutHomeTab.getScrollY());
                    if (diff <= 900 && !isLoadingMoreVideos) {
                        loadNextEducationalBatch();
                    }
                }
            }
        });
    }

    private void loadNextEducationalBatch() {
        if (isLoadingMoreVideos) return;
        isLoadingMoreVideos = true;

        if (layoutInfiniteScrollLoading != null) {
            layoutInfiniteScrollLoading.setVisibility(View.VISIBLE);
        }

        YouTubeSearchService.fetchEducationalTopicStream(infiniteScrollTopicIndex++, new YouTubeSearchService.SearchCallback() {
            @Override
            public void onSuccess(List<Class11Video> videos) {
                isLoadingMoreVideos = false;
                if (layoutInfiniteScrollLoading != null) {
                    layoutInfiniteScrollLoading.setVisibility(View.GONE);
                }

                if (videos != null && !videos.isEmpty()) {
                    appendEducationalVideos(videos);
                }
            }

            @Override
            public void onError(Throwable throwable) {
                isLoadingMoreVideos = false;
                if (layoutInfiniteScrollLoading != null) {
                    layoutInfiniteScrollLoading.setVisibility(View.GONE);
                }
            }
        });
    }

    private void appendEducationalVideos(List<Class11Video> moreVideos) {
        if (layoutClass11VideosList == null || moreVideos == null || moreVideos.isEmpty()) return;

        LayoutInflater inflater = LayoutInflater.from(this);
        for (final Class11Video video : moreVideos) {
            if (displayedVideoIds.contains(video.getId())) continue;
            displayedVideoIds.add(video.getId());

            View itemView = inflater.inflate(R.layout.item_class11_video, layoutClass11VideosList, false);

            ImageView ivThumbnail = itemView.findViewById(R.id.ivItemThumbnail);
            TextView tvRankBadge = itemView.findViewById(R.id.tvItemRankBadge);
            TextView tvDuration = itemView.findViewById(R.id.tvItemDuration);
            TextView tvSubject = itemView.findViewById(R.id.tvItemSubject);
            TextView tvTitle = itemView.findViewById(R.id.tvItemTitle);
            TextView tvChannel = itemView.findViewById(R.id.tvItemChannel);
            TextView tvDescription = itemView.findViewById(R.id.tvItemDescription);

            if (ivThumbnail != null) {
                AsyncThumbnailLoader.load(video.getThumbnailUrl(), ivThumbnail);
            }
            if (tvRankBadge != null) tvRankBadge.setText(video.getBadge());
            if (tvDuration != null) tvDuration.setText(video.getDuration());
            if (tvSubject != null) tvSubject.setText(video.getSubject().toUpperCase() + " 11");
            if (tvTitle != null) tvTitle.setText(video.getTitle());
            if (tvChannel != null) tvChannel.setText(video.getChannel());
            if (tvDescription != null) tvDescription.setText(video.getDescription());

            itemView.setOnClickListener(v -> playClass11Video(video));
            attachTouchShrink(itemView);

            layoutClass11VideosList.addView(itemView);
        }
    }

    // ========================================================
    // CLASS 11 HOME FEED POPULATION
    // ========================================================
    private void initClass11HomeFeed() {
        final Class11Video heroVideo = Class11VideoRepository.getHeroVideo();

        if (ivHeroThumbnail != null) {
            AsyncThumbnailLoader.load(heroVideo.getThumbnailUrl(), ivHeroThumbnail);
        }

        if (cardHeroVideo11 != null) {
            cardHeroVideo11.setOnClickListener(v -> playClass11Video(heroVideo));
            attachTouchShrink(cardHeroVideo11);
        }

        if (btnOpenYouTubeApp != null) {
            btnOpenYouTubeApp.setOnClickListener(v -> playClass11Video(heroVideo));
            attachTouchShrink(btnOpenYouTubeApp);
        }

        renderClass11Videos(Class11VideoRepository.getAllVideos());
    }

    private String lastDirectPlayedId = "";

    public static String extractYouTubeVideoId(String input) {
        if (input == null) return null;
        String text = input.trim();
        if (text.isEmpty()) return null;

        if (text.matches("^[a-zA-Z0-9_-]{11}$") && (text.contains("-") || text.contains("_") || text.matches(".*\\d.*"))) {
            return text;
        }

        Pattern pattern = Pattern.compile(
                "(?:https?:\\/\\/)?(?:www\\.|m\\.)?(?:youtube\\.com\\/(?:watch\\?.*?v=|embed\\/|v\\/|shorts\\/|live\\/)|youtu\\.be\\/)([a-zA-Z0-9_-]{11})",
                Pattern.CASE_INSENSITIVE
        );
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }

    private void handleDirectYouTubeLink(final String videoId) {
        if (videoId == null || videoId.isEmpty()) return;
        hideSoftKeyboard();

        if (layoutHeroSectionContainer != null) {
            layoutHeroSectionContainer.setVisibility(View.GONE);
        }
        if (tvAllLecturesHeader != null) {
            tvAllLecturesHeader.setText("DIRECT YOUTUBE LECTURE");
        }
        if (tvEmptySearchStatus != null) {
            tvEmptySearchStatus.setVisibility(View.GONE);
        }

        // Check if video already exists in curated repository
        Class11Video matched = null;
        for (Class11Video v : Class11VideoRepository.getAllVideos()) {
            if (v.getId().equalsIgnoreCase(videoId)) {
                matched = v;
                break;
            }
        }

        final Class11Video videoToPlay;
        if (matched != null) {
            videoToPlay = matched;
        } else {
            videoToPlay = new Class11Video(
                    videoId,
                    "YouTube Video (" + videoId + ")",
                    "StudyTube",
                    "YouTube",
                    "Direct Stream",
                    "Full Video",
                    "📺 DIRECT LINK",
                    "Educational video lecture loaded directly via YouTube link."
            );
            fetchYouTubeMetadata(videoId);
        }

        List<Class11Video> directList = new ArrayList<>();
        directList.add(videoToPlay);
        renderClass11Videos(directList);

        if (!videoId.equals(lastDirectPlayedId) || currentPlayingVideo == null || !videoId.equals(currentPlayingVideo.getId())) {
            lastDirectPlayedId = videoId;
            Toast.makeText(this, "📺 Loading Direct YouTube Video...", Toast.LENGTH_SHORT).show();
            playClass11Video(videoToPlay);
        }
    }

    private void fetchYouTubeMetadata(final String videoId) {
        new Thread(() -> {
            try {
                String oEmbedUrl = "https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=" + videoId + "&format=json";
                java.net.URL url = new java.net.URL(oEmbedUrl);
                java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(6000);
                conn.setReadTimeout(6000);
                conn.setRequestMethod("GET");
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10)");

                if (conn.getResponseCode() == 200) {
                    java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(conn.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                    }
                    reader.close();

                    org.json.JSONObject json = new org.json.JSONObject(sb.toString());
                    final String title = json.optString("title", "YouTube Video (" + videoId + ")");
                    final String channel = json.optString("author_name", "YouTube");

                    runOnUiThread(() -> {
                        if (currentPlayingVideo != null && currentPlayingVideo.getId().equals(videoId)) {
                            Class11Video updated = new Class11Video(
                                    videoId,
                                    title,
                                    "StudyTube",
                                    channel,
                                    "Direct Stream",
                                    "Full Video",
                                    "📺 DIRECT LINK",
                                    "Educational lecture: " + title
                            );
                            currentPlayingVideo = updated;
                            if (tvPlayerToolbarTitle != null) tvPlayerToolbarTitle.setText(title);
                            if (tvPlayerVideoTitle != null) tvPlayerVideoTitle.setText(title);
                            if (tvPlayerChannelName != null) tvPlayerChannelName.setText(channel);
                            if (tvPlayerDescription != null) tvPlayerDescription.setText(title);

                            List<Class11Video> directList = new ArrayList<>();
                            directList.add(updated);
                            renderClass11Videos(directList);
                        }
                    });
                }
            } catch (Exception ignored) {}
        }).start();
    }

    private void filterClass11VideosBySearch(final String query) {
        if (query == null || query.trim().isEmpty()) {
            if (layoutHeroSectionContainer != null) {
                layoutHeroSectionContainer.setVisibility(View.VISIBLE);
            }
            if (tvAllLecturesHeader != null) {
                tvAllLecturesHeader.setText("ALL CLASS 11 LECTURES (MOST POPULAR)");
            }
            if (tvEmptySearchStatus != null) tvEmptySearchStatus.setVisibility(View.GONE);
            renderClass11Videos(Class11VideoRepository.getAllVideos());
            return;
        }

        final String cleanQuery = query.trim();

        // Direct YouTube Link Detection
        final String directVideoId = extractYouTubeVideoId(cleanQuery);
        if (directVideoId != null) {
            handleDirectYouTubeLink(directVideoId);
            return;
        }

        // Active Search: HIDE Most Wanted Class 11th Lecture section!
        if (layoutHeroSectionContainer != null) {
            layoutHeroSectionContainer.setVisibility(View.GONE);
        }
        if (tvAllLecturesHeader != null) {
            tvAllLecturesHeader.setText("SEARCH RESULTS FOR \"" + cleanQuery.toUpperCase() + "\"");
        }

        // 1. Strict Non-Educational Query Blocker:
        if (YouTubeSearchService.isNonEducationalQuery(cleanQuery)) {
            if (layoutClass11VideosList != null) layoutClass11VideosList.removeAllViews();
            displayedVideoIds.clear();
            if (tvEmptySearchStatus != null) {
                tvEmptySearchStatus.setText("NON-EDUCATIONAL CONTENT BLOCKED\n\nStudyTube is strictly restricted to educational lectures, NCERT syllabus, and study topics.\nGaming, movies, and entertainment are blocked.");
                tvEmptySearchStatus.setVisibility(View.VISIBLE);
            }
            return;
        }

        // Show immediate local results while live search is fetching
        List<Class11Video> localResults = Class11VideoRepository.search(cleanQuery);
        if (!localResults.isEmpty()) {
            renderClass11Videos(localResults);
        }

        // Execute live strictly educational YouTube search
        YouTubeSearchService.search(cleanQuery, new YouTubeSearchService.SearchCallback() {
            @Override
            public void onSuccess(List<Class11Video> videos) {
                if (etYouTubeSearch != null && cleanQuery.equals(etYouTubeSearch.getText().toString().trim())) {
                    if (videos != null && !videos.isEmpty()) {
                        renderClass11Videos(videos);
                    } else {
                        if (layoutClass11VideosList != null) layoutClass11VideosList.removeAllViews();
                        displayedVideoIds.clear();
                        if (tvEmptySearchStatus != null) {
                            tvEmptySearchStatus.setText("No educational lectures found matching \"" + cleanQuery + "\". Try searching for Physics, Chemistry, Maths, or Biology topics.");
                            tvEmptySearchStatus.setVisibility(View.VISIBLE);
                        }
                    }
                }
            }

            @Override
            public void onError(Throwable throwable) {
                // Keep local results on error
            }
        });
    }

    private void renderClass11Videos(List<Class11Video> videos) {
        if (layoutClass11VideosList == null) return;
        layoutClass11VideosList.removeAllViews();
        displayedVideoIds.clear();

        if (videos == null || videos.isEmpty()) {
            if (tvEmptySearchStatus != null) tvEmptySearchStatus.setVisibility(View.VISIBLE);
            return;
        }

        if (tvEmptySearchStatus != null) tvEmptySearchStatus.setVisibility(View.GONE);

        appendEducationalVideos(videos);
    }

    // =========================================================================
    // STUDY STREAK ENGINE & DAILY FOCUS POINTS
    // =========================================================================
    private void setupStreakBadge() {
        StudyLessonsManager.recordDailyVisit(this);
        updateStreakUI();

        if (layoutStudyStreakBadge != null) {
            layoutStudyStreakBadge.setOnClickListener(v -> openStudyRankPage());
            attachTouchShrink(layoutStudyStreakBadge);
        }
    }

    private void updateStreakUI() {
        int points = StudyLessonsManager.getStreakPoints(this);
        int rankLevel = StudyLessonsManager.getFireRankLevel(this);

        // Display Points Number Only (No Day, No Progress Bar)
        if (tvStreakScore != null) {
            tvStreakScore.setText(String.valueOf(points));
        }

        // Fire Logo Updates Procedural Animated Flame & StudyTube Rank Tier
        if (ivStreakFire != null) {
            ivStreakFire.setRankLevel(rankLevel);
            if (tvStreakScore != null) {
                tvStreakScore.setTextColor(ivStreakFire.getRankScoreColor());
            }
        }
    }

    private void openStudyRankPage() {
        if (ivStreakFire != null) {
            ivStreakFire.triggerSurge();
        }
        try {
            Intent intent = new Intent(YouTubeActivity.this, StudyRankActivity.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        } catch (Exception e) {
            Toast.makeText(this, "Opening StudyTube Rank...", Toast.LENGTH_SHORT).show();
        }
    }

    private void showStreakDialog() {
        openStudyRankPage();
    }

    private GradientDrawable createTintedPillDrawable(int color) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(dpToPx(12));
        gd.setColor(color);
        return gd;
    }

    // =========================================================================
    // PREVIOUS INCOMPLETE LESSON (20+ MIN RESUME BANNER)
    // =========================================================================
    private void scheduleResumePromptCheck() {
        resumePromptHandler.removeCallbacksAndMessages(null);
        resumePromptHandler.postDelayed(() -> {
            if (isFinishing() || isDestroyed()) return;
            if (layoutCustomMediaPlayerOverlay != null && layoutCustomMediaPlayerOverlay.getVisibility() == View.VISIBLE) {
                return; // Player already active
            }
            final StudyLessonsManager.ResumeSession session = StudyLessonsManager.getLastWatchedSession(YouTubeActivity.this);
            if (session != null && layoutResumeLessonPrompt != null) {
                if (tvResumePromptSubtitle != null) {
                    tvResumePromptSubtitle.setText(session.title + " • at " + session.getFormattedPosition());
                }
                layoutResumeLessonPrompt.setVisibility(View.VISIBLE);
                layoutResumeLessonPrompt.setAlpha(0f);
                layoutResumeLessonPrompt.setTranslationY(dpToPx(60));
                layoutResumeLessonPrompt.animate()
                        .alpha(1f)
                        .translationY(0f)
                        .setDuration(320)
                        .setInterpolator(new DecelerateInterpolator())
                        .start();

                if (btnResumeLessonAction != null) {
                    btnResumeLessonAction.setOnClickListener(v -> {
                        dismissResumePrompt(false);
                        resumeLessonSession(session);
                    });
                }

                if (btnDismissResumePrompt != null) {
                    btnDismissResumePrompt.setOnClickListener(v -> dismissResumePrompt(true));
                }
            }
        }, 3500);
    }

    private void dismissResumePrompt(boolean clearSession) {
        if (layoutResumeLessonPrompt == null || layoutResumeLessonPrompt.getVisibility() != View.VISIBLE) return;
        if (clearSession) {
            StudyLessonsManager.clearLastWatchedSession(this);
        }
        layoutResumeLessonPrompt.animate()
                .alpha(0f)
                .translationY(dpToPx(60))
                .setDuration(220)
                .withEndAction(() -> layoutResumeLessonPrompt.setVisibility(View.GONE))
                .start();
    }

    private void resumeLessonSession(StudyLessonsManager.ResumeSession session) {
        if (session == null) return;
        Class11Video target = null;
        for (Class11Video v : Class11VideoRepository.getAllVideos()) {
            if (v.getId().equals(session.id)) {
                target = v;
                break;
            }
        }
        if (target == null) {
            target = new Class11Video(
                    session.id,
                    session.title,
                    session.subject,
                    session.channel,
                    "Study Lecture",
                    session.getFormattedPosition(),
                    "RESUME",
                    "Resume previously paused focus lesson."
            );
        }
        playClass11VideoWithSeek(target, session.positionMs);
    }

    // =========================================================================
    // DYNAMIC LESSONS & COMPLETED TABS (ZERO DEMO DATA)
    // =========================================================================
    private void loadDynamicLessonsTabs() {
        LayoutInflater inflater = LayoutInflater.from(this);

        // 1. Incomplete Lessons
        List<Class11Video> incomplete = StudyLessonsManager.getIncompleteLessons(this);
        if (tvIncompleteCountBadge != null) {
            tvIncompleteCountBadge.setText(String.valueOf(incomplete.size()));
        }

        if (layoutIncompleteLessonsList != null && layoutIncompleteEmptyState != null) {
            layoutIncompleteLessonsList.removeAllViews();
            if (incomplete.isEmpty()) {
                layoutIncompleteEmptyState.setVisibility(View.VISIBLE);
                layoutIncompleteLessonsList.setVisibility(View.GONE);
            } else {
                layoutIncompleteEmptyState.setVisibility(View.GONE);
                layoutIncompleteLessonsList.setVisibility(View.VISIBLE);

                for (final Class11Video v : incomplete) {
                    View item = inflater.inflate(R.layout.item_study_lesson_entry, layoutIncompleteLessonsList, false);
                    bindLessonItem(item, v, "• In-Progress", false, () -> {
                        confirmDeleteLesson(v, "In-Progress", () -> {
                            StudyLessonsManager.removeIncompleteLesson(YouTubeActivity.this, v.getId());
                            loadDynamicLessonsTabs();
                        });
                    });
                    layoutIncompleteLessonsList.addView(item);
                }
            }
        }

        // 2. Upcoming Lessons
        List<Class11Video> upcoming = StudyLessonsManager.getUpcomingLessons(this);
        if (tvUpcomingCountBadge != null) {
            tvUpcomingCountBadge.setText(String.valueOf(upcoming.size()));
        }

        if (layoutUpcomingLessonsList != null && layoutUpcomingEmptyState != null) {
            layoutUpcomingLessonsList.removeAllViews();
            if (upcoming.isEmpty()) {
                layoutUpcomingEmptyState.setVisibility(View.VISIBLE);
                layoutUpcomingLessonsList.setVisibility(View.GONE);
            } else {
                layoutUpcomingEmptyState.setVisibility(View.GONE);
                layoutUpcomingLessonsList.setVisibility(View.VISIBLE);

                for (final Class11Video v : upcoming) {
                    View item = inflater.inflate(R.layout.item_study_lesson_entry, layoutUpcomingLessonsList, false);
                    bindLessonItem(item, v, "• Upcoming", false, () -> {
                        confirmDeleteLesson(v, "Upcoming", () -> {
                            StudyLessonsManager.removeUpcomingLesson(YouTubeActivity.this, v.getId());
                            loadDynamicLessonsTabs();
                        });
                    });
                    layoutUpcomingLessonsList.addView(item);
                }
            }
        }

        // 3. Completed Lessons
        List<Class11Video> completed = StudyLessonsManager.getCompletedLessons(this);
        if (tvCompletedTotalCount != null) {
            tvCompletedTotalCount.setText(String.valueOf(completed.size()));
        }

        if (layoutCompletedLessonsList != null && layoutCompletedEmptyState != null) {
            layoutCompletedLessonsList.removeAllViews();
            if (completed.isEmpty()) {
                layoutCompletedEmptyState.setVisibility(View.VISIBLE);
                layoutCompletedLessonsList.setVisibility(View.GONE);
            } else {
                layoutCompletedEmptyState.setVisibility(View.GONE);
                layoutCompletedLessonsList.setVisibility(View.VISIBLE);

                for (final Class11Video v : completed) {
                    View item = inflater.inflate(R.layout.item_study_lesson_entry, layoutCompletedLessonsList, false);
                    // Completed lessons are permanent and cannot be deleted
                    bindLessonItem(item, v, "• Completed", true, null);
                    layoutCompletedLessonsList.addView(item);
                }
            }
        }
    }

    private void bindLessonItem(View item, final Class11Video v, String statusText, boolean isCompleted, final Runnable onDeleteConfirm) {
        ImageView ivThumb = item.findViewById(R.id.ivLessonThumb);
        TextView tvDuration = item.findViewById(R.id.tvLessonDuration);
        TextView tvSubject = item.findViewById(R.id.tvLessonSubject);
        TextView tvStatusBadge = item.findViewById(R.id.tvLessonStatusBadge);
        TextView tvTitle = item.findViewById(R.id.tvLessonTitle);
        TextView tvChannel = item.findViewById(R.id.tvLessonChannel);

        if (ivThumb != null) AsyncThumbnailLoader.load(v.getThumbnailUrl(), ivThumb);
        if (tvDuration != null) tvDuration.setText(v.getDuration());
        if (tvSubject != null) tvSubject.setText(v.getSubject().toUpperCase());
        if (tvStatusBadge != null) {
            tvStatusBadge.setText(statusText);
            tvStatusBadge.setTextColor(isCompleted ? Color.parseColor("#34D399") : Color.parseColor("#94A3B8"));
        }
        if (tvTitle != null) tvTitle.setText(v.getTitle());
        if (tvChannel != null) {
            tvChannel.setText(isCompleted ? (v.getChannel() + " • Completed Archive") : (v.getChannel() + " • Hold to delete"));
        }

        item.setOnClickListener(view -> playClass11Video(v));

        if (onDeleteConfirm != null) {
            item.setOnLongClickListener(view -> {
                try { view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); } catch (Exception ignored) {}
                onDeleteConfirm.run();
                return true;
            });
        } else {
            item.setOnLongClickListener(null);
            item.setLongClickable(false);
        }
        attachTouchShrink(item);
    }

    private void confirmDeleteLesson(final Class11Video video, String categoryName, final Runnable onConfirm) {
        if (isFinishing() || isDestroyed() || video == null) return;

        try {
            final AlertDialog dialog = new AlertDialog.Builder(this).create();
            View dialogView = getLayoutInflater().inflate(R.layout.dialog_confirm_delete_lesson, null);
            dialog.setView(dialogView);

            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.getWindow().setDimAmount(0.72f);
            }

            final View layoutDeleteDialogCard = dialogView.findViewById(R.id.layoutDeleteDialogCard);
            final View layoutDeleteIconGlow = dialogView.findViewById(R.id.layoutDeleteIconGlow);
            TextView tvDeleteDialogTitle = dialogView.findViewById(R.id.tvDeleteDialogTitle);
            TextView tvDeleteCategoryBadge = dialogView.findViewById(R.id.tvDeleteCategoryBadge);
            ImageView ivDeleteVideoThumb = dialogView.findViewById(R.id.ivDeleteVideoThumb);
            TextView tvDeleteVideoDuration = dialogView.findViewById(R.id.tvDeleteVideoDuration);
            TextView tvDeleteVideoSubject = dialogView.findViewById(R.id.tvDeleteVideoSubject);
            TextView tvDeleteVideoTitle = dialogView.findViewById(R.id.tvDeleteVideoTitle);
            TextView tvDeleteVideoChannel = dialogView.findViewById(R.id.tvDeleteVideoChannel);
            View btnCancelDelete = dialogView.findViewById(R.id.btnCancelDelete);
            View btnConfirmDelete = dialogView.findViewById(R.id.btnConfirmDelete);

            if (tvDeleteDialogTitle != null) {
                tvDeleteDialogTitle.setText("Remove Lesson?");
            }

            if (tvDeleteCategoryBadge != null) {
                tvDeleteCategoryBadge.setText("• " + categoryName.toUpperCase() + " TRACK");
            }

            if (ivDeleteVideoThumb != null) {
                AsyncThumbnailLoader.load(video.getThumbnailUrl(), ivDeleteVideoThumb);
            }

            if (tvDeleteVideoDuration != null) {
                tvDeleteVideoDuration.setText(video.getDuration());
            }

            if (tvDeleteVideoSubject != null) {
                tvDeleteVideoSubject.setText(video.getSubject().toUpperCase());
            }

            if (tvDeleteVideoTitle != null) {
                tvDeleteVideoTitle.setText(video.getTitle());
            }

            if (tvDeleteVideoChannel != null) {
                tvDeleteVideoChannel.setText(video.getChannel());
            }

            if (btnCancelDelete != null) {
                btnCancelDelete.setOnClickListener(v -> {
                    if (layoutDeleteDialogCard != null) {
                        layoutDeleteDialogCard.animate()
                                .scaleX(0.88f)
                                .scaleY(0.88f)
                                .alpha(0f)
                                .setDuration(160)
                                .withEndAction(dialog::dismiss)
                                .start();
                    } else {
                        dialog.dismiss();
                    }
                });
                attachTouchShrink(btnCancelDelete);
            }

            if (btnConfirmDelete != null) {
                btnConfirmDelete.setOnClickListener(v -> {
                    if (layoutDeleteDialogCard != null) {
                        layoutDeleteDialogCard.animate()
                                .scaleX(0.88f)
                                .scaleY(0.88f)
                                .alpha(0f)
                                .setDuration(160)
                                .withEndAction(() -> {
                                    dialog.dismiss();
                                    if (onConfirm != null) onConfirm.run();
                                    Toast.makeText(YouTubeActivity.this, "Lesson removed from track ✓", Toast.LENGTH_SHORT).show();
                                })
                                .start();
                    } else {
                        dialog.dismiss();
                        if (onConfirm != null) onConfirm.run();
                        Toast.makeText(YouTubeActivity.this, "Lesson removed from track ✓", Toast.LENGTH_SHORT).show();
                    }
                });
                attachTouchShrink(btnConfirmDelete);
            }

            dialog.show();

            // Entrance spring & bounce animation
            if (layoutDeleteDialogCard != null) {
                layoutDeleteDialogCard.setScaleX(0.84f);
                layoutDeleteDialogCard.setScaleY(0.84f);
                layoutDeleteDialogCard.setAlpha(0f);
                layoutDeleteDialogCard.animate()
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .alpha(1.0f)
                        .setDuration(220)
                        .setInterpolator(new OvershootInterpolator(1.3f))
                        .start();
            }

            if (layoutDeleteIconGlow != null) {
                layoutDeleteIconGlow.setScaleX(0.4f);
                layoutDeleteIconGlow.setScaleY(0.4f);
                layoutDeleteIconGlow.animate()
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .setDuration(300)
                        .setInterpolator(new OvershootInterpolator(2.4f))
                        .setStartDelay(80)
                        .start();
            }

        } catch (Exception e) {
            if (onConfirm != null) onConfirm.run();
        }
    }

    // =========================================================================
    // QUICK ACTION BUTTONS UNDER PLAYER (ADD TO LESSONS, DOWNLOAD, MORE)
    // =========================================================================
    private void setupPlayerActionButtons() {
        if (btnAddCurrentToLessons != null) {
            btnAddCurrentToLessons.setOnClickListener(v -> {
                if (currentPlayingVideo != null) {
                    boolean added = StudyLessonsManager.addIncompleteLesson(YouTubeActivity.this, currentPlayingVideo);
                    Toast.makeText(YouTubeActivity.this, added ? "Added to In-Progress Lessons!" : "Already in Lessons!", Toast.LENGTH_SHORT).show();
                    loadDynamicLessonsTabs();
                }
            });
            attachTouchShrink(btnAddCurrentToLessons);
        }

        if (btnPlayerDownload != null) {
            btnPlayerDownload.setOnClickListener(v -> showOfflineDownloadOptions());
            attachTouchShrink(btnPlayerDownload);
        }

        if (btnPlayerMore != null) {
            btnPlayerMore.setOnClickListener(v -> showPlayerMoreOptions());
            attachTouchShrink(btnPlayerMore);
        }
    }

    private void showOfflineDownloadOptions() {
        if (currentPlayingVideo == null) return;

        final List<String> optionsList = new ArrayList<>();
        final List<String> qualityList = new ArrayList<>();

        if (currentMediaResult != null && !currentMediaResult.qualityStreams.isEmpty()) {
            if (currentMediaResult.qualityStreams.containsKey("1080p")) {
                optionsList.add("📥 Download 1080p FHD (Crystal Clear)");
                qualityList.add("1080p");
            }
            if (currentMediaResult.qualityStreams.containsKey("720p")) {
                optionsList.add("📥 Download 720p HD (Recommended)");
                qualityList.add("720p");
            }
            if (currentMediaResult.qualityStreams.containsKey("480p")) {
                optionsList.add("📥 Download 480p (Balanced)");
                qualityList.add("480p");
            }
            if (currentMediaResult.qualityStreams.containsKey("360p")) {
                optionsList.add("📥 Download 360p (Data Saver)");
                qualityList.add("360p");
            }
        } else {
            optionsList.add("📥 Download 720p HD (Recommended)");
            qualityList.add("720p");
            optionsList.add("📥 Download 360p (Data Saver)");
            qualityList.add("360p");
        }

        optionsList.add("🎧 Download Focus Audio (M4A Track)");
        qualityList.add("AUDIO");

        optionsList.add("📄 Chapter Formula & Revision Notes (PDF)");
        qualityList.add("PDF");

        final String[] items = optionsList.toArray(new String[0]);

        new AlertDialog.Builder(this)
                .setTitle("Offline Download Quality")
                .setItems(items, (dialog, which) -> {
                    String selectedType = qualityList.get(which);
                    if ("PDF".equals(selectedType)) {
                        Toast.makeText(YouTubeActivity.this, "Fetching chapter revision notes PDF...", Toast.LENGTH_SHORT).show();
                    } else if ("AUDIO".equals(selectedType)) {
                        startRealAudioDownload(currentPlayingVideo);
                    } else {
                        startRealVideoDownload(currentPlayingVideo, selectedType);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void startRealAudioDownload(final Class11Video video) {
        if (video == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }
        StudyVideoDownloadManager dm = StudyVideoDownloadManager.getInstance(this);
        if (dm.isDownloaded(video.getId())) {
            Toast.makeText(this, "Lecture already downloaded! Ready in Downloads tab.", Toast.LENGTH_SHORT).show();
            switchTab(4);
            return;
        }
        if (dm.isDownloading(video.getId())) {
            Toast.makeText(this, "Download already in progress! Check notification bar.", Toast.LENGTH_SHORT).show();
            switchTab(4);
            return;
        }
        dm.startAudioDownload(video);
        Toast.makeText(this, "📥 Starting audio download: " + video.getTitle(), Toast.LENGTH_LONG).show();
        loadDownloadedLessonsTab();
    }

    private void startRealVideoDownload(final Class11Video video) {
        startRealVideoDownload(video, "720p");
    }

    private void startRealVideoDownload(final Class11Video video, final String requestedQuality) {
        if (video == null) return;

        // Check Notification Permission on Android 13+ (TIRAMISU)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }

        StudyVideoDownloadManager dm = StudyVideoDownloadManager.getInstance(this);
        if (dm.isDownloaded(video.getId())) {
            Toast.makeText(this, "Lecture already downloaded! Ready in Downloads tab.", Toast.LENGTH_SHORT).show();
            switchTab(4);
            return;
        }

        if (dm.isDownloading(video.getId())) {
            Toast.makeText(this, "Download already in progress! Check notification bar.", Toast.LENGTH_SHORT).show();
            switchTab(4);
            return;
        }

        dm.startDownload(video, requestedQuality);
        Toast.makeText(this, "📥 Starting download (" + requestedQuality + "): " + video.getTitle(), Toast.LENGTH_LONG).show();
        loadDownloadedLessonsTab();
    }

    private void loadDownloadedLessonsTab() {
        if (layoutDownloadsList == null || layoutDownloadsEmpty == null) return;
        StudyVideoDownloadManager dm = StudyVideoDownloadManager.getInstance(this);
        Map<String, StudyVideoDownloadManager.DownloadTask> activeTasks = dm.getActiveTasks();
        List<Class11Video> downloaded = dm.getAllDownloadedVideos();

        layoutDownloadsList.removeAllViews();

        if (activeTasks.isEmpty() && downloaded.isEmpty()) {
            layoutDownloadsEmpty.setVisibility(View.VISIBLE);
            layoutDownloadsList.setVisibility(View.GONE);
            return;
        }

        layoutDownloadsEmpty.setVisibility(View.GONE);
        layoutDownloadsList.setVisibility(View.VISIBLE);
        LayoutInflater inflater = LayoutInflater.from(this);

        // 1. Render Active Downloading Tasks
        for (final StudyVideoDownloadManager.DownloadTask task : activeTasks.values()) {
            final Class11Video v = task.video;
            View item = inflater.inflate(R.layout.item_download_video_entry, layoutDownloadsList, false);

            ImageView ivThumb = item.findViewById(R.id.ivDownloadThumb);
            TextView tvDuration = item.findViewById(R.id.tvDownloadDuration);
            TextView tvSubject = item.findViewById(R.id.tvDownloadSubject);
            TextView tvStatusBadge = item.findViewById(R.id.tvDownloadStatusBadge);
            TextView tvTitle = item.findViewById(R.id.tvDownloadTitle);
            TextView tvChannelSize = item.findViewById(R.id.tvDownloadChannelSize);
            View layoutProgress = item.findViewById(R.id.layoutProgressContainer);
            ProgressBar pb = item.findViewById(R.id.pbDownloadProgress);
            TextView tvProgress = item.findViewById(R.id.tvDownloadProgressPercent);
            View btnAction = item.findViewById(R.id.btnDownloadAction);
            ImageView ivAction = item.findViewById(R.id.ivDownloadActionIcon);

            if (ivThumb != null) AsyncThumbnailLoader.load(v.getThumbnailUrl(), ivThumb);
            if (tvDuration != null) tvDuration.setText(v.getDuration());
            if (tvSubject != null) tvSubject.setText(v.getSubject().toUpperCase());
            if (tvStatusBadge != null) {
                tvStatusBadge.setText("• DOWNLOADING");
                tvStatusBadge.setTextColor(Color.parseColor("#38BDF8"));
            }
            if (tvTitle != null) tvTitle.setText(v.getTitle());
            if (tvChannelSize != null) tvChannelSize.setText(v.getChannel());

            if (layoutProgress != null) layoutProgress.setVisibility(View.VISIBLE);
            if (pb != null) {
                pb.setProgress(task.progress);
                if (task.totalBytes <= 0) pb.setIndeterminate(true);
                else pb.setIndeterminate(false);
            }
            if (tvProgress != null) tvProgress.setText(task.statusMessage);

            if (ivAction != null) {
                ivAction.setImageResource(R.drawable.ic_close);
                ivAction.setColorFilter(Color.parseColor("#94A3B8"));
            }
            if (btnAction != null) {
                btnAction.setOnClickListener(view -> {
                    dm.cancelDownload(v.getId());
                    Toast.makeText(YouTubeActivity.this, "Download cancelled", Toast.LENGTH_SHORT).show();
                    loadDownloadedLessonsTab();
                });
            }

            attachTouchShrink(item);
            layoutDownloadsList.addView(item);
        }

        // 2. Render Completed Downloaded Videos
        for (final Class11Video v : downloaded) {
            View item = inflater.inflate(R.layout.item_download_video_entry, layoutDownloadsList, false);

            ImageView ivThumb = item.findViewById(R.id.ivDownloadThumb);
            TextView tvDuration = item.findViewById(R.id.tvDownloadDuration);
            TextView tvSubject = item.findViewById(R.id.tvDownloadSubject);
            TextView tvStatusBadge = item.findViewById(R.id.tvDownloadStatusBadge);
            TextView tvTitle = item.findViewById(R.id.tvDownloadTitle);
            TextView tvChannelSize = item.findViewById(R.id.tvDownloadChannelSize);
            View layoutProgress = item.findViewById(R.id.layoutProgressContainer);
            View btnAction = item.findViewById(R.id.btnDownloadAction);
            ImageView ivAction = item.findViewById(R.id.ivDownloadActionIcon);

            if (ivThumb != null) AsyncThumbnailLoader.load(v.getThumbnailUrl(), ivThumb);
            if (tvDuration != null) tvDuration.setText(v.getDuration());
            if (tvSubject != null) tvSubject.setText(v.getSubject().toUpperCase());
            if (tvStatusBadge != null) {
                tvStatusBadge.setText("• OFFLINE READY");
                tvStatusBadge.setTextColor(Color.parseColor("#34D399"));
            }
            if (tvTitle != null) tvTitle.setText(v.getTitle());

            File localFile = dm.getDownloadedFile(v.getId());
            long size = localFile != null ? localFile.length() : 0;
            File localAudio = dm.getDownloadedAudioFile(v.getId());
            if (localAudio != null && localAudio.exists()) {
                size += localAudio.length();
            }
            if (tvChannelSize != null) {
                tvChannelSize.setText(v.getChannel() + " • " + StudyVideoDownloadManager.formatBytes(size));
            }

            if (layoutProgress != null) layoutProgress.setVisibility(View.GONE);

            if (ivAction != null) {
                ivAction.setImageResource(R.drawable.ic_trash_delete);
                ivAction.setColorFilter(Color.parseColor("#EF4444"));
            }
            if (btnAction != null) {
                btnAction.setOnClickListener(view -> confirmDeleteDownload(v));
            }

            // Click on card plays the video directly from offline storage!
            item.setOnClickListener(view -> playClass11Video(v));

            item.setOnLongClickListener(view -> {
                confirmDeleteDownload(v);
                return true;
            });

            attachTouchShrink(item);
            layoutDownloadsList.addView(item);
        }
    }

    private void confirmDeleteDownload(final Class11Video video) {
        if (isFinishing() || isDestroyed() || video == null) return;
        new AlertDialog.Builder(this)
                .setTitle("Delete Offline Lecture?")
                .setMessage("Remove \"" + video.getTitle() + "\" from device storage?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    StudyVideoDownloadManager.getInstance(YouTubeActivity.this).deleteDownload(video.getId());
                    loadDownloadedLessonsTab();
                    Toast.makeText(YouTubeActivity.this, "Offline download deleted", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showPlayerMoreOptions() {
        if (currentPlayingVideo == null) return;
        final String[] options = {
                "🤖 Ask AI Doubt (Instant Video Explanation)",
                "Add to Upcoming Lessons",
                "Share Focus Lecture Link",
                "View Chapter Overview"
        };
        new AlertDialog.Builder(this)
                .setTitle("Lecture Options")
                .setItems(options, (dialog, which) -> {
                    switch (which) {
                        case 0:
                            showAiDoubtSolverDialog();
                            break;
                        case 1:
                            boolean added = StudyLessonsManager.addUpcomingLesson(YouTubeActivity.this, currentPlayingVideo);
                            Toast.makeText(YouTubeActivity.this, added ? "Added to Upcoming Lessons!" : "Already in Upcoming!", Toast.LENGTH_SHORT).show();
                            loadDynamicLessonsTabs();
                            break;
                        case 2:
                            Intent shareIntent = new Intent(Intent.ACTION_SEND);
                            shareIntent.setType("text/plain");
                            shareIntent.putExtra(Intent.EXTRA_SUBJECT, currentPlayingVideo.getTitle());
                            shareIntent.putExtra(Intent.EXTRA_TEXT, "Watch \"" + currentPlayingVideo.getTitle() + "\" on StudyTube Focus Hub:\nhttps://youtu.be/" + currentPlayingVideo.getId());
                            startActivity(Intent.createChooser(shareIntent, "Share Study Lecture"));
                            break;
                        case 3:
                            new AlertDialog.Builder(YouTubeActivity.this)
                                    .setTitle(currentPlayingVideo.getTitle())
                                    .setMessage("Subject: " + currentPlayingVideo.getSubject() + "\n"
                                            + "Channel: " + currentPlayingVideo.getChannel() + "\n"
                                            + "Duration: " + currentPlayingVideo.getDuration() + "\n\n"
                                            + currentPlayingVideo.getDescription())
                                    .setPositiveButton("OK", null)
                                    .show();
                            break;
                    }
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .show();
    }

    // =========================================================================
    // CUSTOM MEDIA PLAYER (ANDROIDX MEDIA3 EXOPLAYER - NEWPIPE NATIVE)
    // =========================================================================
    private void initCustomMediaPlayer() {
        // Initialize Media3 ExoPlayer
        if (playerViewMedia3 != null) {
            exoPlayer = new ExoPlayer.Builder(this).build();
            playerViewMedia3.setPlayer(exoPlayer);

            exoPlayer.addListener(new Player.Listener() {
                @Override
                public void onPlaybackStateChanged(int playbackState) {
                    if (playbackState == Player.STATE_BUFFERING) {
                        showBufferingLoader();
                    } else if (playbackState == Player.STATE_READY) {
                        hideBufferingLoader();
                        isPlaying = exoPlayer.isPlaying();
                        updatePlayPauseIcon(isPlaying);
                        updateScreenOnState(isPlaying);
                    } else if (playbackState == Player.STATE_ENDED) {
                        isPlaying = false;
                        updatePlayPauseIcon(false);
                        updateScreenOnState(false);
                        if (currentPlayingVideo != null) {
                            StudyLessonsManager.markLessonCompleted(YouTubeActivity.this, currentPlayingVideo);
                            updateStreakUI();
                            loadDynamicLessonsTabs();
                            Toast.makeText(YouTubeActivity.this, "🎉 Lecture Completed! +50 Focus Points!", Toast.LENGTH_LONG).show();
                        }
                    }
                }

                @Override
                public void onIsPlayingChanged(boolean isPlayingNow) {
                    isPlaying = isPlayingNow;
                    updatePlayPauseIcon(isPlayingNow);
                    updateScreenOnState(isPlayingNow);
                }

                @Override
                public void onPlayerError(@NonNull PlaybackException error) {
                    updateScreenOnState(false);
                    if (playerRetryCount < 1 && currentPlayingVideo != null) {
                        playerRetryCount++;
                        showBufferingLoader();
                        MediaStreamResolver.resolveStreamUrl(YouTubeActivity.this, currentPlayingVideo.getId(), new MediaStreamResolver.StreamCallback() {
                            @Override
                            public void onStreamResolved(String streamUrl) {
                                playStreamWithMedia3(streamUrl, 0);
                            }

                            @Override
                            public void onError(String message) {
                                hideBufferingLoader();
                                Toast.makeText(YouTubeActivity.this, message, Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else {
                        hideBufferingLoader();
                        Toast.makeText(YouTubeActivity.this, "Playback error: " + (error != null ? error.getMessage() : "Unknown"), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        // Initialize Player Control Overlay Views
        tvPlayerQualityBadge = findViewById(R.id.tvPlayerQualityBadge);
        btnPlayerPip = findViewById(R.id.btnPlayerPip);
        btnPlayerRotate = findViewById(R.id.btnPlayerRotate);
        btnPlayerSettings = findViewById(R.id.btnPlayerSettings);
        ivPlayerFullscreenIcon = findViewById(R.id.ivPlayerFullscreenIcon);

        playerSeekBar = findViewById(R.id.playerSeekBar);
        tvPlayerCurrentTime = findViewById(R.id.tvPlayerCurrentTime);
        tvPlayerTotalDuration = findViewById(R.id.tvPlayerTotalDuration);

        layoutPlayerSettingsSheet = findViewById(R.id.layoutPlayerSettingsSheet);
        btnSettingsClose = findViewById(R.id.btnSettingsClose);
        btnSheetPip = findViewById(R.id.btnSheetPip);
        btnSheetLandscape = findViewById(R.id.btnSheetLandscape);
        btnSheetFullscreen = findViewById(R.id.btnSheetFullscreen);

        // Animated Neon SeekBar Scrubbing
        if (playerSeekBar != null) {
            playerSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    if (fromUser && exoPlayer != null) {
                        long dur = exoPlayer.getDuration();
                        if (dur > 0) {
                            long targetPos = (dur * progress) / 1000L;
                            if (tvPlayerCurrentTime != null) {
                                tvPlayerCurrentTime.setText(formatTime((int) (targetPos / 1000L)));
                            }
                        }
                    }
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                    isUserSeeking = true;
                    controlsHideHandler.removeCallbacks(hideControlsRunnable);
                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                    if (exoPlayer != null) {
                        long dur = exoPlayer.getDuration();
                        if (dur > 0) {
                            long seekPos = (dur * seekBar.getProgress()) / 1000L;
                            exoPlayer.seekTo(seekPos);

                            long checkpointInterval = 20 * 60 * 1000L;
                            long expectedCheckpoint = (seekPos / checkpointInterval) * checkpointInterval;
                            if (expectedCheckpoint != lastQuizCheckpointMs) {
                                lastQuizCheckpointMs = expectedCheckpoint;
                                prefetchedQuiz = null;
                                prefetchedVideoId = null;
                                hasPrefetchedForCurrentCheckpoint = false;
                                isPrefetchingQuiz = false;
                                checkAndTriggerAdvancePrefetch();
                            }
                        }
                    }
                    isUserSeeking = false;
                    controlsHideHandler.postDelayed(hideControlsRunnable, 3500);
                }
            });
        }

        // Native Player Buttons
        if (btnMinimizePlayer != null) {
            btnMinimizePlayer.setOnClickListener(v -> closeCustomPlayer());
            attachTouchShrink(btnMinimizePlayer);
        }
        if (btnPlayerHeaderClose != null) {
            btnPlayerHeaderClose.setOnClickListener(v -> closeCustomPlayer());
            attachTouchShrink(btnPlayerHeaderClose);
        }

        if (btnPlayerPlayPause != null) {
            btnPlayerPlayPause.setOnClickListener(v -> toggleVideoPlayback());
            attachTouchShrink(btnPlayerPlayPause);
        }

        if (btnPlayerRewind10 != null) {
            btnPlayerRewind10.setOnClickListener(v -> seekVideoRelative(-10));
            attachTouchShrink(btnPlayerRewind10);
        }

        if (btnPlayerForward10 != null) {
            btnPlayerForward10.setOnClickListener(v -> seekVideoRelative(10));
            attachTouchShrink(btnPlayerForward10);
        }

        // Speed & Settings Buttons
        if (btnPlayerSpeed != null) {
            btnPlayerSpeed.setOnClickListener(v -> showPlayerSettingsSheet());
            attachTouchShrink(btnPlayerSpeed);
        }

        if (tvPlayerQualityBadge != null) {
            tvPlayerQualityBadge.setOnClickListener(v -> showPlayerSettingsSheet());
            attachTouchShrink(tvPlayerQualityBadge);
        }

        if (btnPlayerSettings != null) {
            btnPlayerSettings.setOnClickListener(v -> togglePlayerSettingsSheet());
            attachTouchShrink(btnPlayerSettings);
        }

        if (btnSettingsClose != null) {
            btnSettingsClose.setOnClickListener(v -> hidePlayerSettingsSheet());
            attachTouchShrink(btnSettingsClose);
        }

        // Mode Action Buttons: PiP, Rotate, Fullscreen
        if (btnPlayerPip != null) {
            btnPlayerPip.setOnClickListener(v -> enterFloatingPipMode());
            attachTouchShrink(btnPlayerPip);
        }
        if (btnSheetPip != null) {
            btnSheetPip.setOnClickListener(v -> {
                hidePlayerSettingsSheet();
                enterFloatingPipMode();
            });
            attachTouchShrink(btnSheetPip);
        }

        if (btnPlayerRotate != null) {
            btnPlayerRotate.setOnClickListener(v -> toggleLandscapeMode());
            attachTouchShrink(btnPlayerRotate);
        }
        if (btnSheetLandscape != null) {
            btnSheetLandscape.setOnClickListener(v -> {
                hidePlayerSettingsSheet();
                toggleLandscapeMode();
            });
            attachTouchShrink(btnSheetLandscape);
        }

        if (btnPlayerFullscreen != null) {
            btnPlayerFullscreen.setOnClickListener(v -> toggleFullscreenPlayer());
            attachTouchShrink(btnPlayerFullscreen);
        }
        if (btnSheetFullscreen != null) {
            btnSheetFullscreen.setOnClickListener(v -> {
                hidePlayerSettingsSheet();
                toggleFullscreenPlayer();
            });
            attachTouchShrink(btnSheetFullscreen);
        }

        if (layoutVideoContainer != null) {
            layoutVideoContainer.setOnClickListener(v -> togglePlayerControlsOverlay());
        }

        // Wire Up Settings Modal Chips (Speed up to 4.0x & Video Quality)
        setupSettingsSheet();
    }

    private void updateTimeAndSeekBar(long posMs, long durMs) {
        if (tvPlayerCurrentTime != null) {
            tvPlayerCurrentTime.setText(formatTime((int) (posMs / 1000L)));
        }
        if (tvPlayerTotalDuration != null) {
            tvPlayerTotalDuration.setText(durMs > 0 ? formatTime((int) (durMs / 1000L)) : "--:--");
        }
        if (playerSeekBar != null && durMs > 0) {
            int progress = (int) ((posMs * 1000L) / durMs);
            playerSeekBar.setProgress(progress);
            if (exoPlayer != null) {
                long buffered = exoPlayer.getBufferedPosition();
                int secondary = (int) ((buffered * 1000L) / durMs);
                playerSeekBar.setSecondaryProgress(secondary);
            }
        }
    }

    private void updatePlayPauseIcon(boolean playing) {
        if (ivPlayerPlayPauseIcon != null) {
            ivPlayerPlayPauseIcon.setImageResource(playing ? R.drawable.ic_pause : R.drawable.ic_play_arrow);
        }
    }


    private String formatTime(int totalSeconds) {
        int m = totalSeconds / 60;
        int s = totalSeconds % 60;
        return String.format(Locale.getDefault(), "%02d:%02d", m, s);
    }

    public void playClass11Video(final Class11Video video) {
        playClass11VideoWithSeek(video, 0);
    }

    public void playClass11VideoWithSeek(final Class11Video video, final long initialSeekMs) {
        if (video == null) return;
        resetVideoAndQuizSession();
        currentPlayingVideo = video;
        playerRetryCount = 0;
        lastQuizCheckpointMs = (initialSeekMs / (20 * 60 * 1000L)) * (20 * 60 * 1000L);
        isQuizDialogOpen = false;
        checkAndTriggerAdvancePrefetch();

        try {
            if (layoutCustomMediaPlayerOverlay != null) {
                layoutCustomMediaPlayerOverlay.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            }
        } catch (Exception ignored) {}

        // Bind Details
        if (tvPlayerToolbarTitle != null) tvPlayerToolbarTitle.setText(video.getTitle());
        if (tvPlayerSubjectBadge != null) tvPlayerSubjectBadge.setText("CLASS 11 • " + video.getSubject().toUpperCase());
        if (tvPlayerRankTag != null) tvPlayerRankTag.setText(video.getBadge());
        if (tvPlayerVideoTitle != null) tvPlayerVideoTitle.setText(video.getTitle());
        if (tvPlayerChannelName != null) tvPlayerChannelName.setText(video.getChannel());
        if (tvPlayerDuration != null) tvPlayerDuration.setText("• " + video.getDuration());
        if (tvPlayerDescription != null) tvPlayerDescription.setText(video.getDescription());

        // Populate Recommendations
        populatePlayerRecommendations(video);

        // Slide Up Player Overlay
        if (layoutCustomMediaPlayerOverlay != null && layoutCustomMediaPlayerOverlay.getVisibility() != View.VISIBLE) {
            layoutCustomMediaPlayerOverlay.setVisibility(View.VISIBLE);
            layoutCustomMediaPlayerOverlay.setAlpha(0f);
            layoutCustomMediaPlayerOverlay.setTranslationY(dpToPx(60));
            layoutCustomMediaPlayerOverlay.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setDuration(280)
                    .setInterpolator(new DecelerateInterpolator())
                    .start();
        }

        // First-Time Gestures Tutorial (Shown only once)
        if (!StudyLessonsManager.isGestureTutorialShown(this) && layoutGestureTutorialOverlay != null) {
            layoutGestureTutorialOverlay.setVisibility(View.VISIBLE);
            layoutGestureTutorialOverlay.setAlpha(0f);
            layoutGestureTutorialOverlay.animate().alpha(1f).setDuration(250).start();
        }

        // Ensure PlayerView is visible
        if (playerViewMedia3 != null) playerViewMedia3.setVisibility(View.VISIBLE);

        // Check if video is already downloaded locally for instant offline playback
        File localFile = StudyVideoDownloadManager.getInstance(this).getDownloadedFile(video.getId());
        if (localFile != null && localFile.exists() && localFile.length() > 0) {
            hideBufferingLoader();
            playOfflineVideo(video.getId(), localFile, initialSeekMs);
            Toast.makeText(this, "⚡ Playing from offline storage", Toast.LENGTH_SHORT).show();
            return;
        }

        // Show Native Glowing Buffering Loader (No text displayed)
        showBufferingLoader();

        // Resolve Multi-Quality Stream via NewPipe-style MediaStreamResolver
        MediaStreamResolver.resolveMediaStream(this, video.getId(), new MediaStreamResolver.StreamResultCallback() {
            @Override
            public void onStreamsResolved(MediaStreamResolver.MediaStreamResult result) {
                currentMediaResult = result;
                updateAvailableQualityChips(result);

                // Find preferred stream
                MediaStreamResolver.VideoStreamInfo targetStream = null;
                if (currentSelectedQuality != null && !currentSelectedQuality.startsWith("Auto")) {
                    targetStream = result.getStreamForQuality(currentSelectedQuality);
                }
                if (targetStream == null) {
                    targetStream = result.qualityStreams.get("720p");
                    if (targetStream == null) {
                        targetStream = result.bestStream != null ? result.bestStream : result.progressiveStream;
                    }
                }

                if (targetStream != null) {
                    playVideoStream(targetStream, initialSeekMs);
                } else if (result.hlsManifestUrl != null && !result.hlsManifestUrl.isEmpty()) {
                    playStreamWithMedia3(result.hlsManifestUrl, initialSeekMs);
                } else {
                    hideBufferingLoader();
                    Toast.makeText(YouTubeActivity.this, "Stream currently unavailable", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onError(String message) {
                hideBufferingLoader();
                Toast.makeText(YouTubeActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void playVideoStream(MediaStreamResolver.VideoStreamInfo streamInfo, long initialSeekMs) {
        if (exoPlayer == null || streamInfo == null) return;
        if (playerViewMedia3 != null) playerViewMedia3.setVisibility(View.VISIBLE);

        currentVideoStreamInfo = streamInfo;

        try {
            DataSource.Factory httpFactory = new DefaultHttpDataSource.Factory()
                    .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                    .setConnectTimeoutMs(15000)
                    .setReadTimeoutMs(15000);

            MediaSource mediaSource;
            if (streamInfo.isProgressive || streamInfo.audioUrl == null || streamInfo.audioUrl.isEmpty()) {
                mediaSource = new ProgressiveMediaSource.Factory(httpFactory)
                        .createMediaSource(MediaItem.fromUri(streamInfo.videoUrl));
            } else {
                MediaSource videoSource = new ProgressiveMediaSource.Factory(httpFactory)
                        .createMediaSource(MediaItem.fromUri(streamInfo.videoUrl));
                MediaSource audioSource = new ProgressiveMediaSource.Factory(httpFactory)
                        .createMediaSource(MediaItem.fromUri(streamInfo.audioUrl));
                mediaSource = new MergingMediaSource(videoSource, audioSource);
            }

            exoPlayer.setMediaSource(mediaSource);
            exoPlayer.prepare();
            if (initialSeekMs > 0) {
                exoPlayer.seekTo(initialSeekMs);
            }
            exoPlayer.play();

            if (tvPlayerQualityBadge != null) {
                String badgeText = streamInfo.qualityLabel.contains(" ") ? streamInfo.qualityLabel.split(" ")[0] : streamInfo.qualityLabel;
                tvPlayerQualityBadge.setText(badgeText);
            }

            updateQualityChipsUI(streamInfo.qualityLabel);

            timeTrackerHandler.removeCallbacks(timeTrackerRunnable);
            timeTrackerHandler.post(timeTrackerRunnable);
        } catch (Exception e) {
            playStreamWithMedia3(streamInfo.videoUrl, initialSeekMs);
        }
    }

    private void playOfflineVideo(String videoId, File videoFile, long initialSeekMs) {
        if (exoPlayer == null || videoFile == null) return;
        if (playerViewMedia3 != null) playerViewMedia3.setVisibility(View.VISIBLE);

        try {
            File audioFile = StudyVideoDownloadManager.getInstance(this).getDownloadedAudioFile(videoId);
            if (audioFile != null && audioFile.exists() && audioFile.length() > 0) {
                DataSource.Factory fileDataSource = new DefaultDataSource.Factory(this);
                MediaSource videoSource = new ProgressiveMediaSource.Factory(fileDataSource)
                        .createMediaSource(MediaItem.fromUri(Uri.fromFile(videoFile)));
                MediaSource audioSource = new ProgressiveMediaSource.Factory(fileDataSource)
                        .createMediaSource(MediaItem.fromUri(Uri.fromFile(audioFile)));
                exoPlayer.setMediaSource(new MergingMediaSource(videoSource, audioSource));
            } else {
                MediaItem mediaItem = MediaItem.fromUri(Uri.fromFile(videoFile));
                exoPlayer.setMediaItem(mediaItem);
            }

            exoPlayer.prepare();
            if (initialSeekMs > 0) {
                exoPlayer.seekTo(initialSeekMs);
            }
            exoPlayer.play();

            if (tvPlayerQualityBadge != null) {
                tvPlayerQualityBadge.setText("Offline");
            }

            timeTrackerHandler.removeCallbacks(timeTrackerRunnable);
            timeTrackerHandler.post(timeTrackerRunnable);
        } catch (Exception e) {
            playStreamWithMedia3(Uri.fromFile(videoFile).toString(), initialSeekMs);
        }
    }

    private void playStreamWithMedia3(String streamUrl, long initialSeekMs) {
        if (exoPlayer == null) return;
        if (playerViewMedia3 != null) playerViewMedia3.setVisibility(View.VISIBLE);

        MediaItem mediaItem = MediaItem.fromUri(streamUrl);
        exoPlayer.setMediaItem(mediaItem);
        exoPlayer.prepare();
        if (initialSeekMs > 0) {
            exoPlayer.seekTo(initialSeekMs);
        }
        exoPlayer.play();

        timeTrackerHandler.removeCallbacks(timeTrackerRunnable);
        timeTrackerHandler.post(timeTrackerRunnable);
    }

    private void showBufferingLoader() {
        if (layoutPlayerBuffering != null) {
            layoutPlayerBuffering.setVisibility(View.VISIBLE);
            layoutPlayerBuffering.setAlpha(1f);
        }
        if (tvPlayerBufferStatus != null) {
            tvPlayerBufferStatus.setVisibility(View.GONE);
        }
    }

    private void hideBufferingLoader() {
        if (layoutPlayerBuffering != null && layoutPlayerBuffering.getVisibility() == View.VISIBLE) {
            layoutPlayerBuffering.animate()
                    .alpha(0f)
                    .setDuration(250)
                    .withEndAction(() -> layoutPlayerBuffering.setVisibility(View.GONE))
                    .start();
        }
    }

    private void togglePlayerControlsOverlay() {
        if (layoutPlayerControls == null) return;
        if (layoutPlayerControls.getVisibility() == View.VISIBLE) {
            hidePlayerControlsOverlay();
        } else {
            showPlayerControlsOverlay();
        }
    }

    private void showPlayerControlsOverlay() {
        if (layoutPlayerControls == null) return;
        layoutPlayerControls.setVisibility(View.VISIBLE);
        layoutPlayerControls.setAlpha(0f);
        layoutPlayerControls.animate().alpha(1f).setDuration(180).start();

        controlsHideHandler.removeCallbacks(hideControlsRunnable);
        controlsHideHandler.postDelayed(hideControlsRunnable, 3500);
    }

    private void hidePlayerControlsOverlay() {
        if (layoutPlayerControls == null) return;
        controlsHideHandler.removeCallbacks(hideControlsRunnable);
        layoutPlayerControls.animate()
                .alpha(0f)
                .setDuration(180)
                .withEndAction(() -> layoutPlayerControls.setVisibility(View.GONE))
                .start();
    }

    private void toggleVideoPlayback() {
        if (exoPlayer != null) {
            if (exoPlayer.isPlaying()) {
                exoPlayer.pause();
                updatePlayPauseIcon(false);
            } else {
                exoPlayer.play();
                updatePlayPauseIcon(true);
            }
        }
    }

    private void seekVideoRelative(int seconds) {
        if (exoPlayer != null) {
            long target = Math.max(0, exoPlayer.getCurrentPosition() + (seconds * 1000L));
            exoPlayer.seekTo(target);
            Toast.makeText(this, (seconds > 0 ? "+" : "") + seconds + "s", Toast.LENGTH_SHORT).show();
        }
    }

    private void replayVideo() {
        if (exoPlayer != null) {
            exoPlayer.seekTo(0);
            exoPlayer.play();
            showBufferingLoader();
        }
    }

    private void setupSettingsSheet() {
        // Speed Chips from 0.25x to 4.0x
        final int[] speedChipIds = {
                R.id.speed025, R.id.speed050, R.id.speed075, R.id.speed100,
                R.id.speed125, R.id.speed150, R.id.speed175, R.id.speed200,
                R.id.speed250, R.id.speed300, R.id.speed350, R.id.speed400
        };
        final float[] speeds = {
                0.25f, 0.5f, 0.75f, 1.0f,
                1.25f, 1.5f, 1.75f, 2.0f,
                2.5f, 3.0f, 3.5f, 4.0f
        };

        for (int i = 0; i < speedChipIds.length; i++) {
            final int idx = i;
            final TextView chip = findViewById(speedChipIds[i]);
            speedChipViews[i] = chip;
            if (chip != null) {
                highlightChip(chip, Math.abs(speeds[i] - currentPlaybackSpeed) < 0.01f);
                chip.setOnClickListener(v -> setPlaybackSpeed(speeds[idx], chip));
                attachTouchShrink(chip);
            }
        }

        // Quality Chips from Auto (Best) to 144p
        final int[] qualityChipIds = {
                R.id.qualityAuto, R.id.quality1080, R.id.quality720,
                R.id.quality480, R.id.quality360, R.id.quality240, R.id.quality144
        };
        final String[] qualityLabels = {
                "Auto (Best)", "1080p FHD", "720p HD",
                "480p", "360p", "240p", "144p"
        };
        final int[][] qualityResolutions = {
                {Integer.MAX_VALUE, Integer.MAX_VALUE}, // Auto
                {1920, 1080},                          // 1080p
                {1280, 720},                           // 720p
                {854, 480},                            // 480p
                {640, 360},                            // 360p
                {426, 240},                            // 240p
                {256, 144}                             // 144p
        };

        for (int i = 0; i < qualityChipIds.length; i++) {
            final int idx = i;
            final TextView chip = findViewById(qualityChipIds[i]);
            qualityChipViews[i] = chip;
            if (chip != null) {
                highlightChip(chip, qualityLabels[i].equals(currentSelectedQuality));
                chip.setOnClickListener(v -> setVideoQuality(
                        qualityLabels[idx],
                        qualityResolutions[idx][0],
                        qualityResolutions[idx][1],
                        chip
                ));
                attachTouchShrink(chip);
            }
        }
    }

    private void highlightChip(TextView chip, boolean active) {
        if (chip == null) return;
        if (active) {
            chip.setBackgroundResource(R.drawable.bg_chip_neon_active);
            chip.setTextColor(Color.WHITE);
        } else {
            chip.setBackgroundResource(R.drawable.bg_chip_neon);
            chip.setTextColor(Color.parseColor("#94A3B8"));
        }
    }

    private void setPlaybackSpeed(float speed, TextView activeChip) {
        currentPlaybackSpeed = speed;
        if (exoPlayer != null) {
            exoPlayer.setPlaybackParameters(new PlaybackParameters(speed));
        }

        String label = (speed == (long) speed)
                ? String.format(Locale.getDefault(), "%.0fx", speed)
                : String.format(Locale.getDefault(), "%.2fx", speed);

        if (btnPlayerSpeed != null) {
            btnPlayerSpeed.setText(label);
        }

        for (TextView chip : speedChipViews) {
            if (chip != null) {
                highlightChip(chip, chip == activeChip);
            }
        }

        Toast.makeText(this, "Playback Speed: " + label, Toast.LENGTH_SHORT).show();
    }

    private void setVideoQuality(String qualityLabel, int maxWidth, int maxHeight, TextView activeChip) {
        setVideoQuality(qualityLabel, activeChip);
    }

    private void setVideoQuality(String qualityLabel, TextView activeChip) {
        currentSelectedQuality = qualityLabel;

        for (TextView chip : qualityChipViews) {
            if (chip != null) {
                highlightChip(chip, chip == activeChip);
            }
        }

        if (tvPlayerQualityBadge != null) {
            tvPlayerQualityBadge.setText(qualityLabel.contains(" ") ? qualityLabel.split(" ")[0] : qualityLabel);
        }

        if (currentMediaResult == null) {
            Toast.makeText(this, "Quality: " + qualityLabel, Toast.LENGTH_SHORT).show();
            return;
        }

        MediaStreamResolver.VideoStreamInfo targetStream = currentMediaResult.getStreamForQuality(qualityLabel);
        if (targetStream == null) {
            Toast.makeText(this, qualityLabel + " not available for this video", Toast.LENGTH_SHORT).show();
            return;
        }

        if (currentVideoStreamInfo != null && currentVideoStreamInfo.qualityLabel.equalsIgnoreCase(targetStream.qualityLabel)) {
            Toast.makeText(this, "Already playing in " + targetStream.qualityLabel, Toast.LENGTH_SHORT).show();
            return;
        }

        long currentPos = exoPlayer != null ? exoPlayer.getCurrentPosition() : 0;
        boolean wasPlaying = exoPlayer != null && exoPlayer.isPlaying();

        showBufferingLoader();
        playVideoStream(targetStream, currentPos);

        if (wasPlaying && exoPlayer != null) {
            exoPlayer.play();
        }

        Toast.makeText(this, "Switched to " + targetStream.qualityLabel + " ✓", Toast.LENGTH_SHORT).show();
    }

    private void updateQualityChipsUI(String activeQualityLabel) {
        final String[] qualityLabels = {
                "Auto (Best)", "1080p FHD", "720p HD",
                "480p", "360p", "240p", "144p"
        };
        for (int i = 0; i < qualityChipViews.length; i++) {
            TextView chip = qualityChipViews[i];
            if (chip != null) {
                boolean isActive = qualityLabels[i].equalsIgnoreCase(activeQualityLabel)
                        || (activeQualityLabel != null && activeQualityLabel.contains(qualityLabels[i].split(" ")[0]))
                        || (activeQualityLabel != null && qualityLabels[i].contains(activeQualityLabel.split(" ")[0]));
                highlightChip(chip, isActive);
            }
        }
    }

    private void updateAvailableQualityChips(MediaStreamResolver.MediaStreamResult result) {
        if (result == null) return;
        final String[] keys = {"Auto", "1080p", "720p", "480p", "360p", "240p", "144p"};
        for (int i = 0; i < qualityChipViews.length; i++) {
            TextView chip = qualityChipViews[i];
            if (chip == null) continue;
            if (i == 0) {
                chip.setEnabled(true);
                chip.setAlpha(1.0f);
            } else {
                boolean avail = result.qualityStreams.containsKey(keys[i]);
                chip.setEnabled(avail);
                chip.setAlpha(avail ? 1.0f : 0.35f);
            }
        }
    }

    private void showPlayerSettingsSheet() {
        if (layoutPlayerSettingsSheet == null) return;
        layoutPlayerSettingsSheet.setVisibility(View.VISIBLE);
        layoutPlayerSettingsSheet.setTranslationY(dpToPx(380));
        layoutPlayerSettingsSheet.animate()
                .translationY(0f)
                .setDuration(260)
                .setInterpolator(new DecelerateInterpolator())
                .start();
    }

    private void hidePlayerSettingsSheet() {
        if (layoutPlayerSettingsSheet == null || layoutPlayerSettingsSheet.getVisibility() != View.VISIBLE) return;
        layoutPlayerSettingsSheet.animate()
                .translationY(dpToPx(380))
                .setDuration(220)
                .withEndAction(() -> layoutPlayerSettingsSheet.setVisibility(View.GONE))
                .start();
    }

    private void togglePlayerSettingsSheet() {
        if (layoutPlayerSettingsSheet == null) return;
        if (layoutPlayerSettingsSheet.getVisibility() == View.VISIBLE) {
            hidePlayerSettingsSheet();
        } else {
            showPlayerSettingsSheet();
        }
    }

    // ==========================================
    // MULTI-TASKING MODES: PIP, LANDSCAPE, FULL
    // ==========================================

    private void enterFloatingPipMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                hidePlayerSettingsSheet();
                hidePlayerControlsOverlay();
                Rational rational = new Rational(16, 9);
                PictureInPictureParams.Builder pipBuilder = new PictureInPictureParams.Builder();
                pipBuilder.setAspectRatio(rational);
                enterPictureInPictureMode(pipBuilder.build());
            } catch (Exception e) {
                Toast.makeText(this, "Picture-in-Picture error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Picture-in-Picture requires Android 8.0+", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode, Configuration newConfig) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig);
        if (isInPictureInPictureMode) {
            if (layoutPlayerControls != null) layoutPlayerControls.setVisibility(View.GONE);
            if (layoutPlayerSettingsSheet != null) layoutPlayerSettingsSheet.setVisibility(View.GONE);
            if (scrollPlayerDetails != null) scrollPlayerDetails.setVisibility(View.GONE);

            View topBar = findViewById(R.id.youtubeTopBar);
            View navDock = findViewById(R.id.layoutBottomNavDock);
            if (topBar != null) topBar.setVisibility(View.GONE);
            if (navDock != null) navDock.setVisibility(View.GONE);

            if (layoutVideoContainer != null) {
                layoutVideoContainer.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
                layoutVideoContainer.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
                layoutVideoContainer.requestLayout();
            }
        } else {
            View topBar = findViewById(R.id.youtubeTopBar);
            View navDock = findViewById(R.id.layoutBottomNavDock);
            if (topBar != null) topBar.setVisibility(View.VISIBLE);
            if (navDock != null) navDock.setVisibility(View.VISIBLE);
            applyOrientationLayout(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE);
        }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (exoPlayer != null && exoPlayer.isPlaying() && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            enterFloatingPipMode();
        }
    }

    private void toggleLandscapeMode() {
        int currentOrientation = getResources().getConfiguration().orientation;
        if (currentOrientation == Configuration.ORIENTATION_LANDSCAPE) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        }
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        boolean isLandscape = newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE;
        applyOrientationLayout(isLandscape);
    }

    private void applyOrientationLayout(boolean isLandscape) {
        isLandscapeMode = isLandscape;
        if (layoutVideoContainer == null) return;

        View topBar = findViewById(R.id.youtubeTopBar);
        View navDock = findViewById(R.id.layoutBottomNavDock);

        if (isLandscape) {
            if (topBar != null) topBar.setVisibility(View.GONE);
            if (navDock != null) navDock.setVisibility(View.GONE);
            if (scrollPlayerDetails != null) scrollPlayerDetails.setVisibility(View.GONE);

            layoutVideoContainer.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
            layoutVideoContainer.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
            layoutVideoContainer.requestLayout();

            setImmersiveFullscreen(true);
        } else {
            if (!isFullscreenMode) {
                if (topBar != null) topBar.setVisibility(View.VISIBLE);
                if (navDock != null) navDock.setVisibility(View.VISIBLE);
                if (scrollPlayerDetails != null) scrollPlayerDetails.setVisibility(View.VISIBLE);

                layoutVideoContainer.getLayoutParams().height = (int) dpToPx(225);
                layoutVideoContainer.getLayoutParams().width = ViewGroup.LayoutParams.MATCH_PARENT;
                layoutVideoContainer.requestLayout();

                setImmersiveFullscreen(false);
            }
        }
    }

    private void setImmersiveFullscreen(boolean immersive) {
        View decor = getWindow().getDecorView();
        if (immersive) {
            decor.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            );
        } else {
            decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        }
    }

    private void toggleFullscreenPlayer() {
        if (layoutVideoContainer == null) return;
        isFullscreenMode = !isFullscreenMode;

        if (isFullscreenMode) {
            layoutVideoContainer.getLayoutParams().height = ViewGroup.LayoutParams.MATCH_PARENT;
            if (scrollPlayerDetails != null) scrollPlayerDetails.setVisibility(View.GONE);
            setImmersiveFullscreen(true);
            if (ivPlayerFullscreenIcon != null) {
                ivPlayerFullscreenIcon.setImageResource(R.drawable.ic_close);
            }
            Toast.makeText(this, "Fullscreen Mode", Toast.LENGTH_SHORT).show();
        } else {
            if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            }
            layoutVideoContainer.getLayoutParams().height = (int) dpToPx(225);
            if (scrollPlayerDetails != null) scrollPlayerDetails.setVisibility(View.VISIBLE);
            setImmersiveFullscreen(false);
            if (ivPlayerFullscreenIcon != null) {
                ivPlayerFullscreenIcon.setImageResource(R.drawable.ic_player_fullscreen);
            }
        }
        layoutVideoContainer.requestLayout();
    }

    private void populatePlayerRecommendations(final Class11Video current) {
        if (layoutPlayerRecommendations == null) return;
        layoutPlayerRecommendations.removeAllViews();

        LayoutInflater inflater = LayoutInflater.from(this);
        List<Class11Video> all = Class11VideoRepository.getAllVideos();
        int count = 0;

        for (final Class11Video v : all) {
            if (v.getId().equals(current.getId())) continue;
            if (count >= 5) break;

            View itemView = inflater.inflate(R.layout.item_class11_video, layoutPlayerRecommendations, false);

            ImageView ivThumbnail = itemView.findViewById(R.id.ivItemThumbnail);
            TextView tvRankBadge = itemView.findViewById(R.id.tvItemRankBadge);
            TextView tvDuration = itemView.findViewById(R.id.tvItemDuration);
            TextView tvSubject = itemView.findViewById(R.id.tvItemSubject);
            TextView tvTitle = itemView.findViewById(R.id.tvItemTitle);
            TextView tvChannel = itemView.findViewById(R.id.tvItemChannel);
            TextView tvDescription = itemView.findViewById(R.id.tvItemDescription);

            if (ivThumbnail != null) AsyncThumbnailLoader.load(v.getThumbnailUrl(), ivThumbnail);
            if (tvRankBadge != null) tvRankBadge.setText(v.getBadge());
            if (tvDuration != null) tvDuration.setText(v.getDuration());
            if (tvSubject != null) tvSubject.setText(v.getSubject().toUpperCase() + " 11");
            if (tvTitle != null) tvTitle.setText(v.getTitle());
            if (tvChannel != null) tvChannel.setText(v.getChannel());
            if (tvDescription != null) tvDescription.setText(v.getDescription());

            itemView.setOnClickListener(view -> playClass11Video(v));
            attachTouchShrink(itemView);

            layoutPlayerRecommendations.addView(itemView);
            count++;
        }
    }

    /**
     * Completely resets active video and quiz session state.
     * Closes open quiz dialogs and cleans prefetch state so switching videos
     * or closing the player leaves zero stale quiz state.
     */
    private void resetVideoAndQuizSession() {
        if (activeQuizDialog != null && activeQuizDialog.isShowing()) {
            try {
                activeQuizDialog.dismiss();
            } catch (Exception ignored) {}
        }
        activeQuizDialog = null;
        isQuizDialogOpen = false;
        prefetchedQuiz = null;
        isPrefetchedAiGenerated = false;
        isPrefetchingQuiz = false;
        hasPrefetchedForCurrentCheckpoint = false;
        isWaitingForPrefetchToTriggerQuiz = false;
        prefetchedVideoId = null;
        prefetchedForCheckpointMs = 0;
        lastQuizCheckpointMs = 0;
        watchTickCounter = 0;
    }

    private void closeCustomPlayer() {
        if (exoPlayer != null) {
            exoPlayer.stop();
            exoPlayer.clearMediaItems();
        }
        updateScreenOnState(false);
        timeTrackerHandler.removeCallbacks(timeTrackerRunnable);
        hideBufferingLoader();
        hidePlayerSettingsSheet();
        resetVideoAndQuizSession();
        currentPlayingVideo = null;

        if (isFullscreenMode) {
            toggleFullscreenPlayer();
        }
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }

        if (layoutCustomMediaPlayerOverlay != null) {
            layoutCustomMediaPlayerOverlay.animate()
                    .alpha(0f)
                    .translationY(dpToPx(60))
                    .setDuration(220)
                    .withEndAction(() -> layoutCustomMediaPlayerOverlay.setVisibility(View.GONE))
                    .start();
        }
    }

    private void handleBackAction() {
        if (dynamicIslandController != null && dynamicIslandController.isExpanded()) {
            dynamicIslandController.collapseIsland();
            return;
        }
        if (layoutPlayerSettingsSheet != null && layoutPlayerSettingsSheet.getVisibility() == View.VISIBLE) {
            hidePlayerSettingsSheet();
            return;
        }
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            return;
        }
        if (isFullscreenMode) {
            toggleFullscreenPlayer();
            return;
        }
        if (layoutCustomMediaPlayerOverlay != null && layoutCustomMediaPlayerOverlay.getVisibility() == View.VISIBLE) {
            closeCustomPlayer();
            return;
        }
        if (currentTab != 2) {
            switchTab(2);
            return;
        }
        finishWithZoomTransition();
    }

    private void animateEntrance() {
        View topBar = findViewById(R.id.youtubeTopBar);
        View dock = findViewById(R.id.layoutBottomNavDock);

        if (topBar != null) {
            topBar.setAlpha(0f);
            topBar.setTranslationY(-dpToPx(20));
            topBar.animate().alpha(1f).translationY(0f).setDuration(360).start();
        }

        if (dock != null) {
            dock.setAlpha(0f);
            dock.setTranslationY(dpToPx(40));
            dock.animate().alpha(1f).translationY(0f).setDuration(400).setInterpolator(new OvershootInterpolator(1.2f)).start();
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private void attachTouchShrink(final View v) {
        if (v == null) return;
        v.setHapticFeedbackEnabled(false);
        v.setOnTouchListener((view, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                view.animate().scaleX(0.95f).scaleY(0.95f).setDuration(100).start();
            } else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                view.animate().scaleX(1.0f).scaleY(1.0f).setDuration(140).start();
            }
            return false;
        });
    }

    // =========================================================================
    // PLAYER GESTURES: DOUBLE TAP SEEK, HUD BRIGHTNESS/VOLUME, SCRUB & 2X BOOST
    // =========================================================================
    @SuppressLint("ClickableViewAccessibility")
    private void setupPlayerGestures() {
        final AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                togglePlayerControlsOverlay();
                return true;
            }

            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (layoutVideoContainer == null) return false;
                int width = layoutVideoContainer.getWidth();
                float x = e.getX();

                if (x < width * 0.40f) {
                    seekVideoRelative(-10);
                    showDoubleTapOverlay(layoutDoubleTapRewindOverlay);
                    return true;
                } else if (x > width * 0.60f) {
                    seekVideoRelative(10);
                    showDoubleTapOverlay(layoutDoubleTapForwardOverlay);
                    return true;
                } else {
                    toggleVideoPlayback();
                    return true;
                }
            }

            @Override
            public void onLongPress(MotionEvent e) {
                if (exoPlayer != null && layoutVideoContainer != null) {
                    try { layoutVideoContainer.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); } catch (Exception ignored) {}
                    isSpeedBoostActive = true;
                    exoPlayer.setPlaybackParameters(new PlaybackParameters(2.0f));
                    if (layoutGestureSpeedBadge != null) {
                        layoutGestureSpeedBadge.setVisibility(View.VISIBLE);
                        layoutGestureSpeedBadge.setAlpha(1f);
                    }
                }
            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                if (e1 == null || e2 == null || layoutVideoContainer == null) return false;

                int width = layoutVideoContainer.getWidth();
                int height = layoutVideoContainer.getHeight();
                float startX = e1.getX();
                float diffX = e2.getX() - e1.getX();
                float diffY = e2.getY() - e1.getY();

                // Predominantly Horizontal Swipe -> Precise Scrubbing Preview
                if (Math.abs(diffX) > Math.abs(diffY) * 1.3f && Math.abs(diffX) > 20) {
                    if (exoPlayer != null && exoPlayer.getDuration() > 0) {
                        isScrubbingActive = true;
                        long dur = exoPlayer.getDuration();
                        if (scrubStartPositionMs == 0) {
                            scrubStartPositionMs = exoPlayer.getCurrentPosition();
                        }
                        float deltaRatio = diffX / (float) width;
                        long deltaMs = (long) (deltaRatio * Math.min(dur, 180000L));
                        scrubTargetPositionMs = Math.max(0, Math.min(dur, scrubStartPositionMs + deltaMs));

                        int deltaSec = (int) (deltaMs / 1000L);
                        String previewStr = formatTime((int) (scrubTargetPositionMs / 1000L)) + " / "
                                + formatTime((int) (dur / 1000L))
                                + " [ " + (deltaSec >= 0 ? "+" : "") + deltaSec + "s ]";

                        if (tvGestureSeekPreview != null) tvGestureSeekPreview.setText(previewStr);
                        if (layoutGestureSeekHud != null) layoutGestureSeekHud.setVisibility(View.VISIBLE);
                    }
                    return true;
                }

                // Predominantly Vertical Swipe
                if (Math.abs(diffY) > 20) {
                    // Left Edge -> Brightness HUD
                    if (startX < width * 0.35f) {
                        WindowManager.LayoutParams lp = getWindow().getAttributes();
                        float currentBrightness = lp.screenBrightness;
                        if (currentBrightness < 0) currentBrightness = 0.5f;

                        float deltaBrightness = (distanceY / (float) height);
                        float newBrightness = Math.max(0.01f, Math.min(1.0f, currentBrightness + deltaBrightness));
                        lp.screenBrightness = newBrightness;
                        getWindow().setAttributes(lp);

                        int pct = (int) (newBrightness * 100);
                        if (tvBrightnessPercent != null) tvBrightnessPercent.setText(pct + "%");
                        if (pbBrightnessLevel != null) pbBrightnessLevel.setProgress(pct);
                        if (layoutGestureBrightnessHud != null) layoutGestureBrightnessHud.setVisibility(View.VISIBLE);

                        scheduleHideGestureHuds();
                        return true;
                    }

                    // Right Edge -> Volume HUD
                    if (startX > width * 0.65f && audioManager != null) {
                        int maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                        int direction = distanceY > 0 ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER;
                        audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, 0);

                        int updatedVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
                        int pct = (updatedVol * 100) / Math.max(1, maxVol);
                        if (tvVolumePercent != null) tvVolumePercent.setText(pct + "%");
                        if (pbVolumeLevel != null) pbVolumeLevel.setProgress(pct);
                        if (layoutGestureVolumeHud != null) layoutGestureVolumeHud.setVisibility(View.VISIBLE);

                        scheduleHideGestureHuds();
                        return true;
                    }

                    // Center Vertical Swipe -> Fullscreen Toggle
                    if (startX >= width * 0.35f && startX <= width * 0.65f) {
                        if (distanceY > 40 && !isFullscreenMode) {
                            toggleFullscreenPlayer();
                            return true;
                        } else if (distanceY < -40 && isFullscreenMode) {
                            toggleFullscreenPlayer();
                            return true;
                        }
                    }
                }

                return false;
            }
        });

        if (layoutVideoContainer != null) {
            layoutVideoContainer.setOnTouchListener((v, event) -> {
                boolean handled = gestureDetector.onTouchEvent(event);

                if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                    // Revert 2.0x speed boost on release
                    if (isSpeedBoostActive) {
                        isSpeedBoostActive = false;
                        if (exoPlayer != null) {
                            exoPlayer.setPlaybackParameters(new PlaybackParameters(currentPlaybackSpeed));
                        }
                        if (layoutGestureSpeedBadge != null) {
                            layoutGestureSpeedBadge.setVisibility(View.GONE);
                        }
                    }

                    // Apply Scrubbing on release
                    if (isScrubbingActive) {
                        isScrubbingActive = false;
                        if (exoPlayer != null && scrubTargetPositionMs > 0) {
                            exoPlayer.seekTo(scrubTargetPositionMs);
                        }
                        scrubStartPositionMs = 0;
                        scrubTargetPositionMs = 0;
                        if (layoutGestureSeekHud != null) {
                            layoutGestureSeekHud.setVisibility(View.GONE);
                        }
                    }

                    scheduleHideGestureHuds();
                }

                return handled || true;
            });
        }

        // Gestures Tutorial Dismissal
        if (btnDismissGestureTutorial != null) {
            btnDismissGestureTutorial.setOnClickListener(v -> dismissGesturesTutorial());
        }
        if (layoutGestureTutorialOverlay != null) {
            layoutGestureTutorialOverlay.setOnClickListener(v -> dismissGesturesTutorial());
        }
    }

    private void dismissGesturesTutorial() {
        if (layoutGestureTutorialOverlay != null && layoutGestureTutorialOverlay.getVisibility() == View.VISIBLE) {
            layoutGestureTutorialOverlay.animate()
                    .alpha(0f)
                    .setDuration(200)
                    .withEndAction(() -> layoutGestureTutorialOverlay.setVisibility(View.GONE))
                    .start();
            StudyLessonsManager.setGestureTutorialShown(this, true);
        }
    }

    private void showDoubleTapOverlay(final View overlay) {
        if (overlay == null) return;
        overlay.setVisibility(View.VISIBLE);
        overlay.setAlpha(1f);
        overlay.animate()
                .alpha(0f)
                .setDuration(450)
                .withEndAction(() -> overlay.setVisibility(View.GONE))
                .start();
    }

    private void scheduleHideGestureHuds() {
        gestureHudHandler.removeCallbacks(hideGestureHudsRunnable);
        gestureHudHandler.postDelayed(hideGestureHudsRunnable, 1200);
    }

    private void hideAllGestureHuds() {
        if (layoutGestureBrightnessHud != null && layoutGestureBrightnessHud.getVisibility() == View.VISIBLE) {
            layoutGestureBrightnessHud.animate().alpha(0f).setDuration(200).withEndAction(() -> layoutGestureBrightnessHud.setVisibility(View.GONE)).start();
        }
        if (layoutGestureVolumeHud != null && layoutGestureVolumeHud.getVisibility() == View.VISIBLE) {
            layoutGestureVolumeHud.animate().alpha(0f).setDuration(200).withEndAction(() -> layoutGestureVolumeHud.setVisibility(View.GONE)).start();
        }
        if (layoutGestureSeekHud != null && layoutGestureSeekHud.getVisibility() == View.VISIBLE) {
            layoutGestureSeekHud.setVisibility(View.GONE);
        }
    }

    // =========================================================================
    // AUTO ORIENTATION SENSOR (FULLSCREEN AUTO ROTATION)
    // =========================================================================
    private void setupOrientationListener() {
        orientationEventListener = new OrientationEventListener(this) {
            @Override
            public void onOrientationChanged(int orientation) {
                if (orientation == ORIENTATION_UNKNOWN) return;

                if (isFullscreenMode || (layoutCustomMediaPlayerOverlay != null && layoutCustomMediaPlayerOverlay.getVisibility() == View.VISIBLE)) {
                    if ((orientation >= 70 && orientation <= 110) || (orientation >= 250 && orientation <= 290)) {
                        if (getResources().getConfiguration().orientation != Configuration.ORIENTATION_LANDSCAPE) {
                            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
                        }
                    } else if ((orientation >= 340 || orientation <= 20) || (orientation >= 160 && orientation <= 200)) {
                        if (getResources().getConfiguration().orientation != Configuration.ORIENTATION_PORTRAIT && !isFullscreenMode) {
                            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                        }
                    }
                }
            }
        };

        if (orientationEventListener.canDetectOrientation()) {
            orientationEventListener.enable();
        }
    }

    @Override
    public void onBackPressed() {
        handleBackAction();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isInPictureInPictureMode()) {
            return;
        }
        if (exoPlayer != null && exoPlayer.isPlaying()) {
            exoPlayer.pause();
            updatePlayPauseIcon(false);
        }
        updateScreenOnState(false);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isInPictureInPictureMode()) {
            return;
        }
        if (exoPlayer != null && exoPlayer.isPlaying()) {
            exoPlayer.pause();
            updatePlayPauseIcon(false);
        }
        updateScreenOnState(false);
    }

    @Override
    protected void onDestroy() {
        updateScreenOnState(false);
        StudyVideoDownloadManager.getInstance(this).removeListener(downloadListener);
        if (orientationEventListener != null) {
            orientationEventListener.disable();
            orientationEventListener = null;
        }
        gestureHudHandler.removeCallbacksAndMessages(null);
        resumePromptHandler.removeCallbacksAndMessages(null);
        timeTrackerHandler.removeCallbacks(timeTrackerRunnable);
        resetVideoAndQuizSession();
        currentPlayingVideo = null;
        if (exoPlayer != null) {
            exoPlayer.release();
            exoPlayer = null;
        }
        if (dynamicIslandController != null) {
            dynamicIslandController.onDestroy();
            dynamicIslandController = null;
        }
        super.onDestroy();
    }

    /**
     * Controls keeping the display awake / screen on during active video playback.
     * Prevents screen from turning off or locking while lecture is playing.
     */
    private void updateScreenOnState(boolean isPlayingNow) {
        try {
            if (isPlayingNow) {
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                if (playerViewMedia3 != null) {
                    playerViewMedia3.setKeepScreenOn(true);
                }
            } else {
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                if (playerViewMedia3 != null) {
                    playerViewMedia3.setKeepScreenOn(false);
                }
            }
        } catch (Exception ignored) {}
    }

    private final StudyVideoDownloadManager.DownloadListener downloadListener = new StudyVideoDownloadManager.DownloadListener() {
        @Override
        public void onDownloadProgress(String videoId, int progress, long bytesDownloaded, long totalBytes) {
            if (currentTab == 4) {
                loadDownloadedLessonsTab();
            }
        }

        @Override
        public void onDownloadCompleted(String videoId, File file) {
            loadDownloadedLessonsTab();
        }

        @Override
        public void onDownloadFailed(String videoId, String error) {
            loadDownloadedLessonsTab();
        }

        @Override
        public void onDownloadsChanged() {
            loadDownloadedLessonsTab();
        }
    };

    // =========================================================================
    // 20-MINUTE AI KNOWLEDGE CHECKPOINT & DOUBT SOLVER ENGINE
    // =========================================================================

    private void loadQuizSectionTab() {
        if (layoutQuizList == null || layoutQuizEmpty == null) return;
        List<StudyQuizManager.SavedQuizRecord> quizzes = StudyQuizManager.getAllQuizzes(this);
        StudyQuizManager.QuizStats stats = StudyQuizManager.getQuizStats(this);

        layoutQuizList.removeAllViews();

        if (quizzes.isEmpty()) {
            layoutQuizEmpty.setVisibility(View.VISIBLE);
            if (layoutQuizStatsCard != null) layoutQuizStatsCard.setVisibility(View.GONE);
            layoutQuizList.setVisibility(View.GONE);
            return;
        }

        layoutQuizEmpty.setVisibility(View.GONE);
        if (layoutQuizStatsCard != null) layoutQuizStatsCard.setVisibility(View.VISIBLE);
        layoutQuizList.setVisibility(View.VISIBLE);

        if (tvQuizTotalCount != null) {
            tvQuizTotalCount.setText(String.valueOf(stats.totalQuizzes));
        }
        if (tvQuizPassRate != null) {
            tvQuizPassRate.setText(stats.getPassRatePercent() + "%");
        }
        if (tvQuizAvgScore != null) {
            tvQuizAvgScore.setText(String.format(Locale.US, "%.1f", stats.averageScore));
        }

        LayoutInflater inflater = LayoutInflater.from(this);
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MMM dd, h:mm a", Locale.getDefault());

        for (final StudyQuizManager.SavedQuizRecord quiz : quizzes) {
            View card = inflater.inflate(R.layout.item_saved_quiz_card, layoutQuizList, false);

            TextView tvSubject = card.findViewById(R.id.tvSavedQuizSubject);
            TextView tvDate = card.findViewById(R.id.tvSavedQuizDate);
            TextView tvStatus = card.findViewById(R.id.tvSavedQuizStatusBadge);
            TextView tvTitle = card.findViewById(R.id.tvSavedQuizTitle);
            TextView tvScoreDetail = card.findViewById(R.id.tvSavedQuizScoreDetail);
            View btnReview = card.findViewById(R.id.btnReviewQuizQuestions);
            View btnReattempt = card.findViewById(R.id.btnReattemptQuiz);
            View btnDelete = card.findViewById(R.id.btnDeleteQuiz);

            if (tvSubject != null) tvSubject.setText(quiz.subject != null ? quiz.subject.toUpperCase() : "GENERAL");
            if (tvDate != null) tvDate.setText(sdf.format(new java.util.Date(quiz.timestamp)));
            if (tvTitle != null) tvTitle.setText(quiz.videoTitle);

            if (tvStatus != null) {
                if (quiz.passed) {
                    tvStatus.setText(quiz.score + " / " + quiz.totalQuestions + " • PASSED ✓");
                    tvStatus.setBackgroundResource(R.drawable.bg_permission_pill_granted);
                    tvStatus.setTextColor(Color.parseColor("#34D399"));
                } else {
                    tvStatus.setText(quiz.score + " / " + quiz.totalQuestions + (quiz.penaltyCharged ? " • FAILED (-20m)" : " • FAILED (0 Penalty)"));
                    tvStatus.setBackgroundResource(R.drawable.bg_quiz_option_wrong);
                    tvStatus.setTextColor(Color.parseColor("#F87171"));
                }
            }

            if (tvScoreDetail != null) {
                int pct = (int) Math.round(((double) quiz.score / quiz.totalQuestions) * 100);
                tvScoreDetail.setText("Score: " + quiz.score + "/" + quiz.totalQuestions + " (" + pct + "%)" + (quiz.passed ? " • Mastered" : " • Review needed"));
            }

            if (btnReview != null) {
                btnReview.setOnClickListener(v -> showReviewQuizDialog(quiz));
                attachTouchShrink(btnReview);
            }

            if (btnReattempt != null) {
                btnReattempt.setOnClickListener(v -> startReattemptQuiz(quiz));
                attachTouchShrink(btnReattempt);
            }

            if (btnDelete != null) {
                btnDelete.setOnClickListener(v -> confirmDeleteQuiz(quiz));
                attachTouchShrink(btnDelete);
            }

            layoutQuizList.addView(card);
        }
    }

    private void showReviewQuizDialog(final StudyQuizManager.SavedQuizRecord quiz) {
        if (quiz == null || quiz.questions == null) return;
        try {
            Dialog dialog = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
            dialog.setContentView(R.layout.dialog_review_quiz_questions);

            TextView tvTitle = dialog.findViewById(R.id.tvReviewVideoTitle);
            TextView tvScoreBadge = dialog.findViewById(R.id.tvReviewScoreBadge);
            ImageView btnClose = dialog.findViewById(R.id.btnCloseReview);
            LinearLayout list = dialog.findViewById(R.id.layoutReviewQuestionsList);

            if (tvTitle != null) tvTitle.setText(quiz.videoTitle);
            if (tvScoreBadge != null) {
                int pct = (int) Math.round(((double) quiz.score / quiz.totalQuestions) * 100);
                if (quiz.passed) {
                    tvScoreBadge.setText("Score: " + quiz.score + " / " + quiz.totalQuestions + " (" + pct + "%) • PASSED ✓");
                    tvScoreBadge.setTextColor(Color.parseColor("#34D399"));
                } else {
                    tvScoreBadge.setText("Score: " + quiz.score + " / " + quiz.totalQuestions + " (" + pct + "%) • FAILED (-20m)");
                    tvScoreBadge.setTextColor(Color.parseColor("#F87171"));
                }
            }

            if (btnClose != null) {
                btnClose.setOnClickListener(v -> dialog.dismiss());
            }

            if (list != null) {
                for (int i = 0; i < quiz.questions.size(); i++) {
                    StudyQuizManager.QuizQuestion q = quiz.questions.get(i);
                    LinearLayout item = new LinearLayout(this);
                    item.setOrientation(LinearLayout.VERTICAL);
                    item.setBackgroundResource(R.drawable.bg_permission_card);
                    item.setPadding((int) dpToPx(16), (int) dpToPx(14), (int) dpToPx(16), (int) dpToPx(14));
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    lp.setMargins(0, 0, 0, (int) dpToPx(14));
                    item.setLayoutParams(lp);

                    // Question Header
                    TextView tvQ = new TextView(this);
                    tvQ.setText("Q" + (i + 1) + ". " + q.question);
                    tvQ.setTextColor(Color.WHITE);
                    tvQ.setTextSize(14.5f);
                    tvQ.setTypeface(null, android.graphics.Typeface.BOLD);
                    item.addView(tvQ);

                    // 4 Options
                    for (int optIdx = 0; optIdx < q.options.size(); optIdx++) {
                        String optText = q.options.get(optIdx);
                        TextView tvOpt = new TextView(this);
                        char letter = (char) ('A' + optIdx);
                        tvOpt.setText(letter + ". " + optText);
                        tvOpt.setTextSize(13f);
                        tvOpt.setPadding((int) dpToPx(12), (int) dpToPx(8), (int) dpToPx(12), (int) dpToPx(8));
                        LinearLayout.LayoutParams optLp = new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        optLp.setMargins(0, (int) dpToPx(6), 0, 0);
                        tvOpt.setLayoutParams(optLp);

                        if (optIdx == q.correctIndex) {
                            tvOpt.setBackgroundResource(R.drawable.bg_quiz_option_correct);
                            tvOpt.setTextColor(Color.parseColor("#34D399"));
                            tvOpt.setText(letter + ". " + optText + "  ✓ (Correct)");
                        } else if (optIdx == q.userSelectedIndex && q.userSelectedIndex != q.correctIndex) {
                            tvOpt.setBackgroundResource(R.drawable.bg_quiz_option_wrong);
                            tvOpt.setTextColor(Color.parseColor("#F87171"));
                            tvOpt.setText(letter + ". " + optText + "  ✗ (Your Choice)");
                        } else {
                            tvOpt.setBackgroundResource(R.drawable.bg_quiz_option_normal);
                            tvOpt.setTextColor(Color.parseColor("#CBD5E1"));
                        }
                        item.addView(tvOpt);
                    }

                    // Explanation
                    if (q.explanation != null && !q.explanation.isEmpty()) {
                        TextView tvExp = new TextView(this);
                        tvExp.setText("💡 " + q.explanation);
                        tvExp.setTextColor(Color.parseColor("#38BDF8"));
                        tvExp.setTextSize(12f);
                        tvExp.setPadding(0, (int) dpToPx(8), 0, 0);
                        item.addView(tvExp);
                    }

                    list.addView(item);
                }
            }

            dialog.show();
        } catch (Exception e) {
            Log.e("YouTubeActivity", "Failed to show review dialog", e);
        }
    }

    // =========================================================================
    // ADVANCE PRE-GENERATED VIDEO QUIZ ENGINE (ZERO OUTSIDE QUESTIONS)
    // =========================================================================

    private void checkAndTriggerAdvancePrefetch() {
        if (currentPlayingVideo == null || isQuizDialogOpen || isPrefetchingQuiz) return;
        long checkpointInterval = 20 * 60 * 1000L;
        long nextCheckpointMs = lastQuizCheckpointMs + checkpointInterval;

        if (!hasPrefetchedForCurrentCheckpoint && prefetchedQuiz == null) {
            hasPrefetchedForCurrentCheckpoint = true;
            prefetchCheckpointQuizInAdvance(nextCheckpointMs);
        }
    }

    private void prefetchCheckpointQuizInAdvance(final long targetCheckpointMs) {
        if (currentPlayingVideo == null || isPrefetchingQuiz) return;
        final String targetVideoId = currentPlayingVideo.getId();
        final String targetTitle = currentPlayingVideo.getTitle();
        final String targetSubject = currentPlayingVideo.getSubject();

        isPrefetchingQuiz = true;
        prefetchedQuiz = null;
        isPrefetchedAiGenerated = false;
        prefetchedVideoId = targetVideoId;
        prefetchedForCheckpointMs = targetCheckpointMs;

        Log.d("YouTubeActivity", "⚡ Starting advance pre-generation of quiz for: " + targetTitle + " (" + targetVideoId + ") target checkpoint: " + targetCheckpointMs);

        YouTubeExtractor.extractTranscriptAsync(targetVideoId, "en", new YouTubeExtractor.Callback<Transcript>() {
            @Override
            public void onSuccess(Transcript result) {
                if (currentPlayingVideo == null || !targetVideoId.equals(currentPlayingVideo.getId())) {
                    isPrefetchingQuiz = false;
                    return;
                }

                StringBuilder transcriptBuilder = new StringBuilder();
                if (result != null && result.getSegments() != null) {
                    for (TranscriptSegment seg : result.getSegments()) {
                        if (seg.getStartMs() <= targetCheckpointMs) {
                            transcriptBuilder.append(seg.getText()).append(" ");
                        }
                    }
                }

                String transcriptText = transcriptBuilder.toString().trim();
                if (transcriptText.length() < 60) {
                    Log.w("YouTubeActivity", "Insufficient transcript content for " + targetVideoId + ". Quiz will not be loaded.");
                    isPrefetchingQuiz = false;
                    prefetchedQuiz = null;
                    prefetchedVideoId = null;
                    return;
                }

                executeBackgroundQuizGeneration(transcriptText, targetVideoId, targetTitle, targetSubject, targetCheckpointMs);
            }

            @Override
            public void onError(ExtractionResult error) {
                if (currentPlayingVideo == null || !targetVideoId.equals(currentPlayingVideo.getId())) {
                    isPrefetchingQuiz = false;
                    return;
                }
                Log.w("YouTubeActivity", "Transcript extraction failed for " + targetVideoId + ": " + error + ". Checkpoint quiz will be skipped if not loaded.");
                isPrefetchingQuiz = false;
                prefetchedQuiz = null;
                prefetchedVideoId = null;
            }
        });
    }

    private void executeBackgroundQuizGeneration(String transcriptText, final String targetVideoId, final String targetTitle, final String targetSubject, final long targetCheckpointMs) {
        if (currentPlayingVideo == null || !targetVideoId.equals(currentPlayingVideo.getId())) {
            isPrefetchingQuiz = false;
            return;
        }

        GeminiAiManager.generateCheckpointQuiz(this,
                targetTitle,
                targetSubject,
                transcriptText,
                new GeminiAiManager.QuizCallback() {
                    @Override
                    public void onQuizReady(List<StudyQuizManager.QuizQuestion> questions, boolean isAiGenerated) {
                        handlePrefetchComplete(questions, isAiGenerated, targetVideoId, targetCheckpointMs);
                    }

                    @Override
                    public void onError(String errorMessage) {
                        Log.w("YouTubeActivity", "Video-specific AI Quiz generation failed for " + targetVideoId + ": " + errorMessage);
                        // Rule: Zero questions from outside the video. Never fall back to curated generic science questions!
                        isPrefetchingQuiz = false;
                        prefetchedQuiz = null;
                        prefetchedVideoId = null;
                    }
                });
    }

    private void handlePrefetchComplete(List<StudyQuizManager.QuizQuestion> questions, boolean isAiGenerated, String targetVideoId, long targetCheckpointMs) {
        isPrefetchingQuiz = false;
        // Verify user is still watching the same video
        if (currentPlayingVideo == null || !targetVideoId.equals(currentPlayingVideo.getId())) {
            Log.d("YouTubeActivity", "Discarded preloaded quiz because video changed.");
            prefetchedQuiz = null;
            prefetchedVideoId = null;
            return;
        }

        if (questions == null || questions.isEmpty()) {
            prefetchedQuiz = null;
            prefetchedVideoId = null;
            return;
        }

        prefetchedQuiz = questions;
        isPrefetchedAiGenerated = isAiGenerated;
        prefetchedVideoId = targetVideoId;
        prefetchedForCheckpointMs = targetCheckpointMs;
        Log.d("YouTubeActivity", "✅ Video quiz pre-generated and stored in memory! Video: " + targetVideoId + ", Count: " + questions.size());
    }

    private void trigger20MinCheckpointQuiz(final long targetCheckpointMs) {
        if (currentPlayingVideo == null || isQuizDialogOpen) return;

        // Verify that the preloaded quiz strictly matches the active video
        boolean isQuizReadyForThisVideo = prefetchedQuiz != null
                && !prefetchedQuiz.isEmpty()
                && prefetchedVideoId != null
                && prefetchedVideoId.equals(currentPlayingVideo.getId());

        if (isQuizReadyForThisVideo) {
            // Case 1: Quiz was preloaded and ready in advance!
            isQuizDialogOpen = true;
            if (exoPlayer != null && exoPlayer.isPlaying()) {
                exoPlayer.pause();
                updatePlayPauseIcon(false);
            }

            List<StudyQuizManager.QuizQuestion> questionsToDeliver = new ArrayList<>(prefetchedQuiz);
            boolean aiGen = isPrefetchedAiGenerated;

            // Clear buffer
            prefetchedQuiz = null;
            prefetchedVideoId = null;
            isPrefetchedAiGenerated = false;
            hasPrefetchedForCurrentCheckpoint = false;

            Toast.makeText(this, "🧠 20-Min Checkpoint Reached! Video Quiz Ready.", Toast.LENGTH_SHORT).show();
            showCheckpointQuizDialog(questionsToDeliver, targetCheckpointMs, aiGen, false);
            return;
        }

        // Case 2: Quiz was NOT loaded (failed, no transcript, or API error)
        // User Requirement: "agar load nahi hua to skip ho jana chaiyea"
        // Skip checkpoint without interrupting video playback or showing irrelevant outside questions!
        Log.w("YouTubeActivity", "20-Min Checkpoint: Quiz not loaded for video " + currentPlayingVideo.getId() + ". Skipping checkpoint.");

        lastQuizCheckpointMs = targetCheckpointMs;
        hasPrefetchedForCurrentCheckpoint = false;
        isPrefetchingQuiz = false;
        prefetchedQuiz = null;
        prefetchedVideoId = null;

        Toast.makeText(this, "⏭️ 20-Min Checkpoint: Quiz not loaded, skipping.", Toast.LENGTH_SHORT).show();

        // Immediately start prefetching for next checkpoint
        checkAndTriggerAdvancePrefetch();
    }

    private void showCheckpointQuizDialog(final List<StudyQuizManager.QuizQuestion> questions,
                                          final long triggerPosMs,
                                          final boolean isAiGenerated) {
        showCheckpointQuizDialog(questions, triggerPosMs, isAiGenerated, false);
    }

    private void showCheckpointQuizDialog(final List<StudyQuizManager.QuizQuestion> questions,
                                          final long triggerPosMs,
                                          final boolean isAiGenerated,
                                          final boolean isReattempt) {
        if (questions == null || questions.isEmpty()) {
            isQuizDialogOpen = false;
            if (exoPlayer != null && !isReattempt) exoPlayer.play();
            return;
        }

        try {
            Dialog dialog = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
            dialog.setContentView(R.layout.dialog_ai_video_quiz);
            dialog.setCancelable(false);
            activeQuizDialog = dialog;

            dialog.setOnDismissListener(d -> {
                if (activeQuizDialog == dialog) {
                    activeQuizDialog = null;
                }
                isQuizDialogOpen = false;
            });

            TextView tvQuizVideoTitle = dialog.findViewById(R.id.tvQuizVideoTitle);
            TextView tvQuizModeNote = dialog.findViewById(R.id.tvQuizModeNote);
            ImageView btnCloseQuizDialog = dialog.findViewById(R.id.btnCloseQuizDialog);
            TextView tvQuestionNumber = dialog.findViewById(R.id.tvQuestionNumber);
            TextView tvAnsweredTracker = dialog.findViewById(R.id.tvAnsweredTracker);
            ProgressBar pbQuizProgress = dialog.findViewById(R.id.pbQuizProgress);
            TextView tvQuestionText = dialog.findViewById(R.id.tvQuestionText);

            LinearLayout layoutOpt0 = dialog.findViewById(R.id.layoutOption0);
            LinearLayout layoutOpt1 = dialog.findViewById(R.id.layoutOption1);
            LinearLayout layoutOpt2 = dialog.findViewById(R.id.layoutOption2);
            LinearLayout layoutOpt3 = dialog.findViewById(R.id.layoutOption3);
            LinearLayout[] optContainers = new LinearLayout[]{layoutOpt0, layoutOpt1, layoutOpt2, layoutOpt3};

            TextView tvBadge0 = dialog.findViewById(R.id.tvBadgeOpt0);
            TextView tvBadge1 = dialog.findViewById(R.id.tvBadgeOpt1);
            TextView tvBadge2 = dialog.findViewById(R.id.tvBadgeOpt2);
            TextView tvBadge3 = dialog.findViewById(R.id.tvBadgeOpt3);
            TextView[] optBadges = new TextView[]{tvBadge0, tvBadge1, tvBadge2, tvBadge3};

            TextView tvText0 = dialog.findViewById(R.id.tvTextOpt0);
            TextView tvText1 = dialog.findViewById(R.id.tvTextOpt1);
            TextView tvText2 = dialog.findViewById(R.id.tvTextOpt2);
            TextView tvText3 = dialog.findViewById(R.id.tvTextOpt3);
            TextView[] optTexts = new TextView[]{tvText0, tvText1, tvText2, tvText3};

            AppCompatButton btnPrev = dialog.findViewById(R.id.btnQuizPrev);
            AppCompatButton btnNext = dialog.findViewById(R.id.btnQuizNext);
            AppCompatButton btnSubmit = dialog.findViewById(R.id.btnSubmitQuiz);

            if (tvQuizVideoTitle != null) {
                if (isReattempt) {
                    tvQuizVideoTitle.setText("Re-attempt Practice Session");
                } else if (currentPlayingVideo != null) {
                    tvQuizVideoTitle.setText(currentPlayingVideo.getTitle());
                }
            }
            TextView tvQuizTargetBadge = dialog.findViewById(R.id.tvQuizTargetBadge);
            if (tvQuizTargetBadge != null) {
                if (isReattempt) {
                    tvQuizTargetBadge.setText("🎯 PRACTICE: 15 / 20 (75%)");
                } else if (!isDeepMode) {
                    tvQuizTargetBadge.setText("🎯 SIMPLE MODE: NO REWIND");
                } else {
                    tvQuizTargetBadge.setText("🎯 TARGET: 15 / 20 (75%)");
                }
            }

            if (tvQuizModeNote != null) {
                if (isReattempt) {
                    tvQuizModeNote.setText("Zero Penalty");
                } else if (!isDeepMode) {
                    tvQuizModeNote.setText("Skip / Rewind Free");
                } else {
                    tvQuizModeNote.setText(isAiGenerated ? "⚡ Gemini AI (Max 5 Wrong)" : "📚 Syllabus (Max 5 Wrong)");
                }
            }

            if (btnCloseQuizDialog != null) {
                if (isReattempt) {
                    btnCloseQuizDialog.setVisibility(View.VISIBLE);
                    btnCloseQuizDialog.setOnClickListener(v -> dialog.dismiss());
                } else {
                    btnCloseQuizDialog.setVisibility(View.GONE);
                }
            }

            View btnSkipQuiz = dialog.findViewById(R.id.btnSkipQuiz);
            View btnSkipQuizBottom = dialog.findViewById(R.id.btnSkipQuizBottom);

            View.OnClickListener skipClickListener = v -> {
                isQuizDialogOpen = false;
                prefetchedQuiz = null;
                isPrefetchedAiGenerated = false;
                isPrefetchingQuiz = false;
                hasPrefetchedForCurrentCheckpoint = false;
                isWaitingForPrefetchToTriggerQuiz = false;
                prefetchedVideoId = null;
                prefetchedForCheckpointMs = 0;
                lastQuizCheckpointMs = triggerPosMs;

                dialog.dismiss();
                if (exoPlayer != null) {
                    exoPlayer.play();
                    updatePlayPauseIcon(true);
                }
                Toast.makeText(YouTubeActivity.this, "Checkpoint skipped ⏩", Toast.LENGTH_SHORT).show();
                checkAndTriggerAdvancePrefetch();
            };

            if (btnSkipQuiz != null) {
                if (!isDeepMode && !isReattempt) {
                    btnSkipQuiz.setVisibility(View.VISIBLE);
                    btnSkipQuiz.setOnClickListener(skipClickListener);
                } else {
                    btnSkipQuiz.setVisibility(View.GONE);
                }
            }

            if (btnSkipQuizBottom != null) {
                if (!isDeepMode && !isReattempt) {
                    btnSkipQuizBottom.setVisibility(View.VISIBLE);
                    btnSkipQuizBottom.setOnClickListener(skipClickListener);
                } else {
                    btnSkipQuizBottom.setVisibility(View.GONE);
                }
            }

            final int[] currentIndex = new int[]{0};

            // Question Display Render Function
            Runnable renderQuestion = new Runnable() {
                @Override
                public void run() {
                    int qIdx = currentIndex[0];
                    StudyQuizManager.QuizQuestion q = questions.get(qIdx);

                    if (tvQuestionNumber != null) {
                        tvQuestionNumber.setText("Question " + (qIdx + 1) + " of " + questions.size());
                    }
                    if (pbQuizProgress != null) {
                        pbQuizProgress.setProgress(qIdx + 1);
                    }
                    if (tvQuestionText != null) {
                        tvQuestionText.setText(q.question);
                    }

                    // Count answered questions
                    int answeredCount = 0;
                    for (StudyQuizManager.QuizQuestion item : questions) {
                        if (item.userSelectedIndex >= 0) answeredCount++;
                    }
                    if (tvAnsweredTracker != null) {
                        tvAnsweredTracker.setText(answeredCount + "/" + questions.size() + " Answered");
                    }
                    if (btnSubmit != null) {
                        btnSubmit.setText((isReattempt ? "SUBMIT RE-ATTEMPT (" : "SUBMIT CHECKPOINT QUIZ (") + answeredCount + "/" + questions.size() + ")");
                    }

                    // Render options
                    for (int i = 0; i < 4; i++) {
                        LinearLayout container = optContainers[i];
                        TextView badge = optBadges[i];
                        TextView text = optTexts[i];

                        if (container != null && text != null) {
                            if (i < q.options.size()) {
                                container.setVisibility(View.VISIBLE);
                                text.setText(q.options.get(i));

                                if (q.userSelectedIndex == i) {
                                    container.setBackgroundResource(R.drawable.bg_quiz_option_selected);
                                    if (badge != null) badge.setTextColor(Color.parseColor("#A78BFA"));
                                } else {
                                    container.setBackgroundResource(R.drawable.bg_quiz_option_normal);
                                    if (badge != null) badge.setTextColor(Color.parseColor("#38BDF8"));
                                }
                            } else {
                                container.setVisibility(View.GONE);
                            }
                        }
                    }

                    if (btnPrev != null) {
                        btnPrev.setEnabled(qIdx > 0);
                        btnPrev.setAlpha(qIdx > 0 ? 1.0f : 0.4f);
                    }
                    if (btnNext != null) {
                        btnNext.setEnabled(qIdx < questions.size() - 1);
                        btnNext.setAlpha(qIdx < questions.size() - 1 ? 1.0f : 0.4f);
                    }
                }
            };

            // Wire option taps
            for (int i = 0; i < 4; i++) {
                final int optIndex = i;
                LinearLayout container = optContainers[i];
                if (container != null) {
                    container.setOnClickListener(v -> {
                        try { v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); } catch (Exception ignored) {}
                        questions.get(currentIndex[0]).userSelectedIndex = optIndex;
                        renderQuestion.run();
                    });
                }
            }

            if (btnPrev != null) {
                btnPrev.setOnClickListener(v -> {
                    if (currentIndex[0] > 0) {
                        currentIndex[0]--;
                        renderQuestion.run();
                    }
                });
            }

            if (btnNext != null) {
                btnNext.setOnClickListener(v -> {
                    if (currentIndex[0] < questions.size() - 1) {
                        currentIndex[0]++;
                        renderQuestion.run();
                    }
                });
            }

            if (btnSubmit != null) {
                btnSubmit.setOnClickListener(v -> {
                    try { v.performHapticFeedback(HapticFeedbackConstants.CONFIRM); } catch (Exception ignored) {}

                    // Compute score
                    int correctCount = 0;
                    for (StudyQuizManager.QuizQuestion q : questions) {
                        if (q.userSelectedIndex == q.correctIndex) {
                            correctCount++;
                        }
                    }

                    // Pass threshold: 70%+ correct
                    int totalQ = questions.size();
                    int passRequired = Math.max(1, (int) Math.ceil(totalQ * 0.70));
                    boolean passed = correctCount >= passRequired;

                    // Save to persistent storage
                    StudyQuizManager.SavedQuizRecord record = new StudyQuizManager.SavedQuizRecord();
                    record.videoId = currentPlayingVideo != null ? currentPlayingVideo.getId() : "";
                    record.videoTitle = currentPlayingVideo != null ? currentPlayingVideo.getTitle() : (isReattempt ? "Re-attempt Practice Quiz" : "Lecture Video");
                    record.subject = currentPlayingVideo != null ? currentPlayingVideo.getSubject() : "Science";
                    record.score = correctCount;
                    record.totalQuestions = questions.size();
                    record.passed = passed;
                    // Zero penalty for re-attempt AND zero penalty for Simple Mode!
                    record.penaltyCharged = (isDeepMode && !isReattempt && !passed);
                    record.questions = new ArrayList<>(questions);
                    StudyQuizManager.saveQuiz(YouTubeActivity.this, record);

                    loadQuizSectionTab();
                    dialog.dismiss();

                    if (isReattempt) {
                        // Re-attempt outcome: zero penalty, zero rewind!
                        new AlertDialog.Builder(YouTubeActivity.this)
                                .setTitle(passed ? "🏆 Practice Passed! (" + correctCount + "/" + totalQ + ")" : "🎯 Practice Completed (" + correctCount + "/" + totalQ + ")")
                                .setMessage("You scored " + correctCount + " out of " + totalQ + " (" + (int) Math.round(((double) correctCount / totalQ) * 100) + "%).\n\n"
                                        + (passed ? "Excellent! You have mastered these concepts." : "Keep practicing to achieve " + passRequired + "/" + totalQ + "+!")
                                        + "\n\n(No timer deduction or video rewind applied in Re-attempt mode)")
                                .setPositiveButton("DONE", null)
                                .show();
                        return;
                    }

                    // ========================================================
                    // 1. SIMPLE MODE OUTCOME: ZERO REWIND, ZERO TIMER PENALTY!
                    // ========================================================
                    if (!isDeepMode) {
                        String title = passed ? "🏆 Checkpoint Passed! (" + correctCount + "/" + totalQ + ")" : "🎯 Checkpoint Finished (" + correctCount + "/" + totalQ + ")";
                        String message = passed
                                ? "Great job! You scored " + correctCount + " out of " + totalQ + " (70%+).\n\nLecture video playback has been resumed."
                                : "You scored " + correctCount + " out of " + totalQ + ".\n\n"
                                + "• Simple Mode active: Zero video rewind and zero penalty!\n"
                                + "• Review concepts at your own pace.\n\n"
                                + "Lecture video playback has been resumed.";

                        new AlertDialog.Builder(YouTubeActivity.this)
                                .setTitle(title)
                                .setMessage(message)
                                .setPositiveButton("CONTINUE LECTURE", (d, w) -> {
                                    lastQuizCheckpointMs = triggerPosMs;
                                    isQuizDialogOpen = false;
                                    prefetchedQuiz = null;
                                    hasPrefetchedForCurrentCheckpoint = false;
                                    if (exoPlayer != null) {
                                        exoPlayer.play();
                                        updatePlayPauseIcon(true);
                                    }
                                    checkAndTriggerAdvancePrefetch();
                                })
                                .setCancelable(false)
                                .show();
                        return;
                    }

                    // ========================================================
                    // 2. DEEP MODE OUTCOME: STRICT FOCUS ENFORCEMENT
                    // ========================================================
                    if (passed) {
                        // Checkpoint Passed in Deep Mode (70%+)
                        new AlertDialog.Builder(YouTubeActivity.this)
                                .setTitle("🏆 Checkpoint Cleared! (" + correctCount + "/" + totalQ + ")")
                                .setMessage("Outstanding mastery! You scored " + correctCount + " out of " + totalQ + " (70%+).\n\nLecture video playback has been resumed.")
                                .setPositiveButton("CONTINUE LECTURE", (d, w) -> {
                                    lastQuizCheckpointMs = triggerPosMs;
                                    isQuizDialogOpen = false;
                                    prefetchedQuiz = null;
                                    hasPrefetchedForCurrentCheckpoint = false;
                                    if (exoPlayer != null) {
                                        exoPlayer.play();
                                        updatePlayPauseIcon(true);
                                    }
                                    checkAndTriggerAdvancePrefetch();
                                })
                                .setCancelable(false)
                                .show();
                    } else {
                        // Checkpoint Failed in Deep Mode (<70%)
                        long rewindTarget = Math.max(0, triggerPosMs - 20 * 60 * 1000L);
                        // Bug fix: Wipe prefetch cache so when reaching 20m again, a fresh quiz is generated
                        prefetchedQuiz = null;
                        isPrefetchedAiGenerated = false;
                        isPrefetchingQuiz = false;
                        hasPrefetchedForCurrentCheckpoint = false;
                        isWaitingForPrefetchToTriggerQuiz = false;
                        prefetchedVideoId = null;
                        prefetchedForCheckpointMs = 0;

                        new AlertDialog.Builder(YouTubeActivity.this)
                                .setTitle("❌ Checkpoint Failed (" + correctCount + "/" + totalQ + ")")
                                .setMessage(passRequired + " out of " + totalQ + " correct answers (70%+) are required to proceed in Deep Mode.\n\n"
                                        + "• Video rewound 20 minutes to re-learn concepts.\n"
                                        + "• 15-minute penalty charged to Study Focus Timer.\n"
                                        + "• A fresh quiz will be generated at the next checkpoint!\n\n"
                                        + "Focus on the lecture explanation to master the topic!")
                                .setPositiveButton("RE-WATCH & STUDY", (d, w) -> {
                                    if (exoPlayer != null) {
                                        exoPlayer.seekTo(rewindTarget);
                                        exoPlayer.play();
                                        updatePlayPauseIcon(true);
                                    }
                                    lastQuizCheckpointMs = rewindTarget;
                                    isQuizDialogOpen = false;
                                    StudySessionActivity.applySessionTimerPenalty(15 * 60);
                                    checkAndTriggerAdvancePrefetch();
                                })
                                .setCancelable(false)
                                .show();
                    }
                });
            }

            renderQuestion.run();
            dialog.show();

        } catch (Exception e) {
            Log.e("YouTubeActivity", "Error showing checkpoint dialog", e);
            isQuizDialogOpen = false;
            if (exoPlayer != null && !isReattempt) exoPlayer.play();
        }
    }

    private void confirmDeleteQuiz(final StudyQuizManager.SavedQuizRecord quiz) {
        if (quiz == null || isFinishing() || isDestroyed()) return;
        new AlertDialog.Builder(this)
                .setTitle("Delete Quiz Record?")
                .setMessage("Remove this quiz result (" + quiz.score + "/" + quiz.totalQuestions + ") from your saved quizzes?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    boolean deleted = StudyQuizManager.deleteQuiz(YouTubeActivity.this, quiz.id);
                    if (deleted) {
                        Toast.makeText(YouTubeActivity.this, "Quiz record deleted ✓", Toast.LENGTH_SHORT).show();
                        loadQuizSectionTab();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void startReattemptQuiz(final StudyQuizManager.SavedQuizRecord quiz) {
        if (quiz == null || quiz.questions == null || quiz.questions.isEmpty()) {
            Toast.makeText(this, "Quiz questions not found.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Clone questions with reset user selection, and shuffle question order for fresh challenge
        List<StudyQuizManager.QuizQuestion> reattemptList = new ArrayList<>();
        for (StudyQuizManager.QuizQuestion orig : quiz.questions) {
            StudyQuizManager.QuizQuestion cloned = new StudyQuizManager.QuizQuestion();
            cloned.question = orig.question;
            cloned.options = new ArrayList<>(orig.options);
            cloned.correctIndex = orig.correctIndex;
            cloned.explanation = orig.explanation;
            cloned.userSelectedIndex = -1; // Reset user choice
            reattemptList.add(cloned);
        }

        Collections.shuffle(reattemptList);

        Toast.makeText(this, "🎯 Re-attempting Quiz (Zero Penalty Mode)", Toast.LENGTH_SHORT).show();
        showCheckpointQuizDialog(reattemptList, 0, true, true);
    }

    private void showAiDoubtSolverDialog() {
        if (currentPlayingVideo == null) {
            Toast.makeText(this, "Start playing a video to ask AI doubts.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            BottomSheetDialog dialog = new BottomSheetDialog(this);
            View view = getLayoutInflater().inflate(R.layout.dialog_ai_doubt_solver, null);

            TextView tvContext = view.findViewById(R.id.tvDoubtContext);
            ImageView btnClose = view.findViewById(R.id.btnCloseDoubt);
            TextView chipExplain = view.findViewById(R.id.chipDoubtExplain);
            TextView chipFormula = view.findViewById(R.id.chipDoubtFormula);
            TextView chipSummarize = view.findViewById(R.id.chipDoubtSummarize);
            TextView chipExample = view.findViewById(R.id.chipDoubtExample);
            TextView tvAnswer = view.findViewById(R.id.tvDoubtAnswer);
            View pbLoading = view.findViewById(R.id.pbDoubtLoading);
            TextView btnCopy = view.findViewById(R.id.btnCopyDoubtAnswer);
            EditText etQuestion = view.findViewById(R.id.etDoubtQuestion);
            AppCompatButton btnSend = view.findViewById(R.id.btnSendDoubt);

            final long currentPos = exoPlayer != null ? exoPlayer.getCurrentPosition() : 0;
            final int posSec = (int) (currentPos / 1000L);
            String timeFormatted = formatTime(posSec);

            if (tvContext != null) {
                tvContext.setText(currentPlayingVideo.getTitle() + " • " + timeFormatted);
            }

            if (btnClose != null) {
                btnClose.setOnClickListener(v -> dialog.dismiss());
            }

            // Function to ask Gemini
            final Runnable[] askDoubtRef = new Runnable[1];
            askDoubtRef[0] = new Runnable() {
                @Override
                public void run() {
                    String query = etQuestion != null ? etQuestion.getText().toString().trim() : "";
                    if (query.isEmpty()) {
                        Toast.makeText(YouTubeActivity.this, "Please enter your question", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (pbLoading != null) pbLoading.setVisibility(View.VISIBLE);
                    if (btnSend != null) btnSend.setEnabled(false);

                    GeminiAiManager.askLectureDoubt(YouTubeActivity.this,
                            currentPlayingVideo.getTitle(),
                            currentPlayingVideo.getSubject(),
                            currentPos,
                            "",
                            query,
                            new GeminiAiManager.DoubtCallback() {
                                @Override
                                public void onAnswerReceived(String answer) {
                                    if (pbLoading != null) pbLoading.setVisibility(View.GONE);
                                    if (btnSend != null) btnSend.setEnabled(true);
                                    if (tvAnswer != null) tvAnswer.setText(answer);
                                }

                                @Override
                                public void onError(String errorMessage) {
                                    if (pbLoading != null) pbLoading.setVisibility(View.GONE);
                                    if (btnSend != null) btnSend.setEnabled(true);
                                    if (tvAnswer != null) tvAnswer.setText("⚠️ " + errorMessage);
                                }
                            });
                }
            };

            if (btnSend != null) {
                btnSend.setOnClickListener(v -> askDoubtRef[0].run());
            }

            // Quick chip handlers
            View.OnClickListener chipListener = v -> {
                if (etQuestion != null && v instanceof TextView) {
                    etQuestion.setText(((TextView) v).getText().toString());
                    askDoubtRef[0].run();
                }
            };
            if (chipExplain != null) chipExplain.setOnClickListener(chipListener);
            if (chipFormula != null) chipFormula.setOnClickListener(chipListener);
            if (chipSummarize != null) chipSummarize.setOnClickListener(chipListener);
            if (chipExample != null) chipExample.setOnClickListener(chipListener);

            if (btnCopy != null) {
                btnCopy.setOnClickListener(v -> {
                    if (tvAnswer != null) {
                        android.content.ClipboardManager clipboard =
                                (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        android.content.ClipData clip = android.content.ClipData.newPlainText("AI Explanation", tvAnswer.getText());
                        if (clipboard != null) clipboard.setPrimaryClip(clip);
                        Toast.makeText(YouTubeActivity.this, "Copied explanation to clipboard!", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            dialog.setContentView(view);
            dialog.show();

        } catch (Exception e) {
            Log.e("YouTubeActivity", "Failed to show AI doubt solver", e);
        }
    }

    private void finishWithZoomTransition() {
        finish();
        overridePendingTransition(R.anim.zoom_out_enter, R.anim.zoom_out_exit);
    }

    private float dpToPx(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }
}
