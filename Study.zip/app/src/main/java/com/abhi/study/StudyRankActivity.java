package com.abhi.study;

import android.annotation.SuppressLint;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.HapticFeedbackConstants;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.widget.NestedScrollView;

/**
 * StudyRankActivity:
 * Dedicated Full Screen StudyTube Rank Progression Page.
 * Showcases all 10 Ranks connected along a continuous Rank Push line track with real-time
 * 60fps animated flames, dynamic tier hero centerpiece, live watch time progress,
 * and lock/unlock visual states.
 */
public class StudyRankActivity extends AppCompatActivity {

    private FrameLayout btnRankBack;
    private TextView tvTopBarPoints;
    private NestedScrollView scrollRankContent;

    // Hero Centerpiece Views
    private StudyRankFireView ivHeroFire;
    private TextView tvHeroTitle;
    private TextView tvHeroSubtitle;
    private TextView tvHeroWatchTime;
    private TextView tvHeroPoints;
    private TextView tvHeroStreakDays;
    private TextView tvHeroProgressLabel;
    private TextView tvHeroProgressText;
    private ProgressBar pbHeroProgress;

    // Line Track Container
    private LinearLayout layoutRankTrackContainer;
    private AppCompatButton btnContinueStudy;

    private int userRankLevel = 1;
    private View activeTierNodeView = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        makeFullScreenImmersive();
        setContentView(R.layout.activity_study_rank);

        initViews();
        loadAndDisplayRankData();
        setupBackPressed();
    }

    private void makeFullScreenImmersive() {
        try {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                window.setNavigationBarColor(Color.TRANSPARENT);
            }
            int uiOptions = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            window.getDecorView().setSystemUiVisibility(uiOptions);
        } catch (Exception ignored) {
        }
    }

    private void initViews() {
        btnRankBack = findViewById(R.id.btnRankBack);
        tvTopBarPoints = findViewById(R.id.tvTopBarPoints);
        scrollRankContent = findViewById(R.id.scrollRankContent);

        ivHeroFire = findViewById(R.id.ivHeroFire);
        tvHeroTitle = findViewById(R.id.tvHeroTitle);
        tvHeroSubtitle = findViewById(R.id.tvHeroSubtitle);
        tvHeroWatchTime = findViewById(R.id.tvHeroWatchTime);
        tvHeroPoints = findViewById(R.id.tvHeroPoints);
        tvHeroStreakDays = findViewById(R.id.tvHeroStreakDays);
        tvHeroProgressLabel = findViewById(R.id.tvHeroProgressLabel);
        tvHeroProgressText = findViewById(R.id.tvHeroProgressText);
        pbHeroProgress = findViewById(R.id.pbHeroProgress);

        layoutRankTrackContainer = findViewById(R.id.layoutRankTrackContainer);
        btnContinueStudy = findViewById(R.id.btnContinueStudy);

        if (btnRankBack != null) {
            btnRankBack.setOnClickListener(v -> finishWithAnimation());
            attachTouchShrink(btnRankBack);
        }

        if (btnContinueStudy != null) {
            btnContinueStudy.setOnClickListener(v -> {
                Toast.makeText(this, "Keep watching lectures to push your rank! 🚀", Toast.LENGTH_SHORT).show();
                finishWithAnimation();
            });
            attachTouchShrink(btnContinueStudy);
        }
    }

    private void loadAndDisplayRankData() {
        userRankLevel = StudyLessonsManager.getFireRankLevel(this);
        int points = StudyLessonsManager.getStreakPoints(this);
        int streakDays = StudyLessonsManager.getStreakDays(this);
        String totalWatch = StudyLessonsManager.getFormattedTotalWatchTime(this);
        String nextRankTime = StudyLessonsManager.getWatchTimeToNextRankFormatted(this);
        int progressPct = StudyLessonsManager.getRankProgressPercent(this);

        if (tvTopBarPoints != null) {
            tvTopBarPoints.setText("⭐ " + points + " PTS");
        }

        // Setup Hero Centerpiece with user's current rank
        updateHeroPreview(userRankLevel, true);

        if (tvHeroWatchTime != null) {
            tvHeroWatchTime.setText("⏱ " + totalWatch + " Watched");
        }
        if (tvHeroPoints != null) {
            tvHeroPoints.setText("⭐ " + points + " PTS");
        }
        if (tvHeroStreakDays != null) {
            tvHeroStreakDays.setText("🔥 " + streakDays + " Day Streak");
        }

        // Build Connected Line Track (Level 1 to Level 10)
        buildRankTrackLine(userRankLevel, nextRankTime);
    }

    private void updateHeroPreview(int tierLevel, boolean isUserCurrent) {
        String title = StudyLessonsManager.getRankTitle(tierLevel);
        String subtitle = StudyLessonsManager.getRankSubtitle(tierLevel);
        boolean isUnlocked = (userRankLevel >= tierLevel);

        if (ivHeroFire != null) {
            ivHeroFire.setRankLevel(tierLevel);
            ivHeroFire.setLocked(!isUnlocked);
            ivHeroFire.triggerSurge();
        }

        if (tvHeroTitle != null) {
            tvHeroTitle.setText(title);
            if (ivHeroFire != null) {
                tvHeroTitle.setTextColor(ivHeroFire.getRankScoreColor());
            }
        }

        if (tvHeroSubtitle != null) {
            tvHeroSubtitle.setText(subtitle + " • Level " + tierLevel + " of 10");
        }

        if (isUserCurrent) {
            int progressPct = StudyLessonsManager.getRankProgressPercent(this);
            String nextRankTime = StudyLessonsManager.getWatchTimeToNextRankFormatted(this);

            if (tvHeroProgressLabel != null) {
                tvHeroProgressLabel.setText(userRankLevel >= StudyLessonsManager.MAX_RANK_LEVEL ? "STATUS" : "PROGRESS TO NEXT TIER");
            }
            if (tvHeroProgressText != null) {
                if (userRankLevel >= StudyLessonsManager.MAX_RANK_LEVEL) {
                    tvHeroProgressText.setText("MAX TIER ACHIEVED 👑");
                } else {
                    tvHeroProgressText.setText(progressPct + "% (" + nextRankTime + ")");
                }
            }
            if (pbHeroProgress != null) {
                pbHeroProgress.setProgress(progressPct);
            }
        } else if (isUnlocked) {
            if (tvHeroProgressLabel != null) {
                tvHeroProgressLabel.setText("TIER STATUS");
            }
            if (tvHeroProgressText != null) {
                tvHeroProgressText.setText("Completed ✓ • +100 PTS Awarded");
                tvHeroProgressText.setTextColor(Color.parseColor("#10B981"));
            }
            if (pbHeroProgress != null) {
                pbHeroProgress.setProgress(100);
            }
        } else {
            // Locked Tier Preview
            long hoursPerTier = StudyLessonsManager.SECONDS_PER_RANK_LEVEL / 3600L;
            long requiredHours = (tierLevel - 1) * hoursPerTier;
            if (tvHeroProgressLabel != null) {
                tvHeroProgressLabel.setText("REQUIREMENT");
            }
            if (tvHeroProgressText != null) {
                tvHeroProgressText.setText("Requires " + requiredHours + "h Total Study Time 🔒");
                tvHeroProgressText.setTextColor(Color.parseColor("#94A3B8"));
            }
            if (pbHeroProgress != null) {
                pbHeroProgress.setProgress(0);
            }
        }
    }

    private void buildRankTrackLine(int currentLevel, String nextRankTime) {
        if (layoutRankTrackContainer == null) return;
        layoutRankTrackContainer.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(this);

        for (int i = 1; i <= 10; i++) {
            final int tierLevel = i;
            final boolean isUnlocked = (currentLevel >= tierLevel);
            final boolean isCurrent = (currentLevel == tierLevel);

            View nodeView = inflater.inflate(R.layout.item_rank_line_node, layoutRankTrackContainer, false);

            View lineConnectorTop = nodeView.findViewById(R.id.lineConnectorTop);
            View lineConnectorBottom = nodeView.findViewById(R.id.lineConnectorBottom);
            FrameLayout layoutNodeCircle = nodeView.findViewById(R.id.layoutNodeCircle);
            StudyRankFireView ivNodeFire = nodeView.findViewById(R.id.ivNodeFire);
            View layoutNodeLock = nodeView.findViewById(R.id.layoutNodeLock);

            View layoutNodeCard = nodeView.findViewById(R.id.layoutNodeCard);
            TextView tvNodeTitle = nodeView.findViewById(R.id.tvNodeTitle);
            TextView tvNodeLevelBadge = nodeView.findViewById(R.id.tvNodeLevelBadge);
            TextView tvNodeStatusPill = nodeView.findViewById(R.id.tvNodeStatusPill);
            TextView tvNodeSubtitle = nodeView.findViewById(R.id.tvNodeSubtitle);
            TextView tvNodeRequirement = nodeView.findViewById(R.id.tvNodeRequirement);

            String tierTitle = StudyLessonsManager.getRankTitle(tierLevel);
            String tierSubtitle = StudyLessonsManager.getRankSubtitle(tierLevel);
            long hoursPerTier = StudyLessonsManager.SECONDS_PER_RANK_LEVEL / 3600L;
            long startHours = (tierLevel - 1) * hoursPerTier;
            long endHours = tierLevel * hoursPerTier;

            if (tvNodeTitle != null) tvNodeTitle.setText(tierTitle);
            if (tvNodeLevelBadge != null) tvNodeLevelBadge.setText("LEVEL " + tierLevel);
            if (tvNodeSubtitle != null) tvNodeSubtitle.setText(tierSubtitle);

            // Connectors logic: First item has no top line, last item has no bottom line
            if (lineConnectorTop != null) {
                if (tierLevel == 1) {
                    lineConnectorTop.setVisibility(View.INVISIBLE);
                } else {
                    lineConnectorTop.setVisibility(View.VISIBLE);
                    if (currentLevel >= tierLevel) {
                        lineConnectorTop.setBackgroundResource(R.drawable.bg_rank_track_line_active);
                    } else {
                        lineConnectorTop.setBackgroundResource(R.drawable.bg_rank_track_line_inactive);
                    }
                }
            }

            if (lineConnectorBottom != null) {
                if (tierLevel == 10) {
                    lineConnectorBottom.setVisibility(View.INVISIBLE);
                } else {
                    lineConnectorBottom.setVisibility(View.VISIBLE);
                    if (currentLevel > tierLevel) {
                        lineConnectorBottom.setBackgroundResource(R.drawable.bg_rank_track_line_active);
                    } else {
                        lineConnectorBottom.setBackgroundResource(R.drawable.bg_rank_track_line_inactive);
                    }
                }
            }

            // Fire view setup
            if (ivNodeFire != null) {
                ivNodeFire.setRankLevel(tierLevel);
                ivNodeFire.setLocked(!isUnlocked);
            }

            // Visual State & Badge Styling
            if (isCurrent) {
                activeTierNodeView = nodeView;
                if (layoutNodeCircle != null) {
                    layoutNodeCircle.setBackgroundResource(R.drawable.bg_rank_node_circle_active);
                }
                if (layoutNodeLock != null) {
                    layoutNodeLock.setVisibility(View.GONE);
                }
                if (layoutNodeCard != null) {
                    layoutNodeCard.setBackgroundResource(R.drawable.bg_rank_tier_card_active);
                }
                if (tvNodeRequirement != null) {
                    tvNodeRequirement.setText("⚡ Active Current Rank • " + nextRankTime);
                    tvNodeRequirement.setTextColor(Color.parseColor("#38BDF8"));
                }
                if (tvNodeStatusPill != null) {
                    tvNodeStatusPill.setText("CURRENT");
                    tvNodeStatusPill.setTextColor(Color.parseColor("#0F172A"));
                    tvNodeStatusPill.setBackground(createTintedPillDrawable(Color.parseColor("#38BDF8")));
                }
            } else if (isUnlocked) {
                if (layoutNodeCircle != null) {
                    layoutNodeCircle.setBackgroundResource(R.drawable.bg_rank_node_circle_unlocked);
                }
                if (layoutNodeLock != null) {
                    layoutNodeLock.setVisibility(View.GONE);
                }
                if (layoutNodeCard != null) {
                    layoutNodeCard.setBackgroundResource(R.drawable.bg_rank_tier_card_unlocked);
                }
                if (tvNodeRequirement != null) {
                    tvNodeRequirement.setText("⏱ " + startHours + "h – " + (tierLevel == 10 ? (startHours + "h+") : endHours + "h") + " Study Time • Achieved");
                    tvNodeRequirement.setTextColor(Color.parseColor("#10B981"));
                }
                if (tvNodeStatusPill != null) {
                    tvNodeStatusPill.setText("UNLOCKED");
                    tvNodeStatusPill.setTextColor(Color.parseColor("#10B981"));
                    tvNodeStatusPill.setBackground(createTintedPillDrawable(Color.parseColor("#2610B981")));
                }
            } else {
                // Locked Tier
                if (layoutNodeCircle != null) {
                    layoutNodeCircle.setBackgroundResource(R.drawable.bg_rank_node_circle_locked);
                }
                if (layoutNodeLock != null) {
                    layoutNodeLock.setVisibility(View.VISIBLE);
                }
                if (layoutNodeCard != null) {
                    layoutNodeCard.setBackgroundResource(R.drawable.bg_rank_tier_card_locked);
                    layoutNodeCard.setAlpha(0.68f);
                }
                if (tvNodeRequirement != null) {
                    tvNodeRequirement.setText("🔒 Locked • Requires " + startHours + "h Total Study Time");
                    tvNodeRequirement.setTextColor(Color.parseColor("#94A3B8"));
                }
                if (tvNodeStatusPill != null) {
                    tvNodeStatusPill.setText("LOCKED");
                    tvNodeStatusPill.setTextColor(Color.parseColor("#64748B"));
                    tvNodeStatusPill.setBackground(createTintedPillDrawable(Color.parseColor("#1F334155")));
                }
            }

            // Click interaction to preview this tier in the Hero Centerpiece
            nodeView.setOnClickListener(v -> {
                v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                if (ivNodeFire != null) {
                    ivNodeFire.triggerSurge();
                }
                updateHeroPreview(tierLevel, isCurrent);
                if (!isUnlocked) {
                    Toast.makeText(this, "🔒 " + tierTitle + " requires " + startHours + "h total lecture study time!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "🔥 " + tierTitle + " (" + tierSubtitle + ")", Toast.LENGTH_SHORT).show();
                }
            });
            attachTouchShrink(nodeView);

            layoutRankTrackContainer.addView(nodeView);
        }

        // Auto-scroll track to focus on the active tier node
        if (activeTierNodeView != null && scrollRankContent != null) {
            scrollRankContent.post(() -> {
                try {
                    int top = activeTierNodeView.getTop();
                    scrollRankContent.smoothScrollTo(0, Math.max(0, top - 120));
                } catch (Exception ignored) {
                }
            });
        }
    }

    private GradientDrawable createTintedPillDrawable(int color) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(dpToPx(12));
        gd.setColor(color);
        return gd;
    }

    private void setupBackPressed() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                finishWithAnimation();
            }
        });
    }

    private void finishWithAnimation() {
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void attachTouchShrink(View view) {
        if (view == null) return;
        view.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.animate()
                            .scaleX(0.96f)
                            .scaleY(0.96f)
                            .setDuration(90)
                            .setInterpolator(new OvershootInterpolator(1.2f))
                            .start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.animate()
                            .scaleX(1.0f)
                            .scaleY(1.0f)
                            .setDuration(110)
                            .setInterpolator(new OvershootInterpolator(1.8f))
                            .start();
                    break;
            }
            return false;
        });
    }

    private float dpToPx(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }
}
