package com.abhi.study;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Hyperdrive Warp Ring Loading Spinner (.spinner-38):
 * - Circular 46px x 46px geometry with 2px stroke
 * - Transparent side borders, dual opposite glowing cyan (#38bdf8) arcs on top and bottom
 * - Authentic 14px cyan box-shadow radiant glow (box-shadow: 0 0 14px #38bdf8)
 * - Ultra-fast 0.5s linear infinite rotation (animation: spin1 0.5s linear infinite)
 * - Hardware accelerated, zero-allocation onDraw loop.
 */
public class PlanetaryGyroscopeView extends View {

    private static final int WARP_COLOR = Color.parseColor("#38BDF8"); // CSS #38bdf8

    // Paints
    private final Paint arcPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaintOuter = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaintMid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaintInner = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint coreHighlightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // Geometry
    private final RectF arcBounds = new RectF();

    // Animation: 0.5s linear infinite rotation
    private float currentRotation = 0f;
    private ValueAnimator spinAnimator;

    private float progress = 0f;

    public PlanetaryGyroscopeView(Context context) {
        super(context);
        init();
    }

    public PlanetaryGyroscopeView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public PlanetaryGyroscopeView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        // Base Arc Paint: 2px solid #38bdf8
        arcPaint.setStyle(Paint.Style.STROKE);
        arcPaint.setColor(WARP_COLOR);
        arcPaint.setStrokeCap(Paint.Cap.ROUND);

        // Ambient Outer Glow (simulates box-shadow: 0 0 14px #38bdf8)
        glowPaintOuter.setStyle(Paint.Style.STROKE);
        glowPaintOuter.setColor(WARP_COLOR);
        glowPaintOuter.setAlpha(40);
        glowPaintOuter.setStrokeCap(Paint.Cap.ROUND);

        // Mid Glow
        glowPaintMid.setStyle(Paint.Style.STROKE);
        glowPaintMid.setColor(WARP_COLOR);
        glowPaintMid.setAlpha(95);
        glowPaintMid.setStrokeCap(Paint.Cap.ROUND);

        // Inner Glow
        glowPaintInner.setStyle(Paint.Style.STROKE);
        glowPaintInner.setColor(WARP_COLOR);
        glowPaintInner.setAlpha(160);
        glowPaintInner.setStrokeCap(Paint.Cap.ROUND);

        // Subtle Optical Hotspot at the center of the arc
        coreHighlightPaint.setStyle(Paint.Style.STROKE);
        coreHighlightPaint.setColor(Color.parseColor("#E0F2FE"));
        coreHighlightPaint.setAlpha(140);
        coreHighlightPaint.setStrokeCap(Paint.Cap.ROUND);

        setupSpinAnimator();
    }

    private void setupSpinAnimator() {
        // CSS: animation: spin1 0.5s linear infinite; (500ms duration)
        spinAnimator = ValueAnimator.ofFloat(0f, 360f);
        spinAnimator.setDuration(500);
        spinAnimator.setInterpolator(new LinearInterpolator());
        spinAnimator.setRepeatCount(ValueAnimator.INFINITE);
        spinAnimator.addUpdateListener(anim -> {
            currentRotation = (float) anim.getAnimatedValue();
            postInvalidateOnAnimation();
        });
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        startAnimation();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stopAnimation();
    }

    @Override
    protected void onVisibilityChanged(@NonNull View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        if (visibility == VISIBLE) {
            startAnimation();
        } else {
            stopAnimation();
        }
    }

    public void startAnimation() {
        if (spinAnimator != null && !spinAnimator.isRunning()) {
            spinAnimator.start();
        }
    }

    public void stopAnimation() {
        if (spinAnimator != null) {
            spinAnimator.cancel();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        float cx = w / 2f;
        float cy = h / 2f;
        float minDim = Math.min(w, h);

        // Scale relative to CSS 46px
        float baseSizePx = dpToPx(46f);
        float scale = minDim / baseSizePx;
        if (scale <= 0.05f) scale = 1.0f;

        // CSS: border 2px solid #38bdf8
        float strokeWidth = Math.max(dpToPx(1.8f), dpToPx(2.2f) * scale);
        arcPaint.setStrokeWidth(strokeWidth);

        // CSS: box-shadow 0 0 14px #38bdf8 (Layered blur aura)
        float outerGlowStroke = strokeWidth + dpToPx(13f) * scale;
        float midGlowStroke = strokeWidth + dpToPx(7f) * scale;
        float innerGlowStroke = strokeWidth + dpToPx(3f) * scale;
        float highlightStroke = strokeWidth * 0.55f;

        glowPaintOuter.setStrokeWidth(outerGlowStroke);
        glowPaintMid.setStrokeWidth(midGlowStroke);
        glowPaintInner.setStrokeWidth(innerGlowStroke);
        coreHighlightPaint.setStrokeWidth(highlightStroke);

        // Radius: accounts for glow padding so it doesn't clip
        float padding = (outerGlowStroke / 2f) + dpToPx(1.5f);
        float radius = Math.max(dpToPx(6f), (minDim / 2f) - padding);
        arcBounds.set(cx - radius, cy - radius, cx + radius, cy + radius);

        // Rotate Canvas around center by current rotation (0 to 360 deg in 500ms)
        canvas.save();
        canvas.rotate(currentRotation, cx, cy);

        // Top border arc (centered at -90° / 270°: from 225° to 315°, sweep 90°)
        // Bottom border arc (centered at 90°: from 45° to 135°, sweep 90°)
        final float topStartAngle = 225f;
        final float bottomStartAngle = 45f;
        final float sweepAngle = 90f;

        // 1. Layer 1: Outer Ambient Glow (14px aura)
        canvas.drawArc(arcBounds, topStartAngle, sweepAngle, false, glowPaintOuter);
        canvas.drawArc(arcBounds, bottomStartAngle, sweepAngle, false, glowPaintOuter);

        // 2. Layer 2: Mid Radiant Glow (7px halo)
        canvas.drawArc(arcBounds, topStartAngle, sweepAngle, false, glowPaintMid);
        canvas.drawArc(arcBounds, bottomStartAngle, sweepAngle, false, glowPaintMid);

        // 3. Layer 3: Inner Intense Glow (3px corona)
        canvas.drawArc(arcBounds, topStartAngle, sweepAngle, false, glowPaintInner);
        canvas.drawArc(arcBounds, bottomStartAngle, sweepAngle, false, glowPaintInner);

        // 4. Layer 4: Sharp Neon Core (2px solid #38bdf8)
        canvas.drawArc(arcBounds, topStartAngle, sweepAngle, false, arcPaint);
        canvas.drawArc(arcBounds, bottomStartAngle, sweepAngle, false, arcPaint);

        // 5. Layer 5: High-intensity Core Highlight
        canvas.drawArc(arcBounds, topStartAngle + 12f, sweepAngle - 24f, false, coreHighlightPaint);
        canvas.drawArc(arcBounds, bottomStartAngle + 12f, sweepAngle - 24f, false, coreHighlightPaint);

        canvas.restore();
    }

    public void setProgress(float progress) {
        this.progress = Math.max(0, Math.min(100, progress));
        invalidate();
    }

    public float getProgress() {
        return progress;
    }

    private float dpToPx(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }
}
