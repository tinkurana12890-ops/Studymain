package com.abhi.study.youtube

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.ConnectionPool
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * YouTubeExtractor:
 * Production-grade, mobile-optimized YouTube metadata and transcript extractor inspired by NewPipe.
 *
 * Characteristics:
 * - Zero Google Play Services / Official YouTube API keys required.
 * - Zero heavy scraping or JS runtimes; strictly relies on OkHttp3 & native org.json.
 * - Fully asynchronous, lifecycle-safe, non-blocking on Dispatchers.IO.
 * - Handles auto-generated captions, translated captions, and no-caption edge cases gracefully.
 */
object YouTubeExtractor {

    private const val INNERTUBE_PLAYER_URL = "https://www.youtube.com/youtubei/v1/player"
    private const val DEFAULT_USER_AGENT =
        "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    // Shared thread-safe OkHttpClient with connection pooling for mobile efficiency
    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(12, TimeUnit.SECONDS)
            .connectionPool(ConnectionPool(5, 5, TimeUnit.MINUTES))
            .retryOnConnectionFailure(true)
            .build()
    }

    // Java-interop coroutine scope
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // =========================================================================
    // COROUTINES / SUSPENDING API
    // =========================================================================

    /**
     * Extracts full video metadata for a given YouTube URL or video ID.
     */
    suspend fun extractMetadata(videoIdOrUrl: String): ExtractionResult<YouTubeVideoMetadata> =
        withContext(Dispatchers.IO) {
            val videoId = YouTubeUrlParser.extractVideoId(videoIdOrUrl)
                ?: return@withContext ExtractionResult.ParseError(
                    IllegalArgumentException("Invalid YouTube URL or Video ID: $videoIdOrUrl")
                )

            try {
                // 1. Try Android Client Handshake
                val androidResult = queryInnertube(videoId, clientName = "ANDROID", clientVersion = "19.09.37")
                if (androidResult is ExtractionResult.Success) {
                    return@withContext androidResult
                }

                // 2. Fallback to Web Client Handshake if Android client had restrictions
                val webResult = queryInnertube(videoId, clientName = "WEB", clientVersion = "2.20240105.01.00")
                return@withContext webResult
            } catch (ioe: IOException) {
                ExtractionResult.NetworkError(ioe)
            } catch (t: Throwable) {
                ExtractionResult.ParseError(t)
            }
        }

    /**
     * Extracts transcript segments from a specific [CaptionTrack].
     */
    suspend fun extractTranscript(
        videoId: String,
        captionTrack: CaptionTrack
    ): ExtractionResult<Transcript> = withContext(Dispatchers.IO) {
        try {
            var url = captionTrack.baseUrl
            if (!url.contains("fmt=")) {
                url += "&fmt=json3"
            }

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", DEFAULT_USER_AGENT)
                .get()
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext ExtractionResult.NetworkError(
                    IOException("HTTP ${response.code}: Failed to download captions"),
                    statusCode = response.code
                )
            }

            val payload = response.body?.string()
            if (payload.isNullOrBlank()) {
                return@withContext ExtractionResult.NoCaptionsAvailable(
                    videoId,
                    "Empty caption body returned from YouTube timedtext endpoint."
                )
            }

            val segments = YouTubeTranscriptParser.parseTranscript(payload)
            if (segments.isEmpty()) {
                return@withContext ExtractionResult.NoCaptionsAvailable(
                    videoId,
                    "No transcript segments found in track (${captionTrack.languageCode})."
                )
            }

            ExtractionResult.Success(
                Transcript(
                    videoId = videoId,
                    languageCode = captionTrack.languageCode,
                    isAutoGenerated = captionTrack.isAutoGenerated,
                    segments = segments
                )
            )
        } catch (ioe: IOException) {
            ExtractionResult.NetworkError(ioe)
        } catch (t: Throwable) {
            ExtractionResult.ParseError(t)
        }
    }

    /**
     * Fetches metadata and automatically extracts transcript for the preferred language.
     */
    suspend fun extractTranscript(
        videoIdOrUrl: String,
        preferredLanguage: String = "en",
        allowAutoGenerated: Boolean = true
    ): ExtractionResult<Transcript> = withContext(Dispatchers.IO) {
        val metaResult = extractMetadata(videoIdOrUrl)
        if (metaResult !is ExtractionResult.Success) {
            @Suppress("UNCHECKED_CAST")
            return@withContext metaResult as ExtractionResult<Nothing>
        }

        val metadata = metaResult.data
        val track = metadata.findCaptionTrack(preferredLanguage, allowAutoGenerated)
            ?: return@withContext ExtractionResult.NoCaptionsAvailable(
                metadata.videoId,
                "No matching caption track found for language '$preferredLanguage'."
            )

        extractTranscript(metadata.videoId, track)
    }

    /**
     * Extracts both metadata and transcript in a single call.
     */
    suspend fun extractAll(
        videoIdOrUrl: String,
        preferredLanguage: String = "en"
    ): ExtractionResult<YouTubeExtractionData> = withContext(Dispatchers.IO) {
        val metaResult = extractMetadata(videoIdOrUrl)
        if (metaResult !is ExtractionResult.Success) {
            @Suppress("UNCHECKED_CAST")
            return@withContext metaResult as ExtractionResult<Nothing>
        }

        val metadata = metaResult.data
        val track = metadata.findCaptionTrack(preferredLanguage, allowAutoGenerated = true)
        val transcript = if (track != null) {
            val transcriptResult = extractTranscript(metadata.videoId, track)
            transcriptResult.getOrNull()
        } else {
            null
        }

        ExtractionResult.Success(
            YouTubeExtractionData(
                metadata = metadata,
                transcript = transcript
            )
        )
    }

    // =========================================================================
    // INNERTUBE HANDSHAKE & RESPONSE PARSER
    // =========================================================================

    private fun queryInnertube(
        videoId: String,
        clientName: String,
        clientVersion: String
    ): ExtractionResult<YouTubeVideoMetadata> {
        val requestJson = JSONObject().apply {
            val context = JSONObject().apply {
                val client = JSONObject().apply {
                    put("clientName", clientName)
                    put("clientVersion", clientVersion)
                    put("hl", "en")
                    put("gl", "IN")
                }
                put("client", client)
            }
            put("context", context)
            put("videoId", videoId)
        }

        val request = Request.Builder()
            .url(INNERTUBE_PLAYER_URL)
            .header("Content-Type", "application/json")
            .header("User-Agent", DEFAULT_USER_AGENT)
            .post(requestJson.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()

        val response = httpClient.newCall(request).execute()
        val responseBody = response.body?.string()

        if (!response.isSuccessful || responseBody.isNullOrBlank()) {
            return ExtractionResult.NetworkError(
                IOException("HTTP ${response.code}: Innertube player request failed"),
                statusCode = response.code
            )
        }

        return parseInnertubePlayerResponse(videoId, responseBody)
    }

    private fun parseInnertubePlayerResponse(
        videoId: String,
        jsonString: String
    ): ExtractionResult<YouTubeVideoMetadata> {
        val root = JSONObject(jsonString)

        // 1. Check Playability Status
        val playabilityStatus = root.optJSONObject("playabilityStatus")
        val status = playabilityStatus?.optString("status", "OK") ?: "OK"
        val isPlayable = "OK".equals(status, ignoreCase = true)
        val reason = playabilityStatus?.optString("reason", "")?.takeIf { it.isNotEmpty() }

        if (!isPlayable && reason != null) {
            return ExtractionResult.VideoUnplayable(videoId, reason)
        }

        // 2. Video Details
        val videoDetails = root.optJSONObject("videoDetails")
            ?: return ExtractionResult.ParseError(IllegalStateException("Missing 'videoDetails' object in response"))

        val title = videoDetails.optString("title", "Untitled")
        val author = videoDetails.optString("author", "Unknown Channel")
        val channelId = videoDetails.optString("channelId", "")
        val lengthSeconds = videoDetails.optString("lengthSeconds", "0").toLongOrNull() ?: 0L
        val viewCount = videoDetails.optString("viewCount", "0").toLongOrNull() ?: 0L
        val description = videoDetails.optString("shortDescription", "")
        val isLive = videoDetails.optBoolean("isLiveContent", false)

        // Parse Thumbnails (select highest available resolution)
        var thumbnailUrl = "https://img.youtube.com/vi/$videoId/hqdefault.jpg"
        val thumbnailObj = videoDetails.optJSONObject("thumbnail")
        if (thumbnailObj != null) {
            val thumbnailsArray = thumbnailObj.optJSONArray("thumbnails")
            if (thumbnailsArray != null && thumbnailsArray.length() > 0) {
                // Last thumbnail in array is typically highest resolution
                val bestThumb = thumbnailsArray.getJSONObject(thumbnailsArray.length() - 1)
                thumbnailUrl = bestThumb.optString("url", thumbnailUrl)
            }
        }

        // 3. Captions Extraction
        val captionTracks = ArrayList<CaptionTrack>()
        val captions = root.optJSONObject("captions")
        val playerCaptionsTracklist = captions?.optJSONObject("playerCaptionsTracklistRenderer")
        val tracksArray = playerCaptionsTracklist?.optJSONArray("captionTracks")

        if (tracksArray != null) {
            for (i in 0 until tracksArray.length()) {
                val trackObj = tracksArray.optJSONObject(i) ?: continue
                val baseUrl = trackObj.optString("baseUrl", "")
                if (baseUrl.isBlank()) continue

                val vssId = trackObj.optString("vssId", "")
                val languageCode = trackObj.optString("languageCode", "en")
                val kind = trackObj.optString("kind", "")
                val isAutoGenerated = "asr".equals(kind, ignoreCase = true) || vssId.startsWith("a.")
                val isTranslatable = trackObj.optBoolean("isTranslatable", true)

                // Track name extraction (handles both 'runs' and 'simpleText')
                var trackName = ""
                val nameObj = trackObj.optJSONObject("name")
                if (nameObj != null) {
                    if (nameObj.has("simpleText")) {
                        trackName = nameObj.optString("simpleText", "")
                    } else if (nameObj.has("runs")) {
                        val runs = nameObj.optJSONArray("runs")
                        if (runs != null && runs.length() > 0) {
                            trackName = runs.getJSONObject(0).optString("text", "")
                        }
                    }
                }
                if (trackName.isBlank()) {
                    trackName = if (isAutoGenerated) "$languageCode (auto-generated)" else languageCode
                }

                captionTracks.add(
                    CaptionTrack(
                        baseUrl = baseUrl,
                        name = trackName,
                        languageCode = languageCode,
                        vssId = vssId,
                        isAutoGenerated = isAutoGenerated,
                        isTranslatable = isTranslatable
                    )
                )
            }
        }

        return ExtractionResult.Success(
            YouTubeVideoMetadata(
                videoId = videoId,
                title = title,
                author = author,
                channelId = channelId,
                durationSeconds = lengthSeconds,
                viewCount = viewCount,
                description = description,
                thumbnailUrl = thumbnailUrl,
                isLive = isLive,
                isPlayable = isPlayable,
                playabilityReason = reason,
                captionTracks = captionTracks
            )
        )
    }

    // =========================================================================
    // JAVA INTEROPERABILITY CALLBACKS
    // =========================================================================

    interface Callback<T> {
        fun onSuccess(result: T)
        fun onError(error: ExtractionResult<Nothing>)
    }

    @JvmStatic
    fun extractMetadataAsync(videoIdOrUrl: String, callback: Callback<YouTubeVideoMetadata>) {
        scope.launch {
            when (val result = extractMetadata(videoIdOrUrl)) {
                is ExtractionResult.Success -> callback.onSuccess(result.data)
                is ExtractionResult.NoCaptionsAvailable -> callback.onError(result)
                is ExtractionResult.VideoUnplayable -> callback.onError(result)
                is ExtractionResult.NetworkError -> callback.onError(result)
                is ExtractionResult.ParseError -> callback.onError(result)
            }
        }
    }

    @JvmStatic
    @JvmOverloads
    fun extractTranscriptAsync(
        videoIdOrUrl: String,
        preferredLanguage: String = "en",
        callback: Callback<Transcript>
    ) {
        scope.launch {
            when (val result = extractTranscript(videoIdOrUrl, preferredLanguage)) {
                is ExtractionResult.Success -> callback.onSuccess(result.data)
                is ExtractionResult.NoCaptionsAvailable -> callback.onError(result)
                is ExtractionResult.VideoUnplayable -> callback.onError(result)
                is ExtractionResult.NetworkError -> callback.onError(result)
                is ExtractionResult.ParseError -> callback.onError(result)
            }
        }
    }
}
