package com.abhi.study;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Lightweight, zero-dependency asynchronous thumbnail loader with LruCache.
 * Safely fetches YouTube HQ default thumbnails and populates ImageViews on the UI thread.
 */
public class AsyncThumbnailLoader {

    private static final int MAX_CACHE_SIZE = (int) (Runtime.getRuntime().maxMemory() / 1024) / 8;
    private static final LruCache<String, Bitmap> MEMORY_CACHE = new LruCache<String, Bitmap>(MAX_CACHE_SIZE) {
        @Override
        protected int sizeOf(String key, Bitmap bitmap) {
            return bitmap.getByteCount() / 1024;
        }
    };

    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(4);
    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());

    public static void load(final String urlString, final ImageView imageView) {
        if (urlString == null || imageView == null) return;

        imageView.setTag(urlString);

        // 1. Check in-memory cache
        Bitmap cached = MEMORY_CACHE.get(urlString);
        if (cached != null) {
            imageView.setImageBitmap(cached);
            return;
        }

        // 2. Fetch asynchronously in background thread pool
        EXECUTOR.execute(() -> {
            Bitmap bitmap = null;
            HttpURLConnection connection = null;
            try {
                URL url = new URL(urlString);
                connection = (HttpURLConnection) url.openConnection();
                connection.setConnectTimeout(6000);
                connection.setReadTimeout(6000);
                connection.setDoInput(true);
                connection.connect();

                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    try (InputStream input = connection.getInputStream()) {
                        bitmap = BitmapFactory.decodeStream(input);
                    }
                }
            } catch (Exception ignored) {
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }

            if (bitmap != null) {
                final Bitmap finalBitmap = bitmap;
                MEMORY_CACHE.put(urlString, finalBitmap);

                MAIN_HANDLER.post(() -> {
                    if (urlString.equals(imageView.getTag())) {
                        imageView.setImageBitmap(finalBitmap);
                        imageView.setAlpha(0f);
                        imageView.animate().alpha(1f).setDuration(220).start();
                    }
                });
            }
        });
    }
}
