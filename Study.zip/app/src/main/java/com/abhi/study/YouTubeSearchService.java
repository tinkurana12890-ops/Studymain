package com.abhi.study;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * YouTubeSearchService:
 * 100% Native, strictly educational YouTube query and infinite stream provider.
 * Features:
 * - Strict Non-Educational Query Blocker (Zero gaming/movies/entertainment allowed).
 * - Multi-layer Educational Content Whitelist & Entertainment Blacklist.
 * - Non-stop Continuous Syllabus Feed for infinite scrolling.
 * - Zero external heavy dependencies, asynchronous IO via ExecutorService.
 */
public class YouTubeSearchService {

    public interface SearchCallback {
        void onSuccess(List<Class11Video> videos);
        void onError(Throwable throwable);
    }

    private static final String SEARCH_ENDPOINT = "https://www.youtube.com/youtubei/v1/search";
    private static final String USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(3);
    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());

    // Comprehensive list of Class 11 educational syllabus chapters for non-stop infinite scrolling
    public static final String[] EDUCATIONAL_SYLLABUS_TOPICS = {
            "Class 11 Physics Work Energy and Power One Shot",
            "Class 11 Chemistry Chemical Bonding and Molecular Structure One Shot",
            "Class 11 Mathematics Trigonometric Functions One Shot",
            "Class 11 Biology Cell Cycle and Cell Division One Shot",
            "Class 11 Physics Gravitation Full Chapter NCERT",
            "Class 11 Chemistry Equilibrium One Shot Detailed",
            "Class 11 Mathematics Limits and Derivatives One Shot",
            "Class 11 Biology Biomolecules One Shot NCERT NEET",
            "Class 11 Physics Thermodynamics One Shot Revision",
            "Class 11 Chemistry Some Basic Concepts of Chemistry Mole Concept",
            "Class 11 Mathematics Sequences and Series AP GP One Shot",
            "Class 11 Biology Morphology of Flowering Plants NCERT",
            "Class 11 Physics Mechanical Properties of Fluids One Shot",
            "Class 11 Chemistry Organic Chemistry Some Basic Principles",
            "Class 11 Mathematics Straight Lines Conic Sections",
            "Class 11 Biology Photosynthesis in Higher Plants One Shot",
            "Class 11 Physics Oscillations and Waves One Shot",
            "Class 11 Chemistry Redox Reactions Full Lecture",
            "Class 11 Mathematics Permutations and Combinations One Shot",
            "Class 11 Biology Plant Kingdom One Shot NCERT",
            "Class 11 Physics Kinetic Theory of Gases One Shot",
            "Class 11 Chemistry Structure of Atom One Shot",
            "Class 11 Mathematics Binomial Theorem One Shot",
            "Class 11 Biology Animal Kingdom One Shot NCERT",
            "Class 11 Physics Laws of Motion Numericals and PYQs",
            "Class 11 Chemistry Classification of Elements Periodic Table",
            "Class 11 Mathematics Sets and Relations Functions One Shot",
            "Class 11 Biology Neural Control and Coordination One Shot"
    };

    /**
     * Checks if a user's search query is non-educational entertainment or gaming.
     */
    public static boolean isNonEducationalQuery(String query) {
        if (query == null) return false;
        String q = query.toLowerCase().trim();
        String[] forbidden = {
                "game", "gaming", "gameplay", "pubg", "battle royale", "gta", "minecraft", "roblox", "bgmi",
                "movie", "film", "trailer", "teaser", "song", "songs", "music", "dance", "comedy",
                "vlog", "vlogs", "prank", "roast", "tiktok", "reels", "funny", "meme", "entertainment",
                "action movie", "fight", "drama", "serial", "dj remix", "lofi remix", "status 4k", "status video"
        };
        for (String bad : forbidden) {
            if (q.contains(bad)) {
                // Safeguard against academic phrases like "game theory in mathematics"
                if (bad.equals("game") && (q.contains("theory") || q.contains("strategy"))) {
                    continue;
                }
                return true;
            }
        }
        return false;
    }

    /**
     * Strictly verifies that video title, channel, and description represent authentic educational syllabus material.
     */
    public static boolean isStrictlyEducational(String title, String channel, String description) {
        String text = (title + " " + channel + " " + description).toLowerCase();

        // 1. Blacklist check - instant disqualification for entertainment
        String[] blacklist = {
                "gaming", "gameplay", "walkthrough", "pubg", "battle royale", "gta", "roblox", "minecraft",
                "trailer", "teaser", "official song", "music video", "audio song", "remix", "lofi remix",
                "dance cover", "comedy video", "prank", "roast", "funny moments", "movie clip", "web series",
                "episode 1", "season 1", "tiktok", "reels", "shorts", "status 4k", "dj remix", "unboxing phone"
        };
        for (String bad : blacklist) {
            if (text.contains(bad)) {
                return false;
            }
        }

        // 2. Whitelist check - must be educational syllabus, lecture, chapter, or teacher
        String[] educationalKeywords = {
                "class 11", "class 12", "class 10", "class 9", "lecture", "chapter", "one shot",
                "revision", "physics", "chemistry", "math", "biology", "neet", "jee", "pyq",
                "syllabus", "formula", "derivation", "numerical", "ncert", "cbse", "icse",
                "board", "wallah", "academy", "teacher", "education", "study", "science",
                "magnet brains", "eduhap", "bhaiya", "sir", "concepts", "explanation", "crash course"
        };
        for (String good : educationalKeywords) {
            if (text.contains(good)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Executes real-time live search strictly for educational content against YouTube.
     * Non-educational queries are blocked at the source.
     */
    public static void search(final String rawQuery, final SearchCallback callback) {
        if (callback == null) return;

        if (rawQuery == null || rawQuery.trim().isEmpty()) {
            callback.onSuccess(Class11VideoRepository.getAllVideos());
            return;
        }

        final String query = rawQuery.trim();

        // If the query is explicitly non-educational, block it and return empty list immediately
        if (isNonEducationalQuery(query)) {
            MAIN_HANDLER.post(() -> callback.onSuccess(new ArrayList<>()));
            return;
        }

        EXECUTOR.execute(() -> {
            try {
                // Enforce educational context on the search query
                String enforcedQuery = query + " class 11 12 full lecture education ncert study";
                List<Class11Video> results = performInnertubeSearch(enforcedQuery, query);
                if (results != null && !results.isEmpty()) {
                    MAIN_HANDLER.post(() -> callback.onSuccess(results));
                } else {
                    // Fallback to local curated matching educational videos
                    MAIN_HANDLER.post(() -> callback.onSuccess(Class11VideoRepository.search(query)));
                }
            } catch (Exception e) {
                // Fall back gracefully to local repo without crashing
                MAIN_HANDLER.post(() -> callback.onSuccess(Class11VideoRepository.search(query)));
            }
        });
    }

    /**
     * Fetches the next educational chapter batch for non-stop infinite scrolling.
     */
    public static void fetchEducationalTopicStream(final int topicIndex, final SearchCallback callback) {
        if (callback == null) return;

        final String topic = EDUCATIONAL_SYLLABUS_TOPICS[Math.abs(topicIndex) % EDUCATIONAL_SYLLABUS_TOPICS.length];

        EXECUTOR.execute(() -> {
            try {
                List<Class11Video> results = performInnertubeSearch(topic, topic);
                if (results != null && !results.isEmpty()) {
                    MAIN_HANDLER.post(() -> callback.onSuccess(results));
                } else {
                    MAIN_HANDLER.post(() -> callback.onSuccess(new ArrayList<>()));
                }
            } catch (Exception e) {
                MAIN_HANDLER.post(() -> callback.onSuccess(new ArrayList<>()));
            }
        });
    }

    private static List<Class11Video> performInnertubeSearch(String searchQuery, String displayContext) throws Exception {
        URL url = new URL(SEARCH_ENDPOINT);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(6000);
        conn.setReadTimeout(6000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        conn.setRequestProperty("User-Agent", USER_AGENT);

        // Build Innertube Context
        JSONObject client = new JSONObject();
        client.put("clientName", "WEB");
        client.put("clientVersion", "2.20240105.01.00");
        client.put("hl", "en");
        client.put("gl", "IN");

        JSONObject context = new JSONObject();
        context.put("client", client);

        JSONObject requestBody = new JSONObject();
        requestBody.put("context", context);
        requestBody.put("query", searchQuery);

        byte[] postBytes = requestBody.toString().getBytes(StandardCharsets.UTF_8);
        conn.setFixedLengthStreamingMode(postBytes.length);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(postBytes);
            os.flush();
        }

        int statusCode = conn.getResponseCode();
        if (statusCode != HttpURLConnection.HTTP_OK) {
            conn.disconnect();
            return null;
        }

        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        reader.close();
        conn.disconnect();

        return parseSearchResults(sb.toString(), displayContext);
    }

    private static List<Class11Video> parseSearchResults(String jsonStr, String query) {
        List<Class11Video> list = new ArrayList<>();
        try {
            JSONObject root = new JSONObject(jsonStr);
            JSONObject contents = root.optJSONObject("contents");
            if (contents == null) return list;

            JSONObject twoColumn = contents.optJSONObject("twoColumnSearchResultsRenderer");
            if (twoColumn == null) return list;

            JSONObject primary = twoColumn.optJSONObject("primaryContents");
            if (primary == null) return list;

            JSONObject sectionList = primary.optJSONObject("sectionListRenderer");
            if (sectionList == null) return list;

            JSONArray sectionContents = sectionList.optJSONArray("contents");
            if (sectionContents == null) return list;

            for (int i = 0; i < sectionContents.length(); i++) {
                JSONObject section = sectionContents.optJSONObject(i);
                if (section == null) continue;

                JSONObject itemSection = section.optJSONObject("itemSectionRenderer");
                if (itemSection == null) continue;

                JSONArray items = itemSection.optJSONArray("contents");
                if (items == null) continue;

                for (int j = 0; j < items.length(); j++) {
                    JSONObject item = items.optJSONObject(j);
                    if (item == null || !item.has("videoRenderer")) continue;

                    JSONObject vr = item.optJSONObject("videoRenderer");
                    if (vr == null) continue;

                    String videoId = vr.optString("videoId", "");
                    if (videoId.isEmpty()) continue;

                    // Title
                    String title = "Educational Video";
                    JSONObject titleObj = vr.optJSONObject("title");
                    if (titleObj != null && titleObj.has("runs")) {
                        JSONArray runs = titleObj.optJSONArray("runs");
                        if (runs != null && runs.length() > 0) {
                            title = runs.getJSONObject(0).optString("text", title);
                        }
                    }

                    // Channel / Author
                    String channel = "PW / Top Educator";
                    JSONObject ownerObj = vr.optJSONObject("ownerText");
                    if (ownerObj != null && ownerObj.has("runs")) {
                        JSONArray runs = ownerObj.optJSONArray("runs");
                        if (runs != null && runs.length() > 0) {
                            channel = runs.getJSONObject(0).optString("text", channel);
                        }
                    }

                    // Duration
                    String duration = "Video";
                    JSONObject lengthObj = vr.optJSONObject("lengthText");
                    if (lengthObj != null) {
                        duration = lengthObj.optString("simpleText", duration);
                    }

                    // View Count
                    String views = "High Views";
                    JSONObject viewsObj = vr.optJSONObject("viewCountText");
                    if (viewsObj != null) {
                        views = viewsObj.optString("simpleText", views);
                    }

                    // Description Snippet
                    String description = "Learn chapter concepts, NCERT theory, and numericals.";
                    JSONArray descSnippets = vr.optJSONArray("detailedMetadataSnippets");
                    if (descSnippets != null && descSnippets.length() > 0) {
                        JSONObject snippet = descSnippets.optJSONObject(0);
                        if (snippet != null && snippet.has("snippetText")) {
                            JSONObject snippetText = snippet.optJSONObject("snippetText");
                            if (snippetText != null && snippetText.has("runs")) {
                                JSONArray runs = snippetText.optJSONArray("runs");
                                if (runs != null) {
                                    StringBuilder descSb = new StringBuilder();
                                    for (int r = 0; r < runs.length(); r++) {
                                        descSb.append(runs.getJSONObject(r).optString("text", ""));
                                    }
                                    if (descSb.length() > 0) {
                                        description = descSb.toString().trim();
                                    }
                                }
                            }
                        }
                    }

                    // Strict Educational Filter: Reject any video that is not authentic educational syllabus
                    if (!isStrictlyEducational(title, channel, description)) {
                        continue;
                    }

                    // Detect Subject from query or title
                    String subject = detectSubject(query, title);

                    String badge = views.isEmpty() || views.equals("High Views") ? "🔥 EDUCATIONAL" : "🔥 " + views.toUpperCase();

                    list.add(new Class11Video(
                            videoId,
                            title,
                            subject,
                            channel,
                            views,
                            duration,
                            badge,
                            description
                    ));

                    if (list.size() >= 15) {
                        return list;
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    private static String detectSubject(String query, String title) {
        String combined = (query + " " + title).toLowerCase();
        if (combined.contains("physic") || combined.contains("motion") || combined.contains("kinematics") || combined.contains("gravitation") || combined.contains("thermodynamics") || combined.contains("friction") || combined.contains("fluid") || combined.contains("wave") || combined.contains("oscillation")) {
            return "Physics";
        } else if (combined.contains("chem") || combined.contains("mole") || combined.contains("atom") || combined.contains("periodic") || combined.contains("bonding") || combined.contains("organic") || combined.contains("equilibrium") || combined.contains("redox")) {
            return "Chemistry";
        } else if (combined.contains("math") || combined.contains("calculus") || combined.contains("trig") || combined.contains("algebra") || combined.contains("relation") || combined.contains("function") || combined.contains("set") || combined.contains("limit") || combined.contains("derivative") || combined.contains("conic")) {
            return "Mathematics";
        } else if (combined.contains("bio") || combined.contains("cell") || combined.contains("plant") || combined.contains("animal") || combined.contains("living") || combined.contains("botany") || combined.contains("zoology") || combined.contains("biomolecule")) {
            return "Biology";
        }
        return "One-Shot";
    }
}
