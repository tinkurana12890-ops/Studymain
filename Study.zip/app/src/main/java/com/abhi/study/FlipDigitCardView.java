package com.abhi.study;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Camera;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/**
 * iOS 26 Liquid Crystal Mechanical Split-Flap Clock Digit Card.
 * Implements an authentic half-flip animation where the bottom flap
 * turns upward like a page turning up around the center crease line,
 * revealing the next digit with realistic 3D perspective and dynamic liquid glass reflections.
 */
public class FlipDigitCardView extends View {

    private String currentValue = "00";
    private String nextValue = "00";
    private float flipProgress = 1.0f; // 0.0f = started, 1.0f = idle / complete
    private boolean isFlipping = false;

    private Paint backgroundPaint;
    private Paint borderPaint;
    private Paint digitPaint;
    private Paint dividerPaint;
    private Paint dividerHighlightPaint;
    private Paint shadowPaint;
    private Paint sheenPaint;

    private RectF cardBounds = new RectF();
    private RectF topClipRect = new RectF();
    private RectF bottomClipRect = new RectF();

    private final Camera camera = new Camera();
    private final Matrix matrix = new Matrix();

    private ValueAnimator flipAnimator;
    private final DecelerateInterpolator interpolator = new DecelerateInterpolator(1.5f);

    private int glowColor = Color.parseColor("#8038BDF8");
    private float cornerRadius = 0f;

    public FlipDigitCardView(Context context) {
        super(context);
        init();
    }

    public FlipDigitCardView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public FlipDigitCardView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        float density = getResources().getDisplayMetrics().density;
        cornerRadius = 16f * density;

        // Background dark frosted glass fill
        backgroundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        backgroundPaint.setStyle(Paint.Style.FILL);

        // Specular frosted border
        borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(1.4f * density);
        borderPaint.setColor(Color.parseColor("#55FFFFFF"));

        // Glowing digits typography (San Francisco style bold)
        digitPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        digitPaint.setColor(Color.WHITE);
        digitPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        digitPaint.setTextAlign(Paint.Align.CENTER);
        digitPaint.setLetterSpacing(0.04f);
        digitPaint.setShadowLayer(16f * density, 0, 0, glowColor);

        // Center split crease line
        dividerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        dividerPaint.setColor(Color.parseColor("#99000000"));
        dividerPaint.setStrokeWidth(1.5f * density);

        // Center split specular highlight line
        dividerHighlightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        dividerHighlightPaint.setColor(Color.parseColor("#33FFFFFF"));
        dividerHighlightPaint.setStrokeWidth(1.0f * density);

        // Top specular sheen
        sheenPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        sheenPaint.setStyle(Paint.Style.FILL);

        // Dynamic 3D lighting shadow overlay
        shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        shadowPaint.setStyle(Paint.Style.FILL);

        // Setup camera distance for realistic 3D perspective
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            setCameraDistance(9000f * density);
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        float density = getResources().getDisplayMetrics().density;
        float inset = 1f * density;
        cardBounds.set(inset, inset, w - inset, h - inset);

        float halfH = h / 2f;
        topClipRect.set(0, 0, w, halfH);
        bottomClipRect.set(0, halfH, w, h);

        digitPaint.setTextSize(h * 0.52f);

        // Liquid glass body gradient
        LinearGradient bgGradient = new LinearGradient(
                0, 0, 0, h,
                new int[]{Color.parseColor("#381E293B"), Color.parseColor("#260F172A"), Color.parseColor("#330B132B")},
                null,
                Shader.TileMode.CLAMP
        );
        backgroundPaint.setShader(bgGradient);

        // Top specular reflection gradient
        LinearGradient sheenGradient = new LinearGradient(
                0, 0, 0, halfH,
                new int[]{Color.parseColor("#47FFFFFF"), Color.parseColor("#14FFFFFF"), Color.TRANSPARENT},
                null,
                Shader.TileMode.CLAMP
        );
        sheenPaint.setShader(sheenGradient);
    }

    public void setValue(String newValue) {
        if (newValue == null) newValue = "00";
        if (newValue.length() == 1) newValue = "0" + newValue;

        if (newValue.equals(currentValue) && !isFlipping) {
            return;
        }

        if (isFlipping) {
            nextValue = newValue;
            return;
        }

        nextValue = newValue;
        startUpwardHalfFlip();
    }

    private void startUpwardHalfFlip() {
        isFlipping = true;
        if (flipAnimator != null) {
            flipAnimator.cancel();
        }

        flipAnimator = ValueAnimator.ofFloat(0.0f, 1.0f);
        flipAnimator.setDuration(320);
        flipAnimator.setInterpolator(interpolator);
        flipAnimator.addUpdateListener(anim -> {
            flipProgress = (float) anim.getAnimatedValue();
            invalidate();
        });
        flipAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                currentValue = nextValue;
                flipProgress = 1.0f;
                isFlipping = false;
                invalidate();
            }
        });
        flipAnimator.start();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;

        float cx = w / 2f;
        float halfH = h / 2f;

        // Calculate vertical center baseline for text
        Paint.FontMetrics fm = digitPaint.getFontMetrics();
        float textY = halfH - (fm.ascent + fm.descent) / 2f;

        // 1. Draw Card Background with Rounded Corners & Specular Rim
        canvas.drawRoundRect(cardBounds, cornerRadius, cornerRadius, backgroundPaint);

        // Draw top specular sheen
        canvas.save();
        canvas.clipRect(topClipRect);
        canvas.drawRoundRect(cardBounds, cornerRadius, cornerRadius, sheenPaint);
        canvas.restore();

        if (!isFlipping || flipProgress >= 1.0f) {
            // IDLE STATE: Just draw full digit with split divider
            drawSplitDigit(canvas, currentValue, cx, textY);
        } else {
            // ========================================================
            // UPWARD HALF-FLIP ANIMATION (Page Turning Upward)
            // The bottom flap lifts up from bottom and folds over the top
            // ========================================================

            // Layer 1: Static Top Half (shows NEXT value ready underneath)
            canvas.save();
            canvas.clipRect(topClipRect);
            canvas.drawText(nextValue, cx, textY, digitPaint);
            canvas.restore();

            // Layer 2: Static Bottom Half (shows NEXT value revealed as page turns up)
            canvas.save();
            canvas.clipRect(bottomClipRect);
            canvas.drawText(nextValue, cx, textY, digitPaint);
            canvas.restore();

            // Layer 3: Flipping Page Flap (Turning Upward around center crease)
            float angle = flipProgress * 180.0f; // 0 to 180 degrees

            canvas.save();
            camera.save();

            if (flipProgress < 0.5f) {
                // First half (0° to 90°): Bottom half of OLD digit lifts UPWARD towards viewer
                camera.rotateX(angle);
                camera.getMatrix(matrix);
                camera.restore();

                matrix.preTranslate(-cx, -halfH);
                matrix.postTranslate(cx, halfH);

                canvas.concat(matrix);
                canvas.clipRect(bottomClipRect);

                // Draw background of flipping flap
                canvas.drawRoundRect(cardBounds, cornerRadius, cornerRadius, backgroundPaint);
                canvas.drawText(currentValue, cx, textY, digitPaint);

                // Realistic progressive shadow as flap tilts
                int shadowAlpha = (int) (140 * (flipProgress / 0.5f));
                shadowPaint.setColor(Color.argb(Math.min(140, shadowAlpha), 0, 0, 0));
                canvas.drawRect(bottomClipRect, shadowPaint);

            } else {
                // Second half (90° to 180°): Top half of NEW digit folds flat onto top half
                camera.rotateX(angle - 180.0f);
                camera.getMatrix(matrix);
                camera.restore();

                matrix.preTranslate(-cx, -halfH);
                matrix.postTranslate(cx, halfH);

                canvas.concat(matrix);
                canvas.clipRect(topClipRect);

                // Draw background of flipping flap
                canvas.drawRoundRect(cardBounds, cornerRadius, cornerRadius, backgroundPaint);
                canvas.drawRoundRect(cardBounds, cornerRadius, cornerRadius, sheenPaint);
                canvas.drawText(nextValue, cx, textY, digitPaint);

                // Shadow lightens smoothly as flap lands
                int shadowAlpha = (int) (140 * ((1.0f - flipProgress) / 0.5f));
                shadowPaint.setColor(Color.argb(Math.max(0, shadowAlpha), 0, 0, 0));
                canvas.drawRect(topClipRect, shadowPaint);
            }

            canvas.restore();
        }

        // 4. Center Horizontal Split Crease Line & Specular Edge
        canvas.drawLine(0, halfH - 1f, w, halfH - 1f, dividerHighlightPaint);
        canvas.drawLine(0, halfH, w, halfH, dividerPaint);

        // 5. Specular Outer Glass Border
        canvas.drawRoundRect(cardBounds, cornerRadius, cornerRadius, borderPaint);
    }

    private void drawSplitDigit(Canvas canvas, String text, float cx, float textY) {
        // Draw top half
        canvas.save();
        canvas.clipRect(topClipRect);
        canvas.drawText(text, cx, textY, digitPaint);
        canvas.restore();

        // Draw bottom half
        canvas.save();
        canvas.clipRect(bottomClipRect);
        canvas.drawText(text, cx, textY, digitPaint);
        canvas.restore();
    }

    public void setGlowColor(int color) {
        this.glowColor = color;
        float density = getResources().getDisplayMetrics().density;
        digitPaint.setShadowLayer(16f * density, 0, 0, color);
        invalidate();
    }
}
