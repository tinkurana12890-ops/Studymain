package com.abhi.study;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * iOS 26 Liquid Focus Session Aura View.
 * Displays an animated breathing liquid energy field, comet head beads,
 * and high-performance zero-allocation radial glow shaders.
 */
public class FocusSessionAuraView extends View {

    private Paint glowPaint;
    private Paint trackPaint;
    private Paint progressPaint;
    private Paint beadPaint;
    private Paint particlePaint;

    private RectF arcBounds = new RectF();
    private float pulsePhase = 0f;
    private float spinAngle = 0f;
    private float progressPercent = 100f; // 100% to 0% for Deep Mode

    private boolean isDeepMode = true;
    private boolean isPaused = false;

    private ValueAnimator spinAnimator;
    private ValueAnimator pulseAnimator;

    // Zero-allocation shader transforms
    private RadialGradient cachedGlowShader;
    private final Matrix glowMatrix = new Matrix();

    private static class Sparkle {
        float x, y, radius, speedX, speedY;
        int alpha, maxAlpha;
        float phase;
    }

    private final List<Sparkle> sparkles = new ArrayList<>();
    private final Random random = new Random();

    public FocusSessionAuraView(Context context) {
        super(context);
        init();
    }

    public FocusSessionAuraView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public FocusSessionAuraView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        glowPaint.setStyle(Paint.Style.FILL);

        trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        trackPaint.setStyle(Paint.Style.STROKE);
        trackPaint.setStrokeWidth(dpToPx(5f));
        trackPaint.setColor(Color.parseColor("#18FFFFFF"));

        progressPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        progressPaint.setStyle(Paint.Style.STROKE);
        progressPaint.setStrokeWidth(dpToPx(7f));
        progressPaint.setStrokeCap(Paint.Cap.ROUND);

        beadPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        beadPaint.setStyle(Paint.Style.FILL);

        particlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        particlePaint.setStyle(Paint.Style.FILL);

        for (int i = 0; i < 20; i++) {
            Sparkle s = new Sparkle();
            resetSparkle(s, true);
            sparkles.add(s);
        }

        setupAnimators();
    }

    private void resetSparkle(Sparkle s, boolean randomY) {
        s.radius = dpToPx(1f + random.nextFloat() * 1.8f);
        s.speedY = dpToPx(0.2f + random.nextFloat() * 0.6f);
        s.speedX = dpToPx((random.nextFloat() - 0.5f) * 0.4f);
        s.maxAlpha = 110 + random.nextInt(120);
        s.alpha = randomY ? random.nextInt(s.maxAlpha) : 0;
        s.phase = random.nextFloat() * (float) Math.PI * 2f;
    }

    private void setupAnimators() {
        spinAnimator = ValueAnimator.ofFloat(0f, 360f);
        spinAnimator.setDuration(4000);
        spinAnimator.setRepeatCount(ValueAnimator.INFINITE);
        spinAnimator.setInterpolator(new LinearInterpolator());
        spinAnimator.addUpdateListener(anim -> {
            if (!isPaused) {
                spinAngle = (float) anim.getAnimatedValue();
                invalidate();
            }
        });

        pulseAnimator = ValueAnimator.ofFloat(0f, (float) Math.PI * 2f);
        pulseAnimator.setDuration(2200);
        pulseAnimator.setRepeatCount(ValueAnimator.INFINITE);
        pulseAnimator.setInterpolator(new LinearInterpolator());
        pulseAnimator.addUpdateListener(anim -> {
            if (!isPaused) {
                pulsePhase = (float) anim.getAnimatedValue();
            }
        });
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (spinAnimator != null && !spinAnimator.isRunning()) spinAnimator.start();
        if (pulseAnimator != null && !pulseAnimator.isRunning()) pulseAnimator.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (spinAnimator != null) spinAnimator.cancel();
        if (pulseAnimator != null) pulseAnimator.cancel();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        float cx = w / 2f;
        float cy = h / 2f;
        float radius = Math.min(w, h) * 0.42f;
        arcBounds.set(cx - radius, cy - radius, cx + radius, cy + radius);

        updateShaders(cx, cy);

        for (Sparkle s : sparkles) {
            s.x = cx + (random.nextFloat() - 0.5f) * radius * 2.2f;
            s.y = cy + (random.nextFloat() - 0.5f) * radius * 2.2f;
        }
    }

    private void updateShaders(float cx, float cy) {
        int coreColor = isDeepMode ? Color.parseColor("#8B5CF6") : Color.parseColor("#06B6D4");

        // Base unit radial gradient for zero-allocation rendering in onDraw()
        cachedGlowShader = new RadialGradient(
                0, 0, 100f,
                new int[]{
                        Color.argb(85, Color.red(coreColor), Color.green(coreColor), Color.blue(coreColor)),
                        Color.argb(25, Color.red(coreColor), Color.green(coreColor), Color.blue(coreColor)),
                        Color.TRANSPARENT
                },
                new float[]{0.0f, 0.65f, 1.0f},
                Shader.TileMode.CLAMP
        );
        glowPaint.setShader(cachedGlowShader);

        if (isDeepMode) {
            // Indigo-Violet gradient sweep
            int[] colors = new int[]{
                    Color.parseColor("#6366F1"),
                    Color.parseColor("#8B5CF6"),
                    Color.parseColor("#C4B5FD"),
                    Color.parseColor("#6366F1")
            };
            SweepGradient sweep = new SweepGradient(cx, cy, colors, null);
            progressPaint.setShader(sweep);
        } else {
            // Mint-Cyan gradient sweep
            int[] colors = new int[]{
                    Color.parseColor("#10B981"),
                    Color.parseColor("#06B6D4"),
                    Color.parseColor("#6EE7B7"),
                    Color.parseColor("#10B981")
            };
            SweepGradient sweep = new SweepGradient(cx, cy, colors, null);
            progressPaint.setShader(sweep);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float minDim = Math.min(getWidth(), getHeight());
        float radius = arcBounds.width() / 2f;

        // 1. Central Breathing Aura Glow (Zero Allocation via Matrix Scale)
        float pulse = 0.88f + 0.12f * (float) Math.sin(pulsePhase);
        float glowRadius = radius * 0.95f * pulse;

        if (cachedGlowShader != null) {
            glowMatrix.reset();
            glowMatrix.setScale(glowRadius / 100f, glowRadius / 100f);
            glowMatrix.postTranslate(cx, cy);
            cachedGlowShader.setLocalMatrix(glowMatrix);
            canvas.drawCircle(cx, cy, glowRadius, glowPaint);
        }

        // 2. Ambient Floating Sparkles
        for (Sparkle s : sparkles) {
            s.y -= s.speedY;
            s.x += s.speedX;
            s.phase += 0.04f;
            float alphaOsc = (float) Math.sin(s.phase);
            int currentAlpha = (int) (s.maxAlpha * (0.6f + 0.4f * alphaOsc));
            if (currentAlpha < 0) currentAlpha = 0;
            if (currentAlpha > 255) currentAlpha = 255;

            particlePaint.setColor(Color.argb(currentAlpha, 224, 242, 254));
            canvas.drawCircle(s.x, s.y, s.radius, particlePaint);

            if (s.y < cy - minDim * 0.48f || s.x < cx - minDim * 0.48f || s.x > cx + minDim * 0.48f) {
                s.x = cx + (random.nextFloat() - 0.5f) * minDim * 0.8f;
                s.y = cy + minDim * 0.42f;
                resetSparkle(s, false);
            }
        }

        // 3. Track Background Ring
        canvas.drawCircle(cx, cy, radius, trackPaint);

        // 4. Active Progress Arc
        if (isDeepMode) {
            // Countdown arc: Starts at -90 deg (top), sweeps proportionally to remaining percentage
            float sweepAngle = (progressPercent / 100f) * 360f;
            canvas.drawArc(arcBounds, -90, sweepAngle, false, progressPaint);

            // Glowing comet head bead at active tip
            if (sweepAngle > 0) {
                double tipRad = Math.toRadians(-90 + sweepAngle);
                float beadX = cx + (float) (radius * Math.cos(tipRad));
                float beadY = cy + (float) (radius * Math.sin(tipRad));

                beadPaint.setColor(Color.WHITE);
                canvas.drawCircle(beadX, beadY, dpToPx(5.5f), beadPaint);
                beadPaint.setColor(Color.parseColor("#80C4B5FD"));
                canvas.drawCircle(beadX, beadY, dpToPx(9.0f), beadPaint);
            }
        } else {
            // Simple Mode: Revolving infinite focus loop (swirling 270 deg arc that spins)
            canvas.save();
            canvas.rotate(spinAngle, cx, cy);
            canvas.drawArc(arcBounds, 0, 270, false, progressPaint);

            // Luminous bead
            double tipRad = Math.toRadians(270);
            float beadX = cx + (float) (radius * Math.cos(tipRad));
            float beadY = cy + (float) (radius * Math.sin(tipRad));

            beadPaint.setColor(Color.WHITE);
            canvas.drawCircle(beadX, beadY, dpToPx(5.5f), beadPaint);
            beadPaint.setColor(Color.parseColor("#806EE7B7"));
            canvas.drawCircle(beadX, beadY, dpToPx(9.0f), beadPaint);
            canvas.restore();
        }
    }

    public void setMode(boolean deepMode) {
        this.isDeepMode = deepMode;
        if (getWidth() > 0 && getHeight() > 0) {
            updateShaders(getWidth() / 2f, getHeight() / 2f);
        }
        invalidate();
    }

    public void setProgressPercent(float percent) {
        this.progressPercent = Math.max(0f, Math.min(100f, percent));
        invalidate();
    }

    public void setPaused(boolean paused) {
        this.isPaused = paused;
        invalidate();
    }

    private float dpToPx(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }
}
