package com.abhi.study;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

import androidx.annotation.Nullable;

/**
 * IosTorchFanView:
 * Custom view reproducing the authentic iOS 18 Dynamic Island Flashlight light cone / beam "fan".
 * Renders the illuminated light beam cone with warm amber gradients, radiating rays,
 * apex emitter glow, and subtle breathing luminance.
 */
public class IosTorchFanView extends View {

    private Paint beamPaint;
    private Paint rayPaint;
    private Paint emitterPaint;
    private Paint glowPaint;

    private Path beamPath;
    private float pulseAlpha = 1.0f;
    private ValueAnimator pulseAnimator;

    public IosTorchFanView(Context context) {
        super(context);
        init();
    }

    public IosTorchFanView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public IosTorchFanView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        beamPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        beamPaint.setStyle(Paint.Style.FILL);

        rayPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        rayPaint.setStyle(Paint.Style.STROKE);
        rayPaint.setStrokeWidth(2f);

        emitterPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        emitterPaint.setStyle(Paint.Style.FILL);

        glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        glowPaint.setStyle(Paint.Style.FILL);

        beamPath = new Path();

        startPulseAnimation();
    }

    private void startPulseAnimation() {
        if (pulseAnimator != null) {
            pulseAnimator.cancel();
        }
        pulseAnimator = ValueAnimator.ofFloat(0.88f, 1.0f);
        pulseAnimator.setDuration(1200);
        pulseAnimator.setRepeatCount(ValueAnimator.INFINITE);
        pulseAnimator.setRepeatMode(ValueAnimator.REVERSE);
        pulseAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        pulseAnimator.addUpdateListener(animation -> {
            pulseAlpha = (float) animation.getAnimatedValue();
            invalidate();
        });
        pulseAnimator.start();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int desiredWidth = (int) (160 * getResources().getDisplayMetrics().density);
        int desiredHeight = (int) (90 * getResources().getDisplayMetrics().density);

        int width = resolveSize(desiredWidth, widthMeasureSpec);
        int height = resolveSize(desiredHeight, heightMeasureSpec);
        setMeasuredDimension(width, height);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        float apexX = w / 2f;
        float apexY = 12f;

        float bottomWidth = w * 0.85f;
        float bottomY = h - 6f;
        float leftBottomX = (w - bottomWidth) / 2f;
        float rightBottomX = leftBottomX + bottomWidth;

        // 1. Construct the Light Cone Fan Path
        beamPath.reset();
        beamPath.moveTo(apexX - 10f, apexY + 4f);
        beamPath.lineTo(leftBottomX, bottomY);
        // Subtle curved arc for the light fan's edge
        beamPath.quadTo(apexX, bottomY + 12f, rightBottomX, bottomY);
        beamPath.lineTo(apexX + 10f, apexY + 4f);
        beamPath.close();

        // 2. Linear Gradient for the Beam Fan
        int alphaInt = (int) (255 * pulseAlpha);
        int topColor = Color.argb((int) (alphaInt * 0.95f), 254, 240, 138);  // Warm white #FEF08A
        int midColor = Color.argb((int) (alphaInt * 0.65f), 245, 158, 11);   // Amber glow #F59E0B
        int endColor = Color.argb(0, 217, 119, 6);                           // Fade out

        LinearGradient beamGradient = new LinearGradient(
                apexX, apexY,
                apexX, bottomY,
                new int[]{topColor, midColor, endColor},
                new float[]{0.0f, 0.45f, 1.0f},
                Shader.TileMode.CLAMP
        );
        beamPaint.setShader(beamGradient);
        canvas.drawPath(beamPath, beamPaint);

        // 3. Draw Radiating Rays inside the Fan
        int rayColor = Color.argb((int) (alphaInt * 0.35f), 255, 255, 255);
        rayPaint.setColor(rayColor);

        // Center ray
        canvas.drawLine(apexX, apexY + 6f, apexX, bottomY + 6f, rayPaint);
        // Left rays
        canvas.drawLine(apexX - 4f, apexY + 6f, leftBottomX + (bottomWidth * 0.22f), bottomY + 3f, rayPaint);
        canvas.drawLine(apexX - 7f, apexY + 6f, leftBottomX + (bottomWidth * 0.08f), bottomY, rayPaint);
        // Right rays
        canvas.drawLine(apexX + 4f, apexY + 6f, rightBottomX - (bottomWidth * 0.22f), bottomY + 3f, rayPaint);
        canvas.drawLine(apexX + 7f, apexY + 6f, rightBottomX - (bottomWidth * 0.08f), bottomY, rayPaint);

        // 4. Luminous Emitter Apex Glow
        int glowColorCenter = Color.argb(alphaInt, 255, 255, 255);
        int glowColorEdge = Color.argb(0, 251, 191, 36);
        RadialGradient emitterGlow = new RadialGradient(
                apexX, apexY,
                24f,
                new int[]{glowColorCenter, Color.argb((int) (alphaInt * 0.75f), 251, 191, 36), glowColorEdge},
                new float[]{0.0f, 0.45f, 1.0f},
                Shader.TileMode.CLAMP
        );
        glowPaint.setShader(emitterGlow);
        canvas.drawCircle(apexX, apexY, 22f, glowPaint);

        // 5. Central Emitter Lens Pip
        emitterPaint.setColor(Color.WHITE);
        canvas.drawCircle(apexX, apexY, 5.5f, emitterPaint);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (pulseAnimator != null && !pulseAnimator.isStarted()) {
            pulseAnimator.start();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (pulseAnimator != null) {
            pulseAnimator.cancel();
        }
    }
}
