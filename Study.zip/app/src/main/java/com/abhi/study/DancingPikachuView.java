package com.abhi.study;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

import androidx.annotation.Nullable;

/**
 * DancingPikachuView:
 * A high-fps, hardware-accelerated, native Canvas animated dancing Pikachu!
 * Features:
 * - Rhythmic body bounce, playful ear wiggling, tap-dancing feet, waving hands, and swishing lightning tail.
 * - Rosy electric cheeks with glowing pulse.
 * - Reactive animations: accelerates tempo and brightens cheeks when user touches or drags the slider.
 * - Interactive lean: tilts in the direction of the slider drag.
 */
public class DancingPikachuView extends View {

    private Paint paintBody;
    private Paint paintBlack;
    private Paint paintCheek;
    private Paint paintCheekGlow;
    private Paint paintMouth;
    private Paint paintTongue;
    private Paint paintStroke;
    private Paint paintWhite;
    private Paint paintTailBrown;
    private Paint paintSparkle;

    private Path tailPath;
    private Path earPath;
    private Path earTipPath;
    private Path eyePathLeft;
    private Path eyePathRight;
    private Path mouthPath;
    private Path tonguePath;
    private Path starPath;

    private RectF bodyRect;
    private RectF headRect;
    private RectF handRectLeft;
    private RectF handRectRight;
    private RectF footRectLeft;
    private RectF footRectRight;

    private ValueAnimator danceAnimator;
    private float danceProgress = 0f;
    private boolean isExcited = false;
    private float dragLean = 0f; // -1f (left) to +1f (right)

    public DancingPikachuView(Context context) {
        super(context);
        init();
    }

    public DancingPikachuView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public DancingPikachuView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        paintBody = new Paint(Paint.ANTI_ALIAS_FLAG);
        paintBody.setStyle(Paint.Style.FILL);
        paintBody.setColor(Color.parseColor("#FFD200"));

        paintBlack = new Paint(Paint.ANTI_ALIAS_FLAG);
        paintBlack.setStyle(Paint.Style.FILL);
        paintBlack.setColor(Color.parseColor("#1C1917"));

        paintCheek = new Paint(Paint.ANTI_ALIAS_FLAG);
        paintCheek.setStyle(Paint.Style.FILL);
        paintCheek.setColor(Color.parseColor("#FF2D55"));

        paintCheekGlow = new Paint(Paint.ANTI_ALIAS_FLAG);
        paintCheekGlow.setStyle(Paint.Style.FILL);
        paintCheekGlow.setColor(Color.parseColor("#60FF2D55"));

        paintMouth = new Paint(Paint.ANTI_ALIAS_FLAG);
        paintMouth.setStyle(Paint.Style.FILL);
        paintMouth.setColor(Color.parseColor("#991B1B"));

        paintTongue = new Paint(Paint.ANTI_ALIAS_FLAG);
        paintTongue.setStyle(Paint.Style.FILL);
        paintTongue.setColor(Color.parseColor("#FB7185"));

        paintStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        paintStroke.setStyle(Paint.Style.STROKE);
        paintStroke.setColor(Color.parseColor("#292524"));
        paintStroke.setStrokeWidth(1.6f);
        paintStroke.setStrokeCap(Paint.Cap.ROUND);

        paintWhite = new Paint(Paint.ANTI_ALIAS_FLAG);
        paintWhite.setStyle(Paint.Style.FILL);
        paintWhite.setColor(Color.WHITE);

        paintTailBrown = new Paint(Paint.ANTI_ALIAS_FLAG);
        paintTailBrown.setStyle(Paint.Style.FILL);
        paintTailBrown.setColor(Color.parseColor("#854D0E"));

        paintSparkle = new Paint(Paint.ANTI_ALIAS_FLAG);
        paintSparkle.setStyle(Paint.Style.FILL);
        paintSparkle.setColor(Color.parseColor("#FBBF24"));

        tailPath = new Path();
        earPath = new Path();
        earTipPath = new Path();
        eyePathLeft = new Path();
        eyePathRight = new Path();
        mouthPath = new Path();
        tonguePath = new Path();
        starPath = new Path();

        bodyRect = new RectF();
        headRect = new RectF();
        handRectLeft = new RectF();
        handRectRight = new RectF();
        footRectLeft = new RectF();
        footRectRight = new RectF();

        // Build canonical lightning tail path
        tailPath.moveTo(0, 0);
        tailPath.lineTo(-3, -5);
        tailPath.lineTo(1, -6);
        tailPath.lineTo(-5, -14);
        tailPath.lineTo(2, -15);
        tailPath.lineTo(-7, -25);
        tailPath.lineTo(7, -23);
        tailPath.lineTo(0, -13);
        tailPath.lineTo(5, -12);
        tailPath.lineTo(0, -5);
        tailPath.lineTo(3, -4);
        tailPath.close();

        // Canonical Ear Path
        earPath.moveTo(-5, 0);
        earPath.quadTo(-8, -16, -3, -28);
        earPath.quadTo(2, -28, 5, -16);
        earPath.quadTo(5, -5, 3, 0);
        earPath.close();

        // Canonical Ear Black Tip
        earTipPath.moveTo(-7, -19);
        earTipPath.quadTo(-8, -25, -3, -28);
        earTipPath.quadTo(2, -28, 4, -20);
        earTipPath.close();

        // Canonical 4-point star sparkle path
        starPath.moveTo(0, -4);
        starPath.quadTo(0, 0, 4, 0);
        starPath.quadTo(0, 0, 0, 4);
        starPath.quadTo(0, 0, -4, 0);
        starPath.quadTo(0, 0, 0, -4);
        starPath.close();

        setupDanceAnimation();
    }

    private void setupDanceAnimation() {
        long duration = isExcited ? 550L : 900L;
        if (danceAnimator != null) {
            danceAnimator.cancel();
        }
        danceAnimator = ValueAnimator.ofFloat(0f, 1f);
        danceAnimator.setDuration(duration);
        danceAnimator.setRepeatCount(ValueAnimator.INFINITE);
        danceAnimator.setInterpolator(new LinearInterpolator());
        danceAnimator.addUpdateListener(anim -> {
            danceProgress = (float) anim.getAnimatedValue();
            invalidate();
        });
        danceAnimator.start();
    }

    public void setExcited(boolean excited) {
        if (this.isExcited != excited) {
            this.isExcited = excited;
            setupDanceAnimation();
        }
    }

    public void setDragLean(float lean) {
        this.dragLean = Math.max(-1f, Math.min(1f, lean));
        invalidate();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (danceAnimator != null && !danceAnimator.isRunning()) {
            danceAnimator.start();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (danceAnimator != null) {
            danceAnimator.cancel();
        }
    }

    @Override
    protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        if (visibility == VISIBLE) {
            if (danceAnimator != null && !danceAnimator.isRunning()) {
                danceAnimator.start();
            }
        } else {
            if (danceAnimator != null) {
                danceAnimator.cancel();
            }
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();
        if (width <= 0 || height <= 0) return;

        // Canonical space: 100 x 100
        float scale = Math.min(width, height) / 100f;
        float cx = width / 2f;
        float cy = (height / 2f) + (4f * scale); // slight offset for ears

        float t = danceProgress;
        double angleRad = t * 2.0 * Math.PI;

        // Dance physics:
        // 1) Rhythmic vertical bouncing (two hops per beat)
        float bounceHop = (float) Math.abs(Math.sin(angleRad * 2.0)) * 4.5f * scale;

        // 2) Body sway angle (left to right playful dance rocking)
        float swayAngle = ((float) Math.sin(angleRad) * 11f) + (dragLean * 15f);

        // 3) Ear wiggles (phase shifted)
        float earLeftAngle = -26f + ((float) Math.sin(angleRad + 0.6) * 16f) + (dragLean * 10f);
        float earRightAngle = 26f + ((float) Math.sin(angleRad - 0.6) * 16f) + (dragLean * 10f);

        // 4) Tail wagging (opposite phase for balance)
        float tailWag = -((float) Math.sin(angleRad) * 22f) - (dragLean * 20f);

        // 5) Stepping feet
        float leftFootStep = Math.max(0f, (float) Math.sin(angleRad) * 4f) * scale;
        float rightFootStep = Math.max(0f, -(float) Math.sin(angleRad) * 4f) * scale;

        // 6) Waving hands
        float leftHandWave = (float) Math.sin(angleRad) * 6f * scale;
        float rightHandWave = -(float) Math.sin(angleRad) * 6f * scale;

        // 7) Cheek glow pulse
        float cheekPulse = 1f + (float) Math.abs(Math.sin(angleRad * 2.0)) * (isExcited ? 0.35f : 0.15f);

        // Apply global scale and center translation
        canvas.save();
        canvas.translate(cx, cy - bounceHop);
        canvas.rotate(swayAngle, 0, 0);
        canvas.scale(scale, scale);

        // Gradient shader for Pikachu's golden body
        if (paintBody.getShader() == null) {
            paintBody.setShader(new LinearGradient(
                    0, -25, 0, 25,
                    Color.parseColor("#FFE14D"), Color.parseColor("#F59E0B"),
                    Shader.TileMode.CLAMP
            ));
        }

        // --- 1. TAIL (Behind body) ---
        canvas.save();
        canvas.translate(-10f, 14f);
        canvas.rotate(tailWag, 0, 0);
        // Draw tail base in brown
        canvas.drawCircle(0, 0, 3.5f, paintTailBrown);
        // Draw lightning bolt
        canvas.drawPath(tailPath, paintBody);
        canvas.restore();

        // --- 2. FEET (Stepping tap dance) ---
        footRectLeft.set(-13f, 20f - leftFootStep, -4f, 26f - leftFootStep);
        canvas.drawRoundRect(footRectLeft, 3f, 3f, paintBody);

        footRectRight.set(4f, 20f - rightFootStep, 13f, 26f - rightFootStep);
        canvas.drawRoundRect(footRectRight, 3f, 3f, paintBody);

        // --- 3. EARS ---
        // Left Ear
        canvas.save();
        canvas.translate(-13f, -14f);
        canvas.rotate(earLeftAngle, 0, 0);
        canvas.drawPath(earPath, paintBody);
        canvas.drawPath(earTipPath, paintBlack);
        canvas.restore();

        // Right Ear
        canvas.save();
        canvas.translate(13f, -14f);
        canvas.rotate(earRightAngle, 0, 0);
        canvas.drawPath(earPath, paintBody);
        canvas.drawPath(earTipPath, paintBlack);
        canvas.restore();

        // --- 4. CHUBBY BODY & HEAD ---
        bodyRect.set(-18f, -6f, 18f, 22f);
        canvas.drawRoundRect(bodyRect, 18f, 18f, paintBody);

        headRect.set(-17f, -19f, 17f, 3f);
        canvas.drawRoundRect(headRect, 16f, 16f, paintBody);

        // --- 5. ROSY ELECTRIC CHEEKS ---
        float cheekRadius = 4.4f * cheekPulse;
        if (isExcited) {
            canvas.drawCircle(-12.5f, -3f, cheekRadius * 1.5f, paintCheekGlow);
            canvas.drawCircle(12.5f, -3f, cheekRadius * 1.5f, paintCheekGlow);
        }
        canvas.drawCircle(-12.5f, -3f, cheekRadius, paintCheek);
        canvas.drawCircle(12.5f, -3f, cheekRadius, paintCheek);

        // --- 6. EYES (Blinking / Happy Wink) ---
        // Cheerful blink on beats 0.40 - 0.52
        boolean isBlinking = (t >= 0.40f && t <= 0.52f);
        if (isBlinking || isExcited && (t >= 0.85f)) {
            // Happy cheerful curved eyes ( ^ ‿ ^ )
            eyePathLeft.reset();
            eyePathLeft.moveTo(-10.5f, -9f);
            eyePathLeft.quadTo(-7.5f, -12f, -4.5f, -9f);
            canvas.drawPath(eyePathLeft, paintStroke);

            eyePathRight.reset();
            eyePathRight.moveTo(4.5f, -9f);
            eyePathRight.quadTo(7.5f, -12f, 10.5f, -9f);
            canvas.drawPath(eyePathRight, paintStroke);
        } else {
            // Shiny round eyes
            canvas.drawCircle(-7.5f, -9.5f, 3.0f, paintBlack);
            canvas.drawCircle(7.5f, -9.5f, 3.0f, paintBlack);
            // White highlight glint
            canvas.drawCircle(-6.8f, -10.5f, 1.1f, paintWhite);
            canvas.drawCircle(8.2f, -10.5f, 1.1f, paintWhite);
        }

        // --- 7. NOSE ---
        canvas.drawCircle(0, -5.5f, 0.85f, paintBlack);

        // --- 8. SMILING MOUTH & TONGUE ---
        mouthPath.reset();
        mouthPath.moveTo(-4f, -2.5f);
        mouthPath.quadTo(0, 3.5f, 4f, -2.5f);
        mouthPath.close();
        canvas.drawPath(mouthPath, paintMouth);

        tonguePath.reset();
        tonguePath.moveTo(-2.5f, 0f);
        tonguePath.quadTo(0, 3.2f, 2.5f, 0f);
        tonguePath.close();
        canvas.drawPath(tonguePath, paintTongue);

        // Cat-mouth smile outline
        canvas.drawLine(-4f, -2.5f, 0, -1.8f, paintStroke);
        canvas.drawLine(0, -1.8f, 4f, -2.5f, paintStroke);

        // --- 9. HANDS / PAWS (Waving in rhythm) ---
        handRectLeft.set(-16.5f, 4f + leftHandWave, -8.5f, 11f + leftHandWave);
        canvas.drawRoundRect(handRectLeft, 4f, 4f, paintBody);

        handRectRight.set(8.5f, 4f + rightHandWave, 16.5f, 11f + rightHandWave);
        canvas.drawRoundRect(handRectRight, 4f, 4f, paintBody);

        // --- 10. DANCE SPARKLES / MUSIC STARS ---
        canvas.save();
        float starY1 = -24f - ((float) Math.sin(angleRad) * 3f);
        canvas.translate(-24f, starY1);
        canvas.scale(0.85f, 0.85f);
        canvas.drawPath(starPath, paintSparkle);
        canvas.restore();

        canvas.save();
        float starY2 = -26f + ((float) Math.sin(angleRad + 1.2) * 3f);
        canvas.translate(24f, starY2);
        canvas.scale(0.85f, 0.85f);
        canvas.drawPath(starPath, paintSparkle);
        canvas.restore();

        canvas.restore(); // restore global scale & translation
    }
}
