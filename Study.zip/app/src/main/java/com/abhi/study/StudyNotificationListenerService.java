package com.abhi.study;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/**
 * StudyNotificationListenerService:
 * Real-time notification receiver that intercepts calls and messages
 * strictly for whitelisted study apps (Phone, WhatsApp, SMS).
 */
public class StudyNotificationListenerService extends NotificationListenerService {

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        try {
            StatusBarNotification[] active = getActiveNotifications();
            if (active != null) {
                for (StatusBarNotification sbn : active) {
                    StudyFocusNotificationManager.processPostedNotification(sbn);
                }
            }
        } catch (Exception ignored) {}
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        StudyFocusNotificationManager.processPostedNotification(sbn);
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        StudyFocusNotificationManager.processRemovedNotification(sbn);
    }
}
