package com.abhi.study;

import android.Manifest;
import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import androidx.core.content.ContextCompat;

public class StudyPermissionHelper {

    public static final String[] PHONE_PERMISSIONS = {
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.ANSWER_PHONE_CALLS
    };

    public static boolean isOverlayGranted(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return Settings.canDrawOverlays(context);
        }
        return true;
    }

    public static boolean isNotificationListenerGranted(Context context) {
        return StudyFocusNotificationManager.isNotificationListenerEnabled(context);
    }

    public static boolean isPhonePermissionsGranted(Context context) {
        for (String perm : PHONE_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(context, perm) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    public static boolean isNotificationPostGranted(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                    == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    public static boolean isCameraGranted(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean isBatteryOptimizationIgnored(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                return pm.isIgnoringBatteryOptimizations(context.getPackageName());
            }
        }
        return true;
    }

    public static boolean isDeviceAdminGranted(Context context) {
        DevicePolicyManager dpm = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName adminComponent = new ComponentName(context, StudyDeviceAdminReceiver.class);
        return dpm != null && dpm.isAdminActive(adminComponent);
    }

    public static boolean isGeminiAiConfigured(Context context) {
        return GeminiAiManager.hasValidApiKey(context);
    }

    /**
     * Checks if all required permissions are enabled before entering Simple or Deep mode.
     */
    public static boolean areRequiredPermissionsGranted(Context context, boolean isDeepMode) {
        boolean overlay = isOverlayGranted(context);
        boolean notifListener = isNotificationListenerGranted(context);
        boolean phone = isPhonePermissionsGranted(context);

        if (!overlay || !notifListener || !phone) {
            return false;
        }

        if (isDeepMode) {
            return isDeviceAdminGranted(context);
        }
        return true;
    }

    public static int getGrantedCount(Context context) {
        int count = 0;
        if (isOverlayGranted(context)) count++;
        if (isNotificationListenerGranted(context)) count++;
        if (isPhonePermissionsGranted(context)) count++;
        if (isNotificationPostGranted(context)) count++;
        if (isCameraGranted(context)) count++;
        if (isBatteryOptimizationIgnored(context)) count++;
        if (isDeviceAdminGranted(context)) count++;
        if (isGeminiAiConfigured(context)) count++;
        return count;
    }

    public static int getTotalPermissionsCount() {
        return 8;
    }

    public static void openOverlaySettings(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + context.getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        }
    }

    public static void openNotificationListenerSettings(Context context) {
        Intent intent = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    public static void openBatteryOptimizationSettings(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + context.getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            } catch (Exception e) {
                Intent intent = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        }
    }

    public static void openDeviceAdminSettings(Activity activity, int requestCode) {
        ComponentName comp = new ComponentName(activity, StudyDeviceAdminReceiver.class);
        Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, comp);
        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Study Deep Mode requires Device Administrator privileges to lock distractions during high-focus sessions.");
        activity.startActivityForResult(intent, requestCode);
    }

    public static void openAppSettings(Context context) {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(Uri.parse("package:" + context.getPackageName()));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }
}
