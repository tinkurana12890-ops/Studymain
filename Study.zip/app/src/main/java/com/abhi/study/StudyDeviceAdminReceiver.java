package com.abhi.study;

import android.app.admin.DeviceAdminReceiver;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

/**
 * Device Admin & Device Owner Receiver for Focus OS Study App.
 * Enables true hardware-level Kiosk Lock Task Mode during Deep Focus sessions.
 * Provisioning command:
 *   adb shell dpm set-device-owner com.abhi.study/.StudyDeviceAdminReceiver
 */
public class StudyDeviceAdminReceiver extends DeviceAdminReceiver {

    private static final String TAG = "StudyDeviceAdmin";
    public static final String ACTION_REMOVE_OWNER = "com.abhi.study.REMOVE_DEVICE_OWNER";

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (intent != null && (ACTION_REMOVE_OWNER.equals(intent.getAction()) || "com.abhi.study.ACTION_REMOVE_ADMIN".equals(intent.getAction()))) {
            DevicePolicyManager dpm = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
            if (dpm != null) {
                try {
                    if (dpm.isDeviceOwnerApp(context.getPackageName())) {
                        dpm.clearDeviceOwnerApp(context.getPackageName());
                        Log.i(TAG, "Device Owner cleared successfully.");
                    }
                    ComponentName component = new ComponentName(context, StudyDeviceAdminReceiver.class);
                    if (dpm.isAdminActive(component)) {
                        dpm.removeActiveAdmin(component);
                        Log.i(TAG, "Active Admin removed successfully.");
                    }
                    Toast.makeText(context, "Study App: Device Admin & Owner Removed ✓", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Log.e(TAG, "Failed to remove device admin/owner", e);
                }
            }
        }
    }

    @Override
    public void onEnabled(Context context, Intent intent) {
        super.onEnabled(context, intent);
        Log.i(TAG, "Study Device Admin enabled");
        Toast.makeText(context, "Study Device Admin Active", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDisabled(Context context, Intent intent) {
        super.onDisabled(context, intent);
        Log.i(TAG, "Study Device Admin disabled");
        Toast.makeText(context, "Study Device Admin Disabled", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onLockTaskModeEntering(Context context, Intent intent, String pkg) {
        super.onLockTaskModeEntering(context, intent, pkg);
        Log.i(TAG, "Entered Kiosk Lock Task Mode for: " + pkg);
    }

    @Override
    public void onLockTaskModeExiting(Context context, Intent intent) {
        super.onLockTaskModeExiting(context, intent);
        Log.i(TAG, "Exited Kiosk Lock Task Mode");
    }
}
