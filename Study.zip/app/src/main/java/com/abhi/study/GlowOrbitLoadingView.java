package com.abhi.study;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * High-performance, photorealistic glowing orbital loading animation for Splash screen.
 * Features dual spinning gradient rings, glowing energy aura, orbiting luminous beads,
 * and drifting ambient particles with zero-allocation onDraw loop.
 */
public class GlowOrbitLoadingView extends View {

    private Paint glowPaint;
    private Paint outerRingPaint;
    private Paint innerRingPaint;
    private Paint progressArcPaint;
    private Paint beadPaint;
    private Paint particlePaint;

    private final RectF outerBounds = new RectF();
    private final RectF innerBounds = new RectF();
    private final RectF progressBounds = new RectF();

    private float outerRotation = 0f;
    private float innerRotation = 0f;
    private float pulsePhase = 0f;
    private float progress = 0f; // 0 to 100

    private ValueAnimator rotationAnimator;
    private ValueAnimator pulseAnimator;

    private RadialGradient cachedCoreGlow;
    private final Matrix glowMatrix = new Matrix();

    private static class Particle {
        float x, y;
        float radius;
        float speedY;
        float speedX;
        int alpha;
        int maxAlpha;
        float phase;
    }

    private final List<Particle> particles = new ArrayList<>();
    private final Random random = new Random();

    public GlowOrbitLoadingView(Context context) {
        super(context);
        init();
    }

    public GlowOrbitLoadingView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public GlowOrbitLoadingView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        // Paints
        glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        glowPaint.setStyle(Paint.Style.FILL);

        outerRingPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        outerRingPaint.setStyle(Paint.Style.STROKE);
        outerRingPaint.setStrokeWidth(dpToPx(3.5f));
        outerRingPaint.setStrokeCap(Paint.Cap.ROUND);

        innerRingPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        innerRingPaint.setStyle(Paint.Style.STROKE);
        innerRingPaint.setStrokeWidth(dpToPx(2.5f));
        innerRingPaint.setStrokeCap(Paint.Cap.ROUND);

        progressArcPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        progressArcPaint.setStyle(Paint.Style.STROKE);
        progressArcPaint.setStrokeWidth(dpToPx(4.5f));
        progressArcPaint.setStrokeCap(Paint.Cap.ROUND);
        progressArcPaint.setColor(Color.parseColor("#38BDF8"));

        beadPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        beadPaint.setStyle(Paint.Style.FILL);

        particlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        particlePaint.setStyle(Paint.Style.FILL);

        // Initialize drifting particles
        for (int i = 0; i < 20; i++) {
            Particle p = new Particle();
            resetParticle(p, true);
            particles.add(p);
        }

        setupAnimators();
    }

    private void resetParticle(Particle p, boolean randomY) {
        p.radius = dpToPx(1f + random.nextFloat() * 2f);
        p.speedY = dpToPx(0.3f + random.nextFloat() * 0.7f);
        p.speedX = dpToPx((random.nextFloat() - 0.5f) * 0.4f);
        p.maxAlpha = 90 + random.nextInt(140);
        p.alpha = randomY ? random.nextInt(p.maxAlpha) : 0;
        p.phase = random.nextFloat() * (float) Math.PI * 2f;
    }

    private void setupAnimators() {
        rotationAnimator = ValueAnimator.ofFloat(0f, 360f);
        rotationAnimator.setDuration(2400);
        rotationAnimator.setRepeatCount(ValueAnimator.INFINITE);
        rotationAnimator.setInterpolator(new LinearInterpolator());
        rotationAnimator.addUpdateListener(anim -> {
            float val = (float) anim.getAnimatedValue();
            outerRotation = val;
            innerRotation = -val * 1.35f;
            invalidate();
        });

        pulseAnimator = ValueAnimator.ofFloat(0f, (float) Math.PI * 2f);
        pulseAnimator.setDuration(1800);
        pulseAnimator.setRepeatCount(ValueAnimator.INFINITE);
        pulseAnimator.setInterpolator(new LinearInterpolator());
        pulseAnimator.addUpdateListener(anim -> {
            pulsePhase = (float) anim.getAnimatedValue();
        });
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (rotationAnimator != null && !rotationAnimator.isRunning()) {
            rotationAnimator.start();
        }
        if (pulseAnimator != null && !pulseAnimator.isRunning()) {
            pulseAnimator.start();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (rotationAnimator != null) rotationAnimator.cancel();
        if (pulseAnimator != null) pulseAnimator.cancel();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        float cx = w / 2f;
        float cy = h / 2f;
        float minDim = Math.min(w, h);

        float outerR = minDim * 0.38f;
        float innerR = minDim * 0.28f;
        float progressR = minDim * 0.44f;

        outerBounds.set(cx - outerR, cy - outerR, cx + outerR, cy + outerR);
        innerBounds.set(cx - innerR, cy - innerR, cx + innerR, cy + innerR);
        progressBounds.set(cx - progressR, cy - progressR, cx + progressR, cy + progressR);

        // Precompute base unit core glow shader for zero allocation
        cachedCoreGlow = new RadialGradient(
                0, 0, 100f,
                new int[]{
                        Color.argb(85, 56, 189, 248),
                        Color.argb(35, 129, 140, 248),
                        Color.TRANSPARENT
                },
                new float[]{0.0f, 0.55f, 1.0f},
                Shader.TileMode.CLAMP
        );
        glowPaint.setShader(cachedCoreGlow);

        // Sweep gradient for outer ring: Mint to Cyan
        int[] outerColors = new int[]{
                Color.parseColor("#10B981"),
                Color.parseColor("#06B6D4"),
                Color.parseColor("#38BDF8"),
                Color.parseColor("#0010B981")
        };
        float[] outerPositions = new float[]{0.0f, 0.45f, 0.85f, 1.0f};
        SweepGradient outerShader = new SweepGradient(cx, cy, outerColors, outerPositions);
        outerRingPaint.setShader(outerShader);

        // Sweep gradient for inner ring: Indigo to Violet to Transparent
        int[] innerColors = new int[]{
                Color.parseColor("#8B5CF6"),
                Color.parseColor("#6366F1"),
                Color.parseColor("#A78BFA"),
                Color.parseColor("#008B5CF6")
        };
        float[] innerPositions = new float[]{0.0f, 0.4f, 0.8f, 1.0f};
        SweepGradient innerShader = new SweepGradient(cx, cy, innerColors, innerPositions);
        innerRingPaint.setShader(innerShader);

        // Scatter particles initially
        for (Particle p : particles) {
            p.x = cx + (random.nextFloat() - 0.5f) * minDim * 0.85f;
            p.y = cy + (random.nextFloat() - 0.5f) * minDim * 0.85f;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float minDim = Math.min(getWidth(), getHeight());

        // 1. Draw glowing pulsating core nebula (Zero allocation via Matrix)
        float pulseFactor = 0.85f + 0.15f * (float) Math.sin(pulsePhase);
        float glowRadius = minDim * 0.32f * pulseFactor;

        if (cachedCoreGlow != null) {
            glowMatrix.reset();
            glowMatrix.setScale(glowRadius / 100f, glowRadius / 100f);
            glowMatrix.postTranslate(cx, cy);
            cachedCoreGlow.setLocalMatrix(glowMatrix);
            canvas.drawCircle(cx, cy, glowRadius, glowPaint);
        }

        // 2. Draw ambient particles
        for (Particle p : particles) {
            p.y -= p.speedY;
            p.x += p.speedX;
            p.phase += 0.04f;
            float alphaOsc = (float) Math.sin(p.phase);
            int currentAlpha = (int) (p.maxAlpha * (0.6f + 0.4f * alphaOsc));
            if (currentAlpha < 0) currentAlpha = 0;
            if (currentAlpha > 255) currentAlpha = 255;

            particlePaint.setColor(Color.argb(currentAlpha, 224, 242, 254));
            canvas.drawCircle(p.x, p.y, p.radius, particlePaint);

            // Wrap around boundaries
            if (p.y < cy - minDim * 0.48f || p.x < cx - minDim * 0.48f || p.x > cx + minDim * 0.48f) {
                p.x = cx + (random.nextFloat() - 0.5f) * minDim * 0.8f;
                p.y = cy + minDim * 0.42f;
                resetParticle(p, false);
            }
        }

        // 3. Draw outer rotating gradient ring
        canvas.save();
        canvas.rotate(outerRotation, cx, cy);
        canvas.drawArc(outerBounds, 0, 310, false, outerRingPaint);

        // Luminous comet bead at head of outer ring
        float outerRadius = outerBounds.width() / 2f;
        double headRad = Math.toRadians(310);
        float beadX = cx + (float) (outerRadius * Math.cos(headRad));
        float beadY = cy + (float) (outerRadius * Math.sin(headRad));

        beadPaint.setColor(Color.WHITE);
        canvas.drawCircle(beadX, beadY, dpToPx(4.5f), beadPaint);
        beadPaint.setColor(Color.parseColor("#8038BDF8"));
        canvas.drawCircle(beadX, beadY, dpToPx(7.5f), beadPaint);
        canvas.restore();

        // 4. Draw inner counter-rotating gradient ring
        canvas.save();
        canvas.rotate(innerRotation, cx, cy);
        canvas.drawArc(innerBounds, 0, 270, false, innerRingPaint);

        // Secondary bead at inner ring
        float innerRadius = innerBounds.width() / 2f;
        double innerHeadRad = Math.toRadians(270);
        float innerBeadX = cx + (float) (innerRadius * Math.cos(innerHeadRad));
        float innerBeadY = cy + (float) (innerRadius * Math.sin(innerHeadRad));

        beadPaint.setColor(Color.WHITE);
        canvas.drawCircle(innerBeadX, innerBeadY, dpToPx(3.5f), beadPaint);
        beadPaint.setColor(Color.parseColor("#80C084FC"));
        canvas.drawCircle(innerBeadX, innerBeadY, dpToPx(6.0f), beadPaint);
        canvas.restore();

        // 5. Draw Progress Arc if progress > 0
        if (progress > 0) {
            float sweepAngle = (progress / 100f) * 360f;
            canvas.drawArc(progressBounds, -90, sweepAngle, false, progressArcPaint);
        }
    }

    public void setProgress(float progress) {
        this.progress = Math.max(0, Math.min(100, progress));
        invalidate();
    }

    public float getProgress() {
        return progress;
    }

    private float dpToPx(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }
}
