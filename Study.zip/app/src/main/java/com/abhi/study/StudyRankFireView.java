package com.abhi.study;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.animation.OvershootInterpolator;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageView;

import java.util.Random;

/**
 * StudyRankFireView:
 * Ultimate Animated, Colorful, and Evolving StudyTube Rank Fire View.
 * Features 10 distinct ranks (Level 1 to Level 10).
 * Every 9 hours of watched video lectures pushes the flame to the next rank tier.
 * Features 60fps dynamic procedural flame animation, undulating tongues, rising spark embers,
 * heroic wings, and a godlike golden apex crown.
 */
public class StudyRankFireView extends AppCompatImageView {

    private int rankLevel = 1;
    private boolean isLocked = false;
    private long startTimeMs = 0;

    // Paints
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint outerFlamePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint innerFlamePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint corePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint particlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint auraWingPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint crownPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // Paths
    private final Path outerFlamePath = new Path();
    private final Path innerFlamePath = new Path();
    private final Path leftWingPath = new Path();
    private final Path rightWingPath = new Path();
    private final Path crownPath = new Path();

    // Floating Ember Particle System
    private static final int EMBER_COUNT = 8;
    private final Ember[] embers = new Ember[EMBER_COUNT];
    private final Random random = new Random();

    // 10-Tier Rank Palettes (StudyTube Rank Style)
    // [Primary Outer, Secondary Inner, Core Center, Ambient Glow, Spark Embers]
    private static final int[][] RANK_PALETTES = {
            // Level 1: Bronze Spark (0 - 9 hrs)
            { Color.parseColor("#CD7F32"), Color.parseColor("#D97706"), Color.parseColor("#FDE047"), Color.parseColor("#66CD7F32"), Color.parseColor("#FBBF24") },
            // Level 2: Silver Blaze (9 - 18 hrs)
            { Color.parseColor("#CBD5E1"), Color.parseColor("#94A3B8"), Color.parseColor("#38BDF8"), Color.parseColor("#6694A3B8"), Color.parseColor("#E2E8F0") },
            // Level 3: Gold Inferno (18 - 27 hrs)
            { Color.parseColor("#F59E0B"), Color.parseColor("#FBBF24"), Color.parseColor("#FEF08A"), Color.parseColor("#77F59E0B"), Color.parseColor("#FDE047") },
            // Level 4: Platinum Flame (27 - 36 hrs)
            { Color.parseColor("#06B6D4"), Color.parseColor("#22D3EE"), Color.parseColor("#A7F3D0"), Color.parseColor("#7706B6D4"), Color.parseColor("#67E8F9") },
            // Level 5: Diamond Fire (36 - 45 hrs)
            { Color.parseColor("#3B82F6"), Color.parseColor("#60A5FA"), Color.parseColor("#E0F2FE"), Color.parseColor("#773B82F6"), Color.parseColor("#93C5FD") },
            // Level 6: Heroic Crimson (45 - 54 hrs) - Heroic Tier
            { Color.parseColor("#DC2626"), Color.parseColor("#EF4444"), Color.parseColor("#FDBA74"), Color.parseColor("#88DC2626"), Color.parseColor("#FCA5A5") },
            // Level 7: Master Violet (54 - 63 hrs) - Master Tier
            { Color.parseColor("#7C3AED"), Color.parseColor("#A855F7"), Color.parseColor("#F472B6"), Color.parseColor("#887C3AED"), Color.parseColor("#E9D5FF") },
            // Level 8: Grandmaster Jade (63 - 72 hrs) - Grandmaster Tier
            { Color.parseColor("#059669"), Color.parseColor("#10B981"), Color.parseColor("#6EE7B7"), Color.parseColor("#88059669"), Color.parseColor("#A7F3D0") },
            // Level 9: Challenger Plasma (72 - 81 hrs) - Challenger Tier
            { Color.parseColor("#E11D48"), Color.parseColor("#F43F5E"), Color.parseColor("#FBCFE8"), Color.parseColor("#88E11D48"), Color.parseColor("#FDA4AF") },
            // Level 10: Godlike Apex Nebula (81+ hrs) - Apex Godlike Legend
            { Color.parseColor("#8B5CF6"), Color.parseColor("#EC4899"), Color.parseColor("#FDE047"), Color.parseColor("#99EC4899"), Color.parseColor("#38BDF8") }
    };

    private static class Ember {
        float x;
        float y;
        float size;
        float speedY;
        float swayFrequency;
        float swayPhase;
        float alpha;

        void reset(float width, float height, Random rnd) {
            this.x = width * (0.32f + rnd.nextFloat() * 0.36f);
            this.y = height * (0.65f + rnd.nextFloat() * 0.30f);
            this.size = 2.0f + rnd.nextFloat() * 2.8f;
            this.speedY = 0.5f + rnd.nextFloat() * 0.9f;
            this.swayFrequency = 0.04f + rnd.nextFloat() * 0.05f;
            this.swayPhase = rnd.nextFloat() * 6.28f;
            this.alpha = 0.6f + rnd.nextFloat() * 0.4f;
        }
    }

    public StudyRankFireView(Context context) {
        super(context);
        init();
    }

    public StudyRankFireView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public StudyRankFireView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        startTimeMs = SystemClock.uptimeMillis();

        outerFlamePaint.setStyle(Paint.Style.FILL);
        innerFlamePaint.setStyle(Paint.Style.FILL);
        corePaint.setStyle(Paint.Style.FILL);
        glowPaint.setStyle(Paint.Style.FILL);
        particlePaint.setStyle(Paint.Style.FILL);

        auraWingPaint.setStyle(Paint.Style.FILL);
        crownPaint.setStyle(Paint.Style.FILL);

        // Initialize particles
        for (int i = 0; i < EMBER_COUNT; i++) {
            embers[i] = new Ember();
            embers[i].reset(100f, 100f, random);
            embers[i].y = random.nextFloat() * 100f; // distribute initially
        }
    }

    public void setRankLevel(int level) {
        int old = this.rankLevel;
        this.rankLevel = Math.max(1, Math.min(10, level));
        if (old != this.rankLevel) {
            triggerSurge();
        }
        invalidate();
    }

    public int getRankLevel() {
        return rankLevel;
    }

    public void setLocked(boolean locked) {
        this.isLocked = locked;
        invalidate();
    }

    public boolean isLocked() {
        return isLocked;
    }

    public int getRankScoreColor() {
        int idx = Math.max(0, Math.min(9, rankLevel - 1));
        return RANK_PALETTES[idx][2]; // returns bright core text color
    }

    public int getRankPrimaryColor() {
        int idx = Math.max(0, Math.min(9, rankLevel - 1));
        return RANK_PALETTES[idx][0];
    }

    public void triggerSurge() {
        animate()
                .scaleX(1.30f)
                .scaleY(1.30f)
                .setDuration(160)
                .setInterpolator(new OvershootInterpolator(2.2f))
                .withEndAction(() -> animate().scaleX(1.0f).scaleY(1.0f).setDuration(140).start())
                .start();
    }

    @Override
    protected void onDraw(@NonNull Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) {
            super.onDraw(canvas);
            return;
        }

        if (isLocked) {
            canvas.saveLayerAlpha(0f, 0f, (float) w, (float) h, 115);
        }

        long elapsed = SystemClock.uptimeMillis() - startTimeMs;
        float time = elapsed * 0.001f;

        int idx = Math.max(0, Math.min(9, rankLevel - 1));
        int[] palette = RANK_PALETTES[idx];

        int colorPrimary = palette[0];
        int colorSecondary = palette[1];
        int colorCore = palette[2];
        int colorGlow = palette[3];
        int colorParticle = palette[4];

        float cx = w * 0.5f;
        float cy = h * 0.56f;
        float radius = Math.min(w, h) * 0.44f;

        // 1. Ambient Radial Glow Aura
        float glowRadius = radius * (1.10f + 0.08f * (float) Math.sin(time * 3.5f));
        RadialGradient glowShader = new RadialGradient(cx, cy, glowRadius, colorGlow, Color.TRANSPARENT, Shader.TileMode.CLAMP);
        glowPaint.setShader(glowShader);
        canvas.drawCircle(cx, cy, glowRadius, glowPaint);

        // 2. High Rank Wings / Magma Flares (Level 6+)
        if (rankLevel >= 6) {
            drawRankWings(canvas, cx, cy, w, h, time, colorPrimary, colorSecondary);
        }

        // 3. Dynamic Outer Flame
        float bottomY = h * 0.90f;
        float topY = h * (rankLevel >= 10 ? 0.22f : 0.15f);

        // Sway & flicker tip
        float tipSwayX = (float) Math.sin(time * 6.5f) * (w * 0.07f);
        float tipSwayY = (float) Math.cos(time * 8.0f) * (h * 0.04f);

        // Belly undulations
        float leftBellyWobble = (float) Math.sin(time * 5.0f) * (w * 0.04f);
        float rightBellyWobble = (float) Math.cos(time * 5.5f) * (w * 0.04f);

        outerFlamePath.reset();
        outerFlamePath.moveTo(cx, bottomY);

        // Left flame curve
        outerFlamePath.cubicTo(
                cx - w * (0.34f + leftBellyWobble / w), bottomY - h * 0.22f,
                cx - w * (0.30f - leftBellyWobble / w), cy - h * 0.18f,
                cx + tipSwayX, topY + tipSwayY
        );

        // Right flame curve
        outerFlamePath.cubicTo(
                cx + w * (0.30f + rightBellyWobble / w), cy - h * 0.18f,
                cx + w * (0.34f - rightBellyWobble / w), bottomY - h * 0.22f,
                cx, bottomY
        );
        outerFlamePath.close();

        LinearGradient outerShader = new LinearGradient(
                cx, bottomY,
                cx, topY,
                colorPrimary,
                colorSecondary,
                Shader.TileMode.CLAMP
        );
        outerFlamePaint.setShader(outerShader);
        canvas.drawPath(outerFlamePath, outerFlamePaint);

        // 4. Dynamic Inner Flame Tongue (Out of phase for multi-layered depth)
        float innerTopY = cy - h * 0.18f;
        float innerTipSwayX = (float) Math.cos(time * 7.5f) * (w * 0.05f);

        innerFlamePath.reset();
        innerFlamePath.moveTo(cx, bottomY - h * 0.06f);

        innerFlamePath.cubicTo(
                cx - w * 0.20f, bottomY - h * 0.20f,
                cx - w * 0.16f, cy - h * 0.06f,
                cx + innerTipSwayX, innerTopY
        );

        innerFlamePath.cubicTo(
                cx + w * 0.16f, cy - h * 0.06f,
                cx + w * 0.20f, bottomY - h * 0.20f,
                cx, bottomY - h * 0.06f
        );
        innerFlamePath.close();

        LinearGradient innerShader = new LinearGradient(
                cx, bottomY,
                cx, innerTopY,
                colorSecondary,
                colorCore,
                Shader.TileMode.CLAMP
        );
        innerFlamePaint.setShader(innerShader);
        canvas.drawPath(innerFlamePath, innerFlamePaint);

        // 5. Pulsing White-Hot Hotspot Core
        float corePulse = 0.85f + 0.15f * (float) Math.sin(time * 9.0f);
        float coreRadiusX = w * 0.12f * corePulse;
        float coreRadiusY = h * 0.15f * corePulse;
        corePaint.setColor(colorCore);
        canvas.drawOval(cx - coreRadiusX, bottomY - h * 0.22f, cx + coreRadiusX, bottomY - h * 0.04f, corePaint);

        // 6. Floating Spark Embers / Particles
        particlePaint.setColor(colorParticle);
        for (Ember e : embers) {
            e.y -= e.speedY;
            float sway = (float) Math.sin(time * 5.0f + e.swayPhase) * 4.0f;
            float currentX = e.x + sway;

            if (e.y < topY - h * 0.12f) {
                e.reset(w, h, random);
            }

            float fade = Math.max(0.1f, Math.min(1.0f, (e.y - topY) / (bottomY - topY)));
            particlePaint.setAlpha((int) (fade * 255 * e.alpha));
            canvas.drawCircle(currentX, e.y, e.size, particlePaint);
        }

        // 7. Godlike Golden Apex Crown (Level 10)
        if (rankLevel >= 10) {
            drawApexCrown(canvas, cx, topY - h * 0.02f, w, h, time);
        }

        if (isLocked) {
            canvas.restore();
        }

        // Keep 60fps animation active
        postInvalidateOnAnimation();
    }

    private void drawRankWings(Canvas canvas, float cx, float cy, int w, int h, float time, int colorPrimary, int colorSecondary) {
        float wingSway = (float) Math.sin(time * 4.5f) * (h * 0.03f);
        auraWingPaint.setColor(colorPrimary);
        auraWingPaint.setAlpha(190);

        // Left Wing
        leftWingPath.reset();
        leftWingPath.moveTo(cx - w * 0.16f, cy + h * 0.12f);
        leftWingPath.cubicTo(
                cx - w * 0.46f, cy + h * 0.04f,
                cx - w * 0.48f, cy - h * 0.14f + wingSway,
                cx - w * 0.32f, cy - h * 0.22f + wingSway
        );
        leftWingPath.quadTo(
                cx - w * 0.26f, cy - h * 0.06f,
                cx - w * 0.16f, cy + h * 0.12f
        );
        leftWingPath.close();
        canvas.drawPath(leftWingPath, auraWingPaint);

        // Right Wing
        rightWingPath.reset();
        rightWingPath.moveTo(cx + w * 0.16f, cy + h * 0.12f);
        rightWingPath.cubicTo(
                cx + w * 0.46f, cy + h * 0.04f,
                cx + w * 0.48f, cy - h * 0.14f + wingSway,
                cx + w * 0.32f, cy - h * 0.22f + wingSway
        );
        rightWingPath.quadTo(
                cx + w * 0.26f, cy - h * 0.06f,
                cx + w * 0.16f, cy + h * 0.12f
        );
        rightWingPath.close();
        canvas.drawPath(rightWingPath, auraWingPaint);
    }

    private void drawApexCrown(Canvas canvas, float cx, float topY, int w, int h, float time) {
        float crownFloat = (float) Math.sin(time * 4.0f) * 3.0f;
        float cy = topY - h * 0.08f + crownFloat;
        float cw = w * 0.24f;
        float ch = h * 0.11f;

        crownPath.reset();
        crownPath.moveTo(cx - cw, cy + ch);
        crownPath.lineTo(cx - cw * 1.05f, cy); // left point
        crownPath.lineTo(cx - cw * 0.45f, cy + ch * 0.45f);
        crownPath.lineTo(cx, cy - ch * 0.4f); // center golden apex point
        crownPath.lineTo(cx + cw * 0.45f, cy + ch * 0.45f);
        crownPath.lineTo(cx + cw * 1.05f, cy); // right point
        crownPath.lineTo(cx + cw, cy + ch);
        crownPath.close();

        crownPaint.setColor(Color.parseColor("#FDE047")); // Brilliant Gold Crown
        crownPaint.setAlpha(240);
        canvas.drawPath(crownPath, crownPaint);

        // Sparkling center jewel
        crownPaint.setColor(Color.parseColor("#FFFFFF"));
        canvas.drawCircle(cx, cy - ch * 0.1f, 2.5f, crownPaint);
    }
}
