package com.abhi.study.youtube

import android.util.Xml
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader

/**
 * YouTubeTranscriptParser:
 * High-performance, low-memory parser for YouTube timedtext transcript responses.
 * Supports primary JSON3 (`&fmt=json3`) parsing and seamless XML fallback.
 */
object YouTubeTranscriptParser {

    /**
     * Parses a raw transcript response string into a list of [TranscriptSegment]s.
     * Tries JSON3 first; if the payload starts with '<', delegates to stream XML parsing.
     */
    fun parseTranscript(rawPayload: String): List<TranscriptSegment> {
        if (rawPayload.isBlank()) return emptyList()
        val trimmed = rawPayload.trim()

        return if (trimmed.startsWith("<")) {
            parseXmlTranscript(trimmed)
        } else {
            try {
                parseJson3Transcript(trimmed)
            } catch (e: Exception) {
                // If JSON3 fails, try XML fallback just in case
                if (trimmed.contains("<transcript") || trimmed.contains("<text")) {
                    parseXmlTranscript(trimmed)
                } else {
                    throw e
                }
            }
        }
    }

    /**
     * Parses YouTube's JSON3 timedtext structure:
     * {
     *   "events": [
     *     {
     *       "tStartMs": 1000,
     *       "dDurationMs": 2500,
     *       "segs": [ { "utf8": "text" } ]
     *     }
     *   ]
     * }
     */
    fun parseJson3Transcript(jsonString: String): List<TranscriptSegment> {
        val root = JSONObject(jsonString)
        val events = root.optJSONArray("events") ?: return emptyList()
        val totalEvents = events.length()

        // Pre-allocate ArrayList to avoid memory reallocation
        val segments = ArrayList<TranscriptSegment>(totalEvents)

        for (i in 0 until totalEvents) {
            val event = events.optJSONObject(i) ?: continue

            val startMs = event.optLong("tStartMs", -1L)
            if (startMs < 0L) continue

            val durationMs = event.optLong("dDurationMs", 0L)
            val segs = event.optJSONArray("segs")

            if (segs == null || segs.length() == 0) continue

            val textBuilder = StringBuilder()
            for (j in 0 until segs.length()) {
                val seg = segs.optJSONObject(j) ?: continue
                val utf8 = seg.optString("utf8", "")
                if (utf8.isNotEmpty()) {
                    textBuilder.append(utf8)
                }
            }

            val cleanedText = YouTubeUrlParser.cleanTranscriptText(textBuilder.toString())
            if (cleanedText.isNotBlank()) {
                segments.add(
                    TranscriptSegment(
                        startMs = startMs,
                        durationMs = durationMs,
                        text = cleanedText
                    )
                )
            }
        }

        return segments
    }

    /**
     * Parses standard YouTube XML timedtext using Android's native XmlPullParser:
     * <transcript>
     *   <text start="1.5" dur="2.4">Hello World</text>
     * </transcript>
     */
    fun parseXmlTranscript(xmlString: String): List<TranscriptSegment> {
        val segments = ArrayList<TranscriptSegment>()
        val parser = Xml.newPullParser()
        parser.setInput(StringReader(xmlString))

        var eventType = parser.eventType
        var currentStartMs = 0L
        var currentDurationMs = 0L
        var insideTextTag = false
        val textBuilder = StringBuilder()

        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    if (parser.name.equals("text", ignoreCase = true)) {
                        insideTextTag = true
                        textBuilder.setLength(0)

                        val startSec = parser.getAttributeValue(null, "start")?.toDoubleOrNull() ?: 0.0
                        val durSec = parser.getAttributeValue(null, "dur")?.toDoubleOrNull() ?: 0.0

                        currentStartMs = (startSec * 1000.0).toLong()
                        currentDurationMs = (durSec * 1000.0).toLong()
                    }
                }

                XmlPullParser.TEXT -> {
                    if (insideTextTag) {
                        textBuilder.append(parser.text)
                    }
                }

                XmlPullParser.END_TAG -> {
                    if (parser.name.equals("text", ignoreCase = true)) {
                        insideTextTag = false
                        val cleanedText = YouTubeUrlParser.cleanTranscriptText(textBuilder.toString())
                        if (cleanedText.isNotBlank()) {
                            segments.add(
                                TranscriptSegment(
                                    startMs = currentStartMs,
                                    durationMs = currentDurationMs,
                                    text = cleanedText
                                )
                            )
                        }
                    }
                }
            }
            eventType = parser.next()
        }

        return segments
    }
}
