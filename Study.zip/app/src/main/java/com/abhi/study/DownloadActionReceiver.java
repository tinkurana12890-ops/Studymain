package com.abhi.study;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

/**
 * DownloadActionReceiver:
 * Receives actions directly from the StudyTube download notification (e.g., Cancel & Delete).
 */
public class DownloadActionReceiver extends BroadcastReceiver {

    public static final String ACTION_CANCEL_DELETE_DOWNLOAD = "com.abhi.study.ACTION_CANCEL_DELETE_DOWNLOAD";
    public static final String EXTRA_VIDEO_ID = "extra_video_id";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) return;

        String action = intent.getAction();
        if (ACTION_CANCEL_DELETE_DOWNLOAD.equals(action)) {
            String videoId = intent.getStringExtra(EXTRA_VIDEO_ID);
            if (videoId != null && !videoId.trim().isEmpty()) {
                StudyVideoDownloadManager dm = StudyVideoDownloadManager.getInstance(context);
                dm.cancelDownload(videoId.trim());
                dm.deleteDownload(videoId.trim());
                new Handler(Looper.getMainLooper()).post(() -> {
                    try {
                        Toast.makeText(context.getApplicationContext(), "Download cancelled & deleted ✕", Toast.LENGTH_SHORT).show();
                    } catch (Exception ignored) {}
                });
            }
        }
    }
}
