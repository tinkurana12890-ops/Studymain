package com.abhi.study;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Splash screen featuring high-end glowing orbital loading animations,
 * dynamic progress countdown, sequential status prompts, and seamless
 * transition redirection to MainActivity.
 */
public class SplashActivity extends AppCompatActivity {

    private GlowOrbitLoadingView glowOrbitView;
    private ImageView imgLogo;
    private TextView tvAppTitle;
    private TextView tvSubtitle;
    private TextView tvStatusMessage;
    private TextView tvPercentage;
    private ProgressBar progressBar;
    private View progressCard;
    private View splashRoot;

    // Bottom Developer & Designer Typewriter Credits
    private LinearLayout layoutCredits;
    private TextView tvCredits;
    private TextView tvCursor;

    private final String[] typewriterTexts = new String[]{
            "Developed by Tinku",
            "Designed by Abhishek"
    };
    private int currentTextIndex = 0;
    private int currentCharIndex = 0;
    private boolean isDeleting = false;
    private Handler typewriterHandler;
    private Runnable typewriterRunnable;
    private Runnable cursorBlinkRunnable;
    private boolean isCursorVisible = true;

    private ValueAnimator progressAnimator;
    private ObjectAnimator logoBreathingAnimator;
    private boolean isRedirecting = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Immersive edge-to-edge transparent system bars
        makeEdgeToEdge();

        setContentView(R.layout.activity_splash);

        initViews();
        startEntrancesAndAnimations();
    }

    private void makeEdgeToEdge() {
        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
        }
        int uiOptions = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        window.getDecorView().setSystemUiVisibility(uiOptions);
    }

    private void initViews() {
        splashRoot = findViewById(R.id.splashRoot);
        glowOrbitView = findViewById(R.id.glowOrbitView);
        imgLogo = findViewById(R.id.imgLogo);
        tvAppTitle = findViewById(R.id.tvAppTitle);
        tvSubtitle = findViewById(R.id.tvSubtitle);
        tvStatusMessage = findViewById(R.id.tvStatusMessage);
        tvPercentage = findViewById(R.id.tvPercentage);
        progressBar = findViewById(R.id.progressBar);
        progressCard = findViewById(R.id.progressCard);

        // Bottom Typewriter Credits
        layoutCredits = findViewById(R.id.layoutCredits);
        tvCredits = findViewById(R.id.tvCredits);
        tvCursor = findViewById(R.id.tvCursor);
    }

    private void startEntrancesAndAnimations() {
        // Initial alphas
        tvAppTitle.setAlpha(0f);
        tvAppTitle.setTranslationY(dpToPx(16));
        tvSubtitle.setAlpha(0f);
        tvSubtitle.setTranslationY(dpToPx(12));
        progressCard.setAlpha(0f);
        progressCard.setTranslationY(dpToPx(24));
        if (layoutCredits != null) {
            layoutCredits.setAlpha(0f);
            layoutCredits.setTranslationY(dpToPx(12));
        }

        // Staggered entrance animations
        tvAppTitle.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(800)
                .setStartDelay(200)
                .setInterpolator(new DecelerateInterpolator())
                .start();

        tvSubtitle.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(800)
                .setStartDelay(400)
                .setInterpolator(new DecelerateInterpolator())
                .start();

        progressCard.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(800)
                .setStartDelay(600)
                .setInterpolator(new DecelerateInterpolator())
                .start();

        if (layoutCredits != null) {
            layoutCredits.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setDuration(800)
                    .setStartDelay(700)
                    .setInterpolator(new DecelerateInterpolator())
                    .start();
        }

        // Logo breathing scale animation
        PropertyValuesHolder pvhX = PropertyValuesHolder.ofFloat(View.SCALE_X, 0.94f, 1.06f);
        PropertyValuesHolder pvhY = PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.94f, 1.06f);
        logoBreathingAnimator = ObjectAnimator.ofPropertyValuesHolder(imgLogo, pvhX, pvhY);
        logoBreathingAnimator.setDuration(1600);
        logoBreathingAnimator.setRepeatCount(ValueAnimator.INFINITE);
        logoBreathingAnimator.setRepeatMode(ValueAnimator.REVERSE);
        logoBreathingAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        logoBreathingAnimator.start();

        // Start typewriter loop for "Developed by Tinku" -> "Designed by Abhishek"
        startTypewriterLoop();

        // 0 to 100% Progress Animation
        progressAnimator = ValueAnimator.ofInt(0, 100);
        progressAnimator.setDuration(5800);
        progressAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        progressAnimator.addUpdateListener(anim -> {
            int progress = (int) anim.getAnimatedValue();
            progressBar.setProgress(progress);
            glowOrbitView.setProgress(progress);
            tvPercentage.setText(progress + "%");

            // Update status text dynamically based on milestones
            if (progress < 30) {
                tvStatusMessage.setText(R.string.loading_step_1);
            } else if (progress < 65) {
                tvStatusMessage.setText(R.string.loading_step_2);
            } else if (progress < 92) {
                tvStatusMessage.setText(R.string.loading_step_3);
            } else {
                tvStatusMessage.setText(R.string.loading_step_4);
            }
        });

        progressAnimator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                completeAndRedirect();
            }
        });

        progressAnimator.start();
    }

    /**
     * Infinite Typewriter loop alternating between:
     * 1. "Developed by Tinku"
     * 2. "Designed by Abhishek"
     * with character-by-character typing, reading pause, character backspacing, and smooth glowing cursor blinking.
     */
    private void startTypewriterLoop() {
        if (tvCredits == null) return;

        typewriterHandler = new Handler(Looper.getMainLooper());

        // Blinking glowing cursor loop
        cursorBlinkRunnable = new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed()) return;
                isCursorVisible = !isCursorVisible;
                if (tvCursor != null) {
                    tvCursor.setAlpha(isCursorVisible ? 1.0f : 0.0f);
                }
                if (typewriterHandler != null) {
                    typewriterHandler.postDelayed(this, 450);
                }
            }
        };
        typewriterHandler.post(cursorBlinkRunnable);

        // Character typing and backspacing state machine
        typewriterRunnable = new Runnable() {
            @Override
            public void run() {
                if (isFinishing() || isDestroyed() || isRedirecting) return;

                String fullText = typewriterTexts[currentTextIndex];

                if (!isDeleting) {
                    // Type forward
                    currentCharIndex++;
                    tvCredits.setText(fullText.substring(0, Math.min(currentCharIndex, fullText.length())));

                    if (currentCharIndex >= fullText.length()) {
                        // Finished typing text: hold for 1400ms for comfortable reading
                        isDeleting = true;
                        if (typewriterHandler != null) {
                            typewriterHandler.postDelayed(this, 1400);
                        }
                        return;
                    }
                    // Typing speed: 65ms per character
                    if (typewriterHandler != null) {
                        typewriterHandler.postDelayed(this, 65);
                    }
                } else {
                    // Backspacing
                    currentCharIndex--;
                    tvCredits.setText(fullText.substring(0, Math.max(0, currentCharIndex)));

                    if (currentCharIndex <= 0) {
                        // Finished deleting: move to next text and pause 350ms before typing next
                        isDeleting = false;
                        currentTextIndex = (currentTextIndex + 1) % typewriterTexts.length;
                        if (typewriterHandler != null) {
                            typewriterHandler.postDelayed(this, 350);
                        }
                        return;
                    }
                    // Backspacing speed: 30ms per character
                    if (typewriterHandler != null) {
                        typewriterHandler.postDelayed(this, 30);
                    }
                }
            }
        };

        // Start typing shortly after splash entrance
        typewriterHandler.postDelayed(typewriterRunnable, 400);
    }

    private void completeAndRedirect() {
        if (isRedirecting) return;
        isRedirecting = true;

        if (progressAnimator != null) {
            progressAnimator.cancel();
        }
        if (typewriterHandler != null) {
            typewriterHandler.removeCallbacksAndMessages(null);
        }

        // Smooth cinematic exit transition
        splashRoot.animate()
                .alpha(0f)
                .scaleX(1.04f)
                .scaleY(1.04f)
                .setDuration(450)
                .setInterpolator(new DecelerateInterpolator())
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                        startActivity(intent);
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        finish();
                    }
                })
                .start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (progressAnimator != null) progressAnimator.cancel();
        if (logoBreathingAnimator != null) logoBreathingAnimator.cancel();
        if (typewriterHandler != null) {
            typewriterHandler.removeCallbacksAndMessages(null);
        }
    }

    private float dpToPx(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }
}
