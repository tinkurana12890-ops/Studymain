package com.abhi.study;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

/**
 * StudyPhoneStateReceiver:
 * Broadcast receiver that catches native phone incoming calls,
 * answers, and terminations in real-time across all Android devices.
 */
public class StudyPhoneStateReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;

        if (TelephonyManager.ACTION_PHONE_STATE_CHANGED.equals(intent.getAction())) {
            String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);

            if (TelephonyManager.EXTRA_STATE_RINGING.equals(state)) {
                String number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);
                if (TextUtils.isEmpty(number)) {
                    number = intent.getStringExtra("incoming_number");
                }
                StudyFocusNotificationManager.onPhoneRinging(context, number);
            } else if (TelephonyManager.EXTRA_STATE_OFFHOOK.equals(state)) {
                StudyFocusNotificationManager.onPhoneOffhook(context);
            } else if (TelephonyManager.EXTRA_STATE_IDLE.equals(state)) {
                StudyFocusNotificationManager.onPhoneIdle(context);
            }
        }
    }
}
