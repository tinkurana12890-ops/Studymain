package com.abhi.study;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

public class StudyQuizManager {

    private static final String TAG = "StudyQuizManager";
    private static final String PREF_NAME = "study_quiz_storage";
    private static final String KEY_QUIZZES_JSON = "saved_quizzes_json";

    public static class QuizQuestion implements Serializable {
        public String question;
        public List<String> options;
        public int correctIndex;
        public String explanation;
        public int userSelectedIndex = -1;

        public QuizQuestion() {
            this.options = new ArrayList<>();
        }

        public QuizQuestion(String question, List<String> options, int correctIndex, String explanation) {
            this.question = question;
            this.options = options;
            this.correctIndex = correctIndex;
            this.explanation = explanation;
            this.userSelectedIndex = -1;
        }

        public JSONObject toJson() {
            try {
                JSONObject obj = new JSONObject();
                obj.put("question", question != null ? question : "");
                JSONArray optArr = new JSONArray();
                if (options != null) {
                    for (String opt : options) {
                        optArr.put(opt);
                    }
                }
                obj.put("options", optArr);
                obj.put("correctIndex", correctIndex);
                obj.put("explanation", explanation != null ? explanation : "");
                obj.put("userSelectedIndex", userSelectedIndex);
                return obj;
            } catch (Exception e) {
                Log.e(TAG, "Error serializing QuizQuestion", e);
                return new JSONObject();
            }
        }

        public static QuizQuestion fromJson(JSONObject obj) {
            if (obj == null) return null;
            QuizQuestion q = new QuizQuestion();
            q.question = obj.optString("question", "");
            q.correctIndex = obj.optInt("correctIndex", 0);
            q.explanation = obj.optString("explanation", "");
            q.userSelectedIndex = obj.optInt("userSelectedIndex", -1);
            JSONArray optArr = obj.optJSONArray("options");
            q.options = new ArrayList<>();
            if (optArr != null) {
                for (int i = 0; i < optArr.length(); i++) {
                    q.options.add(optArr.optString(i, ""));
                }
            }
            return q;
        }
    }

    public static class SavedQuizRecord implements Serializable {
        public String id;
        public String videoId;
        public String videoTitle;
        public String subject;
        public long timestamp;
        public int score;
        public int totalQuestions;
        public boolean passed;
        public boolean penaltyCharged;
        public List<QuizQuestion> questions;

        public SavedQuizRecord() {
            this.id = UUID.randomUUID().toString();
            this.timestamp = System.currentTimeMillis();
            this.questions = new ArrayList<>();
            this.totalQuestions = 20;
        }

        public JSONObject toJson() {
            try {
                JSONObject obj = new JSONObject();
                obj.put("id", id);
                obj.put("videoId", videoId != null ? videoId : "");
                obj.put("videoTitle", videoTitle != null ? videoTitle : "");
                obj.put("subject", subject != null ? subject : "");
                obj.put("timestamp", timestamp);
                obj.put("score", score);
                obj.put("totalQuestions", totalQuestions);
                obj.put("passed", passed);
                obj.put("penaltyCharged", penaltyCharged);

                JSONArray qArr = new JSONArray();
                if (questions != null) {
                    for (QuizQuestion q : questions) {
                        qArr.put(q.toJson());
                    }
                }
                obj.put("questions", qArr);
                return obj;
            } catch (Exception e) {
                Log.e(TAG, "Error serializing SavedQuizRecord", e);
                return new JSONObject();
            }
        }

        public static SavedQuizRecord fromJson(JSONObject obj) {
            if (obj == null) return null;
            SavedQuizRecord record = new SavedQuizRecord();
            record.id = obj.optString("id", UUID.randomUUID().toString());
            record.videoId = obj.optString("videoId", "");
            record.videoTitle = obj.optString("videoTitle", "");
            record.subject = obj.optString("subject", "General");
            record.timestamp = obj.optLong("timestamp", System.currentTimeMillis());
            record.score = obj.optInt("score", 0);
            record.totalQuestions = obj.optInt("totalQuestions", 20);
            record.passed = obj.optBoolean("passed", false);
            record.penaltyCharged = obj.optBoolean("penaltyCharged", false);

            JSONArray qArr = obj.optJSONArray("questions");
            record.questions = new ArrayList<>();
            if (qArr != null) {
                for (int i = 0; i < qArr.length(); i++) {
                    JSONObject qObj = qArr.optJSONObject(i);
                    if (qObj != null) {
                        record.questions.add(QuizQuestion.fromJson(qObj));
                    }
                }
            }
            return record;
        }
    }

    public static class QuizStats {
        public int totalQuizzes = 0;
        public int passedCount = 0;
        public int failedCount = 0;
        public double averageScore = 0.0;
        public int totalQuestionsAnswered = 0;

        public int getPassRatePercent() {
            if (totalQuizzes == 0) return 0;
            return (int) Math.round((passedCount / (double) totalQuizzes) * 100);
        }
    }

    private static SharedPreferences getPrefs(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static synchronized void saveQuiz(Context context, SavedQuizRecord quiz) {
        if (context == null || quiz == null) return;
        try {
            List<SavedQuizRecord> existing = getAllQuizzes(context);
            // Insert at the beginning so latest is first
            existing.add(0, quiz);

            JSONArray arr = new JSONArray();
            for (SavedQuizRecord r : existing) {
                arr.put(r.toJson());
            }

            getPrefs(context).edit().putString(KEY_QUIZZES_JSON, arr.toString()).apply();
            Log.d(TAG, "Saved quiz: " + quiz.id + " score: " + quiz.score + "/" + quiz.totalQuestions);
        } catch (Exception e) {
            Log.e(TAG, "Failed to save quiz", e);
        }
    }

    public static synchronized List<SavedQuizRecord> getAllQuizzes(Context context) {
        List<SavedQuizRecord> list = new ArrayList<>();
        if (context == null) return list;
        try {
            String json = getPrefs(context).getString(KEY_QUIZZES_JSON, null);
            if (json == null || json.trim().isEmpty()) {
                return list;
            }
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.optJSONObject(i);
                if (obj != null) {
                    SavedQuizRecord rec = SavedQuizRecord.fromJson(obj);
                    if (rec != null) list.add(rec);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to load quizzes", e);
        }
        return list;
    }

    public static QuizStats getQuizStats(Context context) {
        QuizStats stats = new QuizStats();
        List<SavedQuizRecord> list = getAllQuizzes(context);
        stats.totalQuizzes = list.size();
        if (list.isEmpty()) return stats;

        int scoreSum = 0;
        for (SavedQuizRecord r : list) {
            if (r.passed) stats.passedCount++;
            else stats.failedCount++;
            scoreSum += r.score;
            stats.totalQuestionsAnswered += r.totalQuestions;
        }
        stats.averageScore = (double) scoreSum / list.size();
        return stats;
    }

    public static synchronized boolean deleteQuiz(Context context, String quizId) {
        if (context == null || quizId == null) return false;
        try {
            List<SavedQuizRecord> existing = getAllQuizzes(context);
            boolean removed = false;
            for (int i = 0; i < existing.size(); i++) {
                if (quizId.equals(existing.get(i).id)) {
                    existing.remove(i);
                    removed = true;
                    break;
                }
            }
            if (removed) {
                JSONArray arr = new JSONArray();
                for (SavedQuizRecord r : existing) {
                    arr.put(r.toJson());
                }
                getPrefs(context).edit().putString(KEY_QUIZZES_JSON, arr.toString()).apply();
                Log.d(TAG, "Deleted quiz: " + quizId);
                return true;
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to delete quiz: " + quizId, e);
        }
        return false;
    }

    public static void clearAllQuizzes(Context context) {
        if (context != null) {
            getPrefs(context).edit().remove(KEY_QUIZZES_JSON).apply();
        }
    }
}
