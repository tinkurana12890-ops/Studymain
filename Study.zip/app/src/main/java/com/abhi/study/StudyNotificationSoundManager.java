package com.abhi.study;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.util.Log;

import java.io.File;

/**
 * StudyNotificationSoundManager:
 * Dedicated audio manager to play the custom iOS-style ringtone (ringtone.m4a)
 * whenever a new notification or call arrives in the Control Panel / Dynamic Island.
 */
public class StudyNotificationSoundManager {

    private static final String TAG = "StudySoundManager";
    private static MediaPlayer activeMediaPlayer = null;
    private static final Object lock = new Object();

    /**
     * Plays the custom ringtone.m4a sound with clean volume, notification audio attributes,
     * and subtle tactile vibration feedback.
     */
    public static void playNotificationSound(final Context context) {
        if (context == null) return;

        new Thread(() -> {
            synchronized (lock) {
                try {
                    // 1. Release previous player instance if playing
                    if (activeMediaPlayer != null) {
                        try {
                            if (activeMediaPlayer.isPlaying()) {
                                activeMediaPlayer.stop();
                            }
                            activeMediaPlayer.reset();
                            activeMediaPlayer.release();
                        } catch (Exception ignored) {}
                        activeMediaPlayer = null;
                    }

                    // 2. Subtle iOS tactile notification vibration
                    triggerTactileVibration(context);

                    // 3. Initialize MediaPlayer with notification audio stream
                    MediaPlayer player = new MediaPlayer();

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        AudioAttributes attrs = new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .build();
                        player.setAudioAttributes(attrs);
                    } else {
                        player.setAudioStreamType(AudioManager.STREAM_NOTIFICATION);
                    }

                    boolean dataSourceSet = false;

                    // Option A: Open from Android AssetManager ("ringtone.m4a")
                    try {
                        AssetFileDescriptor afd = context.getAssets().openFd("ringtone.m4a");
                        if (afd != null) {
                            player.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                            afd.close();
                            dataSourceSet = true;
                        }
                    } catch (Exception ignored) {}

                    // Option B: Open from Raw Resource (R.raw.ringtone)
                    if (!dataSourceSet) {
                        try {
                            AssetFileDescriptor rawAfd = context.getResources().openRawResourceFd(R.raw.ringtone);
                            if (rawAfd != null) {
                                player.setDataSource(rawAfd.getFileDescriptor(), rawAfd.getStartOffset(), rawAfd.getLength());
                                rawAfd.close();
                                dataSourceSet = true;
                            }
                        } catch (Exception ignored) {}
                    }

                    // Option C: Check app cache / files directory fallback
                    if (!dataSourceSet) {
                        File fallbackFile = new File("/storage/emulated/0/Android_apps/Study/app/src/main/assets/ringtone.m4a");
                        if (fallbackFile.exists() && fallbackFile.canRead()) {
                            try {
                                player.setDataSource(fallbackFile.getAbsolutePath());
                                dataSourceSet = true;
                            } catch (Exception ignored) {}
                        }
                    }

                    // Option D: Fallback to System Default Notification Sound
                    if (!dataSourceSet) {
                        Uri defaultUri = Settings.System.DEFAULT_NOTIFICATION_URI;
                        player.setDataSource(context, defaultUri);
                    }

                    player.setVolume(1.0f, 1.0f);
                    player.prepare();
                    player.setOnCompletionListener(mp -> {
                        synchronized (lock) {
                            try {
                                mp.reset();
                                mp.release();
                            } catch (Exception ignored) {}
                            if (activeMediaPlayer == mp) {
                                activeMediaPlayer = null;
                            }
                        }
                    });

                    player.setOnErrorListener((mp, what, extra) -> {
                        synchronized (lock) {
                            try {
                                mp.reset();
                                mp.release();
                            } catch (Exception ignored) {}
                            if (activeMediaPlayer == mp) {
                                activeMediaPlayer = null;
                            }
                        }
                        return true;
                    });

                    activeMediaPlayer = player;
                    player.start();
                    Log.i(TAG, "Notification ringtone sound played successfully");

                } catch (Exception e) {
                    Log.e(TAG, "Failed to play notification sound", e);
                }
            }
        }).start();
    }

    private static void triggerTactileVibration(Context context) {
        try {
            Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    // Authentic iOS double-tap haptic pulse (40ms on, 60ms off, 40ms on)
                    long[] pattern = new long[]{0, 35, 65, 45};
                    int[] amplitudes = new int[]{0, 180, 0, 220};
                    vibrator.vibrate(VibrationEffect.createWaveform(pattern, amplitudes, -1));
                } else {
                    vibrator.vibrate(new long[]{0, 40, 60, 40}, -1);
                }
            }
        } catch (Exception ignored) {}
    }
}
