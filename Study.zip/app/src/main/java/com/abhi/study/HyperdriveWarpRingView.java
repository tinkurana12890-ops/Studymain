package com.abhi.study;

import android.content.Context;
import android.util.AttributeSet;
import androidx.annotation.Nullable;

/**
 * HyperdriveWarpRingView:
 * Direct class for the Hyperdrive Warp Ring Spinner (.spinner-38):
 * - Circular 46px x 46px geometry with 2px stroke
 * - Transparent side borders, dual opposite glowing cyan (#38bdf8) arcs on top and bottom
 * - Authentic 14px cyan box-shadow radiant glow (box-shadow: 0 0 14px #38bdf8)
 * - Ultra-fast 0.5s linear infinite rotation (animation: spin1 0.5s linear infinite)
 */
public class HyperdriveWarpRingView extends PlanetaryGyroscopeView {

    public HyperdriveWarpRingView(Context context) {
        super(context);
    }

    public HyperdriveWarpRingView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public HyperdriveWarpRingView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
