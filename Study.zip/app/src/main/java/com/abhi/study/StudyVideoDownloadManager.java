package com.abhi.study;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;

import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * StudyVideoDownloadManager:
 * Complete native real multi-quality video downloader for StudyTube lectures.
 * - Resolves direct MP4 and adaptive streams (1080p, 720p, 480p, 360p, Audio) via MediaStreamResolver.
 * - Downloads stream byte-by-byte into app-scoped media storage.
 * - Real-time Android notification with progress bar, downloaded MBs, and completion notice.
 * - Persistent downloads registry with automatic offline video playback.
 * - WakeLock management to ensure downloads finish uninterrupted.
 */
public class StudyVideoDownloadManager {

    private static final String PREF_NAME = "studytube_downloads_pref";
    private static final String KEY_SAVED_DOWNLOADS = "key_saved_downloaded_lectures";
    public static final String CHANNEL_ID = "studytube_downloads_channel";

    private static volatile StudyVideoDownloadManager instance;

    private final Context appContext;
    private final NotificationManager notificationManager;
    private final ExecutorService executorService = Executors.newFixedThreadPool(2);
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final List<DownloadListener> listeners = new CopyOnWriteArrayList<>();
    private final Map<String, DownloadTask> activeTasks = Collections.synchronizedMap(new HashMap<>());

    private PowerManager.WakeLock wakeLock;

    public interface DownloadListener {
        void onDownloadProgress(String videoId, int progress, long bytesDownloaded, long totalBytes);
        void onDownloadCompleted(String videoId, File file);
        void onDownloadFailed(String videoId, String error);
        void onDownloadsChanged();
    }

    public static class DownloadTask {
        public final Class11Video video;
        public final int notificationId;
        public String requestedQuality = "720p";
        public boolean isAudioOnly = false;
        public int progress = 0;
        public long bytesDownloaded = 0;
        public long totalBytes = -1;
        public boolean isDownloading = true;
        public String statusMessage = "Connecting...";
        public final AtomicBoolean isCancelled = new AtomicBoolean(false);
        public volatile HttpURLConnection currentConnection = null;

        public DownloadTask(Class11Video video, int notificationId) {
            this.video = video;
            this.notificationId = notificationId;
        }
    }

    public static StudyVideoDownloadManager getInstance(Context context) {
        if (instance == null) {
            synchronized (StudyVideoDownloadManager.class) {
                if (instance == null) {
                    instance = new StudyVideoDownloadManager(context.getApplicationContext());
                }
            }
        }
        return instance;
    }

    private StudyVideoDownloadManager(Context context) {
        this.appContext = context;
        this.notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        createNotificationChannel();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "StudyTube Lecture Downloads",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Progress and status for offline lecture downloads");
            channel.enableVibration(false);
            channel.setSound(null, null);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }

    public void addListener(DownloadListener listener) {
        if (listener != null && !listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    public void removeListener(DownloadListener listener) {
        if (listener != null) {
            listeners.remove(listener);
        }
    }

    public Map<String, DownloadTask> getActiveTasks() {
        return new HashMap<>(activeTasks);
    }

    public boolean isDownloading(String videoId) {
        return videoId != null && activeTasks.containsKey(videoId);
    }

    public DownloadTask getActiveTask(String videoId) {
        if (videoId == null) return null;
        return activeTasks.get(videoId);
    }

    public File getDownloadDirectory() {
        File dir = appContext.getExternalFilesDir(Environment.DIRECTORY_MOVIES);
        if (dir == null) {
            dir = new File(appContext.getFilesDir(), "downloads");
        }
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }

    public File getDownloadedFile(String videoId) {
        if (videoId == null) return null;
        File dir = getDownloadDirectory();
        File file = new File(dir, "lecture_" + videoId.trim() + ".mp4");
        if (file.exists() && file.length() > 0) {
            return file;
        }
        File audioFile = new File(dir, "lecture_" + videoId.trim() + ".m4a");
        if (audioFile.exists() && audioFile.length() > 0) {
            return audioFile;
        }
        return null;
    }

    public File getDownloadedVideoFile(String videoId) {
        if (videoId == null) return null;
        File dir = getDownloadDirectory();
        File file = new File(dir, "lecture_" + videoId.trim() + ".mp4");
        if (file.exists() && file.length() > 0) {
            return file;
        }
        return null;
    }

    public File getDownloadedAudioFile(String videoId) {
        if (videoId == null) return null;
        File dir = getDownloadDirectory();
        File file = new File(dir, "lecture_" + videoId.trim() + ".m4a");
        if (file.exists() && file.length() > 0) {
            return file;
        }
        return null;
    }

    public boolean isDownloaded(String videoId) {
        File file = getDownloadedFile(videoId);
        return file != null && file.exists() && file.length() > 1024;
    }

    public synchronized void startDownload(final Class11Video video) {
        startDownload(video, "720p");
    }

    public synchronized void startDownload(final Class11Video video, final String requestedQuality) {
        if (video == null || video.getId() == null) return;
        final String videoId = video.getId().trim();

        if (isDownloaded(videoId)) {
            return;
        }

        if (activeTasks.containsKey(videoId)) {
            return;
        }

        acquireWakeLock();

        final int notificationId = Math.abs(videoId.hashCode());
        final DownloadTask task = new DownloadTask(video, notificationId);
        task.requestedQuality = requestedQuality != null ? requestedQuality : "720p";
        activeTasks.put(videoId, task);

        // Show Initial Notification: "Resolving stream..."
        updateNotification(task, 0, -1, "Resolving " + task.requestedQuality + " stream...", true);
        notifyDownloadsChanged();

        // Step 1: Resolve Multi-Quality Stream
        MediaStreamResolver.resolveMediaStream(appContext, videoId, new MediaStreamResolver.StreamResultCallback() {
            @Override
            public void onStreamsResolved(final MediaStreamResolver.MediaStreamResult result) {
                if (task.isCancelled.get()) {
                    finishTask(videoId, false);
                    return;
                }

                MediaStreamResolver.VideoStreamInfo selected = result.getStreamForQuality(task.requestedQuality);
                if (selected == null) {
                    selected = result.bestStream != null ? result.bestStream : result.progressiveStream;
                }

                if (selected == null && result.audioUrl != null) {
                    task.isAudioOnly = true;
                    final String aUrl = result.audioUrl;
                    executorService.execute(() -> executeSingleUrlDownload(task, aUrl, ".m4a", "Audio Track"));
                    return;
                }

                if (selected == null) {
                    handleDownloadError(task, "No playable stream found for " + task.requestedQuality);
                    return;
                }

                final MediaStreamResolver.VideoStreamInfo streamToDownload = selected;
                executorService.execute(() -> executeVideoStreamDownload(task, streamToDownload));
            }

            @Override
            public void onError(final String message) {
                handleDownloadError(task, message != null ? message : "Unable to extract stream");
            }
        });
    }

    public synchronized void startAudioDownload(final Class11Video video) {
        if (video == null || video.getId() == null) return;
        final String videoId = video.getId().trim();

        if (isDownloaded(videoId)) {
            return;
        }

        if (activeTasks.containsKey(videoId)) {
            return;
        }

        acquireWakeLock();

        final int notificationId = Math.abs(videoId.hashCode());
        final DownloadTask task = new DownloadTask(video, notificationId);
        task.isAudioOnly = true;
        task.requestedQuality = "Focus Audio";
        activeTasks.put(videoId, task);

        updateNotification(task, 0, -1, "Resolving audio track...", true);
        notifyDownloadsChanged();

        MediaStreamResolver.resolveMediaStream(appContext, videoId, new MediaStreamResolver.StreamResultCallback() {
            @Override
            public void onStreamsResolved(final MediaStreamResolver.MediaStreamResult result) {
                if (task.isCancelled.get()) {
                    finishTask(videoId, false);
                    return;
                }
                String audioUrl = result.audioUrl;
                if (audioUrl == null && result.progressiveStream != null) {
                    audioUrl = result.progressiveStream.videoUrl;
                }
                if (audioUrl == null && result.bestStream != null) {
                    audioUrl = result.bestStream.videoUrl;
                }

                if (audioUrl != null) {
                    final String finalAudio = audioUrl;
                    executorService.execute(() -> executeSingleUrlDownload(task, finalAudio, ".m4a", "Focus Audio"));
                } else {
                    handleDownloadError(task, "Audio track unavailable");
                }
            }

            @Override
            public void onError(final String message) {
                handleDownloadError(task, message != null ? message : "Unable to resolve audio");
            }
        });
    }

    private void executeVideoStreamDownload(final DownloadTask task, final MediaStreamResolver.VideoStreamInfo streamInfo) {
        final String videoId = task.video.getId();
        File dir = getDownloadDirectory();
        File tempVideoFile = new File(dir, "lecture_" + videoId + ".mp4.tmp");
        File finalVideoFile = new File(dir, "lecture_" + videoId + ".mp4");

        // Download Video Stream
        boolean videoSuccess = downloadUrlToFile(task, streamInfo.videoUrl, tempVideoFile, 0.0, streamInfo.isProgressive ? 1.0 : 0.85, streamInfo.qualityLabel + " Video");
        if (!videoSuccess || task.isCancelled.get()) {
            if (tempVideoFile.exists()) tempVideoFile.delete();
            return;
        }

        if (tempVideoFile.exists() && tempVideoFile.length() > 0) {
            if (finalVideoFile.exists()) finalVideoFile.delete();
            boolean renamed = tempVideoFile.renameTo(finalVideoFile);
            if (!renamed) {
                finalVideoFile = tempVideoFile;
            }
        } else {
            handleDownloadError(task, "Downloaded video file is empty");
            return;
        }

        // If adaptive (video only), download separate audio track
        if (!streamInfo.isProgressive && streamInfo.audioUrl != null && !streamInfo.audioUrl.isEmpty()) {
            File tempAudioFile = new File(dir, "lecture_" + videoId + ".m4a.tmp");
            File finalAudioFile = new File(dir, "lecture_" + videoId + ".m4a");

            boolean audioSuccess = downloadUrlToFile(task, streamInfo.audioUrl, tempAudioFile, 0.85, 1.0, "Audio Track");
            if (audioSuccess && tempAudioFile.exists() && tempAudioFile.length() > 0) {
                if (finalAudioFile.exists()) finalAudioFile.delete();
                tempAudioFile.renameTo(finalAudioFile);
            }
        }

        // Save persistent record and complete
        saveDownloadedRecord(task.video, finalVideoFile);
        showDownloadCompleteNotification(task);
        finishTask(videoId, true);
        notifyComplete(videoId, finalVideoFile);
    }

    private void executeSingleUrlDownload(final DownloadTask task, final String url, String extension, String title) {
        final String videoId = task.video.getId();
        File dir = getDownloadDirectory();
        File tempFile = new File(dir, "lecture_" + videoId + extension + ".tmp");
        File finalFile = new File(dir, "lecture_" + videoId + extension);

        boolean success = downloadUrlToFile(task, url, tempFile, 0.0, 1.0, title);
        if (!success || task.isCancelled.get()) {
            if (tempFile.exists()) tempFile.delete();
            return;
        }

        if (tempFile.exists() && tempFile.length() > 0) {
            if (finalFile.exists()) finalFile.delete();
            boolean renamed = tempFile.renameTo(finalFile);
            if (!renamed) {
                finalFile = tempFile;
            }
            saveDownloadedRecord(task.video, finalFile);
            showDownloadCompleteNotification(task);
            finishTask(videoId, true);
            notifyComplete(videoId, finalFile);
        } else {
            handleDownloadError(task, "Downloaded file is empty");
        }
    }

    private boolean downloadUrlToFile(final DownloadTask task, final String streamUrl, final File destFile,
                                     final double progressStartRatio, final double progressEndRatio, final String phaseLabel) {
        final String videoId = task.video.getId();
        HttpURLConnection conn = null;
        InputStream is = null;
        FileOutputStream fos = null;

        try {
            URL url = new URL(streamUrl);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(20000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");

            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_MOVED_TEMP || responseCode == HttpURLConnection.HTTP_MOVED_PERM || responseCode == 307) {
                String redirectUrl = conn.getHeaderField("Location");
                if (redirectUrl != null) {
                    conn.disconnect();
                    url = new URL(redirectUrl);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(15000);
                    conn.setReadTimeout(20000);
                    conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
                    responseCode = conn.getResponseCode();
                }
            }

            if (responseCode != HttpURLConnection.HTTP_OK && responseCode != HttpURLConnection.HTTP_PARTIAL) {
                throw new Exception("HTTP server response " + responseCode);
            }

            long contentLength = conn.getContentLengthLong();
            if (contentLength > 0 && task.totalBytes <= 0) {
                task.totalBytes = contentLength;
            }

            is = conn.getInputStream();
            fos = new FileOutputStream(destFile);

            byte[] buffer = new byte[16384];
            int read;
            long streamDownloaded = 0;
            long lastNotificationTime = 0;

            while ((read = is.read(buffer)) != -1) {
                if (task.isCancelled.get()) {
                    try { fos.close(); } catch (Exception ignored) {}
                    try { is.close(); } catch (Exception ignored) {}
                    if (destFile.exists()) destFile.delete();
                    finishTask(videoId, false);
                    cancelNotification(task.notificationId);
                    return false;
                }

                fos.write(buffer, 0, read);
                streamDownloaded += read;
                task.bytesDownloaded += read;

                int overallProgress = 0;
                if (contentLength > 0) {
                    double phasePct = (double) streamDownloaded / (double) contentLength;
                    double overallPct = progressStartRatio + (phasePct * (progressEndRatio - progressStartRatio));
                    overallProgress = (int) (overallPct * 100);
                    if (overallProgress > 100) overallProgress = 100;
                }
                task.progress = overallProgress;

                long now = System.currentTimeMillis();
                if (now - lastNotificationTime >= 400 || (contentLength > 0 && streamDownloaded == contentLength)) {
                    lastNotificationTime = now;
                    String status = formatProgressStatus(streamDownloaded, contentLength, task.requestedQuality);
                    task.statusMessage = status;
                    updateNotification(task, overallProgress, contentLength, status, false);
                    notifyProgress(videoId, overallProgress, task.bytesDownloaded, task.totalBytes);
                }
            }

            fos.flush();
            fos.close();
            fos = null;
            is.close();
            is = null;
            return true;

        } catch (final Exception e) {
            if (destFile.exists()) destFile.delete();
            handleDownloadError(task, e.getMessage() != null ? e.getMessage() : "Download network error");
            return false;
        } finally {
            try { if (fos != null) fos.close(); } catch (Exception ignored) {}
            try { if (is != null) is.close(); } catch (Exception ignored) {}
            if (conn != null) conn.disconnect();
        }
    }

    public void cancelDownload(String videoId) {
        if (videoId == null) return;
        DownloadTask task = activeTasks.get(videoId);
        if (task != null) {
            task.isCancelled.set(true);
            finishTask(videoId, false);
            cancelNotification(task.notificationId);
            notifyDownloadsChanged();
        }
    }

    public synchronized void cancelAndDeleteDownload(String videoId) {
        if (videoId == null) return;
        cancelDownload(videoId);
        deleteDownload(videoId);
    }

    private void handleDownloadError(DownloadTask task, String errorMessage) {
        finishTask(task.video.getId(), false);
        showDownloadFailedNotification(task, errorMessage);
        notifyFailed(task.video.getId(), errorMessage);
    }

    private void finishTask(String videoId, boolean success) {
        activeTasks.remove(videoId);
        if (activeTasks.isEmpty()) {
            releaseWakeLock();
        }
        notifyDownloadsChanged();
    }

    private void updateNotification(DownloadTask task, int progress, long totalBytes, String statusText, boolean indeterminate) {
        if (notificationManager == null) return;
        try {
            Intent openIntent = new Intent(appContext, YouTubeActivity.class);
            openIntent.putExtra("open_tab", 4);
            openIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent pendingIntent = PendingIntent.getActivity(
                    appContext,
                    task.notificationId,
                    openIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
            );

            NotificationCompat.Builder builder = new NotificationCompat.Builder(appContext, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_download)
                    .setContentTitle("Downloading (" + task.requestedQuality + "): " + task.video.getTitle())
                    .setContentText(statusText)
                    .setOngoing(true)
                    .setOnlyAlertOnce(true)
                    .setContentIntent(pendingIntent)
                    .setPriority(NotificationCompat.PRIORITY_LOW);

            if (indeterminate || totalBytes <= 0) {
                builder.setProgress(100, progress, true);
            } else {
                builder.setProgress(100, progress, false);
            }

            notificationManager.notify(task.notificationId, builder.build());
        } catch (Exception ignored) {}
    }

    private void showDownloadCompleteNotification(DownloadTask task) {
        if (notificationManager == null) return;
        try {
            Intent openIntent = new Intent(appContext, YouTubeActivity.class);
            openIntent.putExtra("open_tab", 4);
            openIntent.putExtra("play_video_id", task.video.getId());
            openIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent pendingIntent = PendingIntent.getActivity(
                    appContext,
                    task.notificationId,
                    openIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
            );

            NotificationCompat.Builder builder = new NotificationCompat.Builder(appContext, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_download)
                    .setContentTitle("Download Complete ✓")
                    .setContentText(task.video.getTitle() + " • Ready in " + task.requestedQuality)
                    .setProgress(0, 0, false)
                    .setOngoing(false)
                    .setAutoCancel(true)
                    .setContentIntent(pendingIntent)
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT);

            notificationManager.notify(task.notificationId, builder.build());
        } catch (Exception ignored) {}
    }

    private void showDownloadFailedNotification(DownloadTask task, String error) {
        if (notificationManager == null) return;
        try {
            NotificationCompat.Builder builder = new NotificationCompat.Builder(appContext, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_download)
                    .setContentTitle("Download Interrupted")
                    .setContentText(task.video.getTitle() + " (" + error + ")")
                    .setProgress(0, 0, false)
                    .setOngoing(false)
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_LOW);

            notificationManager.notify(task.notificationId, builder.build());
        } catch (Exception ignored) {}
    }

    private void cancelNotification(int notificationId) {
        if (notificationManager != null) {
            try {
                notificationManager.cancel(notificationId);
            } catch (Exception ignored) {}
        }
    }

    private void notifyProgress(final String videoId, final int progress, final long downloaded, final long total) {
        mainHandler.post(() -> {
            for (DownloadListener l : listeners) {
                try {
                    l.onDownloadProgress(videoId, progress, downloaded, total);
                } catch (Exception ignored) {}
            }
        });
    }

    private void notifyComplete(final String videoId, final File file) {
        mainHandler.post(() -> {
            for (DownloadListener l : listeners) {
                try {
                    l.onDownloadCompleted(videoId, file);
                } catch (Exception ignored) {}
            }
        });
    }

    private void notifyFailed(final String videoId, final String error) {
        mainHandler.post(() -> {
            for (DownloadListener l : listeners) {
                try {
                    l.onDownloadFailed(videoId, error);
                } catch (Exception ignored) {}
            }
        });
    }

    private void notifyDownloadsChanged() {
        mainHandler.post(() -> {
            for (DownloadListener l : listeners) {
                try {
                    l.onDownloadsChanged();
                } catch (Exception ignored) {}
            }
        });
    }

    // =========================================================================
    // PERSISTENCE OF DOWNLOADED LECTURES
    // =========================================================================
    public synchronized void saveDownloadedRecord(Class11Video video, File file) {
        if (video == null || file == null) return;
        List<Class11Video> list = getAllDownloadedVideos();
        for (Class11Video v : list) {
            if (v.getId().equals(video.getId())) return;
        }
        list.add(0, video);

        SharedPreferences prefs = appContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        try {
            JSONArray arr = new JSONArray();
            for (Class11Video v : list) {
                JSONObject obj = new JSONObject();
                obj.put("id", v.getId());
                obj.put("title", v.getTitle());
                obj.put("subject", v.getSubject());
                obj.put("channel", v.getChannel());
                obj.put("views", v.getViews());
                obj.put("duration", v.getDuration());
                obj.put("badge", v.getBadge());
                obj.put("description", v.getDescription());
                obj.put("path", file.getAbsolutePath());
                obj.put("size", file.length());
                obj.put("time", System.currentTimeMillis());
                arr.put(obj);
            }
            prefs.edit().putString(KEY_SAVED_DOWNLOADS, arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    public synchronized List<Class11Video> getAllDownloadedVideos() {
        List<Class11Video> list = new ArrayList<>();
        SharedPreferences prefs = appContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY_SAVED_DOWNLOADS, null);
        if (raw == null || raw.trim().isEmpty()) {
            return list;
        }
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                String id = obj.getString("id");
                // Verify the local file still exists on disk
                File file = getDownloadedFile(id);
                if (file != null && file.exists() && file.length() > 0) {
                    list.add(new Class11Video(
                            id,
                            obj.optString("title", "Lecture"),
                            obj.optString("subject", "Science"),
                            obj.optString("channel", "Study"),
                            obj.optString("views", ""),
                            obj.optString("duration", ""),
                            obj.optString("badge", "OFFLINE"),
                            obj.optString("description", "")
                    ));
                }
            }
        } catch (Exception ignored) {}
        return list;
    }

    public synchronized boolean deleteDownload(String videoId) {
        if (videoId == null) return false;
        File dir = getDownloadDirectory();
        File videoFile = new File(dir, "lecture_" + videoId.trim() + ".mp4");
        if (videoFile.exists()) {
            videoFile.delete();
        }
        File audioFile = new File(dir, "lecture_" + videoId.trim() + ".m4a");
        if (audioFile.exists()) {
            audioFile.delete();
        }
        File tmpVideo = new File(dir, "lecture_" + videoId.trim() + ".mp4.tmp");
        if (tmpVideo.exists()) tmpVideo.delete();
        File tmpAudio = new File(dir, "lecture_" + videoId.trim() + ".m4a.tmp");
        if (tmpAudio.exists()) tmpAudio.delete();

        SharedPreferences prefs = appContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        List<Class11Video> list = getAllDownloadedVideos();
        boolean removed = false;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId().equals(videoId)) {
                list.remove(i);
                removed = true;
                break;
            }
        }

        if (removed) {
            try {
                JSONArray arr = new JSONArray();
                for (Class11Video v : list) {
                    JSONObject obj = new JSONObject();
                    obj.put("id", v.getId());
                    obj.put("title", v.getTitle());
                    obj.put("subject", v.getSubject());
                    obj.put("channel", v.getChannel());
                    obj.put("views", v.getViews());
                    obj.put("duration", v.getDuration());
                    obj.put("badge", v.getBadge());
                    obj.put("description", v.getDescription());
                    arr.put(obj);
                }
                prefs.edit().putString(KEY_SAVED_DOWNLOADS, arr.toString()).apply();
            } catch (Exception ignored) {}
        }

        notifyDownloadsChanged();
        return removed;
    }

    public static String formatBytes(long bytes) {
        if (bytes <= 0) return "0 MB";
        double mb = bytes / (1024.0 * 1024.0);
        if (mb >= 1000) {
            double gb = mb / 1024.0;
            return String.format(Locale.getDefault(), "%.2f GB", gb);
        }
        return String.format(Locale.getDefault(), "%.1f MB", mb);
    }

    public static String formatProgressStatus(long downloaded, long total, String quality) {
        String qTag = quality != null ? ("[" + quality + "] ") : "";
        if (total > 0) {
            int pct = (int) ((downloaded * 100) / total);
            return String.format(Locale.getDefault(), "%s%d%% • %s / %s", qTag, pct, formatBytes(downloaded), formatBytes(total));
        } else {
            return String.format(Locale.getDefault(), "%s%s downloaded", qTag, formatBytes(downloaded));
        }
    }

    private void acquireWakeLock() {
        try {
            if (wakeLock == null) {
                PowerManager pm = (PowerManager) appContext.getSystemService(Context.POWER_SERVICE);
                if (pm != null) {
                    wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Study:VideoDownloadLock");
                    wakeLock.setReferenceCounted(false);
                }
            }
            if (wakeLock != null && !wakeLock.isHeld()) {
                wakeLock.acquire(10 * 60 * 1000L); // 10 minutes max safeguard
            }
        } catch (Exception ignored) {}
    }

    private void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) {
                wakeLock.release();
            }
        } catch (Exception ignored) {}
    }
}
