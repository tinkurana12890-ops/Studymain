package com.abhi.study;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.GestureDetector;
import android.view.HapticFeedbackConstants;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.widget.AppCompatImageView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * StudyDynamicIslandController:
 * High-fidelity iOS Dynamic Island controller exclusively for Deep Mode.
 * Handles active Phone Calls, WhatsApp Voice/Video Calls, WhatsApp Messages,
 * SMS, and Contact Messages with fluid Apple spring physics, contact initials avatars,
 * live clock time display, slide-up-to-minimize gestures, and full call/message management.
 */
public class StudyDynamicIslandController implements StudyFocusNotificationManager.FocusUpdateListener, StudyTorchManager.TorchListener {

    public interface OnIslandStateChangeListener {
        void onExpanded();
        void onCollapsed();
    }

    private final Context context;
    private final ViewGroup rootViewGroup;
    private OnIslandStateChangeListener stateChangeListener;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    // Root views
    private View layoutDynamicIslandRoot;
    private View islandDimScrim;
    private FrameLayout layoutDynamicIslandPill;

    // Compact State Views
    private LinearLayout layoutIslandCompact;
    private AppCompatImageView ivCompactIcon;
    private View viewCompactPulseDot;
    private TextView tvCompactTitle;
    private TextView tvCompactTime;
    private AppCompatImageView ivCompactTorchFan;
    private LinearLayout layoutCompactEqualizer;
    private View compactEqBar1, compactEqBar2, compactEqBar3;

    // Expanded State Views
    private LinearLayout layoutIslandExpanded;
    private View islandDragHandleBar;
    private AppCompatImageView ivIslandHeaderIcon;
    private TextView tvIslandHeaderLabel;
    private TextView tvIslandStatusTime;
    private FrameLayout btnCloseIsland;

    // Expanded Call View
    private LinearLayout layoutExpandedCallView;
    private TextView tvCallerAvatarInitials;
    private TextView tvCallerName;
    private TextView tvCallSubtitle;
    private View containerDeclineBtn;
    private FrameLayout btnDeclineCall;
    private TextView tvDeclineCallLabel;
    private View containerAnswerBtn;
    private FrameLayout btnAnswerCall;
    private TextView tvAnswerCallLabel;
    private View containerMuteBtn;
    private FrameLayout btnMuteCall;
    private AppCompatImageView ivMuteCallIcon;
    private TextView tvMuteCallLabel;
    private View containerSpeakerBtn;
    private FrameLayout btnSpeakerCall;
    private AppCompatImageView ivSpeakerCallIcon;
    private TextView tvSpeakerCallLabel;
    private TextView btnOpenCallApp;
    private LinearLayout layoutExpandedEqualizer;
    private View expEqBar1, expEqBar2, expEqBar3, expEqBar4;

    // Expanded Message View
    private LinearLayout layoutExpandedMessageView;
    private TextView tvMsgAvatarInitials;
    private TextView tvMsgSenderName;
    private TextView tvMsgBody;
    private TextView btnOpenMessage;
    private TextView btnNextMessage;

    // Expanded Idle View
    private LinearLayout layoutExpandedIdleView;
    private TextView btnQuickPhone;
    private View btnQuickWhatsApp;
    private TextView btnQuickMessages;

    // Expanded Torch View (iOS 18 Flashlight Beam Fan)
    private LinearLayout layoutExpandedTorchView;
    private IosTorchFanView iosTorchFanView;
    private FrameLayout btnToggleTorchIsland;
    private AppCompatImageView ivExpandedTorchIcon;
    private TextView btnTorchOffAction;

    // State tracking
    private boolean isExpanded = false;
    private ValueAnimator morphAnimator = null;
    private ValueAnimator equalizerAnimator = null;
    private int currentMessageIndex = 0;
    private long callConnectedTimestamp = 0;
    private boolean wasRinging = false;
    private boolean isTorchActive = false;
    private boolean isShowingTorchState = false;

    // Real-time clock & timer loop
    private final SimpleDateFormat clockFormat = new SimpleDateFormat("h:mm a", Locale.getDefault());
    private Runnable timeTickerRunnable;

    // Touch gesture detector for smooth slide-to-minimize
    private GestureDetector gestureDetector;
    private float touchStartY = 0f;

    private String lastProcessedMessageKey = null;
    private String lastProcessedMessageSignature = null;
    private boolean hideWhenIdle = false;
    private final Runnable autoHideRunnable;
    private final Runnable autoCollapseMessageRunnable;

    // Call End Auto-dismiss (3s non-touch -> collapse to small pill -> 3s non-touch -> disappear)
    private boolean hadActiveCall = false;
    private boolean isTouchingIsland = false;
    private boolean isWaitingCallEndStage1 = false;
    private boolean isWaitingCallEndStage2 = false;

    private final Runnable callEndStage1Runnable = new Runnable() {
        @Override
        public void run() {
            if (isTouchingIsland) {
                mainHandler.postDelayed(this, 3000);
                return;
            }
            isWaitingCallEndStage1 = false;
            collapseIsland();
            isWaitingCallEndStage2 = true;
            mainHandler.removeCallbacks(callEndStage2Runnable);
            mainHandler.postDelayed(callEndStage2Runnable, 3000);
        }
    };

    private final Runnable callEndStage2Runnable = new Runnable() {
        @Override
        public void run() {
            if (isTouchingIsland) {
                mainHandler.postDelayed(this, 3000);
                return;
            }
            isWaitingCallEndStage2 = false;
            if (layoutDynamicIslandRoot != null) {
                layoutDynamicIslandRoot.animate()
                        .alpha(0f)
                        .setDuration(250)
                        .withEndAction(() -> {
                            if (layoutDynamicIslandRoot != null) {
                                layoutDynamicIslandRoot.setVisibility(View.GONE);
                                layoutDynamicIslandRoot.setAlpha(1f);
                            }
                        })
                        .start();
            }
        }
    };

    public void setHideWhenIdle(boolean hide) {
        this.hideWhenIdle = hide;
        if (hide && layoutDynamicIslandRoot != null) {
            StudyFocusNotificationManager.PhoneCallInfo pc = StudyFocusNotificationManager.getActivePhoneCall(context);
            StudyFocusNotificationManager.WhatsAppCallInfo wc = StudyFocusNotificationManager.getActiveWhatsAppCall();
            List<StudyFocusNotificationManager.FocusMessageItem> msgs = StudyFocusNotificationManager.getRecentMessages();
            boolean hasActive = (pc != null && (pc.isRinging || pc.isOngoing)) || (wc != null) || (msgs != null && !msgs.isEmpty());
            if (!hasActive) {
                layoutDynamicIslandRoot.setVisibility(View.GONE);
            }
        }
    }

    public void setOnIslandStateChangeListener(OnIslandStateChangeListener listener) {
        this.stateChangeListener = listener;
    }

    public StudyDynamicIslandController(Context context, ViewGroup rootViewGroup) {
        this.context = context;
        this.rootViewGroup = rootViewGroup;
        this.autoCollapseMessageRunnable = () -> {
            if (isExpanded) {
                StudyFocusNotificationManager.PhoneCallInfo pc = StudyFocusNotificationManager.getActivePhoneCall(this.context);
                StudyFocusNotificationManager.WhatsAppCallInfo wc = StudyFocusNotificationManager.getActiveWhatsAppCall();
                if ((pc == null || (!pc.isRinging && !pc.isOngoing)) && (wc == null || (!wc.isRinging && !wc.isOngoing))) {
                    collapseIsland();
                }
            }
        };
        this.autoHideRunnable = () -> {
            if (hideWhenIdle && layoutDynamicIslandRoot != null && !isExpanded) {
                StudyFocusNotificationManager.PhoneCallInfo pc = StudyFocusNotificationManager.getActivePhoneCall(this.context);
                StudyFocusNotificationManager.WhatsAppCallInfo wc = StudyFocusNotificationManager.getActiveWhatsAppCall();
                if ((pc == null || (!pc.isRinging && !pc.isOngoing)) && (wc == null || (!wc.isRinging && !wc.isOngoing))) {
                    layoutDynamicIslandRoot.animate()
                            .alpha(0f)
                            .setDuration(250)
                            .withEndAction(() -> {
                                if (layoutDynamicIslandRoot != null) {
                                    layoutDynamicIslandRoot.setVisibility(View.GONE);
                                }
                            })
                            .start();
                }
            }
        };
        init();
    }

    private void init() {
        if (context == null || rootViewGroup == null) return;

        LayoutInflater inflater = LayoutInflater.from(context);
        layoutDynamicIslandRoot = inflater.inflate(R.layout.layout_ios_dynamic_island, rootViewGroup, false);

        if (rootViewGroup instanceof androidx.constraintlayout.widget.ConstraintLayout) {
            androidx.constraintlayout.widget.ConstraintLayout.LayoutParams clp =
                    new androidx.constraintlayout.widget.ConstraintLayout.LayoutParams(
                            androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.MATCH_PARENT,
                            androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.MATCH_PARENT
                    );
            clp.topToTop = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.PARENT_ID;
            clp.bottomToBottom = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.PARENT_ID;
            clp.startToStart = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.PARENT_ID;
            clp.endToEnd = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.PARENT_ID;
            layoutDynamicIslandRoot.setLayoutParams(clp);
        } else {
            FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
            );
            layoutDynamicIslandRoot.setLayoutParams(flp);
        }

        rootViewGroup.addView(layoutDynamicIslandRoot);
        layoutDynamicIslandRoot.bringToFront();
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            layoutDynamicIslandRoot.setElevation(dpToPx(150));
            layoutDynamicIslandRoot.setTranslationZ(dpToPx(150));
        }

        bindViews();
        setupGestures();
        startEqualizerAnimation();
        startTimeTicker();

        StudyFocusNotificationManager.registerListener(this);
        StudyTorchManager.getInstance(context).addListener(this);
        refreshData();
    }

    private void bindViews() {
        islandDimScrim = layoutDynamicIslandRoot.findViewById(R.id.islandDimScrim);
        layoutDynamicIslandPill = layoutDynamicIslandRoot.findViewById(R.id.layoutDynamicIslandPill);

        // Compact Views
        layoutIslandCompact = layoutDynamicIslandRoot.findViewById(R.id.layoutIslandCompact);
        ivCompactIcon = layoutDynamicIslandRoot.findViewById(R.id.ivCompactIcon);
        viewCompactPulseDot = layoutDynamicIslandRoot.findViewById(R.id.viewCompactPulseDot);
        tvCompactTitle = layoutDynamicIslandRoot.findViewById(R.id.tvCompactTitle);
        tvCompactTime = layoutDynamicIslandRoot.findViewById(R.id.tvCompactTime);
        ivCompactTorchFan = layoutDynamicIslandRoot.findViewById(R.id.ivCompactTorchFan);
        layoutCompactEqualizer = layoutDynamicIslandRoot.findViewById(R.id.layoutCompactEqualizer);
        compactEqBar1 = layoutDynamicIslandRoot.findViewById(R.id.compactEqBar1);
        compactEqBar2 = layoutDynamicIslandRoot.findViewById(R.id.compactEqBar2);
        compactEqBar3 = layoutDynamicIslandRoot.findViewById(R.id.compactEqBar3);

        // Expanded Views
        layoutIslandExpanded = layoutDynamicIslandRoot.findViewById(R.id.layoutIslandExpanded);
        islandDragHandleBar = layoutDynamicIslandRoot.findViewById(R.id.islandDragHandleBar);
        ivIslandHeaderIcon = layoutDynamicIslandRoot.findViewById(R.id.ivIslandHeaderIcon);
        tvIslandHeaderLabel = layoutDynamicIslandRoot.findViewById(R.id.tvIslandHeaderLabel);
        tvIslandStatusTime = layoutDynamicIslandRoot.findViewById(R.id.tvIslandStatusTime);
        btnCloseIsland = layoutDynamicIslandRoot.findViewById(R.id.btnCloseIsland);

        // Expanded Call Views
        layoutExpandedCallView = layoutDynamicIslandRoot.findViewById(R.id.layoutExpandedCallView);
        tvCallerAvatarInitials = layoutDynamicIslandRoot.findViewById(R.id.tvCallerAvatarInitials);
        tvCallerName = layoutDynamicIslandRoot.findViewById(R.id.tvCallerName);
        tvCallSubtitle = layoutDynamicIslandRoot.findViewById(R.id.tvCallSubtitle);
        containerDeclineBtn = layoutDynamicIslandRoot.findViewById(R.id.containerDeclineBtn);
        btnDeclineCall = layoutDynamicIslandRoot.findViewById(R.id.btnDeclineCall);
        tvDeclineCallLabel = layoutDynamicIslandRoot.findViewById(R.id.tvDeclineCallLabel);
        containerAnswerBtn = layoutDynamicIslandRoot.findViewById(R.id.containerAnswerBtn);
        btnAnswerCall = layoutDynamicIslandRoot.findViewById(R.id.btnAnswerCall);
        tvAnswerCallLabel = layoutDynamicIslandRoot.findViewById(R.id.tvAnswerCallLabel);
        containerMuteBtn = layoutDynamicIslandRoot.findViewById(R.id.containerMuteBtn);
        btnMuteCall = layoutDynamicIslandRoot.findViewById(R.id.btnMuteCall);
        ivMuteCallIcon = layoutDynamicIslandRoot.findViewById(R.id.ivMuteCallIcon);
        tvMuteCallLabel = layoutDynamicIslandRoot.findViewById(R.id.tvMuteCallLabel);
        containerSpeakerBtn = layoutDynamicIslandRoot.findViewById(R.id.containerSpeakerBtn);
        btnSpeakerCall = layoutDynamicIslandRoot.findViewById(R.id.btnSpeakerCall);
        ivSpeakerCallIcon = layoutDynamicIslandRoot.findViewById(R.id.ivSpeakerCallIcon);
        tvSpeakerCallLabel = layoutDynamicIslandRoot.findViewById(R.id.tvSpeakerCallLabel);
        btnOpenCallApp = layoutDynamicIslandRoot.findViewById(R.id.btnOpenCallApp);
        layoutExpandedEqualizer = layoutDynamicIslandRoot.findViewById(R.id.layoutExpandedEqualizer);
        expEqBar1 = layoutDynamicIslandRoot.findViewById(R.id.expEqBar1);
        expEqBar2 = layoutDynamicIslandRoot.findViewById(R.id.expEqBar2);
        expEqBar3 = layoutDynamicIslandRoot.findViewById(R.id.expEqBar3);
        expEqBar4 = layoutDynamicIslandRoot.findViewById(R.id.expEqBar4);

        // Expanded Message Views
        layoutExpandedMessageView = layoutDynamicIslandRoot.findViewById(R.id.layoutExpandedMessageView);
        tvMsgAvatarInitials = layoutDynamicIslandRoot.findViewById(R.id.tvMsgAvatarInitials);
        tvMsgSenderName = layoutDynamicIslandRoot.findViewById(R.id.tvMsgSenderName);
        tvMsgBody = layoutDynamicIslandRoot.findViewById(R.id.tvMsgBody);
        btnOpenMessage = layoutDynamicIslandRoot.findViewById(R.id.btnOpenMessage);
        btnNextMessage = layoutDynamicIslandRoot.findViewById(R.id.btnNextMessage);

        // Expanded Idle Views
        layoutExpandedIdleView = layoutDynamicIslandRoot.findViewById(R.id.layoutExpandedIdleView);
        btnQuickPhone = layoutDynamicIslandRoot.findViewById(R.id.btnQuickPhone);
        btnQuickWhatsApp = layoutDynamicIslandRoot.findViewById(R.id.btnQuickWhatsApp);
        btnQuickMessages = layoutDynamicIslandRoot.findViewById(R.id.btnQuickMessages);

        // Expanded Torch Views (iOS 18 Flashlight Beam Fan)
        layoutExpandedTorchView = layoutDynamicIslandRoot.findViewById(R.id.layoutExpandedTorchView);
        iosTorchFanView = layoutDynamicIslandRoot.findViewById(R.id.iosTorchFanView);
        btnToggleTorchIsland = layoutDynamicIslandRoot.findViewById(R.id.btnToggleTorchIsland);
        ivExpandedTorchIcon = layoutDynamicIslandRoot.findViewById(R.id.ivExpandedTorchIcon);
        btnTorchOffAction = layoutDynamicIslandRoot.findViewById(R.id.btnTorchOffAction);

        View.OnClickListener turnOffTorchListener = v -> {
            try {
                v.performHapticFeedback(HapticFeedbackConstants.CONFIRM);
            } catch (Exception ignored) {}
            StudyTorchManager.getInstance(context).setTorch(false);
            collapseIsland();
        };
        if (btnToggleTorchIsland != null) btnToggleTorchIsland.setOnClickListener(turnOffTorchListener);
        if (btnTorchOffAction != null) btnTorchOffAction.setOnClickListener(turnOffTorchListener);
        if (iosTorchFanView != null) iosTorchFanView.setOnClickListener(turnOffTorchListener);

        // Click on Scrim, Drag Handle or Close Button collapses
        if (islandDimScrim != null) {
            islandDimScrim.setOnClickListener(v -> collapseIsland());
        }
        if (btnCloseIsland != null) {
            btnCloseIsland.setOnClickListener(v -> collapseIsland());
        }
        if (islandDragHandleBar != null) {
            islandDragHandleBar.setOnClickListener(v -> collapseIsland());
        }

        // Quick App Launcher Buttons in Idle Mode
        if (btnQuickPhone != null) {
            btnQuickPhone.setOnClickListener(v -> {
                StudyFocusNotificationManager.launchDialer(context);
                collapseIsland();
            });
        }
        if (btnQuickWhatsApp != null) {
            btnQuickWhatsApp.setOnClickListener(v -> {
                StudyFocusNotificationManager.launchWhatsApp(context);
                collapseIsland();
            });
        }
        if (btnQuickMessages != null) {
            btnQuickMessages.setOnClickListener(v -> {
                StudyFocusNotificationManager.launchMessages(context);
                collapseIsland();
            });
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupGestures() {
        if (layoutDynamicIslandPill == null) return;

        // Long press to clear all notifications in one go
        View.OnLongClickListener clearAllLongClickListener = v -> {
            performClearAllMessages();
            return true;
        };
        layoutDynamicIslandPill.setOnLongClickListener(clearAllLongClickListener);
        if (layoutIslandExpanded != null) layoutIslandExpanded.setOnLongClickListener(clearAllLongClickListener);

        // Tapping compact pill expands it or prompts permission if needed
        layoutDynamicIslandPill.setOnClickListener(v -> {
            boolean hasListener = StudyFocusNotificationManager.isNotificationListenerEnabled(context);
            if (!hasListener) {
                StudyFocusNotificationManager.openNotificationAccessSettings(context);
                android.widget.Toast.makeText(context, "Enable Notification Access for Study to show WhatsApp & Calls", android.widget.Toast.LENGTH_LONG).show();
                return;
            }
            if (!isExpanded) {
                expandIsland();
            }
        });

        gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public void onLongPress(MotionEvent e) {
                performClearAllMessages();
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                if (e1 == null || e2 == null) return false;
                float diffY = e2.getY() - e1.getY();
                float diffX = e2.getX() - e1.getX();

                // Horizontal fling on compact pill -> dismiss current notification
                if (!isExpanded && Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > dpToPx(20)) {
                    dismissLatestNotificationWithAnimation(diffX > 0);
                    return true;
                }

                // Fling UP -> Minimize/Collapse
                if (isExpanded && (diffY < -dpToPx(15) || velocityY < -600)) {
                    collapseIsland();
                    return true;
                }
                // Fling DOWN -> Expand
                if (!isExpanded && (diffY > dpToPx(15) || velocityY > 600)) {
                    expandIsland();
                    return true;
                }
                return false;
            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                if (e1 == null || e2 == null) return false;
                // distanceY > 0 means drag UP
                if (isExpanded && distanceY > dpToPx(12)) {
                    collapseIsland();
                    return true;
                }
                // distanceY < 0 means drag DOWN
                if (!isExpanded && distanceY < -dpToPx(12)) {
                    expandIsland();
                    return true;
                }
                return false;
            }
        });

        final float[] touchDownX = new float[]{0f};
        final float[] touchDownY = new float[]{0f};

        View.OnTouchListener swipeTouchListener = (v, event) -> {
            gestureDetector.onTouchEvent(event);
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    isTouchingIsland = true;
                    touchDownX[0] = event.getRawX();
                    touchDownY[0] = event.getRawY();
                    touchStartY = event.getY();
                    break;
                case MotionEvent.ACTION_MOVE:
                    isTouchingIsland = true;
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    isTouchingIsland = false;
                    // Reset 3-second non-touch countdown timer upon touch release
                    if (isWaitingCallEndStage1) {
                        mainHandler.removeCallbacks(callEndStage1Runnable);
                        mainHandler.postDelayed(callEndStage1Runnable, 3000);
                    } else if (isWaitingCallEndStage2) {
                        mainHandler.removeCallbacks(callEndStage2Runnable);
                        mainHandler.postDelayed(callEndStage2Runnable, 3000);
                    }
                    if (event.getAction() == MotionEvent.ACTION_UP) {
                        float totalDiffX = event.getRawX() - touchDownX[0];
                        float totalDiffY = event.getRawY() - touchDownY[0];
                        // Horizontal slide on compact pill dismisses notification
                        if (!isExpanded && Math.abs(totalDiffX) > dpToPx(35) && Math.abs(totalDiffX) > Math.abs(totalDiffY)) {
                            dismissLatestNotificationWithAnimation(totalDiffX > 0);
                            return true;
                        }
                        // Slide UP on dynamic island -> minimize
                        if (isExpanded && totalDiffY < -dpToPx(15)) {
                            collapseIsland();
                            return true;
                        }
                        // Slide DOWN on compact pill -> expand
                        if (!isExpanded && totalDiffY > dpToPx(18)) {
                            expandIsland();
                            return true;
                        }
                    }
                    break;
            }
            return false;
        };

        if (layoutDynamicIslandRoot != null) layoutDynamicIslandRoot.setOnTouchListener(swipeTouchListener);
        layoutDynamicIslandPill.setOnTouchListener(swipeTouchListener);
        if (layoutIslandExpanded != null) layoutIslandExpanded.setOnTouchListener(swipeTouchListener);
        if (layoutIslandCompact != null) layoutIslandCompact.setOnTouchListener(swipeTouchListener);
        if (islandDragHandleBar != null) islandDragHandleBar.setOnTouchListener(swipeTouchListener);
        if (islandDimScrim != null) islandDimScrim.setOnTouchListener(swipeTouchListener);
    }

    public void performClearAllMessages() {
        List<StudyFocusNotificationManager.FocusMessageItem> msgs = StudyFocusNotificationManager.getRecentMessages();
        if (!msgs.isEmpty()) {
            try {
                if (layoutDynamicIslandPill != null) {
                    layoutDynamicIslandPill.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                }
            } catch (Exception ignored) {}

            if (layoutDynamicIslandPill != null) {
                layoutDynamicIslandPill.animate()
                        .scaleX(0.92f)
                        .scaleY(0.92f)
                        .setDuration(120)
                        .setInterpolator(new DecelerateInterpolator())
                        .withEndAction(() -> {
                            if (layoutDynamicIslandPill != null) {
                                layoutDynamicIslandPill.animate()
                                        .scaleX(1.0f)
                                        .scaleY(1.0f)
                                        .setDuration(160)
                                        .setInterpolator(new OvershootInterpolator(1.3f))
                                        .start();
                            }
                        })
                        .start();
            }

            StudyFocusNotificationManager.clearAllMessages();
            android.widget.Toast.makeText(context, "All Notifications Cleared", android.widget.Toast.LENGTH_SHORT).show();
            collapseIsland();
        }
    }

    private void dismissLatestNotificationWithAnimation(boolean slideRight) {
        StudyFocusNotificationManager.FocusMessageItem latest = StudyFocusNotificationManager.getLatestMessage();
        if (latest == null) return;

        if (layoutIslandCompact != null) {
            float exitX = slideRight ? dpToPx(100) : -dpToPx(100);
            layoutIslandCompact.animate()
                    .translationX(exitX)
                    .alpha(0f)
                    .setDuration(160)
                    .withEndAction(() -> {
                        layoutIslandCompact.setTranslationX(0f);
                        layoutIslandCompact.setAlpha(1f);
                        try {
                            if (layoutDynamicIslandPill != null) {
                                layoutDynamicIslandPill.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK);
                            }
                        } catch (Exception ignored) {}
                        StudyFocusNotificationManager.removeMessageItem(latest.key);
                    })
                    .start();
        } else {
            StudyFocusNotificationManager.removeMessageItem(latest.key);
        }
    }

    public void expandIsland() {
        if (isExpanded || layoutDynamicIslandPill == null) return;
        isExpanded = true;

        if (stateChangeListener != null) {
            stateChangeListener.onExpanded();
        }

        if (islandDimScrim != null) {
            islandDimScrim.setVisibility(View.VISIBLE);
            islandDimScrim.animate().alpha(1f).setDuration(220).start();
        }

        int rootW = rootViewGroup != null ? rootViewGroup.getWidth() : 0;
        int screenW = (int) dpToPx(380);
        try {
            android.util.DisplayMetrics dm = context.getResources().getDisplayMetrics();
            if (dm != null && dm.widthPixels > 0) {
                screenW = dm.widthPixels;
            }
        } catch (Exception ignored) {}
        int targetWidth = Math.min((rootW > 0 ? rootW : screenW) - (int) dpToPx(32), (int) dpToPx(360));
        if (targetWidth <= 0) targetWidth = (int) dpToPx(340);
        int targetHeight = (int) dpToPx(200);

        animateMorph(layoutDynamicIslandPill.getWidth(), targetWidth,
                layoutDynamicIslandPill.getHeight(), targetHeight,
                R.drawable.bg_dynamic_island_expanded, true);
    }

    public void collapseIsland() {
        if (!isExpanded || layoutDynamicIslandPill == null) return;
        isExpanded = false;

        if (stateChangeListener != null) {
            stateChangeListener.onCollapsed();
        }

        if (islandDimScrim != null) {
            islandDimScrim.animate().alpha(0f).setDuration(180).withEndAction(() -> {
                islandDimScrim.setVisibility(View.GONE);
            }).start();
        }

        int targetWidth = (int) dpToPx(165);
        int targetHeight = (int) dpToPx(36);

        // Adjust compact size based on active call
        StudyFocusNotificationManager.PhoneCallInfo pCall = StudyFocusNotificationManager.getActivePhoneCall(context);
        StudyFocusNotificationManager.WhatsAppCallInfo wCall = StudyFocusNotificationManager.getActiveWhatsAppCall();
        if ((pCall != null && (pCall.isRinging || pCall.isOngoing)) || wCall != null) {
            targetWidth = (int) dpToPx(230);
            targetHeight = (int) dpToPx(38);
        }

        animateMorph(layoutDynamicIslandPill.getWidth(), targetWidth,
                layoutDynamicIslandPill.getHeight(), targetHeight,
                R.drawable.bg_dynamic_island_pill, false);
    }

    public boolean isExpanded() {
        return isExpanded;
    }

    private void animateMorph(int startW, int targetW, int startH, int targetH, int bgRes, boolean expanding) {
        if (morphAnimator != null && morphAnimator.isRunning()) {
            morphAnimator.cancel();
        }

        if (expanding) {
            if (layoutIslandCompact != null) layoutIslandCompact.setVisibility(View.GONE);
            if (layoutIslandExpanded != null) {
                layoutIslandExpanded.setVisibility(View.VISIBLE);
                layoutIslandExpanded.setAlpha(0f);
                layoutIslandExpanded.animate().alpha(1f).setDuration(200).start();
            }
        } else {
            if (layoutIslandExpanded != null) layoutIslandExpanded.setVisibility(View.GONE);
            if (layoutIslandCompact != null) {
                layoutIslandCompact.setVisibility(View.VISIBLE);
                layoutIslandCompact.setAlpha(0f);
                layoutIslandCompact.animate().alpha(1f).setDuration(180).start();
            }
        }

        layoutDynamicIslandPill.setBackgroundResource(bgRes);

        morphAnimator = ValueAnimator.ofFloat(0f, 1f);
        morphAnimator.setDuration(expanding ? 280 : 220);
        morphAnimator.setInterpolator(expanding ? new OvershootInterpolator(1.15f) : new DecelerateInterpolator());

        morphAnimator.addUpdateListener(anim -> {
            float frac = anim.getAnimatedFraction();
            int currentW = (int) (startW + (targetW - startW) * frac);
            int currentH = (int) (startH + (targetH - startH) * frac);

            ViewGroup.LayoutParams lp = layoutDynamicIslandPill.getLayoutParams();
            if (lp != null) {
                lp.width = currentW;
                lp.height = currentH;
                layoutDynamicIslandPill.setLayoutParams(lp);
            }
        });

        morphAnimator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                refreshData();
            }
        });

        morphAnimator.start();
    }

    private void startEqualizerAnimation() {
        equalizerAnimator = ValueAnimator.ofFloat(0.3f, 1.0f);
        equalizerAnimator.setDuration(400);
        equalizerAnimator.setRepeatMode(ValueAnimator.REVERSE);
        equalizerAnimator.setRepeatCount(ValueAnimator.INFINITE);
        equalizerAnimator.addUpdateListener(anim -> {
            float f = (float) anim.getAnimatedValue();
            if (compactEqBar1 != null) compactEqBar1.setScaleY(f);
            if (compactEqBar2 != null) compactEqBar2.setScaleY(1.3f - (f * 0.5f));
            if (compactEqBar3 != null) compactEqBar3.setScaleY(0.5f + (f * 0.5f));

            if (expEqBar1 != null) expEqBar1.setScaleY(f);
            if (expEqBar2 != null) expEqBar2.setScaleY(1.4f - (f * 0.6f));
            if (expEqBar3 != null) expEqBar3.setScaleY(0.4f + (f * 0.6f));
            if (expEqBar4 != null) expEqBar4.setScaleY(f * 0.9f);
        });
        equalizerAnimator.start();
    }

    private void startTimeTicker() {
        timeTickerRunnable = new Runnable() {
            @Override
            public void run() {
                updateTimeDisplay();
                mainHandler.postDelayed(this, 1000);
            }
        };
        mainHandler.post(timeTickerRunnable);
    }

    private void updateTimeDisplay() {
        if (context == null) return;
        if (context instanceof Activity && ((Activity) context).isFinishing()) return;

        StudyFocusNotificationManager.PhoneCallInfo pCall = StudyFocusNotificationManager.getActivePhoneCall(context);
        StudyFocusNotificationManager.WhatsAppCallInfo wCall = StudyFocusNotificationManager.getActiveWhatsAppCall();

        // Call Timer / Live Clock formatting
        String currentTimeStr = clockFormat.format(new Date());

        if (pCall != null && pCall.isOngoing) {
            if (callConnectedTimestamp == 0) callConnectedTimestamp = System.currentTimeMillis();
            long elapsedSec = (System.currentTimeMillis() - callConnectedTimestamp) / 1000;
            String callDuration = String.format(Locale.getDefault(), "%02d:%02d", elapsedSec / 60, elapsedSec % 60);

            if (tvCompactTime != null) {
                tvCompactTime.setText(callDuration);
                tvCompactTime.setTextColor(Color.parseColor("#34C759"));
            }
            if (tvIslandStatusTime != null) {
                tvIslandStatusTime.setText(callDuration);
            }
        } else if (wCall != null && wCall.isOngoing) {
            if (callConnectedTimestamp == 0) callConnectedTimestamp = System.currentTimeMillis();
            long elapsedSec = (System.currentTimeMillis() - callConnectedTimestamp) / 1000;
            String callDuration = String.format(Locale.getDefault(), "%02d:%02d", elapsedSec / 60, elapsedSec % 60);

            if (tvCompactTime != null) {
                tvCompactTime.setText(callDuration);
                tvCompactTime.setTextColor(Color.parseColor("#25D366"));
            }
            if (tvIslandStatusTime != null) {
                tvIslandStatusTime.setText(callDuration);
            }
        } else if ((pCall != null && pCall.isRinging) || (wCall != null && wCall.isRinging)) {
            callConnectedTimestamp = 0;
            boolean isOutgoing = (pCall != null && pCall.isOutgoing) || (wCall != null && wCall.isOutgoing);
            if (tvCompactTime != null) {
                tvCompactTime.setText(isOutgoing ? "Calling..." : "Incoming");
                tvCompactTime.setTextColor(Color.parseColor("#34C759"));
            }
            if (tvIslandStatusTime != null) {
                tvIslandStatusTime.setText(isOutgoing ? "Calling..." : "Incoming Call...");
            }
        } else {
            callConnectedTimestamp = 0;
            if (tvCompactTime != null) {
                tvCompactTime.setText(currentTimeStr);
                tvCompactTime.setTextColor(Color.parseColor("#CBD5E1"));
            }
            if (tvIslandStatusTime != null) {
                tvIslandStatusTime.setText(currentTimeStr);
            }
        }
    }

    public void refreshData() {
        mainHandler.post(() -> {
            if (context == null) return;
            if (context instanceof Activity && ((Activity) context).isFinishing()) return;

            StudyFocusNotificationManager.PhoneCallInfo pCall = StudyFocusNotificationManager.getActivePhoneCall(context);
            StudyFocusNotificationManager.WhatsAppCallInfo wCall = StudyFocusNotificationManager.getActiveWhatsAppCall();
            List<StudyFocusNotificationManager.FocusMessageItem> messages = StudyFocusNotificationManager.getRecentMessages();

            boolean hasCall = (pCall != null && (pCall.isRinging || pCall.isOngoing)) || (wCall != null && (wCall.isRinging || wCall.isOngoing));
            boolean hasMsg = (messages != null && !messages.isEmpty());

            if (hasCall) {
                // Call incoming or ongoing: Island must stay visible and clear any dismiss timers
                hadActiveCall = true;
                isWaitingCallEndStage1 = false;
                isWaitingCallEndStage2 = false;
                mainHandler.removeCallbacks(callEndStage1Runnable);
                mainHandler.removeCallbacks(callEndStage2Runnable);
                mainHandler.removeCallbacks(autoHideRunnable);
                if (layoutDynamicIslandRoot != null) {
                    layoutDynamicIslandRoot.setVisibility(View.VISIBLE);
                    layoutDynamicIslandRoot.setAlpha(1f);
                }
            } else if (hadActiveCall) {
                // Call just ended: wait 3 seconds of non-touch -> collapse into small mode -> wait next 3s non-touch -> disappear
                hadActiveCall = false;
                isWaitingCallEndStage1 = true;
                isWaitingCallEndStage2 = false;
                mainHandler.removeCallbacks(callEndStage1Runnable);
                mainHandler.removeCallbacks(callEndStage2Runnable);
                mainHandler.removeCallbacks(autoHideRunnable);
                mainHandler.postDelayed(callEndStage1Runnable, 3000);
            } else if (!isWaitingCallEndStage1 && !isWaitingCallEndStage2) {
                if (hideWhenIdle) {
                    if (hasMsg) {
                        mainHandler.removeCallbacks(autoHideRunnable);
                        if (layoutDynamicIslandRoot != null) {
                            layoutDynamicIslandRoot.setVisibility(View.VISIBLE);
                            layoutDynamicIslandRoot.setAlpha(1f);
                        }
                    } else {
                        mainHandler.removeCallbacks(autoHideRunnable);
                        mainHandler.postDelayed(autoHideRunnable, wasRinging ? 2500 : 0);
                        if (!wasRinging && layoutDynamicIslandRoot != null && !isExpanded) {
                            layoutDynamicIslandRoot.setVisibility(View.GONE);
                        }
                    }
                }
            }

            boolean isNowRinging = (pCall != null && pCall.isRinging) || (wCall != null && wCall.isRinging);

            // Auto-expand island and play custom ringtone when an incoming call starts ringing
            if (isNowRinging && !wasRinging) {
                StudyNotificationSoundManager.playNotificationSound(context);
                if (!isExpanded) {
                    expandIsland();
                }
            }
            wasRinging = isNowRinging;

            // 1. ACTIVE PHONE CALL
            if (pCall != null && (pCall.isRinging || pCall.isOngoing)) {
                bindPhoneCallState(pCall);
                updateTimeDisplay();
                return;
            }

            // 2. ACTIVE WHATSAPP CALL
            if (wCall != null && (wCall.isRinging || wCall.isOngoing)) {
                bindWhatsAppCallState(wCall);
                updateTimeDisplay();
                return;
            }

            // 3. WHATSAPP & SMS MESSAGES
            if (messages != null && !messages.isEmpty()) {
                StudyFocusNotificationManager.FocusMessageItem latest = messages.get(0);
                String currentSignature = latest.getUniqueMessageSignature();
                boolean isNewIncomingMessage = (lastProcessedMessageSignature == null || !lastProcessedMessageSignature.equals(currentSignature));

                if (isNewIncomingMessage) {
                    lastProcessedMessageSignature = currentSignature;
                    lastProcessedMessageKey = latest.key;
                    currentMessageIndex = 0; // Fresh notification always opens first

                    // Play custom iOS ringtone (ringtone.m4a from assets)
                    StudyNotificationSoundManager.playNotificationSound(context);

                    if (!isExpanded && !isNowRinging) {
                        expandIsland();
                    } else if (isExpanded) {
                        // Authentic iOS Dropdown Jolt: bounces downward and springs back for repeated messages
                        performIosDropdownJolt();
                    }

                    mainHandler.removeCallbacks(autoCollapseMessageRunnable);
                    mainHandler.postDelayed(autoCollapseMessageRunnable, hideWhenIdle ? 3500 : 5000);
                }

                if (hideWhenIdle) {
                    mainHandler.removeCallbacks(autoHideRunnable);
                    mainHandler.postDelayed(autoHideRunnable, 3000);
                }
                bindMessageState(messages);
                updateTimeDisplay();
                return;
            }

            // 4. ACTIVE TORCH / FLASHLIGHT BEAM FAN (iOS 18)
            if (StudyTorchManager.getInstance(context).isTorchOn()) {
                bindTorchState();
                updateTimeDisplay();
                return;
            }

            // 5. DEEP FOCUS IDLE STATE
            bindIdleState();
            updateTimeDisplay();
        });
    }

    private void updateMuteButtonUI(boolean isMuted) {
        if (ivMuteCallIcon != null) {
            ivMuteCallIcon.setImageTintList(ColorStateList.valueOf(isMuted ? Color.parseColor("#FF3B30") : Color.WHITE));
        }
        if (tvMuteCallLabel != null) {
            tvMuteCallLabel.setText(isMuted ? "Muted" : "Mute");
            tvMuteCallLabel.setTextColor(isMuted ? Color.parseColor("#FF3B30") : Color.parseColor("#E2E8F0"));
        }
        if (btnMuteCall != null) {
            btnMuteCall.setBackgroundResource(isMuted ? R.drawable.bg_ios_call_decline_btn : R.drawable.bg_ios_pill_secondary);
        }
    }

    private void updateSpeakerButtonUI(boolean isSpeakerOn) {
        if (ivSpeakerCallIcon != null) {
            ivSpeakerCallIcon.setImageTintList(ColorStateList.valueOf(isSpeakerOn ? Color.parseColor("#34C759") : Color.WHITE));
        }
        if (tvSpeakerCallLabel != null) {
            tvSpeakerCallLabel.setText(isSpeakerOn ? "Speaker On" : "Speaker");
            tvSpeakerCallLabel.setTextColor(isSpeakerOn ? Color.parseColor("#34C759") : Color.parseColor("#E2E8F0"));
        }
        if (btnSpeakerCall != null) {
            btnSpeakerCall.setBackgroundResource(isSpeakerOn ? R.drawable.bg_ios_call_answer_btn : R.drawable.bg_ios_pill_secondary);
        }
    }

    private void bindPhoneCallState(StudyFocusNotificationManager.PhoneCallInfo pCall) {
        String name = !TextUtils.isEmpty(pCall.callerName) ? pCall.callerName : "Incoming Phone Call";
        String number = !TextUtils.isEmpty(pCall.callerNumber) ? pCall.callerNumber : "Phone Call";

        // Compact State
        if (ivCompactIcon != null) {
            ivCompactIcon.setImageResource(R.drawable.ic_phone_dialer);
            ivCompactIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#34C759")));
        }
        if (viewCompactPulseDot != null) {
            viewCompactPulseDot.setVisibility(pCall.isRinging && !pCall.isOutgoing ? View.VISIBLE : View.GONE);
        }
        if (tvCompactTitle != null) {
            tvCompactTitle.setText(name);
        }
        if (layoutCompactEqualizer != null) {
            layoutCompactEqualizer.setVisibility(pCall.isOngoing ? View.VISIBLE : View.GONE);
        }
        if (ivCompactTorchFan != null) {
            ivCompactTorchFan.setVisibility(View.GONE);
        }

        // Expanded State
        isShowingTorchState = false;
        if (layoutExpandedCallView != null) layoutExpandedCallView.setVisibility(View.VISIBLE);
        if (layoutExpandedMessageView != null) layoutExpandedMessageView.setVisibility(View.GONE);
        if (layoutExpandedIdleView != null) layoutExpandedIdleView.setVisibility(View.GONE);
        if (layoutExpandedTorchView != null) layoutExpandedTorchView.setVisibility(View.GONE);

        if (ivIslandHeaderIcon != null) {
            ivIslandHeaderIcon.setImageResource(R.drawable.ic_phone_dialer);
            ivIslandHeaderIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#34C759")));
        }
        if (tvIslandHeaderLabel != null) {
            if (pCall.isOngoing) {
                tvIslandHeaderLabel.setText("CONNECTED CALL");
            } else if (pCall.isOutgoing) {
                tvIslandHeaderLabel.setText("OUTGOING CALL");
            } else {
                tvIslandHeaderLabel.setText("INCOMING CALL");
            }
        }

        if (tvCallerAvatarInitials != null) {
            tvCallerAvatarInitials.setText(pCall.getInitials());
        }
        if (tvCallerName != null) {
            tvCallerName.setText(name);
        }
        if (tvCallSubtitle != null) {
            tvCallSubtitle.setText(pCall.isOutgoing && !pCall.isOngoing ? "Calling..." : number);
        }
        if (layoutExpandedEqualizer != null) {
            layoutExpandedEqualizer.setVisibility(pCall.isOngoing ? View.VISIBLE : View.GONE);
        }

        // Action Buttons: Receive and Decline
        // When outgoing call is ringing/dialing or no answer action exists, never show Receive button! Only show End Call!
        boolean canAnswerPhone = pCall.isRinging && !pCall.isOutgoing && (pCall.answerIntent != null || StudyFocusNotificationManager.hasPhonePermissions(context));
        if (containerAnswerBtn != null) {
            containerAnswerBtn.setVisibility(canAnswerPhone ? View.VISIBLE : View.GONE);
        }
        if (tvAnswerCallLabel != null) {
            tvAnswerCallLabel.setText("Receive");
        }
        View.OnClickListener answerPhoneListener = v -> {
            StudyFocusNotificationManager.answerPhoneCall(context);
            pCall.isRinging = false;
            pCall.isOngoing = true;
            if (callConnectedTimestamp == 0) callConnectedTimestamp = System.currentTimeMillis();
            bindPhoneCallState(pCall);
            updateTimeDisplay();
        };
        if (btnAnswerCall != null) {
            btnAnswerCall.setOnClickListener(answerPhoneListener);
        }
        if (containerAnswerBtn != null) {
            containerAnswerBtn.setOnClickListener(answerPhoneListener);
        }

        if (containerDeclineBtn != null) {
            containerDeclineBtn.setVisibility(View.VISIBLE);
        }
        if (tvDeclineCallLabel != null) {
            tvDeclineCallLabel.setText(pCall.isRinging && !pCall.isOutgoing ? "Decline" : "End Call");
        }
        View.OnClickListener declinePhoneListener = v -> {
            StudyFocusNotificationManager.declinePhoneCall(context);
            callConnectedTimestamp = 0;
            collapseIsland();
        };
        if (btnDeclineCall != null) {
            btnDeclineCall.setOnClickListener(declinePhoneListener);
        }
        if (containerDeclineBtn != null) {
            containerDeclineBtn.setOnClickListener(declinePhoneListener);
        }

        // Mute & Speaker Controls (Active during ongoing call)
        if (containerMuteBtn != null) {
            containerMuteBtn.setVisibility(pCall.isOngoing ? View.VISIBLE : View.GONE);
        }
        if (containerSpeakerBtn != null) {
            containerSpeakerBtn.setVisibility(pCall.isOngoing ? View.VISIBLE : View.GONE);
        }

        if (pCall.isOngoing) {
            updateMuteButtonUI(StudyFocusNotificationManager.isMicrophoneMute(context));
            updateSpeakerButtonUI(StudyFocusNotificationManager.isSpeakerphoneOn(context));

            View.OnClickListener muteListener = v -> {
                boolean muted = StudyFocusNotificationManager.toggleMicrophoneMute(context);
                updateMuteButtonUI(muted);
            };
            if (btnMuteCall != null) btnMuteCall.setOnClickListener(muteListener);
            if (containerMuteBtn != null) containerMuteBtn.setOnClickListener(muteListener);

            View.OnClickListener speakerListener = v -> {
                boolean speaker = StudyFocusNotificationManager.toggleSpeakerphone(context);
                updateSpeakerButtonUI(speaker);
            };
            if (btnSpeakerCall != null) btnSpeakerCall.setOnClickListener(speakerListener);
            if (containerSpeakerBtn != null) containerSpeakerBtn.setOnClickListener(speakerListener);
        }

        if (btnOpenCallApp != null) {
            btnOpenCallApp.setVisibility(pCall.isOngoing ? View.VISIBLE : View.GONE);
            btnOpenCallApp.setText("Return to Call");
            btnOpenCallApp.setOnClickListener(v -> {
                StudyFocusNotificationManager.returnToPhoneCall(context);
                collapseIsland();
            });
        }
    }

    private void bindWhatsAppCallState(StudyFocusNotificationManager.WhatsAppCallInfo wCall) {
        String name = !TextUtils.isEmpty(wCall.callerName) ? wCall.callerName : "WhatsApp Call";
        String type = !TextUtils.isEmpty(wCall.callType) ? wCall.callType : "WhatsApp Audio";

        // Compact State
        if (ivCompactIcon != null) {
            ivCompactIcon.setImageResource(R.drawable.ic_whatsapp);
            ivCompactIcon.setImageTintList(null); // Authentic WhatsApp green bubble + white handset
        }
        if (viewCompactPulseDot != null) {
            viewCompactPulseDot.setVisibility(wCall.isRinging && !wCall.isOutgoing ? View.VISIBLE : View.GONE);
        }
        if (tvCompactTitle != null) {
            tvCompactTitle.setText(name);
        }
        if (layoutCompactEqualizer != null) {
            layoutCompactEqualizer.setVisibility(wCall.isOngoing ? View.VISIBLE : View.GONE);
        }
        if (ivCompactTorchFan != null) {
            ivCompactTorchFan.setVisibility(View.GONE);
        }

        // Expanded State
        isShowingTorchState = false;
        if (layoutExpandedCallView != null) layoutExpandedCallView.setVisibility(View.VISIBLE);
        if (layoutExpandedMessageView != null) layoutExpandedMessageView.setVisibility(View.GONE);
        if (layoutExpandedIdleView != null) layoutExpandedIdleView.setVisibility(View.GONE);
        if (layoutExpandedTorchView != null) layoutExpandedTorchView.setVisibility(View.GONE);

        if (ivIslandHeaderIcon != null) {
            ivIslandHeaderIcon.setImageResource(R.drawable.ic_whatsapp);
            ivIslandHeaderIcon.setImageTintList(null); // Authentic WhatsApp logo
        }
        if (tvIslandHeaderLabel != null) {
            if (wCall.isOngoing) {
                tvIslandHeaderLabel.setText("WHATSAPP CONNECTED");
            } else if (wCall.isOutgoing) {
                tvIslandHeaderLabel.setText("WHATSAPP CALLING");
            } else {
                tvIslandHeaderLabel.setText("WHATSAPP CALL");
            }
        }

        if (tvCallerAvatarInitials != null) {
            tvCallerAvatarInitials.setText(wCall.getInitials());
        }
        if (tvCallerName != null) {
            tvCallerName.setText(name);
        }
        if (tvCallSubtitle != null) {
            tvCallSubtitle.setText(wCall.isOutgoing && !wCall.isOngoing ? "Calling..." : type);
        }
        if (layoutExpandedEqualizer != null) {
            layoutExpandedEqualizer.setVisibility(wCall.isOngoing ? View.VISIBLE : View.GONE);
        }

        // Action buttons
        // When outgoing call is ringing/dialing or no answer action exists, never show Receive button! Only show End Call!
        boolean canAnswerWA = wCall.isRinging && !wCall.isOutgoing && (wCall.answerIntent != null);
        if (containerAnswerBtn != null) {
            containerAnswerBtn.setVisibility(canAnswerWA ? View.VISIBLE : View.GONE);
        }
        if (tvAnswerCallLabel != null) {
            tvAnswerCallLabel.setText("Receive");
        }
        View.OnClickListener answerWAListener = v -> {
            StudyFocusNotificationManager.answerWhatsAppCall(context);
            wCall.isRinging = false;
            wCall.isOngoing = true;
            if (callConnectedTimestamp == 0) callConnectedTimestamp = System.currentTimeMillis();
            bindWhatsAppCallState(wCall);
            updateTimeDisplay();
        };
        if (btnAnswerCall != null) {
            btnAnswerCall.setOnClickListener(answerWAListener);
        }
        if (containerAnswerBtn != null) {
            containerAnswerBtn.setOnClickListener(answerWAListener);
        }

        if (containerDeclineBtn != null) {
            containerDeclineBtn.setVisibility(View.VISIBLE);
        }
        if (tvDeclineCallLabel != null) {
            tvDeclineCallLabel.setText(wCall.isRinging && !wCall.isOutgoing ? "Decline" : "End Call");
        }
        View.OnClickListener declineWAListener = v -> {
            StudyFocusNotificationManager.declineWhatsAppCall(context);
            callConnectedTimestamp = 0;
            collapseIsland();
        };
        if (btnDeclineCall != null) {
            btnDeclineCall.setOnClickListener(declineWAListener);
        }
        if (containerDeclineBtn != null) {
            containerDeclineBtn.setOnClickListener(declineWAListener);
        }

        // Mute & Speaker Controls (Active during ongoing call)
        if (containerMuteBtn != null) {
            containerMuteBtn.setVisibility(wCall.isOngoing ? View.VISIBLE : View.GONE);
        }
        if (containerSpeakerBtn != null) {
            containerSpeakerBtn.setVisibility(wCall.isOngoing ? View.VISIBLE : View.GONE);
        }

        if (wCall.isOngoing) {
            updateMuteButtonUI(StudyFocusNotificationManager.isMicrophoneMute(context));
            updateSpeakerButtonUI(StudyFocusNotificationManager.isSpeakerphoneOn(context));

            View.OnClickListener muteListener = v -> {
                boolean muted = StudyFocusNotificationManager.toggleMicrophoneMute(context);
                updateMuteButtonUI(muted);
            };
            if (btnMuteCall != null) btnMuteCall.setOnClickListener(muteListener);
            if (containerMuteBtn != null) containerMuteBtn.setOnClickListener(muteListener);

            View.OnClickListener speakerListener = v -> {
                boolean speaker = StudyFocusNotificationManager.toggleSpeakerphone(context);
                updateSpeakerButtonUI(speaker);
            };
            if (btnSpeakerCall != null) btnSpeakerCall.setOnClickListener(speakerListener);
            if (containerSpeakerBtn != null) containerSpeakerBtn.setOnClickListener(speakerListener);
        }

        if (btnOpenCallApp != null) {
            btnOpenCallApp.setVisibility(wCall.isOngoing ? View.VISIBLE : View.GONE);
            btnOpenCallApp.setText("Return to Call");
            btnOpenCallApp.setOnClickListener(v -> {
                StudyFocusNotificationManager.returnToWhatsAppCall(context);
                collapseIsland();
            });
        }
    }

    private void bindMessageState(List<StudyFocusNotificationManager.FocusMessageItem> messages) {
        if (messages.isEmpty()) return;
        if (currentMessageIndex >= messages.size()) currentMessageIndex = 0;
        StudyFocusNotificationManager.FocusMessageItem msg = messages.get(currentMessageIndex);

        boolean isWA = msg.isWhatsApp();

        // Compact State
        if (ivCompactIcon != null) {
            ivCompactIcon.setImageResource(isWA ? R.drawable.ic_whatsapp : R.drawable.ic_messages_sms);
            ivCompactIcon.setImageTintList(ColorStateList.valueOf(isWA ? Color.parseColor("#25D366") : Color.parseColor("#38BDF8")));
        }
        if (viewCompactPulseDot != null) viewCompactPulseDot.setVisibility(View.GONE);
        if (tvCompactTitle != null) {
            tvCompactTitle.setText(msg.sender + ": " + msg.message);
        }
        if (layoutCompactEqualizer != null) layoutCompactEqualizer.setVisibility(View.GONE);
        if (ivCompactTorchFan != null) ivCompactTorchFan.setVisibility(View.GONE);

        // Expanded State
        isShowingTorchState = false;
        if (layoutExpandedCallView != null) layoutExpandedCallView.setVisibility(View.GONE);
        if (layoutExpandedMessageView != null) layoutExpandedMessageView.setVisibility(View.VISIBLE);
        if (layoutExpandedIdleView != null) layoutExpandedIdleView.setVisibility(View.GONE);
        if (layoutExpandedTorchView != null) layoutExpandedTorchView.setVisibility(View.GONE);

        if (ivIslandHeaderIcon != null) {
            ivIslandHeaderIcon.setImageResource(isWA ? R.drawable.ic_whatsapp : R.drawable.ic_messages_sms);
            ivIslandHeaderIcon.setImageTintList(ColorStateList.valueOf(isWA ? Color.parseColor("#25D366") : Color.parseColor("#38BDF8")));
        }
        if (tvIslandHeaderLabel != null) {
            tvIslandHeaderLabel.setText(isWA ? "WHATSAPP MESSAGE" : "CONTACT SMS");
        }

        if (tvMsgAvatarInitials != null) {
            tvMsgAvatarInitials.setText(msg.getInitials());
        }
        if (tvMsgSenderName != null) {
            tvMsgSenderName.setText(msg.sender);
        }
        if (tvMsgBody != null) {
            tvMsgBody.setText(msg.message);
        }

        if (btnOpenMessage != null) {
            btnOpenMessage.setText(isWA ? "Open in WhatsApp" : "Open in Messages");
            btnOpenMessage.setTextColor(Color.parseColor(isWA ? "#25D366" : "#38BDF8"));
            btnOpenMessage.setOnClickListener(v -> {
                StudyFocusNotificationManager.openMessageItem(context, msg);
                collapseIsland();
            });
        }

        if (btnNextMessage != null) {
            if (messages.size() > 1) {
                btnNextMessage.setVisibility(View.VISIBLE);
                btnNextMessage.setText("Next (" + (currentMessageIndex + 1) + "/" + messages.size() + ") ›");
                btnNextMessage.setOnClickListener(v -> {
                    currentMessageIndex = (currentMessageIndex + 1) % messages.size();
                    refreshData();
                });
            } else {
                btnNextMessage.setVisibility(View.GONE);
            }
        }

        // Slide / Swipe to Dismiss Gesture for current expanded message card
        if (layoutExpandedMessageView != null) {
            layoutExpandedMessageView.setTranslationX(0f);
            layoutExpandedMessageView.setAlpha(1f);

            final float[] msgDownX = new float[]{0f};
            final float[] msgDownY = new float[]{0f};
            final boolean[] isMsgSwiping = new boolean[]{false};

            layoutExpandedMessageView.setOnTouchListener((v, event) -> {
                gestureDetector.onTouchEvent(event);
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        msgDownX[0] = event.getRawX();
                        msgDownY[0] = event.getRawY();
                        isMsgSwiping[0] = false;
                        return false;

                    case MotionEvent.ACTION_MOVE:
                        float diffX = event.getRawX() - msgDownX[0];
                        float diffY = event.getRawY() - msgDownY[0];

                        if (!isMsgSwiping[0] && Math.abs(diffX) > dpToPx(10) && Math.abs(diffX) > Math.abs(diffY)) {
                            isMsgSwiping[0] = true;
                            if (v.getParent() != null) {
                                v.getParent().requestDisallowInterceptTouchEvent(true);
                            }
                        }

                        if (isMsgSwiping[0]) {
                            layoutExpandedMessageView.setTranslationX(diffX);
                            float cardW = layoutExpandedMessageView.getWidth() > 0 ? layoutExpandedMessageView.getWidth() : dpToPx(300);
                            float progress = Math.min(0.85f, Math.abs(diffX) / cardW);
                            layoutExpandedMessageView.setAlpha(1.0f - progress);
                            return true;
                        }
                        break;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (isMsgSwiping[0]) {
                            isMsgSwiping[0] = false;
                            float totalDiffX = event.getRawX() - msgDownX[0];
                            float dismissThreshold = dpToPx(48);

                            if (Math.abs(totalDiffX) > dismissThreshold) {
                                float cardW = layoutExpandedMessageView.getWidth() > 0 ? layoutExpandedMessageView.getWidth() : dpToPx(300);
                                float exitTarget = (totalDiffX > 0 ? 1 : -1) * (cardW + dpToPx(60));
                                layoutExpandedMessageView.animate()
                                        .translationX(exitTarget)
                                        .alpha(0f)
                                        .setDuration(180)
                                        .setInterpolator(new AccelerateDecelerateInterpolator())
                                        .withEndAction(() -> {
                                            layoutExpandedMessageView.setTranslationX(0f);
                                            layoutExpandedMessageView.setAlpha(1f);
                                            try {
                                                v.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK);
                                            } catch (Exception ignored) {}
                                            StudyFocusNotificationManager.removeMessageItem(msg.key);
                                        })
                                        .start();
                            } else {
                                layoutExpandedMessageView.animate()
                                        .translationX(0f)
                                        .alpha(1f)
                                        .setDuration(220)
                                        .setInterpolator(new OvershootInterpolator(1.2f))
                                        .start();
                            }
                            return true;
                        }
                        break;
                }
                return false;
            });
        }
    }

    private void bindIdleState() {
        boolean hasListener = StudyFocusNotificationManager.isNotificationListenerEnabled(context);
        boolean hasPhone = StudyFocusNotificationManager.hasPhonePermissions(context);

        if (!hasListener || !hasPhone) {
            if (ivCompactIcon != null) {
                ivCompactIcon.setImageResource(R.drawable.ic_lightbulb);
                ivCompactIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#F59E0B")));
            }
            if (viewCompactPulseDot != null) {
                viewCompactPulseDot.setVisibility(View.VISIBLE);
                viewCompactPulseDot.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#F59E0B")));
            }
            if (tvCompactTitle != null) {
                tvCompactTitle.setText("Tap to Enable WhatsApp/Calls");
                tvCompactTitle.setTextColor(Color.parseColor("#FBBF24"));
            }
            if (layoutCompactEqualizer != null) layoutCompactEqualizer.setVisibility(View.GONE);
        } else {
            // Normal Compact State: Sleek Focus Pill with Real Clock Time
            if (ivCompactIcon != null) {
                ivCompactIcon.setImageResource(R.drawable.ic_book_gear);
                ivCompactIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#8B5CF6")));
            }
            if (viewCompactPulseDot != null) viewCompactPulseDot.setVisibility(View.GONE);
            if (tvCompactTitle != null) {
                tvCompactTitle.setText("Radhe Radhe");
                tvCompactTitle.setTextColor(Color.WHITE);
            }
            if (layoutCompactEqualizer != null) layoutCompactEqualizer.setVisibility(View.GONE);
        }

        // Compact State: ensure compact torch fan is hidden if torch is off
        if (ivCompactTorchFan != null) {
            ivCompactTorchFan.setVisibility(View.GONE);
        }
        if (tvCompactTime != null) {
            tvCompactTime.setVisibility(View.VISIBLE);
        }

        // Expanded State: Focus Quick Apps
        isShowingTorchState = false;
        if (layoutExpandedCallView != null) layoutExpandedCallView.setVisibility(View.GONE);
        if (layoutExpandedMessageView != null) layoutExpandedMessageView.setVisibility(View.GONE);
        if (layoutExpandedIdleView != null) layoutExpandedIdleView.setVisibility(View.VISIBLE);
        if (layoutExpandedTorchView != null) layoutExpandedTorchView.setVisibility(View.GONE);

        if (ivIslandHeaderIcon != null) {
            ivIslandHeaderIcon.setImageResource(R.drawable.ic_book_gear);
            ivIslandHeaderIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#8B5CF6")));
        }
        if (tvIslandHeaderLabel != null) {
            tvIslandHeaderLabel.setText("Radhe Radhe");
        }
    }

    private void bindTorchState() {
        isShowingTorchState = true;

        // Compact State: Sleek glowing flashlight indicator
        if (ivCompactIcon != null) {
            ivCompactIcon.setImageResource(R.drawable.ic_flashlight);
            ivCompactIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#F59E0B")));
        }
        if (viewCompactPulseDot != null) {
            viewCompactPulseDot.setVisibility(View.GONE);
        }
        if (tvCompactTitle != null) {
            tvCompactTitle.setText("Flashlight");
            tvCompactTitle.setTextColor(Color.parseColor("#FEF08A"));
        }
        if (ivCompactTorchFan != null) {
            ivCompactTorchFan.setVisibility(View.VISIBLE);
        }
        if (tvCompactTime != null) {
            tvCompactTime.setVisibility(View.GONE);
        }
        if (layoutCompactEqualizer != null) {
            layoutCompactEqualizer.setVisibility(View.GONE);
        }

        // Expanded State: iOS 18 Flashlight Light Beam Fan
        if (layoutExpandedCallView != null) layoutExpandedCallView.setVisibility(View.GONE);
        if (layoutExpandedMessageView != null) layoutExpandedMessageView.setVisibility(View.GONE);
        if (layoutExpandedIdleView != null) layoutExpandedIdleView.setVisibility(View.GONE);
        if (layoutExpandedTorchView != null) layoutExpandedTorchView.setVisibility(View.VISIBLE);

        if (ivIslandHeaderIcon != null) {
            ivIslandHeaderIcon.setImageResource(R.drawable.ic_flashlight);
            ivIslandHeaderIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#F59E0B")));
        }
        if (tvIslandHeaderLabel != null) {
            tvIslandHeaderLabel.setText("FLASHLIGHT");
        }
    }

    private void performIosDropdownJolt() {
        if (layoutDynamicIslandPill == null) return;
        try {
            layoutDynamicIslandPill.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        } catch (Exception ignored) {}

        layoutDynamicIslandPill.animate()
                .translationY(dpToPx(14))
                .scaleX(1.02f)
                .scaleY(1.02f)
                .setDuration(120)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> {
                    if (layoutDynamicIslandPill != null) {
                        layoutDynamicIslandPill.animate()
                                .translationY(0f)
                                .scaleX(1.0f)
                                .scaleY(1.0f)
                                .setDuration(240)
                                .setInterpolator(new OvershootInterpolator(1.8f))
                                .start();
                    }
                })
                .start();
    }

    @Override
    public void onTorchStateChanged(boolean isTorchOn) {
        this.isTorchActive = isTorchOn;
        mainHandler.post(() -> {
            if (isTorchOn) {
                if (!isExpanded) {
                    expandIsland();
                    mainHandler.removeCallbacks(autoCollapseMessageRunnable);
                    mainHandler.postDelayed(autoCollapseMessageRunnable, 3500);
                }
            } else {
                if (isExpanded && isShowingTorchState) {
                    collapseIsland();
                }
            }
            refreshData();
        });
    }

    @Override
    public void onFocusDataChanged() {
        refreshData();
    }

    public void onDestroy() {
        StudyFocusNotificationManager.unregisterListener(this);
        StudyTorchManager.getInstance(context).removeListener(this);
        mainHandler.removeCallbacks(autoCollapseMessageRunnable);
        mainHandler.removeCallbacks(callEndStage1Runnable);
        mainHandler.removeCallbacks(callEndStage2Runnable);
        mainHandler.removeCallbacks(autoHideRunnable);
        if (timeTickerRunnable != null) {
            mainHandler.removeCallbacks(timeTickerRunnable);
            timeTickerRunnable = null;
        }
        if (morphAnimator != null) {
            morphAnimator.cancel();
            morphAnimator = null;
        }
        if (equalizerAnimator != null) {
            equalizerAnimator.cancel();
            equalizerAnimator = null;
        }
    }

    private float dpToPx(float dp) {
        if (context == null) return dp;
        return dp * context.getResources().getDisplayMetrics().density;
    }
}
